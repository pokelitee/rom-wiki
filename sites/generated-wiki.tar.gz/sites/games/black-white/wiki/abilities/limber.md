# Limber

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>7</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">9</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents paralysis.</strong></p>
<p>This Pokémon cannot be paralyzed. If a Pokémon is paralyzed and acquires this ability, its paralysis is healed; this includes when regaining a lost ability upon leaving battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected from paralysis.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/53.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Persian](../pokemon/persian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/106.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonlee](../pokemon/hitmonlee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/427.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buneary](../pokemon/buneary.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/428.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lopunny](../pokemon/lopunny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/431.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glameow](../pokemon/glameow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/509.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purrloin](../pokemon/purrloin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/510.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Liepard](../pokemon/liepard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/7/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rock-head/"><span class="rw-record-nav__label">← Rock Head</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../drought/"><span class="rw-record-nav__label">Drought →</span></a>
</nav>
