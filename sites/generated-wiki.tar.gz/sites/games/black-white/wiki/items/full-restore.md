# Full Restore

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="Full Restore icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>23</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full and cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Restores HP to full and cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A medicine that fully restores the HP and heals any status problems of a single Pokémon.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x0c</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Desert Resort](../locations/header-158.md) | Visible | (72, 56) |
| [Opelucid City](../locations/header-293.md) | Hidden | (439, 173) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Socialite Elizandra](../trainers/trainer-0210.md) | AI battle item |
| [Gentleman Cassandra](../trainers/trainer-0211.md) | AI battle item |
| [Elite Four Grunt](../trainers/trainer-0228.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0229.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0230.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0231.md) | AI battle item |
| [Team Plasma Caitlin](../trainers/trainer-0232.md) | AI battle item |
| [Socialite Anthony](../trainers/trainer-0369.md) | AI battle item |
| [Gentleman Emilia](../trainers/trainer-0370.md) | AI battle item |
| [Champion Ingo](../trainers/trainer-0407.md) | AI battle item |
| [Gentleman Tommy](../trainers/trainer-0425.md) | AI battle item |
| [Socialite Yan](../trainers/trainer-0426.md) | AI battle item |
| [Gentleman Collin](../trainers/trainer-0472.md) | AI battle item |
| [Socialite Ralph](../trainers/trainer-0488.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0494.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0495.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0496.md) | AI battle item |
| [Team Plasma Bianca](../trainers/trainer-0497.md) | AI battle item |
| [GAME FREAK Cheren](../trainers/trainer-0542.md) | AI battle item |
| [Elite Four](../trainers/trainer-0563.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0564.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0565.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0566.md) | AI battle item |
| [⒆⒇ Trainer Caitlin](../trainers/trainer-0567.md) | AI battle item |
| [Team Plasma Mariah](../trainers/trainer-0586.md) | AI battle item |
| [Team Plasma N](../trainers/trainer-0587.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0594.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0595.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0596.md) | AI battle item |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `23` |

Source: exact ROM record from `a/0/2/4` member `23`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/23/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../everstone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/everstone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Everstone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../focus-band/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-band.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Focus Band →</span></a>
</nav>
