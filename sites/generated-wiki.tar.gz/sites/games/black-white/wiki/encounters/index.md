# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City](area-000.md)
- [Driftveil City](area-001.md)
- [Icirrus City](area-002.md)
- [Icirrus City](area-003.md)
- [Icirrus City](area-004.md)
- [Icirrus City](area-005.md)
- [Dreamyard](area-006.md)
- [Dreamyard](area-007.md)
- [Pinwheel Forest](area-008.md)
- [Pinwheel Forest](area-009.md)
- [Desert Resort](area-010.md)
- [Desert Resort](area-011.md)
- [Relic Castle](area-012.md)
- [Relic Castle](area-013.md)
- [Relic Castle](area-014.md)
- [Relic Castle](area-015.md)
- [Relic Castle](area-016.md)
- [Relic Castle](area-017.md)
- [Relic Castle](area-018.md)
- [Relic Castle](area-019.md)
- [Relic Castle](area-020.md)
- [Relic Castle](area-021.md)
- [Relic Castle](area-022.md)
- [Relic Castle](area-023.md)
- [Relic Castle](area-024.md)
- [Relic Castle](area-025.md)
- [Relic Castle](area-026.md)
- [Relic Castle](area-027.md)
- [Relic Castle](area-028.md)
- [Relic Castle](area-029.md)
- [Relic Castle](area-030.md)
- [Relic Castle](area-031.md)
- [Relic Castle](area-032.md)
- [Relic Castle](area-033.md)
- [Relic Castle](area-034.md)
- [Relic Castle](area-035.md)
- [Relic Castle](area-036.md)
- [Relic Castle](area-037.md)
- [Relic Castle](area-038.md)
- [Relic Castle](area-039.md)
- [Relic Castle](area-040.md)
- [Relic Castle](area-041.md)
- [Relic Castle](area-042.md)
- [Cold Storage](area-043.md)
- [Chargestone Cave](area-044.md)
- [Chargestone Cave](area-045.md)
- [Chargestone Cave](area-046.md)
- [Twist Mountain](area-047.md)
- [Twist Mountain](area-048.md)
- [Twist Mountain](area-049.md)
- [Twist Mountain](area-050.md)
- [Twist Mountain](area-051.md)
- [Twist Mountain](area-052.md)
- [Twist Mountain](area-053.md)
- [Twist Mountain](area-054.md)
- [Twist Mountain](area-055.md)
- [Twist Mountain](area-056.md)
- [Twist Mountain](area-057.md)
- [Twist Mountain](area-058.md)
- [Twist Mountain](area-059.md)
- [Twist Mountain](area-060.md)
- [Twist Mountain](area-061.md)
- [Twist Mountain](area-062.md)
- [Dragonspiral Tower](area-063.md)
- [Dragonspiral Tower](area-064.md)
- [Dragonspiral Tower](area-065.md)
- [Dragonspiral Tower](area-066.md)
- [Dragonspiral Tower](area-067.md)
- [Dragonspiral Tower](area-068.md)
- [Dragonspiral Tower](area-069.md)
- [Dragonspiral Tower](area-070.md)
- [Dragonspiral Tower](area-071.md)
- [Dragonspiral Tower](area-072.md)
- [Victory Road](area-073.md)
- [Victory Road](area-074.md)
- [Victory Road](area-075.md)
- [Victory Road](area-076.md)
- [Victory Road](area-077.md)
- [Victory Road](area-078.md)
- [Victory Road](area-079.md)
- [Victory Road](area-080.md)
- [Victory Road](area-081.md)
- [Victory Road](area-082.md)
- [Victory Road](area-083.md)
- [Victory Road](area-084.md)
- [Victory Road](area-085.md)
- [Victory Road](area-086.md)
- [Victory Road](area-087.md)
- [Trial Chamber](area-088.md)
- [Giant Chasm](area-089.md)
- [Giant Chasm](area-090.md)
- [Giant Chasm](area-091.md)
- [Giant Chasm](area-092.md)
- [P2 Laboratory](area-093.md)
- [Undella Bay](area-094.md)
- [Undella Bay](area-095.md)
- [Undella Bay](area-096.md)
- [Undella Bay](area-097.md)
- [Driftveil Drawbridge](area-098.md)
- [Village Bridge](area-099.md)
- [Marvelous Bridge](area-100.md)
- [Route 1](area-101.md)
- [Route 2](area-102.md)
- [Route 3](area-103.md)
- [Wellspring Cave](area-104.md)
- [Wellspring Cave](area-105.md)
- [Route 4](area-106.md)
- [Route 5](area-107.md)
- [Route 6](area-108.md)
- [Route 6](area-109.md)
- [Route 6](area-110.md)
- [Route 6](area-111.md)
- [Mistralton Cave](area-112.md)
- [Mistralton Cave](area-113.md)
- [Guidance Chamber](area-114.md)
- [Route 7](area-115.md)
- [Route 7](area-116.md)
- [Route 7](area-117.md)
- [Route 7](area-118.md)
- [Celestial Tower](area-119.md)
- [Celestial Tower](area-120.md)
- [Celestial Tower](area-121.md)
- [Celestial Tower](area-122.md)
- [Route 8](area-123.md)
- [Route 8](area-124.md)
- [Route 8](area-125.md)
- [Route 8](area-126.md)
- [Moor of Icirrus](area-127.md)
- [Moor of Icirrus](area-128.md)
- [Moor of Icirrus](area-129.md)
- [Moor of Icirrus](area-130.md)
- [Route 9](area-131.md)
- [Challenger's Cave](area-132.md)
- [Challenger's Cave](area-133.md)
- [Challenger's Cave](area-134.md)
- [Route 10](area-135.md)
- [Route 10](area-136.md)
- [Route 11](area-137.md)
- [Route 12](area-138.md)
- [Route 13](area-139.md)
- [Route 14](area-140.md)
- [Abundant Shrine](area-141.md)
- [Route 15](area-142.md)
- [Route 16](area-143.md)
- [Lostlorn Forest](area-144.md)
- [Route 18](area-145.md)
- [Undella Town](area-146.md)
- [Route 17](area-147.md)

</div>
