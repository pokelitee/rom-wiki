# Route 17

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>147</dd></div>
<div><dt>Map index</dt><dd>111</dd></div>
<div><dt>Methods</dt><dd>Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
</dl>
</section>

## Surfing

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/592.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Frillish](../pokemon/frillish-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 5–15 | 100% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/594.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alomomola](../pokemon/alomomola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–20 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/593.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jellicent](../pokemon/jellicent-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 5–20 | 5% |

## Fishing

Encounter rate: 80

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 35% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/211.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/457.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lumineon](../pokemon/lumineon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/230.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingdra](../pokemon/kingdra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 45–70 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `111`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-146/"><span class="rw-record-nav__label">← Undella Town</span></a>
<span></span>
</nav>
