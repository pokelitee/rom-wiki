# Challenger's Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>134</dd></div>
<div><dt>Map index</dt><dd>98</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
</dl>
</section>

!!! info "Version differences"
    Encounter tables on this page differ between the two versions.

## Black

### Grass/Cave

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/302.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/108.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/303.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 50 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 49 | 1% |

### Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 47 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 49 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 50 | 20% |

### Surfing

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–55 | 100% |

### Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–70 | 100% |

### Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 5% |

### Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/62.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwrath](../pokemon/poliwrath.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 45–70 | 5% |

## White

### Grass/Cave

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/302.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/108.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/303.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 49 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 50 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 49 | 1% |

### Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 47 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 49 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 50 | 20% |

### Surfing

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–55 | 100% |

### Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–70 | 100% |

### Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 5% |

### Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/62.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwrath](../pokemon/poliwrath.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 45–70 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `98`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-133/"><span class="rw-record-nav__label">← Challenger&#x27;s Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-135/"><span class="rw-record-nav__label">Route 10 →</span></a>
</nav>
