# P2 Laboratory

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>93</dd></div>
<div><dt>Map index</dt><dd>72</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
</dl>
</section>

## Grass/Cave

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/507.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Herdier](../pokemon/herdier.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/507.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Herdier](../pokemon/herdier.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/599.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klink](../pokemon/klink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/559.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scraggy](../pokemon/scraggy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/507.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Herdier](../pokemon/herdier.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/599.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klink](../pokemon/klink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 31 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/559.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scraggy](../pokemon/scraggy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 31 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 1% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/507.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Herdier](../pokemon/herdier.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 1% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/508.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stoutland](../pokemon/stoutland.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 5% |

## Surfing

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/592.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Frillish](../pokemon/frillish-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 5–15 | 100% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/594.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alomomola](../pokemon/alomomola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–20 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/593.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jellicent](../pokemon/jellicent-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 5–20 | 5% |

## Fishing

Encounter rate: 80

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 35% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/211.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/457.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lumineon](../pokemon/lumineon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/230.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingdra](../pokemon/kingdra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 45–70 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `72`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-092/"><span class="rw-record-nav__label">← Giant Chasm</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-094/"><span class="rw-record-nav__label">Undella Bay →</span></a>
</nav>
