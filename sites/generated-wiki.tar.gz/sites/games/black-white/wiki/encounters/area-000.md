# Striaton City

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>0</dd></div>
<div><dt>Map index</dt><dd>0</dd></div>
<div><dt>Methods</dt><dd>Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
</dl>
</section>

## Surfing

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–15 | 100% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–20 | 100% |

## Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 70% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 30% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 45–70 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `0`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<span></span>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-001/"><span class="rw-record-nav__label">Driftveil City →</span></a>
</nav>
