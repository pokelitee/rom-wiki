# Route 7

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>118</dd></div>
<div><dt>Map index</dt><dd>88</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots</dd></div>
</dl>
</section>

## Grass/Cave

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 28 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 29 | 5% |

## Doubles Grass

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 30 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 30 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 5% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/587.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emolga](../pokemon/emolga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 30% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `88`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table and are cross-referenced to location pages by the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-088-autumn/"><span class="rw-record-nav__label">← Route 7</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-089/"><span class="rw-record-nav__label">Celestial Tower →</span></a>
</nav>
