# Victory Road

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>83</dd></div>
<div><dt>Map index</dt><dd>62</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots</dd></div>
</dl>
</section>

## Grass/Cave

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 39 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 39 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 40 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 41 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/619.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienfoo](../pokemon/mienfoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 41 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 41 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 42 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 42 | 1% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 39 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 41 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 42 | 20% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `62`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-082/"><span class="rw-record-nav__label">← Victory Road</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-084/"><span class="rw-record-nav__label">Victory Road →</span></a>
</nav>
