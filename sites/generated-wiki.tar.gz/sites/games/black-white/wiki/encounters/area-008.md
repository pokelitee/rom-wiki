# Pinwheel Forest

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>8</dd></div>
<div><dt>Map index</dt><dd>5</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots</dd></div>
</dl>
</section>

!!! info "Version differences"
    Encounter tables on this page differ between the two versions.

## Black

### Grass/Cave

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 12 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 14 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 12 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 15 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 5% |

### Doubles Grass

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 16 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 16 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 17 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 17 | 5% |

### Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 12 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 15 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 5% |

## White

### Grass/Cave

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 12 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 14 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 12 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 15 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 5% |

### Doubles Grass

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 16 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 16 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/535.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tympole](../pokemon/tympole.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 17 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 17 | 5% |

### Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 12 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 15 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 15 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `5`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names come from the ROM's own map header table (cross-referenced by wild-encounter-table index); the map headers themselves aren't cross-linked as their own pages yet — see the site's data sources page for why.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-007/"><span class="rw-record-nav__label">← Dreamyard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-009/"><span class="rw-record-nav__label">Pinwheel Forest →</span></a>
</nav>
