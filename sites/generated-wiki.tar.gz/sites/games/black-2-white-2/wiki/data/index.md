# Data downloads

These deterministic gzip files contain the complete normalized datasets used to build this wiki. They include ROM-derived facts and PokéDB reference data, but never ROM or patch bytes.

| Dataset | Download | Records | Schema |
| ------- | -------- | ------: | -----: |
| Abilities | [abilities.json.gz](abilities.json.gz) | 164 | 4 |
| Wild Encounters | [encounters.json.gz](encounters.json.gz) | 174 | 2 |
| Items | [items.json.gz](items.json.gz) | 618 | 8 |
| Locations | [locations.json.gz](locations.json.gz) | 615 | 10 |
| Moves | [moves.json.gz](moves.json.gz) | 560 | 1 |
| Pokemon | [pokemon.json.gz](pokemon.json.gz) | 709 | 2 |
| Trainers | [trainers.json.gz](trainers.json.gz) | 813 | 3 |
| Types | [types.json.gz](types.json.gz) | 17 | 2 |

File sizes and SHA-256 checksums are listed in [the machine-readable manifest](manifest.json).
