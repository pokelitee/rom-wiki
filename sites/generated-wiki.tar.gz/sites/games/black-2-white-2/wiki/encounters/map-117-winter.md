# Map 117 (Winter)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>153</dd></div>
<div><dt>Map index</dt><dd>117</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Moor of Icirrus](../locations/header-346.md) | 346 | Black 2 / White 2 |

## Surfing

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 45–60 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 50–60 | 10% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 45–60 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 50–60 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/537.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seismitoad](../pokemon/seismitoad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50–60 | 5% |

## Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 45–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50–60 | 10% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 45–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50–60 | 10% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `117`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-117-autumn/"><span class="rw-record-nav__label">← Map 117 (Autumn)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-118/"><span class="rw-record-nav__label">Map 118 →</span></a>
</nav>
