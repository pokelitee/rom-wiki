# Map 111 (Winter)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>141</dd></div>
<div><dt>Map index</dt><dd>111</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Route 7](../locations/header-337.md) | 337 | Black 2 / White 2 |

## Grass/Cave

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 30 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 30 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/520.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tranquill](../pokemon/tranquill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 30 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/335.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zangoose](../pokemon/zangoose.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/336.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seviper](../pokemon/seviper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 5% |

## Doubles Grass

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 33 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 33 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/520.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tranquill](../pokemon/tranquill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/335.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zangoose](../pokemon/zangoose.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/336.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seviper](../pokemon/seviper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 36 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 5% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/587.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emolga](../pokemon/emolga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 32 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 33 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/521.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unfezant](../pokemon/unfezant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 5% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `111`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-111-autumn/"><span class="rw-record-nav__label">← Map 111 (Autumn)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-112/"><span class="rw-record-nav__label">Map 112 →</span></a>
</nav>
