# Swarm

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>68</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">24</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Strengthens Bug moves to inflict 1.5× damage at 1/3 max HP or less.</strong></p>
<p>When this Pokémon has 1/3 or less of its HP remaining, its Bug-type moves inflict 1.5× as much regular damage. Overworld: If the lead Pokémon has this ability, the wild encounter rate is increased.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up Bug-type moves in a pinch.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ariados](../pokemon/ariados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Scizor](../pokemon/scizor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Volbeat](../pokemon/volbeat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kricketune](../pokemon/kricketune.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mothim](../pokemon/mothim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sewaddle](../pokemon/sewaddle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Leavanny](../pokemon/leavanny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Venipede](../pokemon/venipede.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whirlipede](../pokemon/whirlipede.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Scolipede](../pokemon/scolipede.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Karrablast](../pokemon/karrablast.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Escavalier](../pokemon/escavalier.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Joltik](../pokemon/joltik.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Galvantula](../pokemon/galvantula.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Larvesta](../pokemon/larvesta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Volcarona](../pokemon/volcarona.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/68/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../torrent/"><span class="rw-record-nav__label">← Torrent</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rock-head/"><span class="rw-record-nav__label">Rock Head →</span></a>
</nav>
