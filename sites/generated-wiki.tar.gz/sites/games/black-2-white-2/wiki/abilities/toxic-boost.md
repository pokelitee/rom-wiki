# Toxic Boost

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>137</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases Attack to 1.5× when poisoned.</strong></p>
<p>This Pokémon has 1.5× its Attack when poisoned.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up physical attacks when poisoned.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zangoose](../pokemon/zangoose.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/137/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../multiscale/"><span class="rw-record-nav__label">← Multiscale</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../flare-boost/"><span class="rw-record-nav__label">Flare Boost →</span></a>
</nav>
