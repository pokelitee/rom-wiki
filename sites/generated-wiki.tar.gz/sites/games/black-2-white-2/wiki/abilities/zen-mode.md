# Zen Mode

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>161</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Changes Darmanitan&#x27;s form after each turn depending on its HP: Zen Mode below 50% max HP, and Standard Mode otherwise.</strong></p>
<p>This Pokémon switches between Standard Mode and Zen Mode after each turn depending on its HP. Below 50% of its maximum HP, it switches to Zen Mode, and at 50% or above, it switches to Standard Mode. This Pokémon returns to Standard Mode upon leaving battle or losing this ability. This ability has no effect if this Pokémon is not a Darmanitan.</p>

<figure class="rw-pokedex-entry">
<blockquote>Changes the Pokémon’s shape when HP is halved.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Darmanitan](../pokemon/darmanitan-standard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/161/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../iron-barbs/"><span class="rw-record-nav__label">← Iron Barbs</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../victory-star/"><span class="rw-record-nav__label">Victory Star →</span></a>
</nav>
