# Undella Bay

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>97</dd></div>
<div><dt>Map index</dt><dd>73</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Undella Bay](../locations/header-240.md) | 240 | Black / White |

## Surfing

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/278.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wingull](../pokemon/wingull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–55 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 25–55 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/279.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pelipper](../pokemon/pelipper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–55 | 10% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/320.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailmer](../pokemon/wailmer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 25–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/321.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailord](../pokemon/wailord.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/365.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Walrein](../pokemon/walrein.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |

## Fishing

Encounter rate: 80

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–55 | 5% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/224.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/91.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cloyster](../pokemon/cloyster.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 45–70 | 5% |

## Same-name encounter areas

These encounter tables resolve to the same map-header display name. A shared map index identifies seasonal variants; a shared name alone does not establish that two maps are the same area.

| Map index | Season | Relationship | Encounter table |
| --------: | ------ | ------------ | --------------- |
| 73 | Spring | Seasonal variant | [Map 073 (Spring)](map-073-spring.md) |
| 73 | Summer | Seasonal variant | [Map 073 (Summer)](map-073-summer.md) |
| 73 | Autumn | Seasonal variant | [Map 073 (Autumn)](map-073-autumn.md) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `73`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-073-autumn/"><span class="rw-record-nav__label">← Undella Bay</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-074/"><span class="rw-record-nav__label">Driftveil Drawbridge →</span></a>
</nav>
