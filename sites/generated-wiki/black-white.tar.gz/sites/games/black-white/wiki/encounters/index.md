# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City](map-000.md)
- [Driftveil City](map-001.md)
- [Icirrus City](map-002.md)
- [Dreamyard](map-003.md)
- [Dreamyard](map-004.md)
- [Pinwheel Forest](map-005.md)
- [Pinwheel Forest](map-006.md)
- [Desert Resort](map-007.md)
- [Desert Resort](map-008.md)
- [Relic Castle](map-009.md)
- [Relic Castle](map-010.md)
- [Relic Castle](map-011.md)
- [Relic Castle](map-012.md)
- [Relic Castle](map-013.md)
- [Relic Castle](map-014.md)
- [Relic Castle](map-015.md)
- [Relic Castle](map-016.md)
- [Relic Castle](map-017.md)
- [Relic Castle](map-018.md)
- [Relic Castle](map-019.md)
- [Relic Castle](map-020.md)
- [Relic Castle](map-021.md)
- [Relic Castle](map-022.md)
- [Relic Castle](map-023.md)
- [Relic Castle](map-024.md)
- [Relic Castle](map-025.md)
- [Relic Castle](map-026.md)
- [Relic Castle](map-027.md)
- [Relic Castle](map-028.md)
- [Relic Castle](map-029.md)
- [Relic Castle](map-030.md)
- [Relic Castle](map-031.md)
- [Relic Castle](map-032.md)
- [Relic Castle](map-033.md)
- [Relic Castle](map-034.md)
- [Relic Castle](map-035.md)
- [Relic Castle](map-036.md)
- [Relic Castle](map-037.md)
- [Relic Castle](map-038.md)
- [Relic Castle](map-039.md)
- [Cold Storage](map-040.md)
- [Chargestone Cave](map-041.md)
- [Chargestone Cave](map-042.md)
- [Chargestone Cave](map-043.md)
- [Twist Mountain](map-044.md)
- [Twist Mountain](map-045.md)
- [Twist Mountain](map-046.md)
- [Twist Mountain](map-047.md)
- [Dragonspiral Tower](map-048.md)
- [Dragonspiral Tower](map-049.md)
- [Dragonspiral Tower](map-050.md)
- [Dragonspiral Tower](map-051.md)
- [Victory Road](map-052.md)
- [Victory Road](map-053.md)
- [Victory Road](map-054.md)
- [Victory Road](map-055.md)
- [Victory Road](map-056.md)
- [Victory Road](map-057.md)
- [Victory Road](map-058.md)
- [Victory Road](map-059.md)
- [Victory Road](map-060.md)
- [Victory Road](map-061.md)
- [Victory Road](map-062.md)
- [Victory Road](map-063.md)
- [Victory Road](map-064.md)
- [Victory Road](map-065.md)
- [Victory Road](map-066.md)
- [Trial Chamber](map-067.md)
- [Giant Chasm](map-068.md)
- [Giant Chasm](map-069.md)
- [Giant Chasm](map-070.md)
- [Giant Chasm](map-071.md)
- [P2 Laboratory](map-072.md)
- [Undella Bay](map-073.md)
- [Driftveil Drawbridge](map-074.md)
- [Village Bridge](map-075.md)
- [Marvelous Bridge](map-076.md)
- [Route 1](map-077.md)
- [Route 2](map-078.md)
- [Route 3](map-079.md)
- [Wellspring Cave](map-080.md)
- [Wellspring Cave](map-081.md)
- [Route 4](map-082.md)
- [Route 5](map-083.md)
- [Route 6](map-084.md)
- [Mistralton Cave](map-085.md)
- [Mistralton Cave](map-086.md)
- [Guidance Chamber](map-087.md)
- [Route 7](map-088.md)
- [Celestial Tower](map-089.md)
- [Celestial Tower](map-090.md)
- [Celestial Tower](map-091.md)
- [Celestial Tower](map-092.md)
- [Route 8](map-093.md)
- [Moor of Icirrus](map-094.md)
- [Route 9](map-095.md)
- [Challenger's Cave](map-096.md)
- [Challenger's Cave](map-097.md)
- [Challenger's Cave](map-098.md)
- [Route 10](map-099.md)
- [Route 10](map-100.md)
- [Route 11](map-101.md)
- [Route 12](map-102.md)
- [Route 13](map-103.md)
- [Route 14](map-104.md)
- [Abundant Shrine](map-105.md)
- [Route 15](map-106.md)
- [Route 16](map-107.md)
- [Lostlorn Forest](map-108.md)
- [Route 18](map-109.md)
- [Undella Town](map-110.md)
- [Route 17](map-111.md)

</div>
