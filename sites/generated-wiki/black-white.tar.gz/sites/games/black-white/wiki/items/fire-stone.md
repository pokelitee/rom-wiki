# Fire Stone

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="Fire Stone icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>82</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Evolves an Eevee into Flareon, a Growlithe into Arcanine, a Pansear into Simisear, or a Vulpix into Ninetales.</strong></p>
<p>Used on a party Pokémon : Evolves an Eevee into Flareon, a Growlithe into Arcanine, a Pansear into Simisear, or a Vulpix into Ninetales.</p>

<figure class="rw-pokedex-entry">
<blockquote>A peculiar stone that makes certain species of Pokémon evolve. It is colored orange.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Driftveil City](../locations/header-096.md) | Visible | (168, 395) |
| [Route 9](../locations/header-348.md) | Hidden | (359, 174) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | Black City resident market | ₽10,000 | Current resident: Vincent |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/38.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ninetales](../pokemon/ninetales.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/59.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arcanine](../pokemon/arcanine.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/136.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Flareon](../pokemon/flareon.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/513.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pansear](../pokemon/pansear.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/514.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Simisear](../pokemon/simisear.md)</span> | Use Item |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `82` |

Source: exact ROM record from `a/0/2/4` member `82`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/82/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../moon-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moon-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Moon Stone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../thunder-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Thunderstone →</span></a>
</nav>
