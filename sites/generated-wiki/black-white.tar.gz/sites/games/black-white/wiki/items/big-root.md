# Big Root

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-root.png" alt="Big Root icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>296</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases HP recovered from draining moves, Ingrain, and Aqua Ring by 3/10 (30%).</strong></p>
<p>Held: HP restored from Absorb, Aqua Ring, Drain Punch, Dream Eater, Giga Drain, Ingrain, Leech Life, Leech Seed, and Mega Drain is increased by 30%. Damage inflicted is not affected.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Pokémon held item that boosts the power of HP-stealing moves to let the holder recover more HP.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>124</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Visible | (50, 42) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/345.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lileep](../pokemon/lileep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--grass">Grass</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/346.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cradily](../pokemon/cradily.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--grass">Grass</span></span> | Rare |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `296` |

Source: exact ROM record from `a/0/2/4` member `296`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/273/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../shed-shell/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/shed-shell.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Shed Shell</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../choice-specs/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-specs.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Choice Specs →</span></a>
</nav>
