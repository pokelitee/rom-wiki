# Hyper Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="Hyper Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>25</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 200 HP.</strong></p>
<p>Used on a party Pokémon : Restores 200 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>HP amount 200</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Castelia City](../locations/header-045.md) | — | `header-045` | Visible | (2, 14) |
| [Dreamyard](../locations/header-152.md) | — | `header-152` | Visible | (38, 21) |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Visible | (62, 34) |
| [Desert Resort](../locations/header-158.md) | — | `header-158` | Hidden | (35, 28) |
| [Relic Castle](../locations/header-187.md) | — | `header-187` | Hidden | (14, 17) |
| [Cold Storage](../locations/header-192.md) | — | `header-192` | Visible | (12, 21) |
| [Chargestone Cave](../locations/header-197.md) | — | `header-197` | Visible | (20, 34) |
| [Twist Mountain](../locations/header-200.md) | — | `header-200` | Hidden | (44, 10) |
| [Dragonspiral Tower](../locations/header-209.md) | — | `header-209` | Visible | (19, 4) |
| [Victory Road](../locations/header-215.md) | — | `header-215` | Visible | (4, 5) |
| [Victory Road](../locations/header-219.md) | — | `header-219` | Hidden | (3, 9) |
| [Route 4](../locations/header-326.md) | — | `header-326` | Visible | (405, 539) |
| [Route 5](../locations/header-329.md) | — | `header-329` | Visible | (375, 425) |
| [Route 6](../locations/header-331.md) | — | `header-331` | Visible | (142, 398) |
| [Mistralton Cave](../locations/header-333.md) | — | `header-333` | Visible | (27, 6) |
| [Mistralton Cave](../locations/header-334.md) | — | `header-334` | Visible | (4, 3) |
| [Guidance Chamber](../locations/header-335.md) | — | `header-335` | Hidden | (7, 9) |
| [Guidance Chamber](../locations/header-335.md) | — | `header-335` | Hidden | (28, 7) |
| [Celestial Tower](../locations/header-340.md) | — | `header-340` | Visible | (23, 15) |
| [Moor of Icirrus](../locations/header-346.md) | — | `header-346` | Hidden | (17, 51) |
| [Route 11](../locations/header-365.md) | — | `header-365` | Visible | (483, 166) |
| [Route 12](../locations/header-368.md) | — | `header-368` | Hidden | (622, 174) |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden | (23, 33) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F1 | ₽1,200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Lenora](../trainers/trainer-0022.md) | AI battle item |
| [Leader Burgh](../trainers/trainer-0023.md) | AI battle item |
| [Leader Elesa](../trainers/trainer-0024.md) | AI battle item |
| [Leader Clay](../trainers/trainer-0025.md) | AI battle item |
| [Leader Roberto](../trainers/trainer-0131.md) | AI battle item |
| [Leader Brycen](../trainers/trainer-0132.md) | AI battle item |
| [Leader Iris](../trainers/trainer-0133.md) | AI battle item |
| [Pokéfan Geoff](../trainers/trainer-0138.md) | AI battle item |
| [Pokéfan Jude](../trainers/trainer-0139.md) | AI battle item |
| [Doctor Devon](../trainers/trainer-0150.md) | AI battle item |
| [Doctor Wayne](../trainers/trainer-0151.md) | AI battle item |
| [Nurse Hank](../trainers/trainer-0152.md) | AI battle item |
| [Doctor Tyrone](../trainers/trainer-0249.md) | AI battle item |
| [Pokéfan Janie](../trainers/trainer-0373.md) | AI battle item |
| [Pokéfan Colin](../trainers/trainer-0374.md) | AI battle item |
| [Doctor Alexander](../trainers/trainer-0384.md) | AI battle item |
| [Pokéfan Ann](../trainers/trainer-0429.md) | AI battle item |
| [ Trainer Shane](../trainers/trainer-0491.md) | AI battle item |
| [ Trainer Bianca](../trainers/trainer-0492.md) | AI battle item |
| [ Trainer Bianca](../trainers/trainer-0493.md) | AI battle item |
| [Doctor Grunt](../trainers/trainer-0613.md) | AI battle item |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `25` |

Source: exact ROM record from `a/0/2/4` member `25`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/25/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Potion →</span></a>
</nav>
