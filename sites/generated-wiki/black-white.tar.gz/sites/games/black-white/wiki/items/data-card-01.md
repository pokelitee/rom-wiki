# Data Card 01

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/data-card.png" alt="Data Card 01 icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>505</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Data Cards</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Records the number of times the trainer has come in first place overall in the Pokéathlon.</strong></p>

<figure class="rw-pokedex-entry">
<blockquote>It holds Pokéathlon records. It&#x27;s a card that shows how many victories you&#x27;ve had.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `505` |

Source: exact ROM record from `a/0/2/4` member `505`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/486/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rage-candy-bar/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rage-candy-bar.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← RageCandyBar</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../data-card-02/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/data-card.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Data Card 02 →</span></a>
</nav>
