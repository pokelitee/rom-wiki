# Fresh Water

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fresh-water.png" alt="Fresh Water icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>30</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 50 HP.</strong></p>
<p>Used on a party Pokémon : Restores 50 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>Water with a high mineral content. It restores the HP of one Pokémon by 50 points.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>HP amount 50</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Striaton City](../locations/header-007.md) | — | `header-007` | Script Awarded | — |
| [Nacrene City](../locations/header-018.md) | — | `header-018` | Script Awarded | — |
| [Castelia City](../locations/header-029.md) | — | `header-029` | Script Awarded | — |
| [Nimbasa City](../locations/header-063.md) | — | `header-063` | Script Awarded | — |
| [Driftveil City](../locations/header-098.md) | — | `header-098` | Script Awarded | — |
| [Icirrus City](../locations/header-114.md) | — | `header-114` | Script Awarded | — |
| [Opelucid City](../locations/header-121.md) | — | `header-121` | Script Awarded | — |
| [Desert Resort](../locations/header-158.md) | — | `header-158` | Visible | (29, 79) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | — | `header-005` | Black City resident market | ₽1,000 | Current resident: Robbie |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Waiter Brooke](../trainers/trainer-0363.md) | Victory reward |
| [Waitress Clint](../trainers/trainer-0364.md) | Victory reward |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `30` |

Source: exact ROM record from `a/0/2/4` member `30`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/30/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-revive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-revive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Revive</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../soda-pop/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/soda-pop.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Soda Pop →</span></a>
</nav>
