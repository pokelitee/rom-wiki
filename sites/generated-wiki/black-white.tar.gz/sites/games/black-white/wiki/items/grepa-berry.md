# Grepa Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grepa-berry.png" alt="Grepa Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>173</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Effort Drop</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Drops Special Defense Effort Values by 10 and raises happiness.</strong></p>
<p>Used on a party Pokémon : Increases happiness by 10/5/2. Lowers Special Defense effort by 10.</p>

<figure class="rw-pokedex-entry">
<blockquote>Using it on a Pokémon makes it more friendly, but it also lowers its base Sp. Def stat.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>3</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>70 power, <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>Sp. Def EVs -10, friendship (low +10, medium +5, high +2)</dd></div>
</dl>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `173` |

Source: exact ROM record from `a/0/2/4` member `173`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/150/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hondew-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hondew-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Hondew Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../tamato-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tamato-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Tamato Berry →</span></a>
</nav>
