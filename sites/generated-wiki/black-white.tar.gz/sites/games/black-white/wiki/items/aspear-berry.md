# Aspear Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/aspear-berry.png" alt="Aspear Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>153</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Medicine</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when frozen to cure frozen.</strong></p>
<p>Held in battle : When the holder is frozen, it consumes this item to thaw itself. Used on a party Pokémon : Cures freezing.</p>

<figure class="rw-pokedex-entry">
<blockquote>If held by a Pokémon, it defrosts it.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>3</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>9</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>5</dd></div>
<div><dt>Fling effect ID</dt><dd>5</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>cures freeze</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Mistralton Cave](../locations/header-333.md) | Hidden | (3, 17) |
| [Moor of Icirrus](../locations/header-346.md) | Visible | (45, 41) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/613.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubchoo](../pokemon/cubchoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | Common |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [⒆⒇ Ranger Richard](../trainers/trainer-0183.md) | Victory reward |
| [⒆⒇ Ranger Shanti](../trainers/trainer-0187.md) | Victory reward |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `153` |

Source: exact ROM record from `a/0/2/4` member `153`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/130/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rawst-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rawst-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Rawst Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../leppa-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leppa-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Leppa Berry →</span></a>
</nav>
