# Focus Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-band.png" alt="Focus Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>230</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder has 10% chance to survive attacks or self-inflicted damage at 1 HP.</strong></p>
<p>Held: If the holder is attacked for regular damage that would faint it, this item has a 10% chance to prevent the holder’s HP from lowering below 1.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. The holder may endure a potential KO attack, leaving it with just 1 HP.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>65</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [N's Castle](../locations/header-271.md) | map_271 | `header-271` | Visible | (5, 8) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | map_67 | `header-067` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-068.md) | map_68 | `header-068` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-069.md) | map_69 | `header-069` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-070.md) | map_70 | `header-070` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-071.md) | map_71 | `header-071` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-072.md) | map_72 | `header-072` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-073.md) | map_73 | `header-073` | Battle Point item exchange | 48 BP | Main game |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `230` |

Source: exact ROM record from `a/0/2/4` member `230`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/207/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../everstone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/everstone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Everstone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../lucky-egg/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lucky-egg.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Lucky Egg →</span></a>
</nav>
