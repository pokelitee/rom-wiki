# Blue Flute

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-flute.png" alt="Blue Flute icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>65</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Flutes</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures sleep.</strong></p>
<p>Used on a party Pokémon : Cures sleep.</p>

<figure class="rw-pokedex-entry">
<blockquote>A toy flute made from blue glass. A maniac will buy it for a high price.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep</dd></div>
</dl>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `65` |

Source: exact ROM record from `a/0/2/4` member `65`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/65/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../fluffy-tail/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fluffy-tail.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Fluffy Tail</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../yellow-flute/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-flute.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Yellow Flute →</span></a>
</nav>
