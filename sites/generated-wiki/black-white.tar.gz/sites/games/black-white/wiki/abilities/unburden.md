# Unburden

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>84</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">9</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Doubles Speed upon using or losing a held item.</strong></p>
<p>When this Pokémon uses or loses its held item, its Speed is doubled. If it gains another item or leaves battle, this bonus is lost. This includes when the Pokémon drops its item because of Knock Off. This bonus does not count as a stat modifier. There is no notification when this ability takes effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>Raises Speed if a held item is used.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/106.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonlee](../pokemon/hitmonlee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/252.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Treecko](../pokemon/treecko.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/253.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grovyle](../pokemon/grovyle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/254.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sceptile](../pokemon/sceptile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/425.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifloon](../pokemon/drifloon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/426.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifblim](../pokemon/drifblim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/509.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purrloin](../pokemon/purrloin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/510.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Liepard](../pokemon/liepard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/617.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Accelgor](../pokemon/accelgor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/84/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../anger-point/"><span class="rw-record-nav__label">← Anger Point</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../heatproof/"><span class="rw-record-nav__label">Heatproof →</span></a>
</nav>
