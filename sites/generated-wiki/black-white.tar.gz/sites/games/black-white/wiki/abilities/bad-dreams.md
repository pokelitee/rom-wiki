# Bad Dreams

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>123</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Damages sleeping opponents for 1/8 their max HP after each turn.</strong></p>
<p>Opposing Pokémon take 1/8 of their maximum HP in damage after each turn while they are asleep.</p>

<figure class="rw-pokedex-entry">
<blockquote>Reduces a sleeping foe’s HP.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/491.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Darkrai](../pokemon/darkrai.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/123/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../flower-gift/"><span class="rw-record-nav__label">← Flower Gift</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../pickpocket/"><span class="rw-record-nav__label">Pickpocket →</span></a>
</nav>
