# Clear Body

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>29</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents stats from being lowered by other Pokémon.</strong></p>
<p>This Pokémon cannot have its stats lowered by other Pokémon. This ability does not prevent any stat losses other than stat modifiers, such as the Speed cut from paralysis. This Pokémon can still be passed negative stat modifiers through Guard Swap, Heart Swap, or Power Swap. This ability functions identically to White Smoke in battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents other Pokémon from lowering its stats.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/73.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/374.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beldum](../pokemon/beldum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/376.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metagross](../pokemon/metagross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/377.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Regirock](../pokemon/regirock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/378.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Regice](../pokemon/regice.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/379.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Registeel](../pokemon/registeel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/599.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klink](../pokemon/klink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/600.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klang](../pokemon/klang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/601.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klinklang](../pokemon/klinklang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/29/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../synchronize/"><span class="rw-record-nav__label">← Synchronize</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../natural-cure/"><span class="rw-record-nav__label">Natural Cure →</span></a>
</nav>
