# Poison Heal

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>90</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">3</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Heals for 1/8 max HP after each turn when poisoned in place of damage.</strong></p>
<p>If this Pokémon is poisoned, it will heal for 1/8 of its maximum HP after each turn rather than taking damage. This includes bad poison.</p>

<figure class="rw-pokedex-entry">
<blockquote>Restores HP if the Pokémon is poisoned.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/285.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shroomish](../pokemon/shroomish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/286.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Breloom](../pokemon/breloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/472.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gliscor](../pokemon/gliscor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/90/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../iron-fist/"><span class="rw-record-nav__label">← Iron Fist</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../adaptability/"><span class="rw-record-nav__label">Adaptability →</span></a>
</nav>
