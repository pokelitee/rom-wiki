# Flower Gift

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>122</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases friendly Pokémon&#x27;s Attack and Special Defense to 1.5× during strong sunlight.</strong></p>
<p>Friendly Pokémon have 1.5× their Attack and Special Defense during strong sunlight if any friendly Pokémon has this ability. Unlike Forecast, Multitype, and Zen Mode, this ability is not tied to its Pokémon&#x27;s form change; Cherrim will switch between its forms even if it loses this ability. As such, this ability also works if obtained by a Pokémon other than Cherrim.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up party Pokémon when it is sunny.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/122/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../multitype/"><span class="rw-record-nav__label">← Multitype</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../bad-dreams/"><span class="rw-record-nav__label">Bad Dreams →</span></a>
</nav>
