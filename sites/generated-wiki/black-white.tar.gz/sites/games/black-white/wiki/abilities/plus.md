# Plus

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>57</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">7</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases Special Attack to 1.5× when a friendly Pokémon has Plus or Minus.</strong></p>
<p>This Pokémon has 1.5× its Special Attack if any friendly Pokémon has Plus or Minus. This bonus does not count as a stat modifier. If either ability is disabled by Gastro Acid, both lose their effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>Ups Sp. Atk if another Pokémon has Plus or Minus.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/179.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mareep](../pokemon/mareep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/180.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/181.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ampharos](../pokemon/ampharos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/599.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klink](../pokemon/klink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/600.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klang](../pokemon/klang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/601.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Klinklang](../pokemon/klinklang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/57/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../cute-charm/"><span class="rw-record-nav__label">← Cute Charm</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../minus/"><span class="rw-record-nav__label">Minus →</span></a>
</nav>
