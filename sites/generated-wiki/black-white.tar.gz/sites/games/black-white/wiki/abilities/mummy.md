# Mummy

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>152</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Changes attacking Pokémon&#x27;s abilities to Mummy on contact.</strong></p>
<p>Whenever a contact move hits this Pokémon, the attacking Pokémon&#x27;s ability changes to Mummy. Multitype is unaffected. If a Pokémon with Moxie knocks this Pokémon out, the former&#x27;s ability will change without taking effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>Contact with this Pokémon spreads this Ability.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/562.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yamask](../pokemon/yamask.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/563.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cofagrigus](../pokemon/cofagrigus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/152/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../infiltrator/"><span class="rw-record-nav__label">← Infiltrator</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../moxie/"><span class="rw-record-nav__label">Moxie →</span></a>
</nav>
