# Prankster

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>158</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Raises non-damaging moves&#x27; priority by one stage.</strong></p>
<p>This Pokémon&#x27;s non-damaging moves have their priority increased by one stage.</p>

<figure class="rw-pokedex-entry">
<blockquote>Gives priority to a status move.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/198.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/302.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/313.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Volbeat](../pokemon/volbeat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/314.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Illumise](../pokemon/illumise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/509.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purrloin](../pokemon/purrloin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/510.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Liepard](../pokemon/liepard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/546.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cottonee](../pokemon/cottonee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/547.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whimsicott](../pokemon/whimsicott.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/641.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tornadus](../pokemon/tornadus-incarnate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/642.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Thundurus](../pokemon/thundurus-incarnate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/158/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sap-sipper/"><span class="rw-record-nav__label">← Sap Sipper</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sand-force/"><span class="rw-record-nav__label">Sand Force →</span></a>
</nav>
