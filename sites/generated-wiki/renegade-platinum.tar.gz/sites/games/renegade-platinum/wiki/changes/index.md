# Changes from base game

Every supported ROM dataset is compared with the configured clean base ROM. Unchanged records remain visible on their detail pages.

| Section | Unchanged | Changed | Added | Removed |
| ------- | --------: | ------: | ----: | ------: |
| [Pokémon](#pokemon) | 1 | 507 | 0 | 0 |
| [Abilities](#abilities) | 30 | 93 | 0 | 0 |
| [Moves](#moves) | 330 | 141 | 0 | 0 |
| [Items](#items) | 200 | 245 | 0 | 0 |
| [Wild encounters](#wild-encounters) | 47 | 136 | 0 | 0 |
| [Trainers](#trainers) | 3 | 925 | 138 | 0 |
| [Locations](#locations) | 418 | 175 | 0 | 0 |

## Pokémon

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Bulbasaur](../pokemon/bulbasaur.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Ivysaur](../pokemon/ivysaur.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Venusaur](../pokemon/venusaur.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Charmander](../pokemon/charmander.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Charmeleon](../pokemon/charmeleon.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Charizard](../pokemon/charizard.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Move tutors, Level-up moves |
| [Squirtle](../pokemon/squirtle.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Wartortle](../pokemon/wartortle.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Blastoise](../pokemon/blastoise.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Caterpie](../pokemon/caterpie.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Metapod](../pokemon/metapod.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Butterfree](../pokemon/butterfree.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Weedle](../pokemon/weedle.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Kakuna](../pokemon/kakuna.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Beedrill](../pokemon/beedrill.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Pidgey](../pokemon/pidgey.md) | Changed | Base stats, Hatch cycles, Level-up moves |
| [Pidgeotto](../pokemon/pidgeotto.md) | Changed | Base stats, Hatch cycles, Level-up moves |
| [Pidgeot](../pokemon/pidgeot.md) | Changed | Base stats, Abilities, Hatch cycles, Level-up moves |
| [Rattata](../pokemon/rattata.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Raticate](../pokemon/raticate.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Spearow](../pokemon/spearow.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Fearow](../pokemon/fearow.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Ekans](../pokemon/ekans.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Arbok](../pokemon/arbok.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Pikachu](../pokemon/pikachu.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Raichu](../pokemon/raichu.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Sandshrew](../pokemon/sandshrew.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Sandslash](../pokemon/sandslash.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Nidoran♀](../pokemon/nidoran-f.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Nidorina](../pokemon/nidorina.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Nidoqueen](../pokemon/nidoqueen.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Nidoran♂](../pokemon/nidoran-m.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Nidorino](../pokemon/nidorino.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Nidoking](../pokemon/nidoking.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Clefairy](../pokemon/clefairy.md) | Changed | Types, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Clefable](../pokemon/clefable.md) | Changed | Base stats, Types, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Vulpix](../pokemon/vulpix.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Ninetales](../pokemon/ninetales.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Jigglypuff](../pokemon/jigglypuff.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Wigglytuff](../pokemon/wigglytuff.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Zubat](../pokemon/zubat.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Golbat](../pokemon/golbat.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Oddish](../pokemon/oddish.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Gloom](../pokemon/gloom.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Vileplume](../pokemon/vileplume.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Paras](../pokemon/paras.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Parasect](../pokemon/parasect.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Venonat](../pokemon/venonat.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Venomoth](../pokemon/venomoth.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Diglett](../pokemon/diglett.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Dugtrio](../pokemon/dugtrio.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Meowth](../pokemon/meowth.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Persian](../pokemon/persian.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Psyduck](../pokemon/psyduck.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Golduck](../pokemon/golduck.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Mankey](../pokemon/mankey.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Primeape](../pokemon/primeape.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Growlithe](../pokemon/growlithe.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Arcanine](../pokemon/arcanine.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Poliwag](../pokemon/poliwag.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Poliwhirl](../pokemon/poliwhirl.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Poliwrath](../pokemon/poliwrath.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Abra](../pokemon/abra.md) | Changed | Abilities, Hatch cycles, Machines |
| [Kadabra](../pokemon/kadabra.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Alakazam](../pokemon/alakazam.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Machop](../pokemon/machop.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Machoke](../pokemon/machoke.md) | Changed | Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Machamp](../pokemon/machamp.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Bellsprout](../pokemon/bellsprout.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Weepinbell](../pokemon/weepinbell.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Victreebel](../pokemon/victreebel.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Tentacool](../pokemon/tentacool.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Tentacruel](../pokemon/tentacruel.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Geodude](../pokemon/geodude.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Graveler](../pokemon/graveler.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Golem](../pokemon/golem.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Ponyta](../pokemon/ponyta.md) | Changed | Abilities, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Rapidash](../pokemon/rapidash.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Slowpoke](../pokemon/slowpoke.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Slowbro](../pokemon/slowbro.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Magnemite](../pokemon/magnemite.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Magneton](../pokemon/magneton.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Farfetch'd](../pokemon/farfetchd.md) | Changed | Base stats, Types, Abilities, EV yield, Hatch cycles, Machines, Level-up moves |
| [Doduo](../pokemon/doduo.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Dodrio](../pokemon/dodrio.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Seel](../pokemon/seel.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Dewgong](../pokemon/dewgong.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Grimer](../pokemon/grimer.md) | Changed | Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Muk](../pokemon/muk.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Shellder](../pokemon/shellder.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Cloyster](../pokemon/cloyster.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Gastly](../pokemon/gastly.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Haunter](../pokemon/haunter.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Gengar](../pokemon/gengar.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Onix](../pokemon/onix.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Drowzee](../pokemon/drowzee.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Hypno](../pokemon/hypno.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Krabby](../pokemon/krabby.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Kingler](../pokemon/kingler.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Voltorb](../pokemon/voltorb.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Electrode](../pokemon/electrode.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Exeggcute](../pokemon/exeggcute.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Exeggutor](../pokemon/exeggutor.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Cubone](../pokemon/cubone.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Marowak](../pokemon/marowak.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Hitmonlee](../pokemon/hitmonlee.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Hitmonchan](../pokemon/hitmonchan.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Lickitung](../pokemon/lickitung.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Koffing](../pokemon/koffing.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Weezing](../pokemon/weezing.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Rhyhorn](../pokemon/rhyhorn.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Rhydon](../pokemon/rhydon.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Chansey](../pokemon/chansey.md) | Changed | Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Tangela](../pokemon/tangela.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Kangaskhan](../pokemon/kangaskhan.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Horsea](../pokemon/horsea.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Seadra](../pokemon/seadra.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Goldeen](../pokemon/goldeen.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Seaking](../pokemon/seaking.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Staryu](../pokemon/staryu.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Starmie](../pokemon/starmie.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Mr. Mime](../pokemon/mr-mime.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Scyther](../pokemon/scyther.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Jynx](../pokemon/jynx.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Electabuzz](../pokemon/electabuzz.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Magmar](../pokemon/magmar.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Pinsir](../pokemon/pinsir.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Tauros](../pokemon/tauros.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Magikarp](../pokemon/magikarp.md) | Changed | Hatch cycles, Level-up moves |
| [Gyarados](../pokemon/gyarados.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Lapras](../pokemon/lapras.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Ditto](../pokemon/ditto.md) | Changed | Hatch cycles |
| [Eevee](../pokemon/eevee.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Vaporeon](../pokemon/vaporeon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Jolteon](../pokemon/jolteon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Flareon](../pokemon/flareon.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Porygon](../pokemon/porygon.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Omanyte](../pokemon/omanyte.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Omastar](../pokemon/omastar.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Kabuto](../pokemon/kabuto.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Kabutops](../pokemon/kabutops.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Aerodactyl](../pokemon/aerodactyl.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Snorlax](../pokemon/snorlax.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Articuno](../pokemon/articuno.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Zapdos](../pokemon/zapdos.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Moltres](../pokemon/moltres.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Dratini](../pokemon/dratini.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Dragonair](../pokemon/dragonair.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Dragonite](../pokemon/dragonite.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Mewtwo](../pokemon/mewtwo.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Mew](../pokemon/mew.md) | Changed | Hatch cycles, Level-up moves |
| [Chikorita](../pokemon/chikorita.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Bayleef](../pokemon/bayleef.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Meganium](../pokemon/meganium.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Cyndaquil](../pokemon/cyndaquil.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Quilava](../pokemon/quilava.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Typhlosion](../pokemon/typhlosion.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Totodile](../pokemon/totodile.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Croconaw](../pokemon/croconaw.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Feraligatr](../pokemon/feraligatr.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Sentret](../pokemon/sentret.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Furret](../pokemon/furret.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Hoothoot](../pokemon/hoothoot.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Noctowl](../pokemon/noctowl.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Ledyba](../pokemon/ledyba.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Ledian](../pokemon/ledian.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Spinarak](../pokemon/spinarak.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Ariados](../pokemon/ariados.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Crobat](../pokemon/crobat.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Chinchou](../pokemon/chinchou.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Lanturn](../pokemon/lanturn.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Pichu](../pokemon/pichu.md) | Changed | Abilities, Wild held items, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Cleffa](../pokemon/cleffa.md) | Changed | Types, Wild held items, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Igglybuff](../pokemon/igglybuff.md) | Changed | Types, Abilities, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Togepi](../pokemon/togepi.md) | Changed | Types, Abilities, Hatch cycles, Base friendship, Level-up moves |
| [Togetic](../pokemon/togetic.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Natu](../pokemon/natu.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Xatu](../pokemon/xatu.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Mareep](../pokemon/mareep.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Flaaffy](../pokemon/flaaffy.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Ampharos](../pokemon/ampharos.md) | Changed | Base stats, Types, Hatch cycles, Machines, Move tutors, Level-up moves |
| [Bellossom](../pokemon/bellossom.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Marill](../pokemon/marill.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Azumarill](../pokemon/azumarill.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Sudowoodo](../pokemon/sudowoodo.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Politoed](../pokemon/politoed.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Hoppip](../pokemon/hoppip.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Skiploom](../pokemon/skiploom.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Jumpluff](../pokemon/jumpluff.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Aipom](../pokemon/aipom.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Sunkern](../pokemon/sunkern.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Sunflora](../pokemon/sunflora.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Yanma](../pokemon/yanma.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Wooper](../pokemon/wooper.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Quagsire](../pokemon/quagsire.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Espeon](../pokemon/espeon.md) | Changed | Hatch cycles, Level-up moves |
| [Umbreon](../pokemon/umbreon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Murkrow](../pokemon/murkrow.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Slowking](../pokemon/slowking.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Misdreavus](../pokemon/misdreavus.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Unown](../pokemon/unown.md) | Changed | Base stats, Catch Rate, Hatch cycles, Level-up moves |
| [Wobbuffet](../pokemon/wobbuffet.md) | Changed | Hatch cycles, Level-up moves |
| [Girafarig](../pokemon/girafarig.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Pineco](../pokemon/pineco.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Forretress](../pokemon/forretress.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Dunsparce](../pokemon/dunsparce.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Gligar](../pokemon/gligar.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Steelix](../pokemon/steelix.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Snubbull](../pokemon/snubbull.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Granbull](../pokemon/granbull.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Qwilfish](../pokemon/qwilfish.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Scizor](../pokemon/scizor.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Shuckle](../pokemon/shuckle.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Heracross](../pokemon/heracross.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Sneasel](../pokemon/sneasel.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Teddiursa](../pokemon/teddiursa.md) | Changed | Hatch cycles, Level-up moves |
| [Ursaring](../pokemon/ursaring.md) | Changed | Hatch cycles, Level-up moves |
| [Slugma](../pokemon/slugma.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Magcargo](../pokemon/magcargo.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Swinub](../pokemon/swinub.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Piloswine](../pokemon/piloswine.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Corsola](../pokemon/corsola.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Remoraid](../pokemon/remoraid.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Octillery](../pokemon/octillery.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Delibird](../pokemon/delibird.md) | Changed | Base stats, Abilities, EV yield, Hatch cycles, Machines, Level-up moves |
| [Mantine](../pokemon/mantine.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Skarmory](../pokemon/skarmory.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Houndour](../pokemon/houndour.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Houndoom](../pokemon/houndoom.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Kingdra](../pokemon/kingdra.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Phanpy](../pokemon/phanpy.md) | Changed | Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Donphan](../pokemon/donphan.md) | Changed | Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Porygon2](../pokemon/porygon2.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Stantler](../pokemon/stantler.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Smeargle](../pokemon/smeargle.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Tyrogue](../pokemon/tyrogue.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Hitmontop](../pokemon/hitmontop.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Smoochum](../pokemon/smoochum.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Elekid](../pokemon/elekid.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Magby](../pokemon/magby.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Miltank](../pokemon/miltank.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Blissey](../pokemon/blissey.md) | Changed | Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Raikou](../pokemon/raikou.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Entei](../pokemon/entei.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Suicune](../pokemon/suicune.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Larvitar](../pokemon/larvitar.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Pupitar](../pokemon/pupitar.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Tyranitar](../pokemon/tyranitar.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Lugia](../pokemon/lugia.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Ho-Oh](../pokemon/ho-oh.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Celebi](../pokemon/celebi.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Treecko](../pokemon/treecko.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Grovyle](../pokemon/grovyle.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Sceptile](../pokemon/sceptile.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Move tutors, Level-up moves |
| [Torchic](../pokemon/torchic.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Combusken](../pokemon/combusken.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Blaziken](../pokemon/blaziken.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Mudkip](../pokemon/mudkip.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Marshtomp](../pokemon/marshtomp.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Swampert](../pokemon/swampert.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Poochyena](../pokemon/poochyena.md) | Changed | Base stats, Wild held items, Hatch cycles, Level-up moves |
| [Mightyena](../pokemon/mightyena.md) | Changed | Base stats, Wild held items, Hatch cycles, Level-up moves |
| [Zigzagoon](../pokemon/zigzagoon.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Linoone](../pokemon/linoone.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Wurmple](../pokemon/wurmple.md) | Changed | Abilities, Wild held items, Hatch cycles, Level-up moves |
| [Silcoon](../pokemon/silcoon.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Beautifly](../pokemon/beautifly.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Cascoon](../pokemon/cascoon.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Dustox](../pokemon/dustox.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Lotad](../pokemon/lotad.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Lombre](../pokemon/lombre.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Ludicolo](../pokemon/ludicolo.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Seedot](../pokemon/seedot.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Nuzleaf](../pokemon/nuzleaf.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Shiftry](../pokemon/shiftry.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Taillow](../pokemon/taillow.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Swellow](../pokemon/swellow.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Wingull](../pokemon/wingull.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Pelipper](../pokemon/pelipper.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Ralts](../pokemon/ralts.md) | Changed | Base stats, Types, Hatch cycles, Machines, Level-up moves |
| [Kirlia](../pokemon/kirlia.md) | Changed | Base stats, Types, Hatch cycles, Machines, Level-up moves |
| [Gardevoir](../pokemon/gardevoir.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Surskit](../pokemon/surskit.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Masquerain](../pokemon/masquerain.md) | Changed | Base stats, Types, Hatch cycles, Machines, Level-up moves |
| [Shroomish](../pokemon/shroomish.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Breloom](../pokemon/breloom.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Slakoth](../pokemon/slakoth.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Vigoroth](../pokemon/vigoroth.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Slaking](../pokemon/slaking.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Nincada](../pokemon/nincada.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Ninjask](../pokemon/ninjask.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Shedinja](../pokemon/shedinja.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Whismur](../pokemon/whismur.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Loudred](../pokemon/loudred.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Exploud](../pokemon/exploud.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Makuhita](../pokemon/makuhita.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Hariyama](../pokemon/hariyama.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Azurill](../pokemon/azurill.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Nosepass](../pokemon/nosepass.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Skitty](../pokemon/skitty.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Delcatty](../pokemon/delcatty.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Sableye](../pokemon/sableye.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Mawile](../pokemon/mawile.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Aron](../pokemon/aron.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Lairon](../pokemon/lairon.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Aggron](../pokemon/aggron.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Meditite](../pokemon/meditite.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Medicham](../pokemon/medicham.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Electrike](../pokemon/electrike.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Manectric](../pokemon/manectric.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Plusle](../pokemon/plusle.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Minun](../pokemon/minun.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Volbeat](../pokemon/volbeat.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Illumise](../pokemon/illumise.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Roselia](../pokemon/roselia.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Gulpin](../pokemon/gulpin.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Swalot](../pokemon/swalot.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Carvanha](../pokemon/carvanha.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Sharpedo](../pokemon/sharpedo.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Wailmer](../pokemon/wailmer.md) | Changed | Hatch cycles, Evolutions, Level-up moves |
| [Wailord](../pokemon/wailord.md) | Changed | Hatch cycles, Level-up moves |
| [Numel](../pokemon/numel.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Camerupt](../pokemon/camerupt.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Torkoal](../pokemon/torkoal.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Spoink](../pokemon/spoink.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Grumpig](../pokemon/grumpig.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Spinda](../pokemon/spinda.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Trapinch](../pokemon/trapinch.md) | Changed | Base stats, Types, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Vibrava](../pokemon/vibrava.md) | Changed | Base stats, Types, Abilities, EV yield, Hatch cycles, Machines, Level-up moves |
| [Flygon](../pokemon/flygon.md) | Changed | Base stats, Types, Abilities, EV yield, Hatch cycles, Machines, Level-up moves |
| [Cacnea](../pokemon/cacnea.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Cacturne](../pokemon/cacturne.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Swablu](../pokemon/swablu.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Level-up moves |
| [Altaria](../pokemon/altaria.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Level-up moves |
| [Zangoose](../pokemon/zangoose.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Seviper](../pokemon/seviper.md) | Changed | Base stats, Types, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Lunatone](../pokemon/lunatone.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Solrock](../pokemon/solrock.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Barboach](../pokemon/barboach.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Whiscash](../pokemon/whiscash.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Corphish](../pokemon/corphish.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Crawdaunt](../pokemon/crawdaunt.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Baltoy](../pokemon/baltoy.md) | Changed | Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Claydol](../pokemon/claydol.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Lileep](../pokemon/lileep.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Cradily](../pokemon/cradily.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Anorith](../pokemon/anorith.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Armaldo](../pokemon/armaldo.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Feebas](../pokemon/feebas.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Milotic](../pokemon/milotic.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Castform](../pokemon/castform.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Kecleon](../pokemon/kecleon.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Shuppet](../pokemon/shuppet.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Banette](../pokemon/banette.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Duskull](../pokemon/duskull.md) | Changed | Abilities, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Dusclops](../pokemon/dusclops.md) | Changed | Abilities, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Tropius](../pokemon/tropius.md) | Changed | Base stats, Base experience, Hatch cycles, Machines, Level-up moves |
| [Chimecho](../pokemon/chimecho.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Absol](../pokemon/absol.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Wynaut](../pokemon/wynaut.md) | Changed | Hatch cycles, Level-up moves |
| [Snorunt](../pokemon/snorunt.md) | Changed | Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Glalie](../pokemon/glalie.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Spheal](../pokemon/spheal.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Sealeo](../pokemon/sealeo.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Walrein](../pokemon/walrein.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Clamperl](../pokemon/clamperl.md) | Changed | Abilities, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Huntail](../pokemon/huntail.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Gorebyss](../pokemon/gorebyss.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Relicanth](../pokemon/relicanth.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Luvdisc](../pokemon/luvdisc.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Bagon](../pokemon/bagon.md) | Changed | Hatch cycles, Level-up moves |
| [Shelgon](../pokemon/shelgon.md) | Changed | Hatch cycles, Level-up moves |
| [Salamence](../pokemon/salamence.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Beldum](../pokemon/beldum.md) | Changed | Abilities, Catch Rate, Hatch cycles, Level-up moves |
| [Metang](../pokemon/metang.md) | Changed | Abilities, Catch Rate, Hatch cycles, Machines, Level-up moves |
| [Metagross](../pokemon/metagross.md) | Changed | Abilities, Catch Rate, Hatch cycles, Machines, Level-up moves |
| [Regirock](../pokemon/regirock.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Regice](../pokemon/regice.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Registeel](../pokemon/registeel.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Latias](../pokemon/latias.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Latios](../pokemon/latios.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Kyogre](../pokemon/kyogre.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Groudon](../pokemon/groudon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Rayquaza](../pokemon/rayquaza.md) | Changed | Hatch cycles, Level-up moves |
| [Jirachi](../pokemon/jirachi.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Deoxys](../pokemon/deoxys-normal.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Turtwig](../pokemon/turtwig.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Grotle](../pokemon/grotle.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Torterra](../pokemon/torterra.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Chimchar](../pokemon/chimchar.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Monferno](../pokemon/monferno.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Infernape](../pokemon/infernape.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Piplup](../pokemon/piplup.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Prinplup](../pokemon/prinplup.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Empoleon](../pokemon/empoleon.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Starly](../pokemon/starly.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Staravia](../pokemon/staravia.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Staraptor](../pokemon/staraptor.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Bidoof](../pokemon/bidoof.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Bibarel](../pokemon/bibarel.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Kricketot](../pokemon/kricketot.md) | Changed | Base stats, Abilities, Hatch cycles, Level-up moves |
| [Kricketune](../pokemon/kricketune.md) | Changed | Base stats, Abilities, Hatch cycles, Level-up moves |
| [Shinx](../pokemon/shinx.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Luxio](../pokemon/luxio.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Luxray](../pokemon/luxray.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Budew](../pokemon/budew.md) | Changed | Abilities, Hatch cycles, Base friendship, Evolutions, Machines, Level-up moves |
| [Roserade](../pokemon/roserade.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Cranidos](../pokemon/cranidos.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Rampardos](../pokemon/rampardos.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Shieldon](../pokemon/shieldon.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Bastiodon](../pokemon/bastiodon.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Burmy](../pokemon/burmy.md) | Changed | Base stats, Abilities, Hatch cycles, Level-up moves |
| [Wormadam](../pokemon/wormadam-plant.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Mothim](../pokemon/mothim.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Combee](../pokemon/combee.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Vespiquen](../pokemon/vespiquen.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Pachirisu](../pokemon/pachirisu.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Buizel](../pokemon/buizel.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Floatzel](../pokemon/floatzel.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Cherubi](../pokemon/cherubi.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Cherrim](../pokemon/cherrim.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Shellos](../pokemon/shellos.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Gastrodon](../pokemon/gastrodon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Ambipom](../pokemon/ambipom.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Drifloon](../pokemon/drifloon.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Drifblim](../pokemon/drifblim.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Buneary](../pokemon/buneary.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Lopunny](../pokemon/lopunny.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Mismagius](../pokemon/mismagius.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Honchkrow](../pokemon/honchkrow.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Glameow](../pokemon/glameow.md) | Changed | Base stats, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Purugly](../pokemon/purugly.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Chingling](../pokemon/chingling.md) | Changed | Base stats, Wild held items, Hatch cycles, Base friendship, Evolutions, Machines, Level-up moves |
| [Stunky](../pokemon/stunky.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Skuntank](../pokemon/skuntank.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Bronzor](../pokemon/bronzor.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Bronzong](../pokemon/bronzong.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Bonsly](../pokemon/bonsly.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Mime Jr.](../pokemon/mime-jr.md) | Changed | Base stats, Types, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Happiny](../pokemon/happiny.md) | Changed | Abilities, Wild held items, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Chatot](../pokemon/chatot.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Spiritomb](../pokemon/spiritomb.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Gible](../pokemon/gible.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Gabite](../pokemon/gabite.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Garchomp](../pokemon/garchomp.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Munchlax](../pokemon/munchlax.md) | Changed | Abilities, Hatch cycles, Level-up moves |
| [Riolu](../pokemon/riolu.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Lucario](../pokemon/lucario.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Hippopotas](../pokemon/hippopotas.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Hippowdon](../pokemon/hippowdon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Skorupi](../pokemon/skorupi.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Drapion](../pokemon/drapion.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Croagunk](../pokemon/croagunk.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Toxicroak](../pokemon/toxicroak.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Carnivine](../pokemon/carnivine.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Finneon](../pokemon/finneon.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Lumineon](../pokemon/lumineon.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Mantyke](../pokemon/mantyke.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Snover](../pokemon/snover.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Abomasnow](../pokemon/abomasnow.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Weavile](../pokemon/weavile.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Magnezone](../pokemon/magnezone.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Lickilicky](../pokemon/lickilicky.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Rhyperior](../pokemon/rhyperior.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Tangrowth](../pokemon/tangrowth.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Electivire](../pokemon/electivire.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Magmortar](../pokemon/magmortar.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Togekiss](../pokemon/togekiss.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Yanmega](../pokemon/yanmega.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Leafeon](../pokemon/leafeon.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Glaceon](../pokemon/glaceon.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Gliscor](../pokemon/gliscor.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Mamoswine](../pokemon/mamoswine.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Porygon-Z](../pokemon/porygon-z.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Gallade](../pokemon/gallade.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Probopass](../pokemon/probopass.md) | Changed | Base stats, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Dusknoir](../pokemon/dusknoir.md) | Changed | Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Froslass](../pokemon/froslass.md) | Changed | Base stats, Abilities, Wild held items, Hatch cycles, Machines, Level-up moves |
| [Rotom](../pokemon/rotom.md) | Changed | Base stats, Hatch cycles, Machines, Level-up moves |
| [Uxie](../pokemon/uxie.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Mesprit](../pokemon/mesprit.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Azelf](../pokemon/azelf.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Dialga](../pokemon/dialga.md) | Changed | Hatch cycles, Level-up moves |
| [Palkia](../pokemon/palkia.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Heatran](../pokemon/heatran.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Regigigas](../pokemon/regigigas.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Giratina](../pokemon/giratina-altered.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Cresselia](../pokemon/cresselia.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Phione](../pokemon/phione.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Manaphy](../pokemon/manaphy.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Darkrai](../pokemon/darkrai.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Shaymin](../pokemon/shaymin-land.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Arceus](../pokemon/arceus.md) | Changed | Hatch cycles, Machines, Level-up moves |
| Egg | Changed | Hatch cycles |
| Bad Egg | Changed | Hatch cycles |
| [Deoxys Attack](../pokemon/deoxys-attack.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Deoxys Defense](../pokemon/deoxys-defense.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Deoxys Speed](../pokemon/deoxys-speed.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Wormadam Sandy](../pokemon/wormadam-sandy.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Wormadam Trash](../pokemon/wormadam-trash.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Giratina Origin](../pokemon/giratina-origin.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Shaymin Sky](../pokemon/shaymin-sky.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Rotom Heat](../pokemon/rotom-heat.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Rotom Wash](../pokemon/rotom-wash.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Rotom Frost](../pokemon/rotom-frost.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Rotom Fan](../pokemon/rotom-fan.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Rotom Mow](../pokemon/rotom-mow.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |

## Abilities

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Stench](../abilities/stench.md) | Changed | Pokémon |
| [Drizzle](../abilities/drizzle.md) | Changed | Pokémon |
| [Speed Boost](../abilities/speed-boost.md) | Changed | Pokémon |
| [Battle Armor](../abilities/battle-armor.md) | Changed | Pokémon |
| [Sturdy](../abilities/sturdy.md) | Changed | Pokémon |
| [Damp](../abilities/damp.md) | Changed | Pokémon |
| [Limber](../abilities/limber.md) | Changed | Pokémon |
| [Sand Veil](../abilities/sand-veil.md) | Changed | Pokémon |
| [Static](../abilities/static.md) | Changed | Pokémon |
| [Volt Absorb](../abilities/volt-absorb.md) | Changed | Pokémon |
| [Water Absorb](../abilities/water-absorb.md) | Changed | Pokémon |
| [Oblivious](../abilities/oblivious.md) | Changed | Pokémon |
| [Cloud Nine](../abilities/cloud-nine.md) | Changed | Pokémon |
| [Compoundeyes](../abilities/compound-eyes.md) | Changed | Pokémon |
| [Insomnia](../abilities/insomnia.md) | Changed | Pokémon |
| [Immunity](../abilities/immunity.md) | Changed | Pokémon |
| [Flash Fire](../abilities/flash-fire.md) | Changed | Pokémon |
| [Shield Dust](../abilities/shield-dust.md) | Changed | Pokémon |
| [Own Tempo](../abilities/own-tempo.md) | Changed | Pokémon |
| [Intimidate](../abilities/intimidate.md) | Changed | Pokémon |
| [Rough Skin](../abilities/rough-skin.md) | Changed | Pokémon |
| [Levitate](../abilities/levitate.md) | Changed | Pokémon |
| [Effect Spore](../abilities/effect-spore.md) | Changed | Pokémon |
| [Synchronize](../abilities/synchronize.md) | Changed | Pokémon |
| [Clear Body](../abilities/clear-body.md) | Changed | Pokémon |
| [Natural Cure](../abilities/natural-cure.md) | Changed | Pokémon |
| [Lightningrod](../abilities/lightning-rod.md) | Changed | Pokémon |
| [Serene Grace](../abilities/serene-grace.md) | Changed | Pokémon |
| [Swift Swim](../abilities/swift-swim.md) | Changed | Pokémon |
| [Chlorophyll](../abilities/chlorophyll.md) | Changed | Pokémon |
| [Illuminate](../abilities/illuminate.md) | Changed | Pokémon |
| [Huge Power](../abilities/huge-power.md) | Changed | Pokémon |
| [Poison Point](../abilities/poison-point.md) | Changed | Pokémon |
| [Inner Focus](../abilities/inner-focus.md) | Changed | Pokémon |
| [Magma Armor](../abilities/magma-armor.md) | Changed | Pokémon |
| [Water Veil](../abilities/water-veil.md) | Changed | Pokémon |
| [Soundproof](../abilities/soundproof.md) | Changed | Pokémon |
| [Rain Dish](../abilities/rain-dish.md) | Changed | Pokémon |
| [Pressure](../abilities/pressure.md) | Changed | Pokémon |
| [Thick Fat](../abilities/thick-fat.md) | Changed | Pokémon |
| [Early Bird](../abilities/early-bird.md) | Changed | Pokémon |
| [Flame Body](../abilities/flame-body.md) | Changed | Pokémon |
| [Run Away](../abilities/run-away.md) | Changed | Pokémon |
| [Keen Eye](../abilities/keen-eye.md) | Changed | Pokémon |
| [Hyper Cutter](../abilities/hyper-cutter.md) | Changed | Pokémon |
| [Pickup](../abilities/pickup.md) | Changed | Pokémon |
| [Hustle](../abilities/hustle.md) | Changed | Pokémon |
| [Cute Charm](../abilities/cute-charm.md) | Changed | Pokémon |
| [Shed Skin](../abilities/shed-skin.md) | Changed | Pokémon |
| [Guts](../abilities/guts.md) | Changed | Pokémon |
| [Marvel Scale](../abilities/marvel-scale.md) | Changed | Pokémon |
| [Overgrow](../abilities/overgrow.md) | Changed | Pokémon |
| [Blaze](../abilities/blaze.md) | Changed | Pokémon |
| [Torrent](../abilities/torrent.md) | Changed | Pokémon |
| [Swarm](../abilities/swarm.md) | Changed | Pokémon |
| [Rock Head](../abilities/rock-head.md) | Changed | Pokémon |
| [Drought](../abilities/drought.md) | Changed | Pokémon |
| [Vital Spirit](../abilities/vital-spirit.md) | Changed | Pokémon |
| [White Smoke](../abilities/white-smoke.md) | Changed | Pokémon |
| [Shell Armor](../abilities/shell-armor.md) | Changed | Pokémon |
| [Tangled Feet](../abilities/tangled-feet.md) | Changed | Pokémon |
| [Motor Drive](../abilities/motor-drive.md) | Changed | Pokémon |
| [Rivalry](../abilities/rivalry.md) | Changed | Pokémon |
| [Steadfast](../abilities/steadfast.md) | Changed | Pokémon |
| [Snow Cloak](../abilities/snow-cloak.md) | Changed | Pokémon |
| [Gluttony](../abilities/gluttony.md) | Changed | Pokémon |
| [Unburden](../abilities/unburden.md) | Changed | Pokémon |
| [Simple](../abilities/simple.md) | Changed | Pokémon |
| [Dry Skin](../abilities/dry-skin.md) | Changed | Pokémon |
| [Iron Fist](../abilities/iron-fist.md) | Changed | Pokémon |
| [Poison Heal](../abilities/poison-heal.md) | Changed | Pokémon |
| [Adaptability](../abilities/adaptability.md) | Changed | Pokémon |
| [Skill Link](../abilities/skill-link.md) | Changed | Pokémon |
| [Hydration](../abilities/hydration.md) | Changed | Pokémon |
| [Solar Power](../abilities/solar-power.md) | Changed | Pokémon |
| [Sniper](../abilities/sniper.md) | Changed | Pokémon |
| [Magic Guard](../abilities/magic-guard.md) | Changed | Pokémon |
| [No Guard](../abilities/no-guard.md) | Changed | Pokémon |
| [Technician](../abilities/technician.md) | Changed | Pokémon |
| [Klutz](../abilities/klutz.md) | Changed | Pokémon |
| [Mold Breaker](../abilities/mold-breaker.md) | Changed | Pokémon |
| [Super Luck](../abilities/super-luck.md) | Changed | Pokémon |
| [Aftermath](../abilities/aftermath.md) | Changed | Pokémon |
| [Anticipation](../abilities/anticipation.md) | Changed | Pokémon |
| [Unaware](../abilities/unaware.md) | Changed | Pokémon |
| [Tinted Lens](../abilities/tinted-lens.md) | Changed | Pokémon |
| [Filter](../abilities/filter.md) | Changed | Pokémon |
| [Scrappy](../abilities/scrappy.md) | Changed | Pokémon |
| [Storm Drain](../abilities/storm-drain.md) | Changed | Pokémon |
| [Solid Rock](../abilities/solid-rock.md) | Changed | Pokémon |
| [Honey Gather](../abilities/honey-gather.md) | Changed | Pokémon |
| [Frisk](../abilities/frisk.md) | Changed | Pokémon |
| [Reckless](../abilities/reckless.md) | Changed | Pokémon |

## Moves

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Double Slap](../moves/double-slap.md) | Changed | Name |
| [Thunder Punch](../moves/thunder-punch.md) | Changed | Name |
| [Vice Grip](../moves/vice-grip.md) | Changed | Name |
| [Swords Dance](../moves/swords-dance.md) | Changed | Pp |
| [Cut](../moves/cut.md) | Changed | Type, Power, Accuracy, Pp, Effect |
| [Fly](../moves/fly.md) | Changed | Power, Accuracy |
| [Bind](../moves/bind.md) | Changed | Accuracy |
| [Vine Whip](../moves/vine-whip.md) | Changed | Power, Pp |
| [Jump Kick](../moves/jump-kick.md) | Changed | Power, Pp |
| [Sand Attack](../moves/sand-attack.md) | Changed | Name |
| [Drill Run](../moves/drill-run.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Flags, Contest effect, Contest type |
| [Tackle](../moves/tackle.md) | Changed | Power, Accuracy |
| [Wrap](../moves/wrap.md) | Changed | Accuracy |
| [Thrash](../moves/thrash.md) | Changed | Power, Pp |
| [Pin Missile](../moves/pin-missile.md) | Changed | Power, Accuracy |
| [Sonic Boom](../moves/sonic-boom.md) | Changed | Name |
| [Disable](../moves/disable.md) | Changed | Accuracy |
| [Flamethrower](../moves/flamethrower.md) | Changed | Power |
| [Hydro Pump](../moves/hydro-pump.md) | Changed | Power |
| [Surf](../moves/surf.md) | Changed | Power |
| [Ice Beam](../moves/ice-beam.md) | Changed | Power |
| [Blizzard](../moves/blizzard.md) | Changed | Power |
| [Bubble Beam](../moves/bubble-beam.md) | Changed | Name, Power, Pp |
| [Aurora Beam](../moves/aurora-beam.md) | Changed | Power, Pp |
| [Play Rough](../moves/play-rough.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Effect chance |
| [Strength](../moves/strength.md) | Changed | Power, Effect, Effect chance |
| [Growth](../moves/growth.md) | Changed | Pp |
| [Solar Beam](../moves/solar-beam.md) | Changed | Name |
| [Poison Powder](../moves/poison-powder.md) | Changed | Name |
| [Petal Dance](../moves/petal-dance.md) | Changed | Power, Pp |
| [Fire Spin](../moves/fire-spin.md) | Changed | Power, Accuracy |
| [Thunder Shock](../moves/thunder-shock.md) | Changed | Name |
| [Thunderbolt](../moves/thunderbolt.md) | Changed | Power |
| [Thunder Wave](../moves/thunder-wave.md) | Changed | Accuracy |
| [Thunder](../moves/thunder.md) | Changed | Power |
| [Toxic](../moves/toxic.md) | Changed | Accuracy |
| [Minimize](../moves/minimize.md) | Changed | Pp |
| [Smokescreen](../moves/smokescreen.md) | Changed | Name |
| [Barrier](../moves/barrier.md) | Changed | Pp |
| [Self-Destruct](../moves/self-destruct.md) | Changed | Name |
| [Lick](../moves/lick.md) | Changed | Power |
| [Smog](../moves/smog.md) | Changed | Power |
| [Sludge](../moves/sludge.md) | Changed | Power, Pp |
| [Fire Blast](../moves/fire-blast.md) | Changed | Power |
| [Clamp](../moves/clamp.md) | Changed | Accuracy, Pp |
| [Skull Bash](../moves/skull-bash.md) | Changed | Power, Pp |
| [Icicle Crash](../moves/icicle-crash.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Effect chance, Contest effect |
| [Soft-Boiled](../moves/soft-boiled.md) | Changed | Name |
| [High Jump Kick](../moves/high-jump-kick.md) | Changed | Name, Power, Pp |
| [Glare](../moves/glare.md) | Changed | Accuracy |
| [Dream Eater](../moves/dream-eater.md) | Changed | Machines |
| [Poison Gas](../moves/poison-gas.md) | Changed | Accuracy |
| [Draining Kiss](../moves/draining-kiss.md) | Changed | Name, Type, Damage class, Power, Accuracy, Pp, Effect, Flags, Contest effect, Contest type |
| [Leech Life](../moves/leech-life.md) | Changed | Power, Pp |
| [Bubble](../moves/bubble.md) | Changed | Power |
| [Psywave](../moves/psywave.md) | Changed | Accuracy |
| [Acid Armor](../moves/acid-armor.md) | Changed | Pp |
| [Crabhammer](../moves/crabhammer.md) | Changed | Power, Accuracy |
| [Thief](../moves/thief.md) | Changed | Power, Pp |
| [Flame Wheel](../moves/flame-wheel.md) | Changed | Power, Pp |
| [Snore](../moves/snore.md) | Changed | Power |
| [Curse](../moves/curse.md) | Changed | Type |
| [Cotton Spore](../moves/cotton-spore.md) | Changed | Accuracy |
| [Protect](../moves/protect.md) | Changed | Priority |
| [Scary Face](../moves/scary-face.md) | Changed | Accuracy |
| [Feint Attack](../moves/feint-attack.md) | Changed | Name |
| [Sweet Kiss](../moves/sweet-kiss.md) | Changed | Type |
| [Detect](../moves/detect.md) | Changed | Priority |
| [Bone Rush](../moves/bone-rush.md) | Changed | Accuracy |
| [Outrage](../moves/outrage.md) | Changed | Pp |
| [Giga Drain](../moves/giga-drain.md) | Changed | Power |
| [Endure](../moves/endure.md) | Changed | Priority |
| [Charm](../moves/charm.md) | Changed | Type |
| [Swagger](../moves/swagger.md) | Changed | Accuracy |
| [Fury Cutter](../moves/fury-cutter.md) | Changed | Power |
| [Dynamic Punch](../moves/dynamic-punch.md) | Changed | Name |
| [Dragon Breath](../moves/dragon-breath.md) | Changed | Name |
| [Moonlight](../moves/moonlight.md) | Changed | Type |
| [Hurricane](../moves/hurricane.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Effect chance, Target, Flags, Contest effect, Machines |
| [Extreme Speed](../moves/extreme-speed.md) | Changed | Name, Priority |
| [Ancient Power](../moves/ancient-power.md) | Changed | Name |
| [Future Sight](../moves/future-sight.md) | Changed | Power, Accuracy, Pp |
| [Rock Smash](../moves/rock-smash.md) | Changed | Power |
| [Whirlpool](../moves/whirlpool.md) | Changed | Power, Accuracy |
| [Fake Out](../moves/fake-out.md) | Changed | Priority |
| [Uproar](../moves/uproar.md) | Changed | Power |
| [Heat Wave](../moves/heat-wave.md) | Changed | Power |
| [Will-O-Wisp](../moves/will-o-wisp.md) | Changed | Accuracy |
| [Smelling Salts](../moves/smelling-salts.md) | Changed | Name, Power |
| [Knock Off](../moves/knock-off.md) | Changed | Power |
| [Dazzling Gleam](../moves/dazzling-gleam.md) | Changed | Name, Type, Power, Pp, Effect, Effect chance, Target, Machines |
| [Disarming Voice](../moves/disarming-voice.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Effect chance, Target, Flags, Contest effect, Contest type |
| [Feather Dance](../moves/feather-dance.md) | Changed | Name |
| [Blaze Kick](../moves/blaze-kick.md) | Changed | Power, Accuracy |
| [Needle Arm](../moves/needle-arm.md) | Changed | Power |
| [Hyper Voice](../moves/hyper-voice.md) | Changed | Machines |
| [Poison Fang](../moves/poison-fang.md) | Changed | Power, Accuracy, Effect chance |
| [Meteor Mash](../moves/meteor-mash.md) | Changed | Power, Accuracy |
| [Air Cutter](../moves/air-cutter.md) | Changed | Power |
| [Overheat](../moves/overheat.md) | Changed | Power |
| [Rock Tomb](../moves/rock-tomb.md) | Changed | Power, Accuracy, Pp |
| [Silver Wind](../moves/silver-wind.md) | Changed | Machines |
| [Grass Whistle](../moves/grass-whistle.md) | Changed | Name |
| [Shadow Punch](../moves/shadow-punch.md) | Changed | Power, Pp |
| [Extrasensory](../moves/extrasensory.md) | Changed | Pp |
| [Bulldoze](../moves/bulldoze.md) | Changed | Name, Power, Accuracy, Pp, Effect, Effect chance, Target, Contest effect, Contest type |
| [Muddy Water](../moves/muddy-water.md) | Changed | Power |
| [Bullet Seed](../moves/bullet-seed.md) | Changed | Power |
| [Icicle Spear](../moves/icicle-spear.md) | Changed | Power |
| [Poison Tail](../moves/poison-tail.md) | Changed | Power, Pp |
| [Covet](../moves/covet.md) | Changed | Power, Pp |
| [Wild Charge](../moves/wild-charge.md) | Changed | Name, Power, Effect, Effect chance, Contest effect, Contest type, Machines |
| [Rock Blast](../moves/rock-blast.md) | Changed | Accuracy |
| [Doom Desire](../moves/doom-desire.md) | Changed | Power, Accuracy |
| [Wake-Up Slap](../moves/wake-up-slap.md) | Changed | Power |
| [Scald](../moves/scald.md) | Changed | Name, Power, Pp, Effect, Effect chance, Flags, Contest effect, Contest type |
| [Natural Gift](../moves/natural-gift.md) | Changed | Machines |
| [Pluck](../moves/pluck.md) | Changed | Machines |
| [Tailwind](../moves/tailwind.md) | Changed | Pp |
| [Assurance](../moves/assurance.md) | Changed | Power |
| [Psycho Shift](../moves/psycho-shift.md) | Changed | Accuracy |
| [Last Resort](../moves/last-resort.md) | Changed | Power |
| [Sucker Punch](../moves/sucker-punch.md) | Changed | Power |
| [Aura Sphere](../moves/aura-sphere.md) | Changed | Power |
| [Air Slash](../moves/air-slash.md) | Changed | Pp |
| [Bug Buzz](../moves/bug-buzz.md) | Changed | Machines |
| [Dragon Pulse](../moves/dragon-pulse.md) | Changed | Power |
| [Power Gem](../moves/power-gem.md) | Changed | Power |
| [Drain Punch](../moves/drain-punch.md) | Changed | Power, Pp |
| [Energy Ball](../moves/energy-ball.md) | Changed | Power |
| [Shadow Claw](../moves/shadow-claw.md) | Changed | Power |
| [Rock Climb](../moves/rock-climb.md) | Changed | Type, Power, Accuracy, Pp |
| [Draco Meteor](../moves/draco-meteor.md) | Changed | Power, Tutors |
| [Leaf Storm](../moves/leaf-storm.md) | Changed | Power |
| [Cross Poison](../moves/cross-poison.md) | Changed | Power, Pp |
| [Gunk Shot](../moves/gunk-shot.md) | Changed | Accuracy |
| [Chatter](../moves/chatter.md) | Changed | Power, Pp, Effect, Effect chance, Flags, Contest effect |
| [Charge Beam](../moves/charge-beam.md) | Changed | Machines |
| [Moonblast](../moves/moonblast.md) | Changed | Name, Type, Damage class, Power, Accuracy, Pp, Effect, Effect chance, Target, Flags, Contest effect |
| [Magma Storm](../moves/magma-storm.md) | Changed | Power, Accuracy |
| [Dark Void](../moves/dark-void.md) | Changed | Accuracy |

## Items

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Master Ball](../items/master-ball.md) | Changed | Locations |
| [Ultra Ball](../items/ultra-ball.md) | Changed | Price, Locations, Shops |
| [Great Ball](../items/great-ball.md) | Changed | Price, Locations, Shops |
| [Poké Ball](../items/poke-ball.md) | Changed | Price, Shops |
| [Luxury Ball](../items/luxury-ball.md) | Changed | Locations |
| [Quick Ball](../items/quick-ball.md) | Changed | Locations |
| [Potion](../items/potion.md) | Changed | Wild Held By, Trainer battle items |
| [Awakening](../items/awakening.md) | Changed | Locations |
| [Full Restore](../items/full-restore.md) | Changed | Trainer battle items |
| [Hyper Potion](../items/hyper-potion.md) | Changed | Trainer battle items |
| [Super Potion](../items/super-potion.md) | Changed | Trainer battle items |
| [Revive](../items/revive.md) | Changed | Wild Held By |
| [Max Revive](../items/max-revive.md) | Changed | Wild Held By |
| [Energy Powder](../items/energy-powder.md) | Changed | Name |
| [Ether](../items/ether.md) | Changed | Locations |
| [Berry Juice](../items/berry-juice.md) | Changed | Wild Held By |
| [Sacred Ash](../items/sacred-ash.md) | Changed | Locations |
| [Dire Hit](../items/dire-hit.md) | Changed | Locations |
| [X Attack](../items/x-attack.md) | Changed | Trainer battle items |
| [X Defend](../items/x-defend.md) | Changed | Locations, Trainer battle items |
| [X Accuracy](../items/x-accuracy.md) | Changed | Locations |
| [X Special](../items/x-special.md) | Changed | Trainer battle items |
| [Yellow Shard](../items/yellow-shard.md) | Changed | Locations |
| [Green Shard](../items/green-shard.md) | Changed | Locations |
| [Sun Stone](../items/sun-stone.md) | Changed | Evolutions |
| [Moon Stone](../items/moon-stone.md) | Changed | Wild Held By, Evolutions |
| [Thunder Stone](../items/thunder-stone.md) | Changed | Name |
| [Leaf Stone](../items/leaf-stone.md) | Changed | Evolutions |
| [Tiny Mushroom](../items/tiny-mushroom.md) | Changed | Name, Wild Held By |
| [Big Mushroom](../items/big-mushroom.md) | Changed | Locations, Wild Held By |
| [Pearl](../items/pearl.md) | Changed | Locations, Wild Held By |
| [Big Pearl](../items/big-pearl.md) | Changed | Wild Held By |
| [Stardust](../items/stardust.md) | Changed | Locations, Wild Held By |
| [Nugget](../items/nugget.md) | Changed | Locations, Wild Held By |
| [Honey](../items/honey.md) | Changed | Wild Held By |
| [Root Fossil](../items/root-fossil.md) | Changed | Locations |
| [Oval Stone](../items/oval-stone.md) | Changed | Locations, Wild Held By |
| [Griseous Orb](../items/griseous-orb.md) | Changed | Wild Held By |
| [Bubble Mail](../items/bubble-mail.md) | Changed | Locations |
| [Mosaic Mail](../items/mosaic-mail.md) | Changed | Locations |
| [Cheri Berry](../items/cheri-berry.md) | Changed | Wild Held By |
| [Chesto Berry](../items/chesto-berry.md) | Changed | Wild Held By |
| [Pecha Berry](../items/pecha-berry.md) | Changed | Locations, Wild Held By |
| [Rawst Berry](../items/rawst-berry.md) | Changed | Locations, Wild Held By |
| [Aspear Berry](../items/aspear-berry.md) | Changed | Locations, Wild Held By |
| [Leppa Berry](../items/leppa-berry.md) | Changed | Wild Held By, Trades |
| [Oran Berry](../items/oran-berry.md) | Changed | Wild Held By, Trainer Held By, Trades |
| [Persim Berry](../items/persim-berry.md) | Changed | Wild Held By |
| [Lum Berry](../items/lum-berry.md) | Changed | Trainer Held By, Trades |
| [Sitrus Berry](../items/sitrus-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Mago Berry](../items/mago-berry.md) | Changed | Locations |
| [Tamato Berry](../items/tamato-berry.md) | Changed | Locations |
| [Occa Berry](../items/occa-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Passho Berry](../items/passho-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Wacan Berry](../items/wacan-berry.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [Rindo Berry](../items/rindo-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Yache Berry](../items/yache-berry.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [Chople Berry](../items/chople-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Kebia Berry](../items/kebia-berry.md) | Changed | Wild Held By |
| [Shuca Berry](../items/shuca-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Coba Berry](../items/coba-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Payapa Berry](../items/payapa-berry.md) | Changed | Wild Held By |
| [Tanga Berry](../items/tanga-berry.md) | Changed | Wild Held By |
| [Charti Berry](../items/charti-berry.md) | Changed | Wild Held By |
| [Kasib Berry](../items/kasib-berry.md) | Changed | Wild Held By |
| [Haban Berry](../items/haban-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Colbur Berry](../items/colbur-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Babiri Berry](../items/babiri-berry.md) | Changed | Wild Held By |
| [Chilan Berry](../items/chilan-berry.md) | Changed | Locations, Wild Held By |
| [Liechi Berry](../items/liechi-berry.md) | Changed | Trainer Held By |
| [Salac Berry](../items/salac-berry.md) | Changed | Trainer Held By |
| [Petaya Berry](../items/petaya-berry.md) | Changed | Trainer Held By |
| [Starf Berry](../items/starf-berry.md) | Changed | Trainer Held By, Trades |
| [Jaboca Berry](../items/jaboca-berry.md) | Changed | Locations |
| [Rowap Berry](../items/rowap-berry.md) | Changed | Locations |
| [Bright Powder](../items/bright-powder.md) | Changed | Name, Wild Held By, Trainer Held By |
| [White Herb](../items/white-herb.md) | Changed | Trainer Held By |
| [Quick Claw](../items/quick-claw.md) | Changed | Wild Held By |
| [Mental Herb](../items/mental-herb.md) | Changed | Wild Held By |
| [Choice Band](../items/choice-band.md) | Changed | Trainer Held By |
| [King's Rock](../items/kings-rock.md) | Changed | Field use, Field-use function, Party use, Party effects, Trainer Held By, Evolutions |
| [Cleanse Tag](../items/cleanse-tag.md) | Changed | Wild Held By |
| [Deep Sea Tooth](../items/deep-sea-tooth.md) | Changed | Name, Field use, Field-use function, Party use, Party effects, Evolutions |
| [Deep Sea Scale](../items/deep-sea-scale.md) | Changed | Name, Field use, Field-use function, Party use, Party effects, Evolutions |
| [Smoke Ball](../items/smoke-ball.md) | Changed | Wild Held By |
| [Everstone](../items/everstone.md) | Changed | Trades |
| [Focus Band](../items/focus-band.md) | Changed | Locations, Wild Held By |
| [Lucky Egg](../items/lucky-egg.md) | Changed | Wild Held By |
| [Scope Lens](../items/scope-lens.md) | Changed | Trainer Held By |
| [Metal Coat](../items/metal-coat.md) | Changed | Field use, Field-use function, Party use, Party effects, Wild Held By, Evolutions |
| [Leftovers](../items/leftovers.md) | Changed | Trainer Held By |
| [Dragon Scale](../items/dragon-scale.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Light Ball](../items/light-ball.md) | Changed | Trainer Held By |
| [Soft Sand](../items/soft-sand.md) | Changed | Wild Held By |
| [Hard Stone](../items/hard-stone.md) | Changed | Wild Held By, Trainer Held By |
| [Miracle Seed](../items/miracle-seed.md) | Changed | Trainer Held By, Gifts |
| [Black Glasses](../items/black-glasses.md) | Changed | Name |
| [Black Belt](../items/black-belt.md) | Changed | Wild Held By |
| [Magnet](../items/magnet.md) | Changed | Wild Held By |
| [Mystic Water](../items/mystic-water.md) | Changed | Wild Held By, Trainer Held By, Gifts |
| [Sharp Beak](../items/sharp-beak.md) | Changed | Wild Held By, Trainer Held By, Trades |
| [Poison Barb](../items/poison-barb.md) | Changed | Trainer Held By, Trades |
| [Never-Melt Ice](../items/never-melt-ice.md) | Changed | Name, Gifts, Trades |
| [Spell Tag](../items/spell-tag.md) | Changed | Wild Held By, Trainer Held By |
| [Twisted Spoon](../items/twisted-spoon.md) | Changed | Name |
| [Charcoal](../items/charcoal.md) | Changed | Wild Held By, Trainer Held By, Gifts |
| [Dragon Fang](../items/dragon-fang.md) | Changed | Trainer Held By |
| [Silk Scarf](../items/silk-scarf.md) | Changed | Locations, Trainer Held By |
| [Up-Grade](../items/up-grade.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Shell Bell](../items/shell-bell.md) | Changed | Trainer Held By |
| [Lax Incense](../items/lax-incense.md) | Changed | Locations |
| [Lucky Punch](../items/lucky-punch.md) | Changed | Wild Held By |
| [Thick Club](../items/thick-club.md) | Changed | Trainer Held By |
| [Wide Lens](../items/wide-lens.md) | Changed | Wild Held By, Trainer Held By |
| [Muscle Band](../items/muscle-band.md) | Changed | Trainer Held By |
| [Wise Glasses](../items/wise-glasses.md) | Changed | Trainer Held By |
| [Expert Belt](../items/expert-belt.md) | Changed | Trainer Held By |
| [Light Clay](../items/light-clay.md) | Changed | Wild Held By, Trainer Held By |
| [Life Orb](../items/life-orb.md) | Changed | Wild Held By, Trainer Held By |
| [Power Herb](../items/power-herb.md) | Changed | Wild Held By, Trainer Held By |
| [Toxic Orb](../items/toxic-orb.md) | Changed | Trainer Held By |
| [Flame Orb](../items/flame-orb.md) | Changed | Trainer Held By |
| [Focus Sash](../items/focus-sash.md) | Changed | Trainer Held By |
| [Zoom Lens](../items/zoom-lens.md) | Changed | Trainer Held By |
| [Iron Ball](../items/iron-ball.md) | Changed | Wild Held By |
| [Black Sludge](../items/black-sludge.md) | Changed | Wild Held By, Trainer Held By |
| [Smooth Rock](../items/smooth-rock.md) | Changed | Trainer Held By |
| [Heat Rock](../items/heat-rock.md) | Changed | Trainer Held By |
| [Damp Rock](../items/damp-rock.md) | Changed | Trainer Held By |
| [Grip Claw](../items/grip-claw.md) | Changed | Wild Held By |
| [Choice Scarf](../items/choice-scarf.md) | Changed | Trainer Held By |
| [Shed Shell](../items/shed-shell.md) | Changed | Wild Held By |
| [Big Root](../items/big-root.md) | Changed | Trainer Held By |
| [Choice Specs](../items/choice-specs.md) | Changed | Trainer Held By |
| [Mind Plate](../items/mind-plate.md) | Changed | Trainer Held By |
| [Spooky Plate](../items/spooky-plate.md) | Changed | Trainer Held By |
| [Rose Incense](../items/rose-incense.md) | Changed | Locations |
| [Protector](../items/protector.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Electirizer](../items/electirizer.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Magmarizer](../items/magmarizer.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Dubious Disc](../items/dubious-disc.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [Reaper Cloth](../items/reaper-cloth.md) | Changed | Field use, Field-use function, Party use, Party effects, Evolutions |
| [TM01](../items/tm01.md) | Changed | Price |
| [TM02](../items/tm02.md) | Changed | Price |
| [TM03](../items/tm03.md) | Changed | Price |
| [TM04](../items/tm04.md) | Changed | Price, Shops |
| [TM05](../items/tm05.md) | Changed | Price |
| [TM06](../items/tm06.md) | Changed | Price, Shops |
| [TM07](../items/tm07.md) | Changed | Price |
| [TM08](../items/tm08.md) | Changed | Price, Shops |
| [TM09](../items/tm09.md) | Changed | Price |
| [TM10](../items/tm10.md) | Changed | Price |
| [TM11](../items/tm11.md) | Changed | Price |
| [TM12](../items/tm12.md) | Changed | Price |
| [TM13](../items/tm13.md) | Changed | Price |
| [TM14](../items/tm14.md) | Changed | Price |
| [TM15](../items/tm15.md) | Changed | Price |
| [TM16](../items/tm16.md) | Changed | Price |
| [TM17](../items/tm17.md) | Changed | Price |
| [TM18](../items/tm18.md) | Changed | Price |
| [TM19](../items/tm19.md) | Changed | Price |
| [TM20](../items/tm20.md) | Changed | Price |
| [TM21](../items/tm21.md) | Changed | Price |
| [TM22](../items/tm22.md) | Changed | Price |
| [TM23](../items/tm23.md) | Changed | Price |
| [TM24](../items/tm24.md) | Changed | Price |
| [TM25](../items/tm25.md) | Changed | Price |
| [TM26](../items/tm26.md) | Changed | Price, Shops |
| [TM27](../items/tm27.md) | Changed | Price |
| [TM28](../items/tm28.md) | Changed | Price |
| [TM29](../items/tm29.md) | Changed | Price |
| [TM30](../items/tm30.md) | Changed | Price, Shops |
| [TM31](../items/tm31.md) | Changed | Price, Shops |
| [TM32](../items/tm32.md) | Changed | Price |
| [TM33](../items/tm33.md) | Changed | Price |
| [TM34](../items/tm34.md) | Changed | Price |
| [TM35](../items/tm35.md) | Changed | Price |
| [TM36](../items/tm36.md) | Changed | Price, Shops |
| [TM37](../items/tm37.md) | Changed | Price |
| [TM38](../items/tm38.md) | Changed | Price |
| [TM39](../items/tm39.md) | Changed | Price |
| [TM40](../items/tm40.md) | Changed | Price, Shops |
| [TM41](../items/tm41.md) | Changed | Price |
| [TM42](../items/tm42.md) | Changed | Price |
| [TM43](../items/tm43.md) | Changed | Price |
| [TM44](../items/tm44.md) | Changed | Price |
| [TM45](../items/tm45.md) | Changed | Price, Shops |
| [TM46](../items/tm46.md) | Changed | Price |
| [TM47](../items/tm47.md) | Changed | Price |
| [TM48](../items/tm48.md) | Changed | Price |
| [TM49](../items/tm49.md) | Changed | Price |
| [TM50](../items/tm50.md) | Changed | Price |
| [TM51](../items/tm51.md) | Changed | Price |
| [TM52](../items/tm52.md) | Changed | Price |
| [TM53](../items/tm53.md) | Changed | Price, Shops |
| [TM54](../items/tm54.md) | Changed | Price |
| [TM55](../items/tm55.md) | Changed | Price |
| [TM56](../items/tm56.md) | Changed | Price |
| [TM57](../items/tm57.md) | Changed | Price |
| [TM58](../items/tm58.md) | Changed | Price |
| [TM59](../items/tm59.md) | Changed | Price, Shops |
| [TM60](../items/tm60.md) | Changed | Price |
| [TM61](../items/tm61.md) | Changed | Price, Shops |
| [TM62](../items/tm62.md) | Changed | Price |
| [TM63](../items/tm63.md) | Changed | Price |
| [TM64](../items/tm64.md) | Changed | Price |
| [TM65](../items/tm65.md) | Changed | Price |
| [TM66](../items/tm66.md) | Changed | Price |
| [TM67](../items/tm67.md) | Changed | Price |
| [TM68](../items/tm68.md) | Changed | Price |
| [TM69](../items/tm69.md) | Changed | Price |
| [TM70](../items/tm70.md) | Changed | Price |
| [TM71](../items/tm71.md) | Changed | Price, Shops |
| [TM72](../items/tm72.md) | Changed | Price |
| [TM73](../items/tm73.md) | Changed | Price, Shops |
| [TM74](../items/tm74.md) | Changed | Price |
| [TM75](../items/tm75.md) | Changed | Price |
| [TM76](../items/tm76.md) | Changed | Price |
| [TM77](../items/tm77.md) | Changed | Price |
| [TM78](../items/tm78.md) | Changed | Price |
| [TM79](../items/tm79.md) | Changed | Price |
| [TM80](../items/tm80.md) | Changed | Price |
| [TM81](../items/tm81.md) | Changed | Price, Shops |
| [TM82](../items/tm82.md) | Changed | Price |
| [TM83](../items/tm83.md) | Changed | Price |
| [TM84](../items/tm84.md) | Changed | Price |
| [TM85](../items/tm85.md) | Changed | Price |
| [TM86](../items/tm86.md) | Changed | Price |
| [TM87](../items/tm87.md) | Changed | Price |
| [TM88](../items/tm88.md) | Changed | Price |
| [TM89](../items/tm89.md) | Changed | Price |
| [TM90](../items/tm90.md) | Changed | Price |
| [TM91](../items/tm91.md) | Changed | Price |
| [TM92](../items/tm92.md) | Changed | Price |
| [Prism Scale](../items/prism-scale.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Evolutions |
| [Rainbow Wing](../items/rainbow-wing.md) | Changed | Name |
| [Silver Wing](../items/silver-wing.md) | Changed | Name |
| [GS Ball](../items/gs-ball.md) | Changed | Name |
| [Tea](../items/tea.md) | Changed | Name |
| [Ice Stone](../items/ice-stone.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Evolutions |
| [Red Orb](../items/red-orb.md) | Changed | Name |
| [Blue Orb](../items/blue-orb.md) | Changed | Name |
| [Jade Orb](../items/jade-orb.md) | Changed | Name |
| [Odd Invitation](../items/odd-invitation.md) | Changed | Name |
| [Secret Potion](../items/secret-potion.md) | Changed | Name |

## Wild encounters

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Canalave City](../encounters/area-000.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Eterna City](../encounters/area-001.md) | Changed | Old Rod, Good Rod, Super Rod |
| [Pastoria City](../encounters/area-002.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Sunyshore City](../encounters/area-003.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Pokémon League](../encounters/area-004.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Oreburgh Mine](../encounters/area-005.md) | Changed | Walking, Special |
| [Oreburgh Mine](../encounters/area-006.md) | Changed | Walking, Special |
| [Valley Windworks](../encounters/area-007.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Eterna Forest](../encounters/area-008.md) | Changed | Walking, Special |
| [Fuego Ironworks](../encounters/area-009.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Coronet](../encounters/area-010.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Coronet](../encounters/area-011.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-012.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-013.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-014.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-015.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Coronet](../encounters/area-016.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-017.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-018.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-019.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-020.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-021.md) | Changed | Walking, Special |
| [Mt. Coronet](../encounters/area-022.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-023.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-024.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-025.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-026.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-027.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Great Marsh](../encounters/area-028.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Victory Road](../encounters/area-047.md) | Changed | Walking, Special |
| [Victory Road](../encounters/area-048.md) | Changed | Walking, Special |
| [Victory Road](../encounters/area-049.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Victory Road](../encounters/area-050.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Victory Road](../encounters/area-051.md) | Changed | Walking, Special |
| [Victory Road](../encounters/area-052.md) | Changed | Walking, Special |
| [Ravaged Path](../encounters/area-053.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Oreburgh Gate](../encounters/area-054.md) | Changed | Walking, Special |
| [Oreburgh Gate](../encounters/area-055.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Stark Mountain](../encounters/area-056.md) | Changed | Walking, Special |
| [Stark Mountain](../encounters/area-057.md) | Changed | Walking, Special |
| [Stark Mountain](../encounters/area-058.md) | Changed | Walking, Special |
| [Sendoff Spring](../encounters/area-059.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Encounter Area 060](../encounters/area-060.md) | Changed | Walking, Special |
| [Turnback Cave](../encounters/area-061.md) | Changed | Name, Locations, Walking, Special |
| [Encounter Area 063](../encounters/area-063.md) | Changed | Name, Locations |
| [Encounter Area 064](../encounters/area-064.md) | Changed | Name, Locations |
| [Encounter Area 065](../encounters/area-065.md) | Changed | Name, Locations |
| [Encounter Area 066](../encounters/area-066.md) | Changed | Name, Locations |
| [Encounter Area 067](../encounters/area-067.md) | Changed | Name, Locations |
| [Encounter Area 068](../encounters/area-068.md) | Changed | Name, Locations |
| [Encounter Area 069](../encounters/area-069.md) | Changed | Name, Locations |
| [Encounter Area 070](../encounters/area-070.md) | Changed | Name, Locations |
| [Encounter Area 071](../encounters/area-071.md) | Changed | Name, Locations |
| [Encounter Area 072](../encounters/area-072.md) | Changed | Name, Locations |
| [Encounter Area 073](../encounters/area-073.md) | Changed | Name, Locations |
| [Encounter Area 074](../encounters/area-074.md) | Changed | Name, Locations |
| [Encounter Area 075](../encounters/area-075.md) | Changed | Name, Locations |
| [Encounter Area 076](../encounters/area-076.md) | Changed | Name, Locations |
| [Encounter Area 077](../encounters/area-077.md) | Changed | Name, Locations |
| [Encounter Area 078](../encounters/area-078.md) | Changed | Name, Locations |
| [Encounter Area 079](../encounters/area-079.md) | Changed | Name, Locations |
| [Snowpoint Temple](../encounters/area-106.md) | Changed | Walking, Special |
| [Snowpoint Temple](../encounters/area-107.md) | Changed | Walking, Special |
| [Snowpoint Temple](../encounters/area-108.md) | Changed | Walking, Special |
| [Snowpoint Temple](../encounters/area-109.md) | Changed | Walking, Special |
| [Snowpoint Temple](../encounters/area-110.md) | Changed | Walking, Special |
| [Snowpoint Temple](../encounters/area-111.md) | Changed | Walking, Special |
| [Wayward Cave](../encounters/area-112.md) | Changed | Walking, Special |
| [Wayward Cave](../encounters/area-113.md) | Changed | Walking, Special |
| [Maniac Tunnel](../encounters/area-116.md) | Changed | Walking, Special |
| [Trophy Garden](../encounters/area-117.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-118.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Iron Island](../encounters/area-119.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-120.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-121.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-122.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-123.md) | Changed | Walking, Special |
| [Iron Island](../encounters/area-124.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-125.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-126.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-127.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-128.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-129.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-130.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-131.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-132.md) | Changed | Walking, Special |
| [Old Chateau](../encounters/area-133.md) | Changed | Walking, Special |
| [Lake Verity](../encounters/area-134.md) | Changed | Locations, Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Encounter Area 135](../encounters/area-135.md) | Changed | Name, Locations |
| [Lake Valor](../encounters/area-136.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Lake Acuity](../encounters/area-137.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Valor Lakefront](../encounters/area-138.md) | Changed | Walking, Special |
| [Acuity Lakefront](../encounters/area-139.md) | Changed | Walking, Special |
| [Route 201](../encounters/area-140.md) | Changed | Walking, Special |
| [Route 202](../encounters/area-141.md) | Changed | Walking, Special |
| [Route 203](../encounters/area-142.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 204](../encounters/area-143.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 204](../encounters/area-144.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 205](../encounters/area-145.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 205](../encounters/area-146.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 206](../encounters/area-147.md) | Changed | Walking, Special |
| [Route 207](../encounters/area-148.md) | Changed | Walking, Special |
| [Route 208](../encounters/area-149.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 209](../encounters/area-150.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 209](../encounters/area-151.md) | Changed | Walking, Special |
| [Route 209](../encounters/area-152.md) | Changed | Walking, Special |
| [Route 209](../encounters/area-153.md) | Changed | Walking, Special |
| [Route 209](../encounters/area-154.md) | Changed | Walking, Special |
| [Route 209](../encounters/area-155.md) | Changed | Walking, Special |
| [Route 210](../encounters/area-156.md) | Changed | Walking, Special |
| [Route 210](../encounters/area-157.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 211](../encounters/area-158.md) | Changed | Walking, Special |
| [Route 211](../encounters/area-159.md) | Changed | Walking, Special |
| [Route 212](../encounters/area-160.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 212](../encounters/area-161.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 213](../encounters/area-162.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 214](../encounters/area-163.md) | Changed | Walking, Old Rod, Good Rod, Super Rod, Special |
| [Route 215](../encounters/area-164.md) | Changed | Walking, Special |
| [Route 216](../encounters/area-165.md) | Changed | Walking, Special |
| [Route 217](../encounters/area-166.md) | Changed | Walking, Super Rod, Special |
| [Route 218](../encounters/area-167.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 219](../encounters/area-168.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Route 221](../encounters/area-169.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 222](../encounters/area-170.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 224](../encounters/area-171.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 225](../encounters/area-172.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 227](../encounters/area-173.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 228](../encounters/area-174.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 229](../encounters/area-175.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Twinleaf Town](../encounters/area-176.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Celestic Town](../encounters/area-177.md) | Changed | Old Rod, Good Rod, Super Rod |
| [Resort Area](../encounters/area-178.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Route 220](../encounters/area-179.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Route 223](../encounters/area-180.md) | Changed | Surf, Old Rod, Good Rod, Super Rod |
| [Route 226](../encounters/area-181.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 230](../encounters/area-182.md) | Changed | Walking, Surf, Old Rod, Good Rod, Super Rod, Special |

## Trainers

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Youngster Tristan](../trainers/trainer-0001.md) | Changed | AI flags, Party, Locations |
| [Youngster Logan](../trainers/trainer-0002.md) | Changed | AI flags, Party |
| [Lass Natalie](../trainers/trainer-0003.md) | Changed | AI flags, Party, Locations |
| [Youngster Michael](../trainers/trainer-0004.md) | Changed | AI flags, Party, Locations |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Camper Mickey](../trainers/trainer-0006.md) | Changed | Party |
| [Picnicker Angelica](../trainers/trainer-0007.md) | Changed | Party |
| [Picnicker Angelica](../trainers/trainer-0008.md) | Changed | Party |
| [Youngster Mickey](../trainers/trainer-0009.md) | Changed | Party |
| [Youngster Tyler](../trainers/trainer-0010.md) | Changed | AI flags, Party |
| [Lass Samantha](../trainers/trainer-0011.md) | Changed | AI flags, Party |
| [Lass Sarah](../trainers/trainer-0012.md) | Changed | AI flags, Party |
| [Bug Catcher Brandon](../trainers/trainer-0013.md) | Changed | AI flags, Party |
| [Aroma Lady Taylor](../trainers/trainer-0014.md) | Changed | AI flags, Party |
| [Twins Liv & Liz](../trainers/trainer-0015.md) | Changed | AI flags, Party |
| [Camper Jacob](../trainers/trainer-0016.md) | Changed | Party |
| [Picnicker Siena](../trainers/trainer-0017.md) | Changed | Party |
| [Hiker Daniel](../trainers/trainer-0018.md) | Changed | AI flags, Party, Locations |
| [Hiker Nicholas](../trainers/trainer-0019.md) | Changed | AI flags, Party |
| [Battle Girl Kelsey](../trainers/trainer-0020.md) | Changed | AI flags, Party |
| [Aroma Lady Elizabeth](../trainers/trainer-0021.md) | Changed | AI flags, Party |
| [Fisherman Andrew](../trainers/trainer-0022.md) | Changed | AI flags, Party |
| [Fisherman Joseph](../trainers/trainer-0023.md) | Changed | AI flags, Party |
| [Fisherman Zachary](../trainers/trainer-0024.md) | Changed | AI flags, Party |
| [Cyclist Axel](../trainers/trainer-0025.md) | Changed | AI flags, Party |
| [Cyclist James](../trainers/trainer-0026.md) | Changed | AI flags, Party |
| [Cyclist John](../trainers/trainer-0027.md) | Changed | AI flags, Party |
| [Cyclist Ryan](../trainers/trainer-0028.md) | Changed | AI flags, Party |
| [Cyclist Megan](../trainers/trainer-0029.md) | Changed | AI flags, Party |
| [Cyclist Nicole](../trainers/trainer-0030.md) | Changed | AI flags, Party |
| [Cyclist Kayla](../trainers/trainer-0031.md) | Changed | AI flags, Party |
| [Cyclist Rachel](../trainers/trainer-0032.md) | Changed | AI flags, Party |
| [Youngster Austin](../trainers/trainer-0033.md) | Changed | AI flags, Party |
| [Camper Anthony](../trainers/trainer-0034.md) | Changed | Party |
| [Picnicker Lauren](../trainers/trainer-0035.md) | Changed | Party |
| [Hiker Kevin](../trainers/trainer-0036.md) | Changed | AI flags, Party |
| [Hiker Justin](../trainers/trainer-0037.md) | Changed | Party |
| [Battle Girl Helen](../trainers/trainer-0038.md) | Changed | AI flags, Party |
| [Hiker Robert](../trainers/trainer-0039.md) | Changed | AI flags, Party |
| [Hiker Alexander](../trainers/trainer-0040.md) | Changed | AI flags, Party, Locations |
| [Hiker Jonathan](../trainers/trainer-0041.md) | Changed | AI flags, Party |
| [Black Belt Kyle](../trainers/trainer-0042.md) | Changed | AI flags, Party |
| [Fisherman Cody](../trainers/trainer-0043.md) | Changed | Party |
| [Aroma Lady Hannah](../trainers/trainer-0044.md) | Changed | AI flags, Party |
| [Artist William](../trainers/trainer-0045.md) | Changed | AI flags, Party |
| [Pokémon Breeder Albert](../trainers/trainer-0046.md) | Changed | AI flags, Party, Locations |
| [Pokémon Breeder Jennifer](../trainers/trainer-0047.md) | Changed | AI flags, Party |
| [Cowgirl Shelley](../trainers/trainer-0048.md) | Changed | AI flags, Party |
| [Jogger Richard](../trainers/trainer-0049.md) | Changed | AI flags, Party |
| [Pokéfan Mickey](../trainers/trainer-0050.md) | Changed | Party |
| [Pokéfan Angelica](../trainers/trainer-0051.md) | Changed | Party |
| [Youngster Mickey](../trainers/trainer-0052.md) | Changed | Party |
| [Poké Kid Danielle](../trainers/trainer-0053.md) | Changed | AI flags, Party |
| [Fisherman Mickey](../trainers/trainer-0054.md) | Changed | Party |
| [Young Couple Ty & Sue](../trainers/trainer-0055.md) | Changed | AI flags, Party |
| [Pokémon Breeder Kahlil](../trainers/trainer-0056.md) | Changed | AI flags, Party |
| [Pokémon Breeder Amber](../trainers/trainer-0057.md) | Changed | AI flags, Party |
| [Cowgirl Angelica](../trainers/trainer-0058.md) | Changed | Party |
| [Jogger Mickey](../trainers/trainer-0059.md) | Changed | Party |
| [Pokéfan Mickey](../trainers/trainer-0060.md) | Changed | Party |
| [Pokéfan Angelica](../trainers/trainer-0061.md) | Changed | Party |
| [Ace Trainer Mickey](../trainers/trainer-0062.md) | Changed | Party |
| [Ace Trainer Angelica](../trainers/trainer-0063.md) | Changed | Party |
| [Waitress Angelica](../trainers/trainer-0064.md) | Changed | Party |
| [Twins Teri&Tia](../trainers/trainer-0065.md) | Changed | Name, AI flags, Party |
| [Ace Trainer Ernest](../trainers/trainer-0066.md) | Changed | Party |
| [Ace Trainer Alyssa](../trainers/trainer-0067.md) | Changed | Party |
| [Veteran Brian](../trainers/trainer-0068.md) | Changed | Party |
| [Black Belt Adam](../trainers/trainer-0069.md) | Changed | AI flags, Party |
| [Ninja Boy Joel](../trainers/trainer-0070.md) | Changed | AI flags, Party |
| [Ninja Boy Nathan](../trainers/trainer-0071.md) | Changed | AI flags, Party |
| [Ninja Boy Davido](../trainers/trainer-0072.md) | Changed | AI flags, Party |
| [Dragon Tamer Patrick](../trainers/trainer-0073.md) | Changed | Party, Locations |
| [Bird Keeper Brianna](../trainers/trainer-0074.md) | Changed | AI flags, Party |
| [Double Team Zac & Jen](../trainers/trainer-0075.md) | Changed | AI flags, Party |
| [Bird Keeper Alexandra](../trainers/trainer-0076.md) | Changed | AI flags, Party |
| [Battle Girl Angelica](../trainers/trainer-0077.md) | Changed | Party |
| [Ninja Boy Zach](../trainers/trainer-0078.md) | Changed | AI flags, Party |
| [Black Belt Sean](../trainers/trainer-0079.md) | Changed | AI flags, Party |
| [Ninja Boy Nick](../trainers/trainer-0080.md) | Changed | AI flags, Party, Locations |
| [Bird Keeper Katherine](../trainers/trainer-0081.md) | Changed | AI flags, Party, Locations |
| [Rich Boy Jason](../trainers/trainer-0082.md) | Changed | AI flags, Party |
| [Lady Melissa](../trainers/trainer-0083.md) | Changed | AI flags, Party |
| [Gentleman Jeremy](../trainers/trainer-0084.md) | Changed | AI flags, Party |
| [Socialite Reina](../trainers/trainer-0085.md) | Changed | AI flags, Party |
| [Beauty Angelica](../trainers/trainer-0086.md) | Changed | Party |
| [Collector Mickey](../trainers/trainer-0087.md) | Changed | Party |
| [Policeman Bobby](../trainers/trainer-0088.md) | Changed | AI flags, Party |
| [Policeman Alex](../trainers/trainer-0089.md) | Changed | AI flags, Party |
| [Policeman Dylan](../trainers/trainer-0090.md) | Changed | AI flags, Party |
| [Fisherman Juan](../trainers/trainer-0091.md) | Changed | AI flags, Party |
| [Fisherman Josh](../trainers/trainer-0092.md) | Changed | AI flags, Party |
| [Fisherman Travis](../trainers/trainer-0093.md) | Changed | AI flags, Party |
| [Pokémon Ranger Taylor](../trainers/trainer-0094.md) | Changed | Party |
| [Pokémon Ranger Jeffrey](../trainers/trainer-0095.md) | Changed | Party |
| [Pokémon Ranger Allison](../trainers/trainer-0096.md) | Changed | Party |
| [Pokémon Ranger Angelica](../trainers/trainer-0097.md) | Changed | Party |
| [Scientist Mickey](../trainers/trainer-0098.md) | Changed | Party |
| [Scientist Stefano](../trainers/trainer-0099.md) | Changed | AI flags, Party |
| [Youngster Mickey](../trainers/trainer-0100.md) | Changed | Party |
| [Youngster Mickey](../trainers/trainer-0101.md) | Changed | Party |
| [Policeman Caleb](../trainers/trainer-0102.md) | Changed | AI flags, Party |
| [Swimmer♂ Sheltin](../trainers/trainer-0103.md) | Changed | AI flags, Party |
| [Swimmer♂ Evan](../trainers/trainer-0104.md) | Changed | AI flags, Party |
| [Swimmer♀ Haley](../trainers/trainer-0105.md) | Changed | AI flags, Party |
| [Swimmer♀ Mary](../trainers/trainer-0106.md) | Changed | Party |
| [Tuber Jared](../trainers/trainer-0107.md) | Changed | AI flags, Party |
| [Tuber Chelsea](../trainers/trainer-0108.md) | Changed | AI flags, Party |
| [Battle Girl Angelica](../trainers/trainer-0109.md) | Changed | Party |
| [Sailor Paul](../trainers/trainer-0110.md) | Changed | AI flags, Party |
| [Fisherman Kenneth](../trainers/trainer-0111.md) | Changed | AI flags, Party |
| [Sis and Bro Tara nd Tim](../trainers/trainer-0112.md) | Changed | Name, Party |
| [Ruin Maniac Bryan](../trainers/trainer-0113.md) | Changed | Party |
| [Ruin Maniac Ronald](../trainers/trainer-0114.md) | Changed | Party |
| [Hiker Mickey](../trainers/trainer-0115.md) | Changed | Party |
| [Veteran Mickey](../trainers/trainer-0116.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0117.md) | Changed | Party |
| [Picnicker Angelica](../trainers/trainer-0118.md) | Changed | Party |
| [Psychic Mitchell](../trainers/trainer-0119.md) | Changed | AI flags, Party |
| [Psychic Abigail](../trainers/trainer-0120.md) | Changed | AI flags, Party |
| [PI Carlos](../trainers/trainer-0121.md) | Changed | AI flags, Party |
| [Guitarist Mickey](../trainers/trainer-0122.md) | Changed | Party |
| [PI Mickey](../trainers/trainer-0123.md) | Changed | Party |
| [Beauty Angelica](../trainers/trainer-0124.md) | Changed | Party |
| [Beauty Angelica](../trainers/trainer-0125.md) | Changed | Party |
| [Black Belt Mickey](../trainers/trainer-0126.md) | Changed | Party |
| [Black Belt Gregory](../trainers/trainer-0127.md) | Changed | AI flags, Party |
| [Black Belt Derek](../trainers/trainer-0128.md) | Changed | AI flags, Party |
| [Black Belt Nathaniel](../trainers/trainer-0129.md) | Changed | AI flags, Party |
| [Jogger Scott](../trainers/trainer-0130.md) | Changed | AI flags, Party |
| [Bird Keeper Angelica](../trainers/trainer-0131.md) | Changed | Party |
| [Ace Trainer Blake](../trainers/trainer-0132.md) | Changed | Party |
| [Ace Trainer Garrett](../trainers/trainer-0133.md) | Changed | Party |
| [Ace Trainer Laura](../trainers/trainer-0134.md) | Changed | Party |
| [Ace Trainer Maria](../trainers/trainer-0135.md) | Changed | Party |
| [Skier Bradley](../trainers/trainer-0136.md) | Changed | AI flags, Party |
| [Skier Edward](../trainers/trainer-0137.md) | Changed | AI flags, Party |
| [Skier Kaitlyn](../trainers/trainer-0138.md) | Changed | AI flags, Party |
| [Skier Andrea](../trainers/trainer-0139.md) | Changed | AI flags, Party |
| [Ace Trainer Dalton](../trainers/trainer-0140.md) | Changed | Party |
| [Ace Trainer Olivia](../trainers/trainer-0141.md) | Changed | Party |
| [Skier Shawn](../trainers/trainer-0142.md) | Changed | AI flags, Party |
| [Skier Bjorn](../trainers/trainer-0143.md) | Changed | AI flags, Party |
| [Skier Lexie](../trainers/trainer-0144.md) | Changed | AI flags, Party |
| [Skier Madison](../trainers/trainer-0145.md) | Changed | AI flags, Party |
| [Ninja Boy Matthew](../trainers/trainer-0146.md) | Changed | AI flags, Party |
| [Ninja Boy Ethan](../trainers/trainer-0147.md) | Changed | AI flags, Party |
| [Black Belt Luke](../trainers/trainer-0148.md) | Changed | AI flags, Party |
| [Swimmer♂ Mickey](../trainers/trainer-0149.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0150.md) | Changed | Party |
| [Swimmer♀ Angelica](../trainers/trainer-0151.md) | Changed | Party |
| [Swimmer♀ Angelica](../trainers/trainer-0152.md) | Changed | Party |
| [Fisherman Miguel](../trainers/trainer-0153.md) | Changed | AI flags, Party |
| [Fisherman Luc](../trainers/trainer-0154.md) | Changed | AI flags, Party |
| [Sis and Bro Tara nd Tim](../trainers/trainer-0155.md) | Changed | Name, Party |
| [Swimmer♂ Mickey](../trainers/trainer-0156.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0157.md) | Changed | Party |
| [Swimmer♀ Angelica](../trainers/trainer-0158.md) | Changed | Party |
| [Swimmer♂ Adrian](../trainers/trainer-0159.md) | Changed | AI flags, Party |
| [Swimmer♂ Erik](../trainers/trainer-0160.md) | Changed | AI flags, Party |
| [Swimmer♂ Vincent](../trainers/trainer-0161.md) | Changed | AI flags, Party |
| [Swimmer♀ Jessica](../trainers/trainer-0162.md) | Changed | AI flags, Party |
| [Swimmer♀ Erica](../trainers/trainer-0163.md) | Changed | AI flags, Party |
| [Swimmer♀ Katelyn](../trainers/trainer-0164.md) | Changed | AI flags, Party |
| [Sis and Bro Tara nd Tim](../trainers/trainer-0165.md) | Changed | Name, Party |
| [Swimmer♂ Dillon](../trainers/trainer-0166.md) | Changed | AI flags, Party |
| [Swimmer♀ Vanessa](../trainers/trainer-0167.md) | Changed | AI flags, Party |
| [Fisherman Cory](../trainers/trainer-0168.md) | Changed | Party |
| [Ruin Maniac Mickey](../trainers/trainer-0169.md) | Changed | Party |
| [Ace Trainer Jake](../trainers/trainer-0170.md) | Changed | Party |
| [Ace Trainer Shannon](../trainers/trainer-0171.md) | Changed | Party |
| [Fisherman Brett](../trainers/trainer-0172.md) | Changed | AI flags, Party |
| [Fisherman Alec](../trainers/trainer-0173.md) | Changed | AI flags, Party |
| [Fisherman George](../trainers/trainer-0174.md) | Changed | AI flags, Party |
| [Fisherman Cole](../trainers/trainer-0175.md) | Changed | AI flags, Party |
| [Roughneck Mickey](../trainers/trainer-0176.md) | Changed | Party |
| [Roughneck Mickey](../trainers/trainer-0177.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0178.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0179.md) | Changed | Party |
| [Sailor Luther](../trainers/trainer-0180.md) | Changed | AI flags, Party |
| [Artist Mickey](../trainers/trainer-0181.md) | Changed | Party |
| [Young Couple Tara nd Tim](../trainers/trainer-0182.md) | Changed | Name, Party |
| [Swimmer♂ Wesley](../trainers/trainer-0183.md) | Changed | AI flags, Party |
| [Swimmer♂ Ricardo](../trainers/trainer-0184.md) | Changed | AI flags, Party |
| [Swimmer♂ Francisco](../trainers/trainer-0185.md) | Changed | AI flags, Party |
| [Swimmer♂ Colton](../trainers/trainer-0186.md) | Changed | AI flags, Party |
| [Swimmer♂ Troy](../trainers/trainer-0187.md) | Changed | AI flags, Party |
| [Swimmer♂ Oscar](../trainers/trainer-0188.md) | Changed | AI flags, Party |
| [Swimmer♀ Miranda](../trainers/trainer-0189.md) | Changed | AI flags, Party |
| [Swimmer♀ Aubree](../trainers/trainer-0190.md) | Changed | AI flags, Party |
| [Swimmer♀ Paige](../trainers/trainer-0191.md) | Changed | AI flags, Party |
| [Swimmer♀ Crystal](../trainers/trainer-0192.md) | Changed | AI flags, Party |
| [Swimmer♀ Cassandra](../trainers/trainer-0193.md) | Changed | AI flags, Party |
| [Swimmer♀ Gabrielle](../trainers/trainer-0194.md) | Changed | AI flags, Party |
| [Worker Colin](../trainers/trainer-0195.md) | Changed | AI flags, Party |
| [Worker Mason](../trainers/trainer-0196.md) | Changed | AI flags, Party |
| [Worker Mickey](../trainers/trainer-0197.md) | Changed | Party |
| [Scientist Mickey](../trainers/trainer-0198.md) | Changed | Party |
| [Scientist Mickey](../trainers/trainer-0199.md) | Changed | Party |
| [Scientist Mickey](../trainers/trainer-0200.md) | Changed | Party |
| [Bug Catcher Jack](../trainers/trainer-0201.md) | Changed | AI flags, Party |
| [Bug Catcher Phillip](../trainers/trainer-0202.md) | Changed | AI flags, Party |
| [Bug Catcher Donald](../trainers/trainer-0203.md) | Changed | AI flags, Party |
| [Lass Briana](../trainers/trainer-0204.md) | Changed | AI flags, Party |
| [Psychic Elijah](../trainers/trainer-0205.md) | Changed | AI flags, Party |
| [Psychic Lindsey](../trainers/trainer-0206.md) | Changed | AI flags, Party |
| [Young Couple Tara nd Tim](../trainers/trainer-0207.md) | Changed | Name, Party |
| [Worker Mickey](../trainers/trainer-0208.md) | Changed | Party |
| [Worker Mickey](../trainers/trainer-0209.md) | Changed | Party |
| [Worker Mickey](../trainers/trainer-0210.md) | Changed | Party |
| [Ace Trainer Mickey](../trainers/trainer-0211.md) | Changed | Party |
| [Ace Trainer Mickey](../trainers/trainer-0212.md) | Changed | Party |
| [Ace Trainer Angelica](../trainers/trainer-0213.md) | Changed | Party |
| [Ace Trainer Angelica](../trainers/trainer-0214.md) | Changed | Party |
| [Veteran Mickey](../trainers/trainer-0215.md) | Changed | Party |
| [Veteran Mickey](../trainers/trainer-0216.md) | Changed | Party |
| [Psychic Mickey](../trainers/trainer-0217.md) | Changed | Party |
| [Psychic Angelica](../trainers/trainer-0218.md) | Changed | Party |
| [Dragon Tamer Mickey](../trainers/trainer-0219.md) | Changed | Party |
| [Sailor Mickey](../trainers/trainer-0220.md) | Changed | Party |
| [School Kid Mickey](../trainers/trainer-0221.md) | Changed | Party |
| [School Kid Angelica](../trainers/trainer-0222.md) | Changed | Party |
| [Young Couple Tara nd Tim](../trainers/trainer-0223.md) | Changed | Name, Party |
| [Ace Trainer Omar](../trainers/trainer-0224.md) | Changed | Party |
| [Ace Trainer Henry](../trainers/trainer-0225.md) | Changed | Party |
| [Ace Trainer Mariah](../trainers/trainer-0226.md) | Changed | Party |
| [Ace Trainer Sydney](../trainers/trainer-0227.md) | Changed | Party |
| [Veteran Edgar](../trainers/trainer-0228.md) | Changed | Party |
| [Veteran Clayton](../trainers/trainer-0229.md) | Changed | Party |
| [Dragon Tamer Ondrej](../trainers/trainer-0230.md) | Changed | Party |
| [Dragon Tamer Clinton](../trainers/trainer-0231.md) | Changed | Party |
| [Black Belt David](../trainers/trainer-0232.md) | Changed | AI flags, Party |
| [Bird Keeper Hana](../trainers/trainer-0233.md) | Changed | AI flags, Party |
| [Psychic Bryce](../trainers/trainer-0234.md) | Changed | AI flags, Party |
| [Psychic Valencia](../trainers/trainer-0235.md) | Changed | AI flags, Party |
| [Double Team Jo & Pat](../trainers/trainer-0236.md) | Changed | AI flags, Party |
| [Double Team Al & Kay](../trainers/trainer-0237.md) | Changed | AI flags, Party |
| [Youngster Mickey](../trainers/trainer-0238.md) | Changed | Party |
| [Lass Angelica](../trainers/trainer-0239.md) | Changed | Party |
| [Veteran Grant](../trainers/trainer-0240.md) | Changed | Party |
| [Fisherman Mickey](../trainers/trainer-0241.md) | Changed | Party |
| [Sailor Mickey](../trainers/trainer-0242.md) | Changed | Party |
| [Beauty Angelica](../trainers/trainer-0243.md) | Changed | Party |
| [Youngster Jonathon](../trainers/trainer-0244.md) | Changed | AI flags, Party |
| [Youngster Darius](../trainers/trainer-0245.md) | Changed | AI flags, Party |
| [Leader Roark](../trainers/trainer-0246.md) | Changed | AI battle items, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0247.md) | Changed | AI flags, AI battle items, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0248.md) | Changed | AI flags, AI battle items, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0249.md) | Changed | AI flags, AI battle items, Party |
| [Leader Byron](../trainers/trainer-0250.md) | Changed | AI battle items, Party |
| [Ace Trainer Angelica](../trainers/trainer-0251.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0252.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0253.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0254.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0255.md) | Changed | Party |
| [Worker Jackson](../trainers/trainer-0256.md) | Changed | AI flags, Party |
| [Worker Gary](../trainers/trainer-0257.md) | Changed | AI flags, Party |
| [Black Belt Philip](../trainers/trainer-0258.md) | Changed | AI flags, Party |
| [Aroma Lady Jenna](../trainers/trainer-0259.md) | Changed | AI flags, Party |
| [Aroma Lady Angela](../trainers/trainer-0260.md) | Changed | AI flags, Party |
| [Elite Four Aaron](../trainers/trainer-0261.md) | Changed | Party |
| [Elite Four Bertha](../trainers/trainer-0262.md) | Changed | Party |
| [Elite Four Flint](../trainers/trainer-0263.md) | Changed | Party |
| [Elite Four Lucian](../trainers/trainer-0264.md) | Changed | AI flags, Party |
| [Camper Curtis](../trainers/trainer-0265.md) | Changed | Party, Locations |
| [Champion Cynthia](../trainers/trainer-0267.md) | Changed | Party |
| [Ace Trainer Sergio](../trainers/trainer-0268.md) | Changed | Party |
| [Ace Trainer Isaiah](../trainers/trainer-0269.md) | Changed | Party |
| [Ace Trainer Savannah](../trainers/trainer-0270.md) | Changed | Party |
| [Ace Trainer Alicia](../trainers/trainer-0271.md) | Changed | Party |
| [Collector Douglas](../trainers/trainer-0272.md) | Changed | AI flags, Party |
| [Collector Brady](../trainers/trainer-0273.md) | Changed | AI flags, Party |
| [Collector Ivan](../trainers/trainer-0274.md) | Changed | AI flags, Party |
| [Collector Fernando](../trainers/trainer-0275.md) | Changed | AI flags, Party |
| [Collector Edwin](../trainers/trainer-0276.md) | Changed | AI flags, Party |
| [Dragon Tamer Hayden](../trainers/trainer-0277.md) | Changed | Party |
| [Ace Trainer Dennis](../trainers/trainer-0278.md) | Changed | Party |
| [Ace Trainer Cesar](../trainers/trainer-0279.md) | Changed | Party |
| [Ace Trainer Allen](../trainers/trainer-0280.md) | Changed | Party |
| [Ace Trainer Zachery](../trainers/trainer-0281.md) | Changed | Party |
| [Ace Trainer Ruben](../trainers/trainer-0282.md) | Changed | Party |
| [Ace Trainer Breanna](../trainers/trainer-0283.md) | Changed | Party |
| [Ace Trainer Catherine](../trainers/trainer-0284.md) | Changed | Party |
| [Ace Trainer Destiny](../trainers/trainer-0285.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0286.md) | Changed | Party |
| [Ace Trainer Maya](../trainers/trainer-0287.md) | Changed | Party |
| [Psychic Maxwell](../trainers/trainer-0288.md) | Changed | AI flags, Party |
| [Psychic Brittney](../trainers/trainer-0289.md) | Changed | AI flags, Party |
| [Belle & Pa Ava&Matt](../trainers/trainer-0290.md) | Changed | Name, Party |
| [Rancher Mickey](../trainers/trainer-0291.md) | Changed | Party |
| [Rancher Marco](../trainers/trainer-0292.md) | Changed | Party |
| [Fisherman Erick](../trainers/trainer-0293.md) | Changed | AI flags, Party |
| [Twins Ema & Lil](../trainers/trainer-0294.md) | Changed | Name, AI flags, Party |
| [Commander Mars](../trainers/trainer-0295.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0296.md) | Changed | AI flags, Party, Script references |
| [Galactic Grunt](../trainers/trainer-0297.md) | Changed | AI flags, Party, Script references |
| [Galactic Grunt](../trainers/trainer-0298.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0299.md) | Changed | AI flags, Party |
| [Guitarist Tony](../trainers/trainer-0300.md) | Changed | AI flags, Party |
| [Guitarist Jerry](../trainers/trainer-0301.md) | Changed | AI flags, Party |
| [Guitarist Preston](../trainers/trainer-0302.md) | Changed | AI flags, Party |
| [Guitarist Lonnie](../trainers/trainer-0303.md) | Changed | AI flags, Party |
| [Ruin Maniac Calvin](../trainers/trainer-0304.md) | Changed | Party |
| [Ruin Maniac Larry](../trainers/trainer-0305.md) | Changed | Party |
| [Jogger Wyatt](../trainers/trainer-0306.md) | Changed | Party |
| [Jogger Craig](../trainers/trainer-0307.md) | Changed | AI flags, Party |
| [Jogger Raul](../trainers/trainer-0308.md) | Changed | AI flags, Party |
| [Black Belt Colby](../trainers/trainer-0309.md) | Changed | AI flags, Party |
| [Black Belt Darren](../trainers/trainer-0310.md) | Changed | AI flags, Party |
| [Black Belt Rafael](../trainers/trainer-0311.md) | Changed | AI flags, Party |
| [Black Belt Jeffery](../trainers/trainer-0312.md) | Changed | AI flags, Party |
| [Black Belt Carl](../trainers/trainer-0313.md) | Changed | AI flags, Party |
| [Black Belt Ricky](../trainers/trainer-0314.md) | Changed | AI flags, Party |
| [Leader Gardenia](../trainers/trainer-0315.md) | Changed | Party |
| [Leader Wake](../trainers/trainer-0316.md) | Changed | Party |
| [Leader Maylene](../trainers/trainer-0317.md) | Changed | AI battle items, Party |
| [Leader Fantina](../trainers/trainer-0318.md) | Changed | AI battle items, Party |
| [Leader Candice](../trainers/trainer-0319.md) | Changed | AI battle items, Party, Script references |
| [Leader Volkner](../trainers/trainer-0320.md) | Changed | Party |
| [Lass Angelica](../trainers/trainer-0321.md) | Changed | Party |
| [Lass Madeline](../trainers/trainer-0322.md) | Changed | AI flags, Party, Locations |
| [Lass Kaitlin](../trainers/trainer-0323.md) | Changed | AI flags, Party, Locations |
| [Lass Caroline](../trainers/trainer-0324.md) | Changed | AI flags, Party |
| [Lass Molly](../trainers/trainer-0325.md) | Changed | AI flags, Party |
| [Hiker Louis](../trainers/trainer-0326.md) | Changed | AI flags, Party |
| [Parasol Lady Alexa](../trainers/trainer-0327.md) | Changed | AI flags, Party |
| [Parasol Lady Sabrina](../trainers/trainer-0328.md) | Changed | AI flags, Party |
| [Picnicker Diana](../trainers/trainer-0329.md) | Changed | Party, Locations |
| [Picnicker Cheyenne](../trainers/trainer-0330.md) | Changed | Party |
| [Poké Kid Meghan](../trainers/trainer-0331.md) | Changed | AI flags, Party |
| [Policeman Danny](../trainers/trainer-0332.md) | Changed | AI flags, Party |
| [Policeman Thomas](../trainers/trainer-0333.md) | Changed | AI flags, Party |
| [Rich Boy Mickey](../trainers/trainer-0334.md) | Changed | Party |
| [Rich Boy Trey](../trainers/trainer-0335.md) | Changed | AI flags, Party |
| [Lady Angelica](../trainers/trainer-0336.md) | Changed | Party |
| [Sailor Marc](../trainers/trainer-0337.md) | Changed | AI flags, Party |
| [Sailor Skyler](../trainers/trainer-0338.md) | Changed | AI flags, Party |
| [Sailor Damian](../trainers/trainer-0339.md) | Changed | AI flags, Party |
| [School Kid Chance](../trainers/trainer-0340.md) | Changed | AI flags, AI battle items, Party |
| [School Kid Forrest](../trainers/trainer-0341.md) | Changed | AI flags, Party |
| [School Kid Harrison](../trainers/trainer-0342.md) | Changed | AI flags, AI battle items, Party |
| [School Kid Mackenzie](../trainers/trainer-0343.md) | Changed | AI flags, AI battle items, Party |
| [School Kid Tiera](../trainers/trainer-0344.md) | Changed | AI flags, Party |
| [School Kid Christine](../trainers/trainer-0345.md) | Changed | AI flags, Party |
| [Beauty Cyndy](../trainers/trainer-0346.md) | Changed | AI flags, Party |
| [Beauty Angelica](../trainers/trainer-0347.md) | Changed | Party |
| [Beauty Lindsay](../trainers/trainer-0348.md) | Changed | Party |
| [Skier Mickey](../trainers/trainer-0349.md) | Changed | Party |
| [Skier Angelica](../trainers/trainer-0350.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0351.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0352.md) | Changed | Party |
| [Swimmer♀ Angelica](../trainers/trainer-0353.md) | Changed | Party |
| [Swimmer♀ Angelica](../trainers/trainer-0354.md) | Changed | Party |
| [Youngster Dallas](../trainers/trainer-0355.md) | Changed | AI flags, Party |
| [Youngster Sebastian](../trainers/trainer-0356.md) | Changed | AI flags, Party, Locations |
| [Youngster Donny](../trainers/trainer-0357.md) | Changed | AI flags, Party |
| [Tuber Trenton](../trainers/trainer-0358.md) | Changed | AI flags, Party |
| [Tuber Conner](../trainers/trainer-0359.md) | Changed | AI flags, Party |
| [Tuber Mariel](../trainers/trainer-0360.md) | Changed | AI flags, Party |
| [Tuber Holly](../trainers/trainer-0361.md) | Changed | AI flags, Party |
| [Veteran Armando](../trainers/trainer-0362.md) | Changed | Party |
| [Waiter Mickey](../trainers/trainer-0363.md) | Changed | Party |
| [Waiter Mickey](../trainers/trainer-0364.md) | Changed | Party |
| [Waiter Mickey](../trainers/trainer-0365.md) | Changed | Party |
| [Waitress Kati](../trainers/trainer-0366.md) | Changed | Party |
| [Worker Gerardo](../trainers/trainer-0367.md) | Changed | AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0368.md) | Changed | Name, AI flags, Party |
| [Cameraman Tevin](../trainers/trainer-0369.md) | Changed | AI flags, Party |
| [Reporter Kinsey](../trainers/trainer-0370.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0371.md) | Changed | AI flags, Party |
| [Battle Girl Tyler](../trainers/trainer-0372.md) | Changed | AI flags, Party |
| [Bird Keeper Autumn](../trainers/trainer-0373.md) | Changed | AI flags, Party |
| [Pokémon Breeder Mickey](../trainers/trainer-0374.md) | Changed | Party |
| [Pokémon Breeder Angelica](../trainers/trainer-0375.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0376.md) | Changed | Party |
| [Camper Zackary](../trainers/trainer-0377.md) | Changed | Party |
| [Camper Lawrence](../trainers/trainer-0378.md) | Changed | Party |
| [Camper Diego](../trainers/trainer-0379.md) | Changed | Party |
| [Camper Parker](../trainers/trainer-0380.md) | Changed | Party |
| [Collector Dean](../trainers/trainer-0381.md) | Changed | AI flags, Party |
| [Collector Jamal](../trainers/trainer-0382.md) | Changed | AI flags, Party |
| [Collector Terry](../trainers/trainer-0383.md) | Changed | AI flags, Party |
| [Pokéfan Mickey](../trainers/trainer-0384.md) | Changed | Party |
| [Pokéfan Angelica](../trainers/trainer-0385.md) | Changed | Party |
| [Dragon Tamer Joe](../trainers/trainer-0386.md) | Changed | Party |
| [Ace Trainer Mickey](../trainers/trainer-0387.md) | Changed | Party |
| [Ace Trainer Jonah](../trainers/trainer-0388.md) | Changed | Party |
| [Ace Trainer Micah](../trainers/trainer-0389.md) | Changed | Party |
| [Ace Trainer Arthur](../trainers/trainer-0390.md) | Changed | Party |
| [Ace Trainer Angelica](../trainers/trainer-0391.md) | Changed | Party |
| [Ace Trainer Brenda](../trainers/trainer-0392.md) | Changed | Party |
| [Ace Trainer Brandi](../trainers/trainer-0393.md) | Changed | Party |
| [Ace Trainer Clarice](../trainers/trainer-0394.md) | Changed | Party |
| [Psychic Kody](../trainers/trainer-0395.md) | Changed | AI flags, Party |
| [Psychic Landon](../trainers/trainer-0396.md) | Changed | AI flags, Party |
| [Psychic Deandre](../trainers/trainer-0397.md) | Changed | AI flags, Party |
| [Psychic Rachael](../trainers/trainer-0398.md) | Changed | AI flags, Party |
| [Psychic Desiree](../trainers/trainer-0399.md) | Changed | AI flags, Party |
| [Psychic Kendra](../trainers/trainer-0400.md) | Changed | AI flags, Party |
| [Fisherman Walter](../trainers/trainer-0401.md) | Changed | AI flags, Party |
| [Gentleman Mickey](../trainers/trainer-0402.md) | Changed | Party |
| [Galactic Boss Cyrus](../trainers/trainer-0403.md) | Changed | AI battle items, Party |
| [Galactic Boss Cyrus](../trainers/trainer-0404.md) | Changed | AI battle items, Party, Script references |
| [Commander Mars](../trainers/trainer-0405.md) | Changed | Party, Script references |
| [Commander Jupiter](../trainers/trainer-0406.md) | Changed | Party, Script references |
| [Commander Jupiter](../trainers/trainer-0407.md) | Changed | AI flags, Party |
| [Commander Saturn](../trainers/trainer-0408.md) | Changed | Party, Script references |
| [Commander Saturn](../trainers/trainer-0409.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0410.md) | Changed | AI flags, Party, Locations |
| [Galactic Grunt](../trainers/trainer-0411.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0412.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0413.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0414.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0415.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0416.md) | Changed | AI flags, Party, Script references |
| [Galactic Grunt](../trainers/trainer-0417.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0418.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0419.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0420.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0421.md) | Changed | AI flags, Party, Locations |
| [Galactic Grunt](../trainers/trainer-0422.md) | Changed | AI flags, Party, Locations |
| [Galactic Grunt](../trainers/trainer-0423.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0424.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0425.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0426.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0427.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0428.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0429.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0430.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0431.md) | Changed | AI flags, Party |
| [Guitarist Mickey](../trainers/trainer-0432.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0433.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0434.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0435.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0436.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0437.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0438.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0439.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0440.md) | Changed | Party |
| [Ruin Maniac Mickey](../trainers/trainer-0441.md) | Changed | Party |
| [Ruin Maniac Harry](../trainers/trainer-0442.md) | Changed | Party |
| [Ruin Maniac Gerald](../trainers/trainer-0443.md) | Changed | Party |
| [Black Belt Miles](../trainers/trainer-0444.md) | Changed | AI flags, Party |
| [Black Belt Kendal](../trainers/trainer-0445.md) | Changed | AI flags, Party |
| [Black Belt Eddie](../trainers/trainer-0446.md) | Changed | AI flags, Party |
| [Black Belt Willie](../trainers/trainer-0447.md) | Changed | AI flags, Party |
| [Socialite Angelica](../trainers/trainer-0448.md) | Changed | Party |
| [Lass Angelica](../trainers/trainer-0449.md) | Changed | Party |
| [Lass Cassidy](../trainers/trainer-0450.md) | Changed | AI flags, Party |
| [Hiker Theodore](../trainers/trainer-0451.md) | Changed | AI flags, Party |
| [Hiker Damon](../trainers/trainer-0452.md) | Changed | AI flags, Party |
| [Hiker Maurice](../trainers/trainer-0453.md) | Changed | AI flags, Party |
| [Hiker Reginald](../trainers/trainer-0454.md) | Changed | AI flags, Party |
| [Hiker Lorenzo](../trainers/trainer-0455.md) | Changed | AI flags, Party |
| [Picnicker Karina](../trainers/trainer-0456.md) | Changed | Party |
| [Picnicker Summer](../trainers/trainer-0457.md) | Changed | Party |
| [Picnicker Tori](../trainers/trainer-0458.md) | Changed | Party |
| [Picnicker Ana](../trainers/trainer-0459.md) | Changed | Party |
| [Clown Lee](../trainers/trainer-0460.md) | Changed | AI flags, Party |
| [Clown Mickey](../trainers/trainer-0461.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0462.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0463.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0464.md) | Changed | Party |
| [Poké Kid Ariel](../trainers/trainer-0465.md) | Changed | Party |
| [Policeman Mickey](../trainers/trainer-0466.md) | Changed | Party |
| [Rich Boy Mickey](../trainers/trainer-0467.md) | Changed | Party |
| [Rich Boy Mickey](../trainers/trainer-0468.md) | Changed | Party |
| [Lady Angelica](../trainers/trainer-0469.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0470.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0471.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0472.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0473.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0474.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0475.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0479.md) | Changed | AI battle items, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0480.md) | Changed | AI battle items, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0481.md) | Changed | Party |
| [Sailor Zachariah](../trainers/trainer-0482.md) | Changed | AI flags, Party |
| [Sailor Samson](../trainers/trainer-0483.md) | Changed | AI flags, Party |
| [School Kid Mickey](../trainers/trainer-0484.md) | Changed | Party |
| [School Kid Angelica](../trainers/trainer-0485.md) | Changed | Party |
| [Scientist Shaun](../trainers/trainer-0486.md) | Changed | AI flags, AI battle items, Party |
| [Scientist Mickey](../trainers/trainer-0487.md) | Changed | Party |
| [Ninja Boy Fabian](../trainers/trainer-0488.md) | Changed | AI flags, Party |
| [Ninja Boy Brennan](../trainers/trainer-0489.md) | Changed | AI flags, Party |
| [Ninja Boy Bruce](../trainers/trainer-0490.md) | Changed | AI flags, Party |
| [Beauty Devon](../trainers/trainer-0491.md) | Changed | AI flags, Party |
| [Beauty Nicola](../trainers/trainer-0492.md) | Changed | AI flags, Party |
| [Swimmer♂ Mickey](../trainers/trainer-0493.md) | Changed | Party |
| [Swimmer♀ Claire](../trainers/trainer-0494.md) | Changed | AI flags, Party |
| [Youngster Mickey](../trainers/trainer-0495.md) | Changed | Party |
| [Youngster Wayne](../trainers/trainer-0496.md) | Changed | AI flags, Party |
| [Tuber Jacky](../trainers/trainer-0497.md) | Changed | AI flags, Party |
| [Tuber Caitlyn](../trainers/trainer-0498.md) | Changed | AI flags, Party |
| [Veteran Terrell](../trainers/trainer-0499.md) | Changed | Party |
| [Veteran Brenden](../trainers/trainer-0500.md) | Changed | Party |
| [Waiter Mickey](../trainers/trainer-0501.md) | Changed | Party |
| [Worker Mickey](../trainers/trainer-0502.md) | Changed | Party |
| [Worker Noel](../trainers/trainer-0503.md) | Changed | AI flags, Party |
| [Worker Braden](../trainers/trainer-0504.md) | Changed | AI flags, Party |
| [Worker Brendon](../trainers/trainer-0505.md) | Changed | AI flags, Party |
| [Worker Quentin](../trainers/trainer-0506.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0507.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0508.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0509.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0510.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0511.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0512.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0513.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0514.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0515.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0516.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0517.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0518.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0519.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0520.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0521.md) | Changed | AI flags, Party, Script references |
| [Galactic Grunt](../trainers/trainer-0522.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0523.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0524.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0525.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0526.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0527.md) | Changed | AI flags, Party, Script references |
| [Commander Mars](../trainers/trainer-0528.md) | Changed | AI flags, Party |
| [Roughneck Kirby](../trainers/trainer-0529.md) | Changed | Party |
| [Pokéfan Leonard](../trainers/trainer-0530.md) | Changed | AI flags, Party |
| [Pokéfan Rebekah](../trainers/trainer-0531.md) | Changed | AI flags, Party |
| [Youngster Oliver](../trainers/trainer-0532.md) | Changed | AI flags, Party |
| [Belle & Pa Beth&Bob](../trainers/trainer-0533.md) | Changed | Name, AI flags, Party |
| [Young Couple Mike&Nat](../trainers/trainer-0534.md) | Changed | Name, AI flags, Party |
| [Aroma Lady Alison](../trainers/trainer-0535.md) | Changed | AI flags, Party, Script references |
| [Artist Ismael](../trainers/trainer-0536.md) | Changed | AI flags, Party, Script references |
| [Pokémon Breeder Kaylee](../trainers/trainer-0537.md) | Changed | AI flags, Party, Script references |
| [Cameraman Darryl](../trainers/trainer-0538.md) | Changed | AI flags, Party, Script references |
| [Collector Eugene](../trainers/trainer-0539.md) | Changed | AI flags, Party, Script references |
| [Pokéfan Meredith](../trainers/trainer-0540.md) | Changed | AI flags, Party, Script references |
| [PI Kendrick](../trainers/trainer-0541.md) | Changed | AI flags, Party, Script references |
| [Gentleman Leonardo](../trainers/trainer-0542.md) | Changed | AI flags, Party, Script references |
| [Socialite Rebecca](../trainers/trainer-0543.md) | Changed | AI flags, Party, Script references |
| [Lass Blythe](../trainers/trainer-0544.md) | Changed | AI flags, Party, Script references |
| [Rich Boy Roman](../trainers/trainer-0545.md) | Changed | AI flags, Party, Script references |
| [Lady Kylie](../trainers/trainer-0546.md) | Changed | AI flags, Party, Script references |
| [Reporter Valerie](../trainers/trainer-0547.md) | Changed | AI flags, Party, Script references |
| [School Kid Esteban](../trainers/trainer-0548.md) | Changed | AI flags, Party, Script references |
| [Scientist Emilio](../trainers/trainer-0549.md) | Changed | AI flags, Party, Script references |
| [Beauty Gabriella](../trainers/trainer-0550.md) | Changed | AI flags, Party, Script references |
| [Beauty Harley](../trainers/trainer-0551.md) | Changed | AI flags, Party, Script references |
| [Veteran Emanuel](../trainers/trainer-0552.md) | Changed | Party, Script references |
| [Ruin Maniac Karl](../trainers/trainer-0553.md) | Changed | Party |
| [Bird Keeper Audrey](../trainers/trainer-0554.md) | Changed | AI flags, Party |
| [Bird Keeper Geneva](../trainers/trainer-0555.md) | Changed | AI flags, Party |
| [Bird Keeper Krystal](../trainers/trainer-0556.md) | Changed | AI flags, Party |
| [Dragon Tamer Geoffrey](../trainers/trainer-0557.md) | Changed | Party |
| [Dragon Tamer Darien](../trainers/trainer-0558.md) | Changed | Party |
| [Dragon Tamer Keegan](../trainers/trainer-0559.md) | Changed | Party |
| [Dragon Tamer Stanley](../trainers/trainer-0560.md) | Changed | Party |
| [Dragon Tamer Drake](../trainers/trainer-0561.md) | Changed | Party |
| [Dragon Tamer Kenny](../trainers/trainer-0562.md) | Changed | Party |
| [Ace Trainer Rodolfo](../trainers/trainer-0563.md) | Changed | Party |
| [Ace Trainer Saul](../trainers/trainer-0564.md) | Changed | Party |
| [Ace Trainer Jose](../trainers/trainer-0565.md) | Changed | Party |
| [Ace Trainer Butler](../trainers/trainer-0566.md) | Changed | Name, Party |
| [Ace Trainer Quinn](../trainers/trainer-0567.md) | Changed | Party |
| [Ace Trainer Graham](../trainers/trainer-0568.md) | Changed | Party |
| [Ace Trainer Keenan](../trainers/trainer-0569.md) | Changed | Party |
| [Ace Trainer Stefan](../trainers/trainer-0570.md) | Changed | Party |
| [Ace Trainer Skylar](../trainers/trainer-0571.md) | Changed | Party |
| [Ace Trainer Abel](../trainers/trainer-0572.md) | Changed | Party |
| [Ace Trainer Deanna](../trainers/trainer-0573.md) | Changed | Party |
| [Ace Trainer Moira](../trainers/trainer-0574.md) | Changed | Party |
| [Ace Trainer Diane](../trainers/trainer-0575.md) | Changed | Name, Party |
| [Ace Trainer Mikayla](../trainers/trainer-0576.md) | Changed | Party |
| [Ace Trainer Meagan](../trainers/trainer-0577.md) | Changed | Party |
| [Ace Trainer Sandra](../trainers/trainer-0578.md) | Changed | Party |
| [Ace Trainer Kassandra](../trainers/trainer-0579.md) | Changed | Party |
| [Ace Trainer Jasmin](../trainers/trainer-0580.md) | Changed | Party |
| [Ace Trainer Natasha](../trainers/trainer-0581.md) | Changed | Party |
| [Ace Trainer Monique](../trainers/trainer-0582.md) | Changed | Party |
| [Psychic Corbin](../trainers/trainer-0583.md) | Changed | AI flags, Party |
| [Psychic Sterling](../trainers/trainer-0584.md) | Changed | AI flags, Party |
| [Psychic Daisy](../trainers/trainer-0585.md) | Changed | AI flags, Party |
| [Psychic Chelsey](../trainers/trainer-0586.md) | Changed | AI flags, Party |
| [Black Belt Davon](../trainers/trainer-0587.md) | Changed | AI flags, Party |
| [Black Belt Griffin](../trainers/trainer-0588.md) | Changed | AI flags, Party, Locations |
| [Black Belt Ray](../trainers/trainer-0589.md) | Changed | AI flags, Party |
| [Black Belt Jarrett](../trainers/trainer-0590.md) | Changed | AI flags, Party |
| [Pokémon Ranger Kyler](../trainers/trainer-0591.md) | Changed | Party |
| [Pokémon Ranger Deshawn](../trainers/trainer-0592.md) | Changed | Party |
| [Pokémon Ranger Dwayne](../trainers/trainer-0593.md) | Changed | Party |
| [Pokémon Ranger Ashlee](../trainers/trainer-0594.md) | Changed | Party |
| [Pokémon Ranger Felicia](../trainers/trainer-0595.md) | Changed | Party |
| [Pokémon Ranger Krista](../trainers/trainer-0596.md) | Changed | Party |
| [Swimmer♂ Glenn](../trainers/trainer-0597.md) | Changed | AI flags, Party |
| [Swimmer♂ Kurt](../trainers/trainer-0598.md) | Changed | AI flags, Party |
| [Swimmer♂ Sam](../trainers/trainer-0599.md) | Changed | AI flags, Party |
| [Swimmer♂ Wade](../trainers/trainer-0600.md) | Changed | AI flags, Party |
| [Swimmer♀ Joanna](../trainers/trainer-0601.md) | Changed | AI flags, Party |
| [Swimmer♀ Sophia](../trainers/trainer-0602.md) | Changed | AI flags, Party |
| [Swimmer♀ Mallory](../trainers/trainer-0603.md) | Changed | AI flags, Party |
| [Swimmer♀ Lydia](../trainers/trainer-0604.md) | Changed | AI flags, Party |
| [Veteran Mickey](../trainers/trainer-0605.md) | Changed | Party |
| [Veteran Harlan](../trainers/trainer-0606.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0607.md) | Changed | Party |
| [Pokémon Trainer Cheryl](../trainers/trainer-0608.md) | Changed | AI battle items, Party |
| [Pokémon Trainer Riley](../trainers/trainer-0609.md) | Changed | Party |
| [Pokémon Trainer Marley](../trainers/trainer-0610.md) | Changed | Party |
| [Pokémon Trainer Buck](../trainers/trainer-0611.md) | Changed | Party |
| [Pokémon Trainer Mira](../trainers/trainer-0612.md) | Changed | AI battle items, Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0613.md) | Changed | Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0614.md) | Changed | Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0615.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0616.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0617.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0618.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0619.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0620.md) | Changed | Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0621.md) | Changed | Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0622.md) | Changed | Party |
| [Pokémon Trainer Lucas](../trainers/trainer-0623.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0624.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0625.md) | Changed | Party |
| [Pokémon Trainer Dawn](../trainers/trainer-0626.md) | Changed | Party |
| [Aroma Lady Elizabeth](../trainers/trainer-0627.md) | Changed | AI flags, Party |
| [Aroma Lady Elizabeth](../trainers/trainer-0628.md) | Changed | AI flags, Party |
| [Aroma Lady Elizabeth](../trainers/trainer-0629.md) | Changed | AI flags, Party |
| [Artist William](../trainers/trainer-0630.md) | Changed | AI flags, Party |
| [Artist William](../trainers/trainer-0631.md) | Changed | AI flags, Party |
| [Artist William](../trainers/trainer-0632.md) | Changed | AI flags, Party |
| [Battle Girl Helen](../trainers/trainer-0633.md) | Changed | AI flags, Party |
| [Battle Girl Helen](../trainers/trainer-0634.md) | Changed | AI flags, Party |
| [Battle Girl Helen](../trainers/trainer-0635.md) | Changed | AI flags, Party |
| [Bird Keeper Brianna](../trainers/trainer-0636.md) | Changed | AI flags, Party |
| [Bird Keeper Brianna](../trainers/trainer-0637.md) | Changed | AI flags, Party |
| [Bird Keeper Audrey](../trainers/trainer-0638.md) | Changed | Party |
| [Pokémon Breeder Albert](../trainers/trainer-0639.md) | Changed | AI flags, Party |
| [Pokémon Breeder Albert](../trainers/trainer-0640.md) | Changed | AI flags, Party |
| [Pokémon Breeder Albert](../trainers/trainer-0641.md) | Changed | AI flags, Party |
| [Pokémon Breeder Jennifer](../trainers/trainer-0642.md) | Changed | AI flags, Party |
| [Pokémon Breeder Jennifer](../trainers/trainer-0643.md) | Changed | AI flags, Party |
| [Pokémon Breeder Jennifer](../trainers/trainer-0644.md) | Changed | AI flags, Party |
| [Camper Zackary](../trainers/trainer-0645.md) | Changed | Party |
| [Camper Zackary](../trainers/trainer-0646.md) | Changed | Party |
| [Camper Zackary](../trainers/trainer-0647.md) | Changed | Party |
| [Ace Trainer Dalton](../trainers/trainer-0648.md) | Changed | Party |
| [Ace Trainer Olivia](../trainers/trainer-0649.md) | Changed | Party |
| [Collector Ivan](../trainers/trainer-0650.md) | Changed | AI flags, Party |
| [Cowgirl Angelica](../trainers/trainer-0651.md) | Changed | Party |
| [Cowgirl Angelica](../trainers/trainer-0652.md) | Changed | Party |
| [Cyclist John](../trainers/trainer-0653.md) | Changed | AI flags, Party |
| [Cyclist John](../trainers/trainer-0654.md) | Changed | AI flags, Party |
| [Cyclist John](../trainers/trainer-0655.md) | Changed | AI flags, Party |
| [Cyclist Kayla](../trainers/trainer-0656.md) | Changed | AI flags, Party |
| [Cyclist Kayla](../trainers/trainer-0657.md) | Changed | AI flags, Party |
| [Cyclist Kayla](../trainers/trainer-0658.md) | Changed | AI flags, Party |
| [Dragon Tamer Patrick](../trainers/trainer-0659.md) | Changed | Party |
| [Dragon Tamer Patrick](../trainers/trainer-0660.md) | Changed | Party |
| [Dragon Tamer Hayden](../trainers/trainer-0661.md) | Changed | Party |
| [Dragon Tamer Geoffrey](../trainers/trainer-0662.md) | Changed | Party |
| [Ace Trainer Jake](../trainers/trainer-0663.md) | Changed | Party |
| [Ace Trainer Dennis](../trainers/trainer-0664.md) | Changed | Party |
| [Ace Trainer Dennis](../trainers/trainer-0665.md) | Changed | Party |
| [Ace Trainer Rodolfo](../trainers/trainer-0666.md) | Changed | Party |
| [Ace Trainer Saul](../trainers/trainer-0667.md) | Changed | Party |
| [Ace Trainer Shannon](../trainers/trainer-0668.md) | Changed | Party |
| [Ace Trainer Maya](../trainers/trainer-0669.md) | Changed | Party |
| [Ace Trainer Maya](../trainers/trainer-0670.md) | Changed | Party |
| [Ace Trainer Deanna](../trainers/trainer-0671.md) | Changed | Party |
| [Ace Trainer Moira](../trainers/trainer-0672.md) | Changed | Party |
| [Psychic Mitchell](../trainers/trainer-0673.md) | Changed | AI flags, Party |
| [Psychic Mitchell](../trainers/trainer-0674.md) | Changed | AI flags, Party |
| [Psychic Maxwell](../trainers/trainer-0675.md) | Changed | Party |
| [Psychic Corbin](../trainers/trainer-0676.md) | Changed | AI flags, Party |
| [Psychic Abigail](../trainers/trainer-0677.md) | Changed | AI flags, Party |
| [Psychic Abigail](../trainers/trainer-0678.md) | Changed | Party |
| [Psychic Brittney](../trainers/trainer-0679.md) | Changed | Party |
| [Psychic Daisy](../trainers/trainer-0680.md) | Changed | Party |
| [Rancher Marco](../trainers/trainer-0681.md) | Changed | AI flags, Party |
| [Rancher Marco](../trainers/trainer-0682.md) | Changed | AI flags, Party |
| [Fisherman Joseph](../trainers/trainer-0683.md) | Changed | AI flags, Party |
| [Fisherman Joseph](../trainers/trainer-0684.md) | Changed | AI flags, Party |
| [Fisherman Miguel](../trainers/trainer-0685.md) | Changed | AI flags, Party |
| [Fisherman Alec](../trainers/trainer-0686.md) | Changed | AI flags, Party |
| [Twins Teri nd Tia](../trainers/trainer-0687.md) | Changed | Name, Party |
| [Twins Teri nd Tia](../trainers/trainer-0688.md) | Changed | Name, Party |
| [PI Carlos](../trainers/trainer-0689.md) | Changed | AI flags, Party |
| [PI Carlos](../trainers/trainer-0690.md) | Changed | AI flags, Party |
| [Gentleman Jeremy](../trainers/trainer-0691.md) | Changed | AI flags, Party |
| [Gentleman Jeremy](../trainers/trainer-0692.md) | Changed | AI flags, Party |
| [Gentleman Jeremy](../trainers/trainer-0693.md) | Changed | AI flags, Party |
| [Guitarist Tony](../trainers/trainer-0694.md) | Changed | AI flags, Party |
| [Ruin Maniac Harry](../trainers/trainer-0695.md) | Changed | Party |
| [Ruin Maniac Harry](../trainers/trainer-0696.md) | Changed | Party |
| [Jogger Craig](../trainers/trainer-0697.md) | Changed | AI flags, Party |
| [Jogger Craig](../trainers/trainer-0698.md) | Changed | AI flags, Party |
| [Black Belt Philip](../trainers/trainer-0699.md) | Changed | AI flags, Party |
| [Black Belt Davon](../trainers/trainer-0700.md) | Changed | AI flags, Party |
| [Socialite Reina](../trainers/trainer-0701.md) | Changed | Party |
| [Socialite Reina](../trainers/trainer-0702.md) | Changed | Party |
| [Lass Samantha](../trainers/trainer-0703.md) | Changed | AI flags, Party |
| [Lass Samantha](../trainers/trainer-0704.md) | Changed | AI flags, Party |
| [Lass Samantha](../trainers/trainer-0705.md) | Changed | AI flags, Party |
| [Lass Madeline](../trainers/trainer-0706.md) | Changed | AI flags, Party |
| [Lass Madeline](../trainers/trainer-0707.md) | Changed | AI flags, Party |
| [Lass Madeline](../trainers/trainer-0708.md) | Changed | AI flags, Party |
| [Hiker Theodore](../trainers/trainer-0709.md) | Changed | Party |
| [Hiker Theodore](../trainers/trainer-0710.md) | Changed | Party |
| [Hiker Theodore](../trainers/trainer-0711.md) | Changed | Party |
| [Bug Catcher Brandon](../trainers/trainer-0712.md) | Changed | AI flags, Party |
| [Bug Catcher Brandon](../trainers/trainer-0713.md) | Changed | AI flags, Party |
| [Bug Catcher Brandon](../trainers/trainer-0714.md) | Changed | AI flags, Party |
| [Parasol Lady Alexa](../trainers/trainer-0715.md) | Changed | AI flags, Party |
| [Parasol Lady Alexa](../trainers/trainer-0716.md) | Changed | AI flags, Party |
| [Parasol Lady Alexa](../trainers/trainer-0717.md) | Changed | AI flags, Party |
| [Picnicker Karina](../trainers/trainer-0718.md) | Changed | Party |
| [Picnicker Karina](../trainers/trainer-0719.md) | Changed | Party |
| [Picnicker Karina](../trainers/trainer-0720.md) | Changed | Party |
| [Poké Kid Danielle](../trainers/trainer-0721.md) | Changed | AI flags, Party |
| [Poké Kid Danielle](../trainers/trainer-0722.md) | Changed | AI flags, Party |
| [Poké Kid Danielle](../trainers/trainer-0723.md) | Changed | AI flags, Party |
| [Policeman Danny](../trainers/trainer-0724.md) | Changed | Party |
| [Policeman Danny](../trainers/trainer-0725.md) | Changed | Party |
| [Policeman Danny](../trainers/trainer-0726.md) | Changed | Party |
| [Rich Boy Trey](../trainers/trainer-0727.md) | Changed | AI flags, Party |
| [Rich Boy Trey](../trainers/trainer-0728.md) | Changed | AI flags, Party |
| [Lady Melissa](../trainers/trainer-0729.md) | Changed | AI flags, Party |
| [Lady Melissa](../trainers/trainer-0730.md) | Changed | AI flags, Party |
| [Lady Melissa](../trainers/trainer-0731.md) | Changed | AI flags, Party |
| [Pokémon Ranger Taylor](../trainers/trainer-0732.md) | Changed | Party |
| [Pokémon Ranger Taylor](../trainers/trainer-0733.md) | Changed | Party |
| [Pokémon Ranger Taylor](../trainers/trainer-0734.md) | Changed | Party |
| [Pokémon Ranger Kyler](../trainers/trainer-0735.md) | Changed | Party |
| [Pokémon Ranger Allison](../trainers/trainer-0736.md) | Changed | Party |
| [Pokémon Ranger Allison](../trainers/trainer-0737.md) | Changed | Party |
| [Pokémon Ranger Allison](../trainers/trainer-0738.md) | Changed | Party |
| [Pokémon Ranger Ashlee](../trainers/trainer-0739.md) | Changed | Party |
| [Sailor Marc](../trainers/trainer-0740.md) | Changed | AI flags, Party |
| [Sailor Marc](../trainers/trainer-0741.md) | Changed | AI flags, Party |
| [Sailor Zachariah](../trainers/trainer-0742.md) | Changed | AI flags, Party |
| [Scientist Shaun](../trainers/trainer-0743.md) | Changed | AI flags, Party |
| [Scientist Shaun](../trainers/trainer-0744.md) | Changed | AI flags, Party |
| [Scientist Shaun](../trainers/trainer-0745.md) | Changed | AI flags, Party |
| [Ninja Boy Zach](../trainers/trainer-0746.md) | Changed | AI flags, Party |
| [Ninja Boy Zach](../trainers/trainer-0747.md) | Changed | AI flags, Party |
| [Ninja Boy Zach](../trainers/trainer-0748.md) | Changed | AI flags, Party |
| [Beauty Cyndy](../trainers/trainer-0749.md) | Changed | AI flags, Party |
| [Beauty Cyndy](../trainers/trainer-0750.md) | Changed | AI flags, Party |
| [Skier Edward](../trainers/trainer-0751.md) | Changed | AI flags, Party |
| [Skier Edward](../trainers/trainer-0752.md) | Changed | AI flags, Party |
| [Skier Bjorn](../trainers/trainer-0753.md) | Changed | AI flags, Party |
| [Skier Bjorn](../trainers/trainer-0754.md) | Changed | AI flags, Party |
| [Skier Andrea](../trainers/trainer-0755.md) | Changed | AI flags, Party |
| [Skier Andrea](../trainers/trainer-0756.md) | Changed | AI flags, Party |
| [Skier Madison](../trainers/trainer-0757.md) | Changed | AI flags, Party |
| [Skier Madison](../trainers/trainer-0758.md) | Changed | AI flags, Party |
| [Swimmer♂ Wesley](../trainers/trainer-0759.md) | Changed | AI flags, Party |
| [Swimmer♂ Francisco](../trainers/trainer-0760.md) | Changed | Party |
| [Swimmer♂ Glenn](../trainers/trainer-0761.md) | Changed | Party |
| [Swimmer♀ Miranda](../trainers/trainer-0762.md) | Changed | AI flags, Party |
| [Swimmer♀ Crystal](../trainers/trainer-0763.md) | Changed | Party |
| [Swimmer♀ Joanna](../trainers/trainer-0764.md) | Changed | AI flags, Party |
| [Youngster Tristan](../trainers/trainer-0765.md) | Changed | AI flags, Party |
| [Youngster Tristan](../trainers/trainer-0766.md) | Changed | AI flags, Party |
| [Youngster Tristan](../trainers/trainer-0767.md) | Changed | AI flags, Party |
| [Youngster Dallas](../trainers/trainer-0768.md) | Changed | AI flags, Party |
| [Youngster Dallas](../trainers/trainer-0769.md) | Changed | AI flags, Party |
| [Youngster Dallas](../trainers/trainer-0770.md) | Changed | AI flags, Party |
| [Tuber Jared](../trainers/trainer-0771.md) | Changed | AI flags, Party |
| [Tuber Jared](../trainers/trainer-0772.md) | Changed | AI flags, Party |
| [Tuber Chelsea](../trainers/trainer-0773.md) | Changed | AI flags, Party |
| [Veteran Brian](../trainers/trainer-0774.md) | Changed | Party |
| [Tuber Chelsea](../trainers/trainer-0775.md) | Changed | AI flags, Party |
| [Veteran Brian](../trainers/trainer-0776.md) | Changed | Party |
| [Veteran Armando](../trainers/trainer-0777.md) | Changed | Party |
| [Veteran Mickey](../trainers/trainer-0778.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0779.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0780.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0781.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0782.md) | Changed | Party |
| [Cameraman Mickey](../trainers/trainer-0783.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0784.md) | Changed | Party |
| [Guitarist Arturo](../trainers/trainer-0785.md) | Changed | Party |
| [Guitarist Arturo](../trainers/trainer-0786.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0787.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0788.md) | Changed | Party |
| [Guitarist Mickey](../trainers/trainer-0789.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0790.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0791.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0792.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0793.md) | Changed | Party |
| [Idol Angelica](../trainers/trainer-0794.md) | Changed | Party |
| [Interviewers Tara nd Tim](../trainers/trainer-0795.md) | Changed | Name, Party |
| [Interviewers Tara nd Tim](../trainers/trainer-0796.md) | Changed | Name, Party |
| [Interviewers Tara nd Tim](../trainers/trainer-0797.md) | Changed | Name, Party |
| [Interviewers Tara nd Tim](../trainers/trainer-0798.md) | Changed | Name, Party |
| [Clown Mickey](../trainers/trainer-0799.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0800.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0801.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0802.md) | Changed | Party |
| [Clown Mickey](../trainers/trainer-0803.md) | Changed | Party |
| [Poké Kid Angelica](../trainers/trainer-0804.md) | Changed | Party |
| [Poké Kid Angelica](../trainers/trainer-0805.md) | Changed | Party |
| [Poké Kid Angelica](../trainers/trainer-0806.md) | Changed | Party |
| [Poké Kid Angelica](../trainers/trainer-0807.md) | Changed | Party |
| [Policeman Mickey](../trainers/trainer-0808.md) | Changed | Party |
| [Reporter Angelica](../trainers/trainer-0809.md) | Changed | Party |
| [Reporter Angelica](../trainers/trainer-0810.md) | Changed | Party |
| [Reporter Angelica](../trainers/trainer-0811.md) | Changed | Party |
| [Reporter Angelica](../trainers/trainer-0812.md) | Changed | Party |
| [Scientist Mickey](../trainers/trainer-0813.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0814.md) | Changed | Party |
| [Waiter Mickey](../trainers/trainer-0815.md) | Changed | Party |
| [Worker Mickey](../trainers/trainer-0816.md) | Changed | Party |
| [Youngster Roland](../trainers/trainer-0817.md) | Changed | Party |
| [Lass Carrie](../trainers/trainer-0818.md) | Changed | Party |
| [Youngster Norman](../trainers/trainer-0819.md) | Changed | Party |
| [Lass Carrie](../trainers/trainer-0821.md) | Changed | Party |
| [Youngster Norman](../trainers/trainer-0822.md) | Changed | Party |
| [Youngster Roland](../trainers/trainer-0823.md) | Changed | Party |
| [Lass Carrie](../trainers/trainer-0824.md) | Changed | Party |
| [Youngster Norman](../trainers/trainer-0825.md) | Changed | Party |
| [Tower Tycoon Palmer](../trainers/trainer-0826.md) | Changed | Party |
| [Ace Trainer Anton](../trainers/trainer-0827.md) | Changed | Party |
| [Ace Trainer Brenna](../trainers/trainer-0828.md) | Changed | Party |
| [Scientist Darrius](../trainers/trainer-0829.md) | Changed | AI flags, Party |
| [Scientist Fredrick](../trainers/trainer-0830.md) | Changed | AI flags, Party |
| [Scientist Travon](../trainers/trainer-0831.md) | Changed | AI flags, AI battle items, Party, Locations |
| [Poké Kid Janet](../trainers/trainer-0832.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0833.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0834.md) | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0835.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0836.md) | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| Pokémon Trainer Cedric | Changed | Party |
| [Galactic Grunt](../trainers/trainer-0843.md) | Changed | AI flags, Party, Script references |
| [Worker Dillan](../trainers/trainer-0844.md) | Changed | AI flags, Party |
| [Worker Holden](../trainers/trainer-0845.md) | Changed | AI flags, Party |
| [Worker Conrad](../trainers/trainer-0846.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0847.md) | Changed | Party, Script references |
| [Galactic Grunt](../trainers/trainer-0848.md) | Changed | AI flags, Party |
| [Galactic Grunt](../trainers/trainer-0849.md) | Changed | AI flags, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0850.md) | Changed | AI flags, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0851.md) | Changed | AI flags, Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0852.md) | Changed | AI flags, Party |
| [Leader Candice](../trainers/trainer-0853.md) | Changed | Party, Script references |
| [Leader Maylene](../trainers/trainer-0854.md) | Changed | AI battle items, Party, Script references |
| [Leader Volkner](../trainers/trainer-0855.md) | Changed | Party, Script references |
| [Leader Byron](../trainers/trainer-0856.md) | Changed | Party, Script references |
| [Leader Gardenia](../trainers/trainer-0857.md) | Changed | Party, Script references |
| [Leader Roark](../trainers/trainer-0858.md) | Changed | Party, Script references |
| [Leader Wake](../trainers/trainer-0859.md) | Changed | Party, Script references |
| [Leader Fantina](../trainers/trainer-0860.md) | Changed | Party, Script references |
| [Pokémon Trainer Riley](../trainers/trainer-0861.md) | Changed | Party, Script references |
| [Pokémon Trainer Buck](../trainers/trainer-0862.md) | Changed | Party, Script references |
| [Pokémon Trainer Marley](../trainers/trainer-0863.md) | Changed | Party, Script references |
| [Pokémon Trainer Mira](../trainers/trainer-0864.md) | Changed | Party, Script references |
| [Pokémon Trainer Cheryl](../trainers/trainer-0865.md) | Changed | Party, Script references |
| [Elite Four Aaron](../trainers/trainer-0866.md) | Changed | AI battle items, Party |
| [Elite Four Bertha](../trainers/trainer-0867.md) | Changed | AI battle items, Party |
| [Elite Four Flint](../trainers/trainer-0868.md) | Changed | AI battle items, Party |
| [Elite Four Lucian](../trainers/trainer-0869.md) | Changed | Party |
| [Champion Cynthia](../trainers/trainer-0870.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0871.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0872.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0873.md) | Changed | Party |
| [Cameraman Tevin](../trainers/trainer-0874.md) | Changed | AI flags, Party |
| [Cameraman Tevin](../trainers/trainer-0875.md) | Changed | AI flags, Party |
| [Cameraman Tevin](../trainers/trainer-0876.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0877.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0878.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0879.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0880.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0881.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0882.md) | Changed | AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0883.md) | Changed | Name, AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0884.md) | Changed | Name, AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0885.md) | Changed | Name, AI flags, Party |
| [Clown Lee](../trainers/trainer-0886.md) | Changed | AI flags, Party |
| [Clown Lee](../trainers/trainer-0887.md) | Changed | Party |
| [Clown Lee](../trainers/trainer-0888.md) | Changed | AI flags, Party |
| [Poké Kid Ariel](../trainers/trainer-0889.md) | Changed | AI flags, Party |
| [Poké Kid Ariel](../trainers/trainer-0890.md) | Changed | AI flags, Party |
| [Poké Kid Ariel](../trainers/trainer-0891.md) | Changed | AI flags, Party |
| [Rich Boy Liam](../trainers/trainer-0892.md) | Changed | Party |
| [Lady Celeste](../trainers/trainer-0893.md) | Changed | Party |
| [Reporter Kinsey](../trainers/trainer-0894.md) | Changed | Party |
| [Reporter Kinsey](../trainers/trainer-0895.md) | Changed | AI flags, Party |
| [Reporter Kinsey](../trainers/trainer-0896.md) | Changed | Party |
| [Maid Belinda](../trainers/trainer-0897.md) | Changed | Party, Script references |
| [Maid Sophie](../trainers/trainer-0898.md) | Changed | Party, Script references |
| [Maid Emily](../trainers/trainer-0899.md) | Changed | Party, Script references |
| [Maid Elena](../trainers/trainer-0900.md) | Changed | Party, Script references |
| [Maid Clare](../trainers/trainer-0901.md) | Changed | Party, Script references |
| [Hall Matron Argenta](../trainers/trainer-0902.md) | Changed | Party |
| [Factory Head Thorton](../trainers/trainer-0903.md) | Changed | Party |
| [Arcade Star Dahlia](../trainers/trainer-0904.md) | Changed | Party |
| [Castle Valet Darach](../trainers/trainer-0905.md) | Changed | Party |
| [Cameraman Tevin](../trainers/trainer-0906.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0907.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0908.md) | Changed | AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0909.md) | Changed | Name, AI flags, Party |
| [Clown Lee](../trainers/trainer-0910.md) | Changed | AI flags, Party |
| [Poké Kid Ariel](../trainers/trainer-0911.md) | Changed | Party |
| [Reporter Kinsey](../trainers/trainer-0912.md) | Changed | AI flags, Party |
| [Galactic Boss Cyrus](../trainers/trainer-0913.md) | Changed | AI battle items, Party, Script references |
| [Cameraman Tevin](../trainers/trainer-0914.md) | Changed | AI flags, Party |
| [Guitarist Arturo](../trainers/trainer-0915.md) | Changed | AI flags, Party |
| [Idol Grace](../trainers/trainer-0916.md) | Changed | AI flags, Party |
| [Interviewers Roxy&Oli](../trainers/trainer-0917.md) | Changed | Name, Party |
| [Clown Lee](../trainers/trainer-0918.md) | Changed | AI flags, Party |
| [Poké Kid Ariel](../trainers/trainer-0919.md) | Changed | AI flags, Party |
| [Reporter Kinsey](../trainers/trainer-0920.md) | Changed | AI flags, Party |
| [Leader Volkner](../trainers/trainer-0921.md) | Changed | Party |
| [Elite Four Flint](../trainers/trainer-0922.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0923.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0924.md) | Changed | Party |
| [Pokémon Trainer Cedric](../trainers/trainer-0925.md) | Changed | Party |
| [Commander Mars](../trainers/trainer-0926.md) | Changed | AI flags, Party, Script references |
| [Commander Jupiter](../trainers/trainer-0927.md) | Changed | AI flags, Party, Script references |
| [Pokémon Trainer Dawn](../trainers/trainer-0928.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0929.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0930.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0931.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0932.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0933.md) | Added | — |
| [Reporter Helen](../trainers/trainer-0934.md) | Added | — |
| [Dragon Tamer Nils](../trainers/trainer-0935.md) | Added | — |
| [Ace Trainer Aran](../trainers/trainer-0936.md) | Added | — |
| [Ace Trainer Nephenee](../trainers/trainer-0937.md) | Added | — |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0939.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0940.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0941.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0942.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0943.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0944.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0945.md) | Added | — |
| [Elite Four Aaron](../trainers/trainer-0946.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0947.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0948.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0949.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0950.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0951.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0952.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0953.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0954.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0955.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0956.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0957.md) | Added | — |
| [Galactic Grunt](../trainers/trainer-0958.md) | Added | — |
| [Commander Saturn](../trainers/trainer-0959.md) | Added | — |
| [Gentleman Backlot](../trainers/trainer-0960.md) | Added | — |
| [Veteran Egadd](../trainers/trainer-0961.md) | Added | — |
| [Psychic Telkin](../trainers/trainer-0962.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0963.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0964.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0966.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0967.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | Added | — |
| [Castle Valet Darach](../trainers/trainer-0969.md) | Added | — |
| [Pokémon Trainer Riley](../trainers/trainer-0970.md) | Added | — |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | Added | — |
| [Galactic Boss Cyrus](../trainers/trainer-0972.md) | Added | — |
| [Arcade Star Dahlia](../trainers/trainer-0973.md) | Added | — |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | Added | — |
| [Elite Four Aaron](../trainers/trainer-0981.md) | Added | — |
| [Elite Four Aaron](../trainers/trainer-0982.md) | Added | — |
| [Elite Four Aaron](../trainers/trainer-0983.md) | Added | — |
| [Elite Four Bertha](../trainers/trainer-0984.md) | Added | — |
| [Elite Four Bertha](../trainers/trainer-0985.md) | Added | — |
| [Elite Four Bertha](../trainers/trainer-0986.md) | Added | — |
| [Elite Four Flint](../trainers/trainer-0987.md) | Added | — |
| [Elite Four Flint](../trainers/trainer-0988.md) | Added | — |
| [Elite Four Flint](../trainers/trainer-0989.md) | Added | — |
| [Elite Four Lucian](../trainers/trainer-0990.md) | Added | — |
| [Elite Four Lucian](../trainers/trainer-0991.md) | Added | — |
| [Elite Four Lucian](../trainers/trainer-0992.md) | Added | — |
| [Champion Cynthia](../trainers/trainer-0993.md) | Added | — |
| [Champion Cynthia](../trainers/trainer-0994.md) | Added | — |
| [Champion Cynthia](../trainers/trainer-0995.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-0996.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-0997.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-0998.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-0999.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1000.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1001.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1002.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1003.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1004.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1005.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1006.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1007.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1008.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1009.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1010.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1011.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1012.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1013.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1014.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1015.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1016.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1017.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1018.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1019.md) | Added | — |
| [Cowgirl Traynee](../trainers/trainer-1020.md) | Added | — |
| [Reporter Jenny](../trainers/trainer-1021.md) | Added | — |
| [Reporter Kayla](../trainers/trainer-1022.md) | Added | — |
| [Pokémon Trainer Buck](../trainers/trainer-1023.md) | Added | — |
| [Ace Trainer Wyver](../trainers/trainer-1024.md) | Added | — |
| [Ace Trainer Slythe](../trainers/trainer-1025.md) | Added | — |
| [Ace Trainer Shade](../trainers/trainer-1026.md) | Added | — |
| [Ace Trainer Gene](../trainers/trainer-1027.md) | Added | — |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Added | — |
| [Bird Keeper Falkner](../trainers/trainer-1029.md) | Added | — |
| [Bug Catcher Bugsy](../trainers/trainer-1030.md) | Added | — |
| [Idol Whitney](../trainers/trainer-1031.md) | Added | — |
| [Ace Trainer Morty](../trainers/trainer-1032.md) | Added | — |
| [Black Belt Chuck](../trainers/trainer-1033.md) | Added | — |
| [Lass Jasmine](../trainers/trainer-1034.md) | Added | — |
| [Veteran Pryce](../trainers/trainer-1035.md) | Added | — |
| [Ace Trainer Clair](../trainers/trainer-1036.md) | Added | — |
| [Psychic Ross](../trainers/trainer-1037.md) | Added | — |
| [Bug Catcher Louie](../trainers/trainer-1038.md) | Added | — |
| [Black Belt Randy](../trainers/trainer-1039.md) | Added | — |
| [Scientist Donnie](../trainers/trainer-1040.md) | Added | — |
| [Hiker Dexter](../trainers/trainer-1041.md) | Added | — |
| [Hiker Hisato](../trainers/trainer-1042.md) | Added | — |
| [Scientist Julian](../trainers/trainer-1043.md) | Added | — |
| [Ace Trainer Edmund](../trainers/trainer-1044.md) | Added | — |
| [Beauty Tessa](../trainers/trainer-1045.md) | Added | — |
| [Lass Sal](../trainers/trainer-1046.md) | Added | — |
| [Guitarist Elton](../trainers/trainer-1047.md) | Added | — |
| [Psychic Frasier](../trainers/trainer-1048.md) | Added | — |
| [Ace Trainer Hazel](../trainers/trainer-1049.md) | Added | — |
| [Ace Trainer Grayson](../trainers/trainer-1050.md) | Added | — |
| [Ace Trainer Kimberly](../trainers/trainer-1051.md) | Added | — |
| [Bird Keeper Thea](../trainers/trainer-1052.md) | Added | — |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-1055.md) | Added | — |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | Added | — |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | Added | — |
| [Commander Mars](../trainers/trainer-1060.md) | Added | — |
| [Commander Jupiter](../trainers/trainer-1061.md) | Added | — |
| [Commander Saturn](../trainers/trainer-1062.md) | Added | — |
| [Galactic Boss Cyrus](../trainers/trainer-1063.md) | Added | — |
| [Pokémon Trainer Cheryl](../trainers/trainer-1064.md) | Added | — |
| [Pokémon Trainer Mira](../trainers/trainer-1065.md) | Added | — |

## Locations

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Jubilife City](../locations/header-004.md) | Changed | Shops |
| [Jubilife City](../locations/header-006.md) | Changed | Pokemon Gifts, Trainers |
| [Canalave City](../locations/header-034.md) | Changed | Shops |
| [Oreburgh City](../locations/header-046.md) | Changed | Shops |
| [Oreburgh City](../locations/header-048.md) | Changed | Pokemon Gifts, Trainers |
| [Oreburgh City](../locations/header-054.md) | Changed | Npc Trades |
| [Oreburgh City](../locations/header-064.md) | Changed | Pokemon Gifts, Trainers |
| [Eterna City](../locations/header-065.md) | Changed | Items, Pokemon Gifts, Trainers |
| [Eterna City](../locations/header-066.md) | Changed | Shops |
| [T.G. Eterna Bldg](../locations/header-075.md) | Changed | Pokemon Gifts |
| [Eterna City](../locations/header-076.md) | Changed | Npc Trades |
| [Eterna City](../locations/header-082.md) | Changed | Roaming activations |
| [Hearthome City](../locations/header-087.md) | Changed | Shops |
| [Route 208](../locations/header-109.md) | Changed | Trainers |
| [Hearthome City](../locations/header-115.md) | Changed | Pokemon Gifts |
| [Pastoria City](../locations/header-120.md) | Changed | Items |
| [Pastoria City](../locations/header-121.md) | Changed | Shops |
| [Pastoria City](../locations/header-122.md) | Changed | Weather |
| [Pastoria City](../locations/header-126.md) | Changed | Trainers |
| [Pastoria City](../locations/header-130.md) | Changed | Pokemon Gifts |
| [Veilstone City](../locations/header-132.md) | Changed | Static Encounters |
| [Veilstone City](../locations/header-134.md) | Changed | Trainers |
| [Veilstone Store](../locations/header-138.md) | Changed | Shops |
| [Veilstone Store](../locations/header-139.md) | Changed | Shops |
| [Veilstone Store](../locations/header-140.md) | Changed | Shops |
| [Veilstone City](../locations/header-144.md) | Changed | Game Corner Prizes |
| [Veilstone City](../locations/header-147.md) | Changed | Pokemon Gifts |
| [Veilstone City](../locations/header-148.md) | Changed | Trainers |
| [Sunyshore City](../locations/header-150.md) | Changed | Items, Trainers |
| [Sunyshore City](../locations/header-153.md) | Changed | Shops |
| [Vista Lighthouse](../locations/header-164.md) | Changed | Trainers |
| [Snowpoint City](../locations/header-165.md) | Changed | Trainers |
| [Snowpoint City](../locations/header-166.md) | Changed | Shops |
| [Snowpoint City](../locations/header-170.md) | Changed | Npc Trades |
| [Pokémon League](../locations/header-172.md) | Changed | Items, Static Encounters, Trainers |
| [Pokémon League](../locations/header-173.md) | Changed | Shops |
| [Pokémon League](../locations/header-175.md) | Changed | Shops |
| [Fight Area](../locations/header-191.md) | Changed | Shops |
| [Valley Windworks](../locations/header-200.md) | Changed | Items, Static Encounters |
| [Eterna Forest](../locations/header-202.md) | Changed | Static Encounters |
| [Eterna Forest](../locations/header-203.md) | Changed | Items, Static Encounters, Trainers |
| [Fuego Ironworks](../locations/header-205.md) | Changed | Day music, Night music |
| [Mt. Coronet](../locations/header-210.md) | Changed | Text archive, Static Encounters |
| [Mt. Coronet](../locations/header-211.md) | Changed | Text archive |
| [Mt. Coronet](../locations/header-212.md) | Changed | Items |
| [Mt. Coronet](../locations/header-216.md) | Changed | Items |
| [Mt. Coronet](../locations/header-218.md) | Changed | Items |
| [Mt. Coronet](../locations/header-219.md) | Changed | Text archive, Weather, Items, Static Encounters |
| [Solaceon Ruins](../locations/header-226.md) | Changed | Trainers |
| [Solaceon Ruins](../locations/header-240.md) | Changed | Static Encounters |
| [Victory Road](../locations/header-245.md) | Changed | Text archive, Items, Static Encounters |
| [Victory Road](../locations/header-247.md) | Changed | Weather, Trainers |
| [Ravaged Path](../locations/header-254.md) | Changed | Items |
| [Floaroma Meadow](../locations/header-256.md) | Changed | Trainers |
| [Oreburgh Gate](../locations/header-258.md) | Changed | Trainers |
| [Oreburgh Gate](../locations/header-259.md) | Changed | Items, Static Encounters |
| [Fullmoon Island](../locations/header-261.md) | Changed | Items, Static Encounters, Roaming activations |
| [Stark Mountain](../locations/header-263.md) | Changed | Items, Static Encounters |
| [Stark Mountain](../locations/header-264.md) | Changed | Items |
| [Stark Mountain](../locations/header-265.md) | Changed | Static Encounters |
| [Sendoff Spring](../locations/header-267.md) | Changed | Trainers |
| [Turnback Cave](../locations/header-268.md) | Changed | Weather |
| [Turnback Cave](../locations/header-269.md) | Changed | Weather |
| [Turnback Cave](../locations/header-270.md) | Changed | Static Encounters |
| [Turnback Cave](../locations/header-271.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-272.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-273.md) | Changed | Weather, Encounter area |
| [Flower Paradise](../locations/header-274.md) | Changed | Static Encounters |
| [Snowpoint Temple](../locations/header-283.md) | Changed | Static Encounters |
| [Wayward Cave](../locations/header-284.md) | Changed | Weather, Items, Static Encounters, Trainers |
| [Iron Island](../locations/header-288.md) | Changed | Trainers |
| [Iron Island](../locations/header-293.md) | Changed | Items, Pokemon Gifts |
| [Old Chateau](../locations/header-300.md) | Changed | Static Encounters |
| [Old Chateau](../locations/header-302.md) | Changed | Static Encounters |
| [Lake Verity](../locations/header-312.md) | Changed | Encounter area |
| [Verity Cavern](../locations/header-313.md) | Changed | Static Encounters, Roaming activations |
| [Valor Cavern](../locations/header-316.md) | Changed | Static Encounters |
| [Acuity Cavern](../locations/header-319.md) | Changed | Static Encounters |
| [Newmoon Island](../locations/header-321.md) | Changed | Static Encounters |
| [Grand Lake](../locations/header-339.md) | Changed | Trainers |
| [Route 201](../locations/header-342.md) | Changed | Static Encounters |
| [Route 202](../locations/header-343.md) | Changed | Trainers |
| [Route 203](../locations/header-344.md) | Changed | Items |
| [Route 207](../locations/header-353.md) | Changed | Trainers |
| [Route 208](../locations/header-354.md) | Changed | Static Encounters |
| [Route 209](../locations/header-356.md) | Changed | Items, Static Encounters |
| [Route 209](../locations/header-357.md) | Changed | Trainers |
| [Route 209](../locations/header-359.md) | Changed | Weather |
| [Route 209](../locations/header-360.md) | Changed | Weather |
| [Route 209](../locations/header-361.md) | Changed | Weather, Static Encounters |
| [Route 210](../locations/header-363.md) | Changed | Weather, Items |
| [Route 211](../locations/header-366.md) | Changed | Items, Static Encounters |
| [Route 212](../locations/header-367.md) | Changed | Trainers |
| [Pokémon Mansion](../locations/header-368.md) | Changed | Trainers |
| [Pokémon Mansion](../locations/header-369.md) | Changed | Items |
| [Pokémon Mansion](../locations/header-370.md) | Changed | Items, Pokemon Gifts |
| [Route 212](../locations/header-371.md) | Changed | Items |
| [Route 213](../locations/header-373.md) | Changed | Items, Static Encounters |
| [Route 214](../locations/header-380.md) | Changed | Warps |
| [Route 217](../locations/header-385.md) | Changed | Weather, Items |
| [Route 219](../locations/header-391.md) | Changed | Day music, Night music, Trainers |
| [Route 221](../locations/header-392.md) | Changed | Day music, Night music |
| [Pal Park](../locations/header-393.md) | Changed | Day music, Night music, Trainers |
| [Route 221](../locations/header-394.md) | Changed | Day music, Night music |
| [Route 224](../locations/header-399.md) | Changed | Trainers |
| [Route 225](../locations/header-400.md) | Changed | Items, Trainers |
| [Route 227](../locations/header-403.md) | Changed | Trainers |
| [Route 228](../locations/header-406.md) | Changed | Trainers |
| [Route 229](../locations/header-407.md) | Changed | Items, Trainers |
| [Twinleaf Town](../locations/header-411.md) | Changed | Weather |
| [Twinleaf Town](../locations/header-414.md) | Changed | Pokemon Gifts |
| [Sandgem Town](../locations/header-419.md) | Changed | Shops |
| [Sandgem Town](../locations/header-422.md) | Changed | Pokemon Gifts |
| [Floaroma Town](../locations/header-427.md) | Changed | Shops |
| [Floaroma Town](../locations/header-428.md) | Changed | Pokemon Gifts, Trainers |
| [Floaroma Town](../locations/header-432.md) | Changed | Npc Trades |
| [Solaceon Town](../locations/header-434.md) | Changed | Shops |
| [Celestic Town](../locations/header-446.md) | Changed | Shops |
| [Celestic Town](../locations/header-449.md) | Changed | Trainers |
| [Survival Area](../locations/header-451.md) | Changed | Shops |
| [Battleground](../locations/header-454.md) | Changed | Trainers |
| [Resort Area](../locations/header-458.md) | Changed | Shops |
| [Route 220](../locations/header-467.md) | Changed | Text archive, Day music, Night music, Static Encounters |
| [Route 226](../locations/header-469.md) | Changed | Trainers |
| [Route 230](../locations/header-471.md) | Changed | Trainers |
| [Route 226](../locations/header-499.md) | Changed | Npc Trades |
| [Great Marsh](../locations/header-505.md) | Changed | Items |
| [Hall of Origin](../locations/header-510.md) | Changed | Static Encounters |
| [Ruin Maniac Cave](../locations/header-512.md) | Changed | Warps |
| [Maniac Tunnel](../locations/header-513.md) | Changed | Warps |
| [Turnback Cave](../locations/header-518.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-519.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-520.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-521.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-522.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-523.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-524.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-525.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-526.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-527.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-528.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-529.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-530.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-531.md) | Changed | Weather, Encounter area |
| [Turnback Cave](../locations/header-532.md) | Changed | Weather |
| [Turnback Cave](../locations/header-533.md) | Changed | Weather |
| [Turnback Cave](../locations/header-534.md) | Changed | Weather |
| [Turnback Cave](../locations/header-535.md) | Changed | Weather |
| [Turnback Cave](../locations/header-536.md) | Changed | Weather |
| [Turnback Cave](../locations/header-537.md) | Changed | Weather |
| [Turnback Cave](../locations/header-538.md) | Changed | Weather |
| [Turnback Cave](../locations/header-539.md) | Changed | Weather |
| [Turnback Cave](../locations/header-540.md) | Changed | Weather |
| [Turnback Cave](../locations/header-541.md) | Changed | Weather |
| [Turnback Cave](../locations/header-542.md) | Changed | Weather |
| [Turnback Cave](../locations/header-543.md) | Changed | Weather |
| [Turnback Cave](../locations/header-544.md) | Changed | Weather |
| [Turnback Cave](../locations/header-545.md) | Changed | Weather |
| [Turnback Cave](../locations/header-546.md) | Changed | Weather |
| [Turnback Cave](../locations/header-547.md) | Changed | Weather |
| [Turnback Cave](../locations/header-548.md) | Changed | Weather |
| [Turnback Cave](../locations/header-549.md) | Changed | Weather |
| [Turnback Cave](../locations/header-550.md) | Changed | Weather |
| [Turnback Cave](../locations/header-551.md) | Changed | Weather |
| [Turnback Cave](../locations/header-552.md) | Changed | Weather |
| [Turnback Cave](../locations/header-553.md) | Changed | Weather |
| [Turnback Cave](../locations/header-554.md) | Changed | Weather |
| [Turnback Cave](../locations/header-555.md) | Changed | Weather |
| [Turnback Cave](../locations/header-556.md) | Changed | Weather |
| [Turnback Cave](../locations/header-557.md) | Changed | Weather |
| [Distortion World](../locations/header-581.md) | Changed | Trainers |
| [Distortion World](../locations/header-582.md) | Changed | Static Encounters |
| [Iron Ruins](../locations/header-588.md) | Changed | Static Encounters |
| [Iceberg Ruins](../locations/header-590.md) | Changed | Static Encounters |
| [Rock Peak Ruins](../locations/header-592.md) | Changed | Static Encounters |
