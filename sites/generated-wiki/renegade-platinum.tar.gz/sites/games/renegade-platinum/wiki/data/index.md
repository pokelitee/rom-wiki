# Data downloads

These deterministic gzip files contain the complete normalized datasets used to build this wiki. They include ROM-derived facts and PokéDB reference data, but never ROM or patch bytes.

| Dataset | Download | Records | Schema |
| ------- | -------- | ------: | -----: |
| Abilities | [abilities.json.gz](abilities.json.gz) | 123 | 5 |
| Wild Encounters | [encounters.json.gz](encounters.json.gz) | 183 | 7 |
| Items | [items.json.gz](items.json.gz) | 445 | 9 |
| Locations | [locations.json.gz](locations.json.gz) | 593 | 16 |
| Moves | [moves.json.gz](moves.json.gz) | 471 | 2 |
| Pokemon | [pokemon.json.gz](pokemon.json.gz) | 508 | 3 |
| Trainers | [trainers.json.gz](trainers.json.gz) | 1066 | 6 |
| Types | [types.json.gz](types.json.gz) | 18 | 2 |

File sizes and SHA-256 checksums are listed in [the machine-readable manifest](manifest.json).
