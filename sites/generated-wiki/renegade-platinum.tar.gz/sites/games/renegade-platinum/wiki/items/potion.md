# Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>17</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽300</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 20 HP.</strong></p>
<p>Used on a friendly Pokémon : Restores 20 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by just 20 points.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>20</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 20</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 201](../locations/header-342.md) | R201 | `header-342` | Script Awarded | — |
| [Route 205](../locations/header-347.md) | R205A | `header-347` | Visible | (213, 640) |
| [Route 212](../locations/header-367.md) | R212A | `header-367` | Hidden | (467, 779) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | C01FS0101 | `header-004` | Common | ₽300 | Start |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Common | ₽300 | Start |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Common | ₽300 | Start |
| [Eterna City](../locations/header-066.md) | C04FS0101 | `header-066` | Common | ₽300 | Start |
| [Hearthome City](../locations/header-087.md) | C05FS0101 | `header-087` | Common | ₽300 | Start |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Common | ₽300 | Start |
| [Sunyshore City](../locations/header-153.md) | C08FS0101 | `header-153` | Common | ₽300 | Start |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽100 | Always |
| [Snowpoint City](../locations/header-166.md) | C09FS0101 | `header-166` | Common | ₽300 | Start |
| [Pokémon League](../locations/header-173.md) | C10PC0101 | `header-173` | Common | ₽300 | Start |
| [Pokémon League](../locations/header-175.md) | C10R0101 | `header-175` | Common | ₽300 | Start |
| [Fight Area](../locations/header-191.md) | C11FS0101 | `header-191` | Common | ₽300 | Start |
| [Sandgem Town](../locations/header-419.md) | T02FS0101 | `header-419` | Common | ₽300 | Start |
| [Floaroma Town](../locations/header-427.md) | T03FS0101 | `header-427` | Common | ₽300 | Start |
| [Solaceon Town](../locations/header-434.md) | T04FS0101 | `header-434` | Common | ₽300 | Start |
| [Solaceon Town](../locations/header-434.md) | T04FS0101 | `header-434` | Specialty | ₽300 | Always |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽300 | Start |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽300 | Start |
| [Survival Area](../locations/header-451.md) | T06FS0101 | `header-451` | Common | ₽300 | Start |
| [Resort Area](../locations/header-458.md) | T07FS0101 | `header-458` | Common | ₽300 | Start |
| [Veilstone Store](../locations/header-566.md) | C07R0207 | `header-566` | Specialty | ₽300 | Always |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Roark](../trainers/trainer-0246.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0247.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0248.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0249.md) | AI battle item |
| [School Kid Harrison](../trainers/trainer-0342.md) | AI battle item |
| [School Kid Christine](../trainers/trainer-0345.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0613.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0614.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0615.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0616.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0617.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0618.md) | AI battle item |
| [Galactic Grunt](../trainers/trainer-0954.md) | AI battle item |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Route 201</li><li>Trainers&#x27; School</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 201</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Zigzagoon</li><li>Linoone</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Grunt</li><li>Cedric</li><li>Cedric</li><li>Cedric</li><li>Harrison</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `17` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `17`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/17/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../cherish-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cherish-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Cherish Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../antidote/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/antidote.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Antidote →</span></a>
</nav>
