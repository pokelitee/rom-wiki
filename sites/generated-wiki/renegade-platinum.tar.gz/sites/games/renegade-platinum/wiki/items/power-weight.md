# Power Weight

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/power-weight.png" alt="Power Weight icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>294</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Effort Training</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">70</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder gains 4 HP effort values, but has halved Speed in battle.</strong></p>
<p>Held: Decreases the holder’s Speed by 50%. Whenever the holder gains HP effort from battle, increases that effort by 4; this applies before the PokéRUS doubling effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Pokémon hold item that promotes HP gain on leveling, but reduces the Speed stat.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>122</dd></div>
<div><dt>Held effect parameter</dt><dd>4</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 217](../locations/header-385.md) | R217 | `header-385` | Visible | (316, 309) |
| [Pokémon Day Care](../locations/header-437.md) | T04R0101 | `header-437` | Script Awarded | — |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽3,000 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 16 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 16 BP | Always |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Pokémon Day Care</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `272` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `272`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/271/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../power-anklet/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/power-anklet.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Power Anklet</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../shed-shell/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/shed-shell.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Shed Shell →</span></a>
</nav>
