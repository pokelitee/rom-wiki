# Macho Brace

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/macho-brace.png" alt="Macho Brace icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>215</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Effort Training</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">60</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder gains double effort values from battles, but has halved Speed in battle.</strong></p>
<p>Held : When the holder would gain effort due to battle, it gains double that effort instead. Held in battle : Holder has half its Speed.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a stiff and heavy brace that promotes strong growth but lowers Speed.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>50</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Stark Mountain — D16R0101](../locations/header-263.md) | Visible | (25, 7) |
| [Great Marsh — D06R0206](../locations/header-509.md) | Hidden | (91, 113) |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `193` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `193`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/192/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../white-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/white-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← White Herb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../exp-share/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/exp-share.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Exp. Share →</span></a>
</nav>
