# Choice Specs

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-specs.png" alt="Choice Specs icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>297</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Choice</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases Special Attack by 50%, but restricts the holder to only one move.</strong></p>
<p>Held: Increases the holder’s Special Attack by 50%, but restricts it to the first move it uses until it leaves battle or loses this item. If this item is swapped for another Choice item via Trick or Switcheroo, the holder’s restriction is still lifted, but it will again be restricted to the next move it uses. (Quirk: If the holder is switched in by U-Turn and it also knows U-Turn, U-Turn becomes its restricted move.)</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. These distinctive glasses boost Sp. Atk, but allow only one kind of move to be used.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>125</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Galactic HQ](../locations/header-305.md) | D26R0101 | `header-305` | Visible | (16, 6) |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Script Awarded | — |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Magmortar |
| [Elite Four Lucian](../trainers/trainer-0869.md) | Held by Latios |
| [Elite Four Flint](../trainers/trainer-0988.md) | Held by Charizard |
| [Elite Four Flint](../trainers/trainer-0989.md) | Held by Houndoom |
| [Champion Cynthia](../trainers/trainer-0994.md) | Held by Glaceon |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Magmortar |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Celestic Town</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Celestic Town</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/glaceon/">Glaceon</a></li><li><a href="../../pokemon/magmortar/">Magmortar</a></li><li><a href="../../pokemon/magmortar/">Magmortar</a></li><li><a href="../../pokemon/houndoom/">Houndoom</a></li><li><a href="../../pokemon/charizard/">Charizard</a></li><li><a href="../../pokemon/latios/">Latios</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `275` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `275`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/274/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../big-root/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-root.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Big Root</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../flame-plate/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/flame-plate.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Flame Plate →</span></a>
</nav>
