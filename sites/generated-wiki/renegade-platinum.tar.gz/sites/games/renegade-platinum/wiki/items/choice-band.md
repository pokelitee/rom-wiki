# Choice Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-band.png" alt="Choice Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>220</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Choice</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases Attack by 50%, but restricts the holder to only one move.</strong></p>
<p>Held in battle : Holder has 1.5× its Attack. When the holder attempts to use a move, all its other moves are disabled until it leaves battle or loses this item. The restriction ends even if this item is swapped for another Choice item via Trick or Switcheroo.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. This headband ups Attack, but allows the use of only one kind of move.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>55</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Floaroma Meadow — D13R0101](../locations/header-256.md) | Hidden | (13, 36) |
| [Stark Mountain — D16R0102](../locations/header-264.md) | Visible | (12, 76) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Specialty | ₽100 | Always |
| [Battle Park — D31R0101](../locations/header-323.md) | Frontier | 48 BP | Always |
| [Battle Frontier — D32](../locations/header-559.md) | Frontier | 48 BP | Always |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Aaron](../trainers/trainer-0261.md) | Held by Armaldo |
| [Elite Four Bertha](../trainers/trainer-0262.md) | Held by Rhyperior |
| [Elite Four Flint](../trainers/trainer-0263.md) | Held by Flareon |
| [Leader Volkner](../trainers/trainer-0320.md) | Held by Luxray |
| [Galactic Boss Cyrus](../trainers/trainer-0403.md) | Held by Crobat |
| [Galactic Boss Cyrus](../trainers/trainer-0404.md) | Held by Crobat |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Rhyperior |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Held by Staraptor |
| [Leader Gardenia](../trainers/trainer-0857.md) | Held by Torterra |
| [Leader Wake](../trainers/trainer-0859.md) | Held by Floatzel |
| [Elite Four Bertha](../trainers/trainer-0867.md) | Held by Dugtrio |
| [Pokémon Trainer Dawn](../trainers/trainer-0963.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0964.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | Held by Lopunny |
| [Pokémon Trainer Lucas](../trainers/trainer-0966.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0967.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | Held by Granbull |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | Held by Mamoswine |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | Held by Mamoswine |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | Held by Mamoswine |
| [Elite Four Aaron](../trainers/trainer-0981.md) | Held by Armaldo |
| [Elite Four Bertha](../trainers/trainer-0984.md) | Held by Rhyperior |
| [Elite Four Bertha](../trainers/trainer-0985.md) | Held by Dugtrio |
| [Elite Four Bertha](../trainers/trainer-0985.md) | Held by Rhyperior |
| [Elite Four Bertha](../trainers/trainer-0986.md) | Held by Dugtrio |
| [Elite Four Bertha](../trainers/trainer-0986.md) | Held by Rhyperior |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | Held by Mamoswine |
| [Pokémon Trainer Dawn](../trainers/trainer-1055.md) | Held by Mamoswine |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | Held by Mamoswine |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | Held by Mamoswine |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Rhyperior |
| [Galactic Boss Cyrus](../trainers/trainer-1063.md) | Held by Crobat |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">39 entries added</p><ul class="rw-comparison-list"><li>Rhyperior</li><li>Rhyperior</li><li>Armaldo</li><li>Armaldo</li><li>Rhyperior</li><li>Rhyperior</li><li>Rhyperior</li><li>Rhyperior</li><li>Dugtrio</li><li>Dugtrio</li><li>Dugtrio</li><li>Flareon</li><li>Crobat</li><li>Crobat</li><li>Crobat</li><li>Torterra</li><li>Luxray</li><li>Floatzel</li><li>Staraptor</li><li>Staraptor</li><li>Staraptor</li><li>Lopunny</li><li>Lopunny</li><li>Lopunny</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Granbull</li><li>Granbull</li><li>Granbull</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li><li>Mamoswine</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `198` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `198`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/197/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../mental-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/mental-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Mental Herb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../kings-rock/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/kings-rock.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">King&#x27;s Rock →</span></a>
</nav>
