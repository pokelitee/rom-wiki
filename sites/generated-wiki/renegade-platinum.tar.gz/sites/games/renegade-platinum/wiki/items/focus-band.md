# Focus Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-band.png" alt="Focus Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>230</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder has 10% chance to survive attacks or self-inflicted damage at 1 HP.</strong></p>
<p>Held: If the holder is attacked for regular damage that would faint it, this item has a 10% chance to prevent the holder’s HP from lowering below 1.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. The holder may endure a potential KO attack, leaving it with just 1 HP.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>65</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Jubilife City](../locations/header-027.md) | C01R0504 | `header-027` | Script Awarded | — |
| [Route 229](../locations/header-407.md) | R229 | `header-407` | Visible | (828, 436) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽200 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 48 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 48 BP | Always |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/66.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machop](../pokemon/machop.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/67.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/68.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machamp](../pokemon/machamp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Route 229</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 229</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Machop</li><li>Machoke</li><li>Machamp</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `208` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `208`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/207/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../everstone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/everstone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Everstone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../lucky-egg/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lucky-egg.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Lucky Egg →</span></a>
</nav>
