# Pink Scarf

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pink-scarf.png" alt="Pink Scarf icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>262</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Scarves</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises the holder’s Cuteness while in a contest.</strong></p>
<p>Held: Increases the holder’s Cuteness during a Super Contest’s Visual Competition.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It boosts the “Cute” aspect of the holder in a Contest.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [T.G. Eterna Bldg](../locations/header-073.md) | C04R0202 | `header-073` | Visible | (3, 12) |
| [Pastoria City](../locations/header-131.md) | C06R0601 | `header-131` | Script Awarded | — |
| [Mt. Coronet](../locations/header-210.md) | D05R0104 | `header-210` | Hidden | (32, 14) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **platinum-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `240` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `240`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/239/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../blue-scarf/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-scarf.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Blue Scarf</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../green-scarf/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-scarf.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Green Scarf →</span></a>
</nav>
