# Black Sludge

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/black-sludge.png" alt="Black Sludge icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>281</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Poison-type holder recovers 1/16 (6.25%) max HP each turn. Non-Poison-Types take 1/8 (12.5%) max HP damage.</strong></p>
<p>Held: If the holder is Poison-type, restores 1/16 max HP at the end of each turn. Otherwise, damages the holder by 1/16 its max HP at the end of each turn.</p>

<figure class="rw-pokedex-entry">
<blockquote>A hold item that gradually restores the HP of Poison-type Pokémon. It inflicts damage on all other types.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>109</dd></div>
<div><dt>Held effect parameter</dt><dd>16</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Fuego Ironworks](../locations/header-205.md) | D04R0101 | `header-205` | Visible | (27, 16) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/453.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Croagunk](../pokemon/croagunk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Ace Trainer Slythe](../trainers/trainer-1025.md) | Held by Tentacruel |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Grimer</li><li>Muk</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Tentacruel</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `259` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `259`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/258/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../destiny-knot/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/destiny-knot.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Destiny Knot</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../icy-rock/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/icy-rock.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Icy Rock →</span></a>
</nav>
