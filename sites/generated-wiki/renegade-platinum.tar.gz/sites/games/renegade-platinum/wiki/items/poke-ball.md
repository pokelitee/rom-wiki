# Poké Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="Poké Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>4</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Standard Balls</dd></div>
<div><dt>Base price</dt><dd>₽50</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A device for catching wild Pokémon. It is thrown like a ball at the target. It is designed as a capsule system.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Oreburgh Gate](../locations/header-259.md) | D14R0102 | `header-259` | Visible | (23, 10) |
| [Route 202](../locations/header-343.md) | R202 | `header-343` | Script Awarded | — |
| [Route 206](../locations/header-350.md) | R206 | `header-350` | Hidden | (313, 647) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | C01FS0101 | `header-004` | Common | ₽50 | Start |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Common | ₽50 | Start |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Common | ₽50 | Start |
| [Eterna City](../locations/header-066.md) | C04FS0101 | `header-066` | Common | ₽50 | Start |
| [Hearthome City](../locations/header-087.md) | C05FS0101 | `header-087` | Common | ₽50 | Start |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Common | ₽50 | Start |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Specialty | ₽50 | Always |
| [Sunyshore City](../locations/header-153.md) | C08FS0101 | `header-153` | Common | ₽50 | Start |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽50 | Always |
| [Snowpoint City](../locations/header-166.md) | C09FS0101 | `header-166` | Common | ₽50 | Start |
| [Pokémon League](../locations/header-173.md) | C10PC0101 | `header-173` | Common | ₽50 | Start |
| [Pokémon League](../locations/header-175.md) | C10R0101 | `header-175` | Common | ₽50 | Start |
| [Fight Area](../locations/header-191.md) | C11FS0101 | `header-191` | Common | ₽50 | Start |
| [Sandgem Town](../locations/header-419.md) | T02FS0101 | `header-419` | Common | ₽50 | Start |
| [Floaroma Town](../locations/header-427.md) | T03FS0101 | `header-427` | Common | ₽50 | Start |
| [Solaceon Town](../locations/header-434.md) | T04FS0101 | `header-434` | Common | ₽50 | Start |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽50 | Start |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽50 | Start |
| [Survival Area](../locations/header-451.md) | T06FS0101 | `header-451` | Common | ₽50 | Start |
| [Resort Area](../locations/header-458.md) | T07FS0101 | `header-458` | Common | ₽50 | Start |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">200<span class="rw-diff-arrow">→</span>50</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Route 202</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 202</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">18 entries removed</p><ul class="rw-comparison-list"><li>Pastoria City</li><li>Pastoria City</li><li>Sunyshore City</li><li>Snowpoint City</li><li>Pokémon League</li><li>Pokémon League</li><li>Fight Area</li><li>Canalave City</li><li>Jubilife City</li><li>Sandgem Town</li><li>Floaroma Town</li><li>Solaceon Town</li><li>Celestic Town</li><li>Survival Area</li><li>Resort Area</li><li>Oreburgh City</li><li>Eterna City</li><li>Hearthome City</li></ul><p class="rw-comparison-count">18 entries added</p><ul class="rw-comparison-list"><li>Pastoria City</li><li>Pastoria City</li><li>Sunyshore City</li><li>Snowpoint City</li><li>Pokémon League</li><li>Pokémon League</li><li>Fight Area</li><li>Canalave City</li><li>Jubilife City</li><li>Sandgem Town</li><li>Floaroma Town</li><li>Solaceon Town</li><li>Celestic Town</li><li>Survival Area</li><li>Resort Area</li><li>Oreburgh City</li><li>Eterna City</li><li>Hearthome City</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `4` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `4`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/4/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../great-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Great Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../safari-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/safari-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Safari Ball →</span></a>
</nav>
