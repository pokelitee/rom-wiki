# Nest Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/nest-ball.png" alt="Nest Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>8</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Special Balls</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Success rate is 3.9× for level 1 Pokémon, and drops steadily to 1× at level 30.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon. Has a catch rate of given by `(40 - level) / 10`, where `level` is the wild Pokémon’s level, to a maximum of 3.9× for level 1 Pokémon. If the wild Pokémon’s level is higher than 30, this ball has a catch rate of 1×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A somewhat different Poké Ball that works especially well on weaker Pokémon in the wild.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Oreburgh Mine](../locations/header-199.md) | D01R0102 | `header-199` | Visible | (26, 24) |
| [Wayward Cave](../locations/header-284.md) | D21R0101 | `header-284` | Hidden | (17, 43) |
| [Route 207](../locations/header-353.md) | R207 | `header-353` | Hidden | (349, 725) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Specialty | ₽1,000 | Always |
| [Eterna City](../locations/header-081.md) | C04R0501 | `header-081` | Specialty | ₽1,000 | Always |
| [Sunyshore City](../locations/header-153.md) | C08FS0101 | `header-153` | Specialty | ₽1,000 | Always |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽50 | Always |
| [Pokémon League](../locations/header-173.md) | C10PC0101 | `header-173` | Specialty | ₽1,000 | Always |
| [Pokémon League](../locations/header-175.md) | C10R0101 | `header-175` | Specialty | ₽1,000 | Always |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Specialty | ₽1,000 | Always |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **platinum-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `8` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `8`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/8/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../dive-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dive-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Dive Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../repeat-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repeat-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Repeat Ball →</span></a>
</nav>
