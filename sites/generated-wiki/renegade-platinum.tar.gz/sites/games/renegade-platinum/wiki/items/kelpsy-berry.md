# Kelpsy Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/kelpsy-berry.png" alt="Kelpsy Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>170</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Effort Drop</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Drops Attack Effort Values by 10 and raises happiness.</strong></p>
<p>Used on a party Pokémon : Increases happiness by 10/5/2. Lowers Attack effort by 10.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. Using it on a Pokémon makes it more friendly, but it also lowers its base Attack stat.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>70 power, <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>Attack EVs -10, friendship (low +10, medium +5, high +2)</dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Hard</dd></div>
<div><dt>Size</dt><dd>150 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>8 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>8</dd></div>
</dl>

### Contest flavor

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>0</dd></div>
<div><dt>Dry</dt><dd>10</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>10</dd></div>
<div><dt>Sour</dt><dd>10</dd></div>
<div><dt>Smoothness</dt><dd>20</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Mt. Coronet](../locations/header-208.md) | D05R0102 | `header-208` | Visible | (3, 31) |
| [Route 224](../locations/header-399.md) | R224 | `header-399` | Hidden | (917, 529) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **platinum-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `148` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `148`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/147/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../pomeg-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pomeg-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Pomeg Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../qualot-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/qualot-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Qualot Berry →</span></a>
</nav>
