# Hyper Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="Hyper Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>25</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 200 HP.</strong></p>
<p>Used on a party Pokémon : Restores 200 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>200</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 200</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Route 212](../locations/header-371.md) | Hidden | (534, 851) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | Common | ₽1,200 | 3 badges |
| [Canalave City](../locations/header-034.md) | Common | ₽1,200 | 3 badges |
| [Oreburgh City](../locations/header-046.md) | Common | ₽1,200 | 3 badges |
| [Eterna City](../locations/header-066.md) | Common | ₽1,200 | 3 badges |
| [Hearthome City](../locations/header-087.md) | Common | ₽1,200 | 3 badges |
| [Pastoria City](../locations/header-121.md) | Common | ₽1,200 | 3 badges |
| [Pastoria City](../locations/header-121.md) | Specialty | ₽1,200 | Always |
| [Veilstone Store](../locations/header-140.md) | Decoration | ₽4,500 | Always |
| [Sunyshore City](../locations/header-153.md) | Common | ₽1,200 | 3 badges |
| [Sunyshore Market](../locations/header-157.md) | Seal | ₽50 | Always |
| [Snowpoint City](../locations/header-166.md) | Common | ₽1,200 | 3 badges |
| [Pokémon League](../locations/header-173.md) | Common | ₽1,200 | 3 badges |
| [Pokémon League](../locations/header-175.md) | Common | ₽1,200 | 3 badges |
| [Fight Area](../locations/header-191.md) | Common | ₽1,200 | 3 badges |
| [Sandgem Town](../locations/header-419.md) | Common | ₽1,200 | 3 badges |
| [Floaroma Town](../locations/header-427.md) | Common | ₽1,200 | 3 badges |
| [Floaroma Town](../locations/header-427.md) | Specialty | ₽1,200 | Always |
| [Solaceon Town](../locations/header-434.md) | Common | ₽1,200 | 3 badges |
| [Celestic Town](../locations/header-446.md) | Common | ₽1,200 | 3 badges |
| [Celestic Town](../locations/header-446.md) | Common | ₽1,200 | 3 badges |
| [Survival Area](../locations/header-451.md) | Common | ₽1,200 | 3 badges |
| [Resort Area](../locations/header-458.md) | Common | ₽1,200 | 3 badges |
| [Veilstone Store](../locations/header-566.md) | Specialty | ₽1,200 | Always |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Wake](../trainers/trainer-0316.md) | AI battle item |
| [Leader Maylene](../trainers/trainer-0317.md) | AI battle item |
| [Leader Fantina](../trainers/trainer-0318.md) | AI battle item |
| [Leader Volkner](../trainers/trainer-0320.md) | AI battle item |
| [School Kid Tiera](../trainers/trainer-0344.md) | AI battle item |
| [Pokémon Trainer Cheryl](../trainers/trainer-0608.md) | AI battle item |
| [Pokémon Trainer Mira](../trainers/trainer-0612.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0940.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0941.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0942.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0943.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0944.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0945.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0963.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0964.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0966.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0967.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | AI battle item |
| [Pokémon Trainer Mira](../trainers/trainer-1065.md) | AI battle item |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Cyrus</li><li>Cyrus</li><li>Byron</li><li>Candice</li></ul><p class="rw-comparison-count">17 entries added</p><ul class="rw-comparison-list"><li>Fantina</li><li>Maylene</li><li>Cheryl</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Mira</li><li>Mira</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `25` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `25`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/25/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Potion →</span></a>
</nav>
