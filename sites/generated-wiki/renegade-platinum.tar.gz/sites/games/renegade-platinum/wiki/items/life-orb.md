# Life Orb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/life-orb.png" alt="Life Orb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>270</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s moves inflict 30% extra damage, but cost 10% max HP.</strong></p>
<p>Held: Damage from the holder’s moves is increased by 30%. On each turn the holder uses a damage-inflicting move, it takes 10% its max HP in damage.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It boosts the power of moves, but at the cost of some HP on each hit.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>98</dd></div>
<div><dt>Held effect parameter</dt><dd>30</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Mt. Coronet](../locations/header-210.md) | D05R0104 | `header-210` | Hidden | (10, 20) |
| [Route 215](../locations/header-382.md) | R215 | `header-382` | Visible | (660, 576) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | Held by Metagross |
| [Elite Four Aaron](../trainers/trainer-0261.md) | Held by Scizor |
| [Elite Four Bertha](../trainers/trainer-0262.md) | Held by Whiscash |
| [Elite Four Flint](../trainers/trainer-0263.md) | Held by Magmortar |
| [Elite Four Lucian](../trainers/trainer-0264.md) | Held by Alakazam |
| [Champion Cynthia](../trainers/trainer-0267.md) | Held by Lucario |
| [Leader Wake](../trainers/trainer-0316.md) | Held by Ludicolo |
| [Leader Wake](../trainers/trainer-0316.md) | Held by Floatzel |
| [Leader Maylene](../trainers/trainer-0317.md) | Held by Infernape |
| [Leader Candice](../trainers/trainer-0319.md) | Held by Froslass |
| [Leader Volkner](../trainers/trainer-0320.md) | Held by Electivire |
| [Galactic Boss Cyrus](../trainers/trainer-0403.md) | Held by Houndoom |
| [Galactic Boss Cyrus](../trainers/trainer-0404.md) | Held by Houndoom |
| [Commander Saturn](../trainers/trainer-0408.md) | Held by Toxicroak |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Alakazam |
| [Pokémon Trainer Cedric](../trainers/trainer-0473.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0474.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0479.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0479.md) | Held by Arcanine |
| [Pokémon Trainer Cedric](../trainers/trainer-0480.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0480.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0481.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0481.md) | Held by Arcanine |
| [Commander Mars](../trainers/trainer-0528.md) | Held by Crobat |
| [Pokémon Trainer Cedric](../trainers/trainer-0607.md) | Held by Azumarill |
| [Pokémon Trainer Cedric](../trainers/trainer-0619.md) | Held by Azumarill |
| [Leader Candice](../trainers/trainer-0853.md) | Held by Froslass |
| [Leader Volkner](../trainers/trainer-0855.md) | Held by Luxray |
| [Leader Gardenia](../trainers/trainer-0857.md) | Held by Roserade |
| [Leader Roark](../trainers/trainer-0858.md) | Held by Aerodactyl |
| [Leader Roark](../trainers/trainer-0858.md) | Held by Tyranitar |
| [Pokémon Trainer Mira](../trainers/trainer-0864.md) | Held by Alakazam |
| [Pokémon Trainer Cheryl](../trainers/trainer-0865.md) | Held by Hariyama |
| [Elite Four Aaron](../trainers/trainer-0866.md) | Held by Scyther |
| [Elite Four Flint](../trainers/trainer-0868.md) | Held by Infernape |
| [Elite Four Lucian](../trainers/trainer-0869.md) | Held by Alakazam |
| [Champion Cynthia](../trainers/trainer-0870.md) | Held by Lucario |
| [Galactic Boss Cyrus](../trainers/trainer-0913.md) | Held by Magnezone |
| [Commander Mars](../trainers/trainer-0926.md) | Held by Crobat |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | Held by Aerodactyl |
| [Pokémon Trainer Dawn](../trainers/trainer-0963.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-0964.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0966.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0967.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | Held by Alakazam |
| [Castle Valet Darach](../trainers/trainer-0969.md) | Held by Metagross |
| [Pokémon Trainer Riley](../trainers/trainer-0970.md) | Held by Lucario |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | Held by Heatran |
| [Arcade Star Dahlia](../trainers/trainer-0973.md) | Held by Ludicolo |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Held by Weavile |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | Held by Alakazam |
| [Elite Four Aaron](../trainers/trainer-0981.md) | Held by Scyther |
| [Elite Four Aaron](../trainers/trainer-0982.md) | Held by Scizor |
| [Elite Four Aaron](../trainers/trainer-0983.md) | Held by Scyther |
| [Elite Four Aaron](../trainers/trainer-0983.md) | Held by Scizor |
| [Elite Four Flint](../trainers/trainer-0987.md) | Held by Magmortar |
| [Elite Four Flint](../trainers/trainer-0988.md) | Held by Magmortar |
| [Elite Four Flint](../trainers/trainer-0989.md) | Held by Magmortar |
| [Elite Four Lucian](../trainers/trainer-0990.md) | Held by Starmie |
| [Elite Four Lucian](../trainers/trainer-0992.md) | Held by Starmie |
| [Champion Cynthia](../trainers/trainer-0993.md) | Held by Lucario |
| [Champion Cynthia](../trainers/trainer-0994.md) | Held by Lucario |
| [Champion Cynthia](../trainers/trainer-0995.md) | Held by Lopunny |
| [Ace Trainer Slythe](../trainers/trainer-1025.md) | Held by Nidoqueen |
| [Ace Trainer Gene](../trainers/trainer-1027.md) | Held by Porygon-Z |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Held by Gardevoir |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Held by Starmie |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-1055.md) | Held by Alakazam |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | Held by Alakazam |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | Held by Alakazam |
| [Commander Mars](../trainers/trainer-1060.md) | Held by Crobat |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Alakazam |
| [Galactic Boss Cyrus](../trainers/trainer-1063.md) | Held by Houndoom |
| [Pokémon Trainer Mira](../trainers/trainer-1065.md) | Held by Kadabra |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Absol</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">85 entries added</p><ul class="rw-comparison-list"><li>Starmie</li><li>Porygon-Z</li><li>Aerodactyl</li><li>Gardevoir</li><li>Nidoqueen</li><li>Ludicolo</li><li>Metagross</li><li>Lopunny</li><li>Lucario</li><li>Lucario</li><li>Lucario</li><li>Lucario</li><li>Crobat</li><li>Crobat</li><li>Crobat</li><li>Toxicroak</li><li>Alakazam</li><li>Alakazam</li><li>Scyther</li><li>Scyther</li><li>Scyther</li><li>Scizor</li><li>Scizor</li><li>Scizor</li><li>Whiscash</li><li>Infernape</li><li>Magmortar</li><li>Magmortar</li><li>Magmortar</li><li>Magmortar</li><li>Starmie</li><li>Starmie</li><li>Alakazam</li><li>Alakazam</li><li>Houndoom</li><li>Houndoom</li><li>Houndoom</li><li>Magnezone</li><li>Froslass</li><li>Froslass</li><li>Roserade</li><li>Infernape</li><li>Aerodactyl</li><li>Tyranitar</li><li>Luxray</li><li>Electivire</li><li>Ludicolo</li><li>Floatzel</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Azumarill</li><li>Breloom</li><li>Breloom</li><li>Arcanine</li><li>Arcanine</li><li>Hariyama</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Alakazam</li><li>Weavile</li><li>Kadabra</li><li>Alakazam</li><li>Lucario</li><li>Metagross</li><li>Heatran</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `248` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `248`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/247/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Light Clay</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../power-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/power-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Power Herb →</span></a>
</nav>
