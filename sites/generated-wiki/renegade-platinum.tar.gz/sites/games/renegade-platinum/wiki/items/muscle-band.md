# Muscle Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/muscle-band.png" alt="Muscle Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>266</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Boosts the damage of physical moves used by the holder by 10%.</strong></p>
<p>Held: Increases the power of the holder’s physical moves by 10%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a headband that slightly boosts the power of physical moves.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>94</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Old Chateau](../locations/header-296.md) | D25R0102 | `header-296` | Visible | (5, 3) |
| [Route 222](../locations/header-395.md) | R222 | `header-395` | Hidden | (796, 789) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽200 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 48 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 48 BP | Always |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | Held by Aerodactyl |
| [Leader Roark](../trainers/trainer-0246.md) | Held by Onix |
| [Leader Byron](../trainers/trainer-0250.md) | Held by Steelix |
| [Elite Four Lucian](../trainers/trainer-0264.md) | Held by Metagross |
| [Leader Gardenia](../trainers/trainer-0315.md) | Held by Breloom |
| [Leader Fantina](../trainers/trainer-0318.md) | Held by Banette |
| [Galactic Boss Cyrus](../trainers/trainer-0404.md) | Held by Gyarados |
| [Commander Mars](../trainers/trainer-0405.md) | Held by Kangaskhan |
| [Commander Jupiter](../trainers/trainer-0407.md) | Held by Sableye |
| [Commander Saturn](../trainers/trainer-0408.md) | Held by Rhydon |
| [Pokémon Trainer Cedric](../trainers/trainer-0470.md) | Held by Staravia |
| [Pokémon Trainer Cedric](../trainers/trainer-0471.md) | Held by Staravia |
| [Pokémon Trainer Cedric](../trainers/trainer-0472.md) | Held by Staravia |
| [Pokémon Trainer Cedric](../trainers/trainer-0473.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0474.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0475.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Held by Heracross |
| [Commander Mars](../trainers/trainer-0528.md) | Held by Kangaskhan |
| [Pokémon Trainer Cedric](../trainers/trainer-0607.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0619.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0620.md) | Held by Heracross |
| [Leader Byron](../trainers/trainer-0856.md) | Held by Forretress |
| [Leader Fantina](../trainers/trainer-0860.md) | Held by Dusknoir |
| [Pokémon Trainer Riley](../trainers/trainer-0861.md) | Held by Metagross |
| [Elite Four Aaron](../trainers/trainer-0866.md) | Held by Scizor |
| [Elite Four Lucian](../trainers/trainer-0869.md) | Held by Gallade |
| [Pokémon Trainer Cedric](../trainers/trainer-0871.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0872.md) | Held by Staraptor |
| [Pokémon Trainer Cedric](../trainers/trainer-0873.md) | Held by Staraptor |
| [Elite Four Flint](../trainers/trainer-0922.md) | Held by Flareon |
| [Commander Mars](../trainers/trainer-0926.md) | Held by Kangaskhan |
| [Commander Jupiter](../trainers/trainer-0927.md) | Held by Sableye |
| [Pokémon Trainer Dawn](../trainers/trainer-0940.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0941.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0942.md) | Held by Lopunny |
| [Pokémon Trainer Lucas](../trainers/trainer-0943.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0944.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0945.md) | Held by Granbull |
| [Elite Four Aaron](../trainers/trainer-0946.md) | Held by Scizor |
| [Commander Saturn](../trainers/trainer-0959.md) | Held by Toxicroak |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | Held by Flareon |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | Held by Flareon |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | Held by Rhyperior |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | Held by Granbull |
| [Elite Four Flint](../trainers/trainer-0987.md) | Held by Steelix |
| [Elite Four Flint](../trainers/trainer-0988.md) | Held by Lopunny |
| [Elite Four Lucian](../trainers/trainer-0992.md) | Held by Metagross |
| [Ace Trainer Shade](../trainers/trainer-1026.md) | Held by Weavile |
| [Ace Trainer Gene](../trainers/trainer-1027.md) | Held by Dodrio |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | Held by Granbull |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | Held by Granbull |
| [Commander Mars](../trainers/trainer-1060.md) | Held by Kangaskhan |
| [Commander Jupiter](../trainers/trainer-1061.md) | Held by Sableye |
| [Galactic Boss Cyrus](../trainers/trainer-1063.md) | Held by Gyarados |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">60 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dodrio/">Dodrio</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/sableye/">Sableye</a></li><li><a href="../../pokemon/sableye/">Sableye</a></li><li><a href="../../pokemon/sableye/">Sableye</a></li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a></li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a></li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a></li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a></li><li><a href="../../pokemon/rhydon/">Rhydon</a></li><li><a href="../../pokemon/toxicroak/">Toxicroak</a></li><li><a href="../../pokemon/scizor/">Scizor</a></li><li><a href="../../pokemon/scizor/">Scizor</a></li><li><a href="../../pokemon/flareon/">Flareon</a></li><li><a href="../../pokemon/steelix/">Steelix</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/gallade/">Gallade</a></li><li><a href="../../pokemon/gyarados/">Gyarados</a></li><li><a href="../../pokemon/gyarados/">Gyarados</a></li><li><a href="../../pokemon/forretress/">Forretress</a></li><li><a href="../../pokemon/steelix/">Steelix</a></li><li><a href="../../pokemon/banette/">Banette</a></li><li><a href="../../pokemon/dusknoir/">Dusknoir</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/onix/">Onix</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/staravia/">Staravia</a></li><li><a href="../../pokemon/staravia/">Staravia</a></li><li><a href="../../pokemon/staravia/">Staravia</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/staraptor/">Staraptor</a></li><li><a href="../../pokemon/flareon/">Flareon</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/flareon/">Flareon</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/granbull/">Granbull</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/aerodactyl/">Aerodactyl</a></li><li><a href="../../pokemon/rhyperior/">Rhyperior</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `244` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `244`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/243/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../wide-lens/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wide-lens.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Wide Lens</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../wise-glasses/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wise-glasses.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Wise Glasses →</span></a>
</nav>
