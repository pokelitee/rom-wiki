# Oak's Letter

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/oaks-letter.png" alt="Oak&#x27;s Letter icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>452</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Event Items</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>No</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Allows access to Seabreak path, Flower Paradise, and Shaymin.</strong></p>
<p>Grants access to Flower Paradise and Shaymin.</p>

<figure class="rw-pokedex-entry">
<blockquote>A letter from Prof. Oak. Written in it is a request for you to go to Rt. 224.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>7</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Eterna City](../locations/header-082.md) | C04R0601 | `header-082` | Script Awarded | — |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Eterna City</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `430` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `430`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/429/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../suite-key/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/suite-key.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Suite Key</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../lunar-wing/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lunar-wing.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Lunar Wing →</span></a>
</nav>
