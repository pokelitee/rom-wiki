# Expert Belt

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/expert-belt.png" alt="Expert Belt icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>268</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s Super Effective moves do 20% extra damage.</strong></p>
<p>Held: When the holder hits with a super-effective move, its power is raised by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a well-worn belt that slightly boosts the power of supereffective moves.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>96</dd></div>
<div><dt>Held effect parameter</dt><dd>20</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Stark Mountain](../locations/header-264.md) | D16R0102 | `header-264` | Hidden | (14, 13) |
| [Route 209](../locations/header-356.md) | R209 | `header-356` | Visible | (556, 703) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Roark](../trainers/trainer-0246.md) | Held by Geodude |
| [Elite Four Flint](../trainers/trainer-0263.md) | Held by Infernape |
| [Leader Candice](../trainers/trainer-0319.md) | Held by Abomasnow |
| [Leader Volkner](../trainers/trainer-0320.md) | Held by Raichu |
| [Galactic Boss Cyrus](../trainers/trainer-0403.md) | Held by Weavile |
| [Commander Saturn](../trainers/trainer-0408.md) | Held by Octillery |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Octillery |
| [Pokémon Trainer Cedric](../trainers/trainer-0473.md) | Held by Arcanine |
| [Pokémon Trainer Cedric](../trainers/trainer-0475.md) | Held by Arcanine |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Held by Arcanine |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Held by Arcanine |
| [Commander Mars](../trainers/trainer-0528.md) | Held by Electivire |
| [Pokémon Trainer Cedric](../trainers/trainer-0607.md) | Held by Arcanine |
| [Pokémon Trainer Cedric](../trainers/trainer-0620.md) | Held by Arcanine |
| [Leader Maylene](../trainers/trainer-0854.md) | Held by Medicham |
| [Leader Volkner](../trainers/trainer-0855.md) | Held by Electivire |
| [Pokémon Trainer Riley](../trainers/trainer-0861.md) | Held by Lucario |
| [Elite Four Bertha](../trainers/trainer-0867.md) | Held by Tyranitar |
| [Elite Four Flint](../trainers/trainer-0868.md) | Held by Magmortar |
| [Galactic Boss Cyrus](../trainers/trainer-0913.md) | Held by Weavile |
| [Commander Mars](../trainers/trainer-0926.md) | Held by Electivire |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | Held by Togekiss |
| [Castle Valet Darach](../trainers/trainer-0969.md) | Held by Alakazam |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Held by Starmie |
| [Elite Four Aaron](../trainers/trainer-0981.md) | Held by Pinsir |
| [Elite Four Aaron](../trainers/trainer-0983.md) | Held by Pinsir |
| [Elite Four Flint](../trainers/trainer-0987.md) | Held by Infernape |
| [Elite Four Flint](../trainers/trainer-0988.md) | Held by Arcanine |
| [Elite Four Flint](../trainers/trainer-0989.md) | Held by Arcanine |
| [Pokémon Trainer Buck](../trainers/trainer-1023.md) | Held by Cloyster |
| [Ace Trainer Slythe](../trainers/trainer-1025.md) | Held by Toxicroak |
| [Ace Trainer Shade](../trainers/trainer-1026.md) | Held by Sharpedo |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Held by Wigglytuff |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Held by Infernape |
| [Commander Mars](../trainers/trainer-1060.md) | Held by Electivire |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Octillery |
| [Pokémon Trainer Mira](../trainers/trainer-1065.md) | Held by Porygon2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">37 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/infernape/">Infernape</a></li><li><a href="../../pokemon/togekiss/">Togekiss</a></li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a></li><li><a href="../../pokemon/sharpedo/">Sharpedo</a></li><li><a href="../../pokemon/toxicroak/">Toxicroak</a></li><li><a href="../../pokemon/alakazam/">Alakazam</a></li><li><a href="../../pokemon/electivire/">Electivire</a></li><li><a href="../../pokemon/electivire/">Electivire</a></li><li><a href="../../pokemon/electivire/">Electivire</a></li><li><a href="../../pokemon/octillery/">Octillery</a></li><li><a href="../../pokemon/octillery/">Octillery</a></li><li><a href="../../pokemon/octillery/">Octillery</a></li><li><a href="../../pokemon/pinsir/">Pinsir</a></li><li><a href="../../pokemon/pinsir/">Pinsir</a></li><li><a href="../../pokemon/tyranitar/">Tyranitar</a></li><li><a href="../../pokemon/infernape/">Infernape</a></li><li><a href="../../pokemon/infernape/">Infernape</a></li><li><a href="../../pokemon/magmortar/">Magmortar</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/abomasnow/">Abomasnow</a></li><li><a href="../../pokemon/medicham/">Medicham</a></li><li><a href="../../pokemon/geodude/">Geodude</a></li><li><a href="../../pokemon/raichu/">Raichu</a></li><li><a href="../../pokemon/electivire/">Electivire</a></li><li><a href="../../pokemon/cloyster/">Cloyster</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/arcanine/">Arcanine</a></li><li><a href="../../pokemon/starmie/">Starmie</a></li><li><a href="../../pokemon/porygon2/">Porygon2</a></li><li><a href="../../pokemon/lucario/">Lucario</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `246` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `246`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/245/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../wise-glasses/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wise-glasses.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Wise Glasses</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Light Clay →</span></a>
</nav>
