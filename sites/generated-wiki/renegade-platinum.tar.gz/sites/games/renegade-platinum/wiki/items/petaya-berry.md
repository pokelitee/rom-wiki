# Petaya Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/petaya-berry.png" alt="Petaya Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>204</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>In A Pinch</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed at 1/4 max HP to boost Special Attack.</strong></p>
<p>Held in battle : When the holder has 1/4 its max HP remaining or less, it consumes this item to raise its Special Attack by one stage.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. If held by a Pokémon, it raises its Sp. Atk stat in a pinch.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>39</dd></div>
<div><dt>Held effect parameter</dt><dd>4</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>19</dd></div>
<div><dt>Fling effect ID</dt><dd>19</dd></div>
<div><dt>Natural Gift</dt><dd>80 power, <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span></dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Very Hard</dd></div>
<div><dt>Size</dt><dd>237 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>24 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>4</dd></div>
</dl>

### Contest flavor

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>30</dd></div>
<div><dt>Dry</dt><dd>0</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>30</dd></div>
<div><dt>Sour</dt><dd>10</dd></div>
<div><dt>Smoothness</dt><dd>40</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 208](../locations/header-355.md) | R208R0101 | `header-355` | Script Awarded | — |
| [Route 225](../locations/header-400.md) | R225 | `header-400` | Visible | (611, 388) |
| [Route 225](../locations/header-400.md) | R225 | `header-400` | Hidden | (621, 331) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Volkner](../trainers/trainer-0855.md) | Held by Jolteon |
| [Leader Fantina](../trainers/trainer-0860.md) | Held by Drifblim |
| [Pokémon Trainer Marley](../trainers/trainer-0863.md) | Held by Sceptile |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Held by Sceptile |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 208</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/drifblim/">Drifblim</a></li><li><a href="../../pokemon/jolteon/">Jolteon</a></li><li><a href="../../pokemon/sceptile/">Sceptile</a></li><li><a href="../../pokemon/sceptile/">Sceptile</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `182` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `182`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/181/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../salac-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/salac-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Salac Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../apicot-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/apicot-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Apicot Berry →</span></a>
</nav>
