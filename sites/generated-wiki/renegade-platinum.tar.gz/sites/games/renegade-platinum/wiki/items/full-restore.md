# Full Restore

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="Full Restore icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>23</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full and cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Restores HP to full and cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A medicine that fully restores the HP and heals any status problems of a single Pokémon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x0c</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion, restores HP, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Route 205](../locations/header-349.md) | Visible | (274, 541) |
| [Route 212](../locations/header-371.md) | Hidden | (527, 847) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | Common | ₽3,000 | 5 badges |
| [Canalave City](../locations/header-034.md) | Common | ₽3,000 | 5 badges |
| [Oreburgh City](../locations/header-046.md) | Common | ₽3,000 | 5 badges |
| [Eterna City](../locations/header-066.md) | Common | ₽3,000 | 5 badges |
| [Hearthome City](../locations/header-087.md) | Common | ₽3,000 | 5 badges |
| [Hearthome City](../locations/header-087.md) | Specialty | ₽3,000 | Always |
| [Pastoria City](../locations/header-121.md) | Common | ₽3,000 | 5 badges |
| [Sunyshore City](../locations/header-153.md) | Common | ₽3,000 | 5 badges |
| [Sunyshore Market](../locations/header-157.md) | Seal | ₽100 | Always |
| [Snowpoint City](../locations/header-166.md) | Common | ₽3,000 | 5 badges |
| [Pokémon League](../locations/header-173.md) | Common | ₽3,000 | 5 badges |
| [Pokémon League](../locations/header-175.md) | Common | ₽3,000 | 5 badges |
| [Fight Area](../locations/header-191.md) | Common | ₽3,000 | 5 badges |
| [Sandgem Town](../locations/header-419.md) | Common | ₽3,000 | 5 badges |
| [Floaroma Town](../locations/header-427.md) | Common | ₽3,000 | 5 badges |
| [Solaceon Town](../locations/header-434.md) | Common | ₽3,000 | 5 badges |
| [Celestic Town](../locations/header-446.md) | Common | ₽3,000 | 5 badges |
| [Celestic Town](../locations/header-446.md) | Common | ₽3,000 | 5 badges |
| [Survival Area](../locations/header-451.md) | Common | ₽3,000 | 5 badges |
| [Resort Area](../locations/header-458.md) | Common | ₽3,000 | 5 badges |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | AI battle item |
| [Rich Boy Jason](../trainers/trainer-0082.md) | AI battle item |
| [Lady Melissa](../trainers/trainer-0083.md) | AI battle item |
| [Gentleman Jeremy](../trainers/trainer-0084.md) | AI battle item |
| [Socialite Reina](../trainers/trainer-0085.md) | AI battle item |
| [Leader Byron](../trainers/trainer-0250.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0261.md) | AI battle item |
| [Elite Four Bertha](../trainers/trainer-0262.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0263.md) | AI battle item |
| [Elite Four Lucian](../trainers/trainer-0264.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0267.md) | AI battle item |
| [Leader Volkner](../trainers/trainer-0320.md) | AI battle item |
| [Rich Boy Trey](../trainers/trainer-0335.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0479.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0480.md) | AI battle item |
| [Gentleman Leonardo](../trainers/trainer-0542.md) | AI battle item |
| [Socialite Rebecca](../trainers/trainer-0543.md) | AI battle item |
| [Rich Boy Roman](../trainers/trainer-0545.md) | AI battle item |
| [Lady Kylie](../trainers/trainer-0546.md) | AI battle item |
| [Gentleman Jeremy](../trainers/trainer-0691.md) | AI battle item |
| [Gentleman Jeremy](../trainers/trainer-0692.md) | AI battle item |
| [Gentleman Jeremy](../trainers/trainer-0693.md) | AI battle item |
| [Socialite Reina](../trainers/trainer-0701.md) | AI battle item |
| [Socialite Reina](../trainers/trainer-0702.md) | AI battle item |
| [Rich Boy Trey](../trainers/trainer-0727.md) | AI battle item |
| [Rich Boy Trey](../trainers/trainer-0728.md) | AI battle item |
| [Lady Melissa](../trainers/trainer-0729.md) | AI battle item |
| [Lady Melissa](../trainers/trainer-0730.md) | AI battle item |
| [Lady Melissa](../trainers/trainer-0731.md) | AI battle item |
| [Leader Candice](../trainers/trainer-0853.md) | AI battle item |
| [Leader Maylene](../trainers/trainer-0854.md) | AI battle item |
| [Leader Volkner](../trainers/trainer-0855.md) | AI battle item |
| [Leader Byron](../trainers/trainer-0856.md) | AI battle item |
| [Leader Gardenia](../trainers/trainer-0857.md) | AI battle item |
| [Leader Roark](../trainers/trainer-0858.md) | AI battle item |
| [Leader Wake](../trainers/trainer-0859.md) | AI battle item |
| [Leader Fantina](../trainers/trainer-0860.md) | AI battle item |
| [Pokémon Trainer Riley](../trainers/trainer-0861.md) | AI battle item |
| [Pokémon Trainer Buck](../trainers/trainer-0862.md) | AI battle item |
| [Pokémon Trainer Marley](../trainers/trainer-0863.md) | AI battle item |
| [Pokémon Trainer Mira](../trainers/trainer-0864.md) | AI battle item |
| [Pokémon Trainer Cheryl](../trainers/trainer-0865.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0866.md) | AI battle item |
| [Elite Four Bertha](../trainers/trainer-0867.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0868.md) | AI battle item |
| [Elite Four Lucian](../trainers/trainer-0869.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0870.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0871.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0872.md) | AI battle item |
| [Pokémon Trainer Cedric](../trainers/trainer-0873.md) | AI battle item |
| [Rich Boy Liam](../trainers/trainer-0892.md) | AI battle item |
| [Lady Celeste](../trainers/trainer-0893.md) | AI battle item |
| [Leader Volkner](../trainers/trainer-0921.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0922.md) | AI battle item |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0946.md) | AI battle item |
| [Gentleman Backlot](../trainers/trainer-0960.md) | AI battle item |
| [Castle Valet Darach](../trainers/trainer-0969.md) | AI battle item |
| [Pokémon Trainer Riley](../trainers/trainer-0970.md) | AI battle item |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | AI battle item |
| [Arcade Star Dahlia](../trainers/trainer-0973.md) | AI battle item |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0981.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0982.md) | AI battle item |
| [Elite Four Aaron](../trainers/trainer-0983.md) | AI battle item |
| [Elite Four Bertha](../trainers/trainer-0984.md) | AI battle item |
| [Elite Four Bertha](../trainers/trainer-0985.md) | AI battle item |
| [Elite Four Bertha](../trainers/trainer-0986.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0987.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0988.md) | AI battle item |
| [Elite Four Flint](../trainers/trainer-0989.md) | AI battle item |
| [Elite Four Lucian](../trainers/trainer-0990.md) | AI battle item |
| [Elite Four Lucian](../trainers/trainer-0991.md) | AI battle item |
| [Elite Four Lucian](../trainers/trainer-0992.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0993.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0994.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0995.md) | AI battle item |
| [Pokémon Trainer Buck](../trainers/trainer-1023.md) | AI battle item |
| [Ace Trainer Wyver](../trainers/trainer-1024.md) | AI battle item |
| [Ace Trainer Slythe](../trainers/trainer-1025.md) | AI battle item |
| [Ace Trainer Shade](../trainers/trainer-1026.md) | AI battle item |
| [Ace Trainer Gene](../trainers/trainer-1027.md) | AI battle item |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | AI battle item |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | AI battle item |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | AI battle item |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Cyrus</li><li>Cyrus</li><li>Candice</li><li>Cedric</li><li>Cedric</li><li>Cedric</li><li>Cedric</li><li>Cedric</li><li>Cedric</li></ul><p class="rw-comparison-count">44 entries added</p><ul class="rw-comparison-list"><li>Gene</li><li>Heather</li><li>Luna</li><li>Shade</li><li>Slythe</li><li>Wyver</li><li>Dahlia</li><li>Darach</li><li>Cynthia</li><li>Cynthia</li><li>Cynthia</li><li>Aaron</li><li>Aaron</li><li>Aaron</li><li>Aaron</li><li>Bertha</li><li>Bertha</li><li>Bertha</li><li>Flint</li><li>Flint</li><li>Flint</li><li>Lucian</li><li>Lucian</li><li>Lucian</li><li>Backlot</li><li>Maylene</li><li>Buck</li><li>Cedric</li><li>Cedric</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Dawn</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Lucas</li><li>Marley</li><li>Riley</li><li>Steven</li><li>Palmer</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `23` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `23`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/23/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../parlyz-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/paralyze-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Parlyz Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Potion →</span></a>
</nav>
