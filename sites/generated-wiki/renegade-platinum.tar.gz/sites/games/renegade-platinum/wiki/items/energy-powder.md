# Energy Powder

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/energy-powder.png" alt="Energy Powder icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>34</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 50 HP, but lowers happiness.</strong></p>
<p>Used on a party Pokémon : Restores 50 HP. Decreases happiness by 5/5/10.</p>

<figure class="rw-pokedex-entry">
<blockquote>A very bitter medicine powder. It restores the HP of one Pokémon by 50 points.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 50, friendship (low -5, medium -5, high -10)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Wayward Cave](../locations/header-284.md) | D21R0101 | `header-284` | Visible | (8, 44) |
| [Solaceon Town](../locations/header-433.md) | T04 | `header-433` | Hidden | (594, 640) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Veilstone Store](../locations/header-137.md) | C07R0201 | `header-137` | Specialty | ₽500 | Always |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽50 | Always |
| [Snowpoint City](../locations/header-166.md) | C09FS0101 | `header-166` | Specialty | ₽500 | Always |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Name</p>
<div class="rw-change__value">EnergyPowder<span class="rw-diff-arrow">→</span>Energy Powder</div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `34` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `34`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/34/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../moomoo-milk/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moomoo-milk.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Moomoo Milk</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../energy-root/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/energy-root.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Energy Root →</span></a>
</nav>
