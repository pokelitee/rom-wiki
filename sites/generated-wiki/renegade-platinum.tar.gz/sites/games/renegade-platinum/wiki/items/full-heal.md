# Full Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-heal.png" alt="Full Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>27</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It heals all the status problems of a single Pokémon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Pastoria City — C06](../locations/header-120.md) | Hidden | (583, 857) |
| [Route 211 — R211A](../locations/header-365.md) | Visible | (368, 535) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City — C01FS0101](../locations/header-004.md) | Common | ₽600 | 3 badges |
| [Canalave City — C02FS0101](../locations/header-034.md) | Common | ₽600 | 3 badges |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Common | ₽600 | 3 badges |
| [Eterna City — C04FS0101](../locations/header-066.md) | Common | ₽600 | 3 badges |
| [Hearthome City — C05FS0101](../locations/header-087.md) | Common | ₽600 | 3 badges |
| [Pastoria City — C06FS0101](../locations/header-121.md) | Common | ₽600 | 3 badges |
| [Veilstone Store — C07R0201](../locations/header-137.md) | Specialty | ₽600 | Always |
| [Veilstone Store — C07R0204](../locations/header-140.md) | Decoration | ₽3,000 | Always |
| [Sunyshore City — C08FS0101](../locations/header-153.md) | Common | ₽600 | 3 badges |
| [Sunyshore Market — C08R0101](../locations/header-157.md) | Seal | ₽50 | Always |
| [Snowpoint City — C09FS0101](../locations/header-166.md) | Common | ₽600 | 3 badges |
| [Pokémon League — C10PC0101](../locations/header-173.md) | Common | ₽600 | 3 badges |
| [Pokémon League — C10R0101](../locations/header-175.md) | Common | ₽600 | 3 badges |
| [Fight Area — C11FS0101](../locations/header-191.md) | Common | ₽600 | 3 badges |
| [Sandgem Town — T02FS0101](../locations/header-419.md) | Common | ₽600 | 3 badges |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Common | ₽600 | 3 badges |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Specialty | ₽600 | Always |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Common | ₽600 | 3 badges |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽600 | 3 badges |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽600 | 3 badges |
| [Survival Area — T06FS0101](../locations/header-451.md) | Common | ₽600 | 3 badges |
| [Resort Area — T07FS0101](../locations/header-458.md) | Common | ₽600 | 3 badges |
| [Veilstone Store — C07R0207](../locations/header-566.md) | Specialty | ₽600 | Always |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokéfan Leonard](../trainers/trainer-0530.md) | AI battle item |
| [Pokéfan Rebekah](../trainers/trainer-0531.md) | AI battle item |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `27` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `27`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/27/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Super Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../revive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/revive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Revive →</span></a>
</nav>
