# Carbos

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="Carbos icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>48</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Speed effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Speed effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Speed stat of a single Pokémon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Speed EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Route 208](../locations/header-354.md) | R208 | `header-354` | Visible | (401, 705) |
| [Route 220](../locations/header-467.md) | W220 | `header-467` | Hidden | (181, 922) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽9,800 | Always |
| [Veilstone Store](../locations/header-137.md) | C07R0201 | `header-137` | Specialty | ₽9,800 | Always |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽50 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 1 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 1 BP | Always |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `48` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `48`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/48/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../iron/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iron.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Iron</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../calcium/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/calcium.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Calcium →</span></a>
</nav>
