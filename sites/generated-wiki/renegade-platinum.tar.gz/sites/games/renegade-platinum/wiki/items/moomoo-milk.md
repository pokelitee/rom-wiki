# Moomoo Milk

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moomoo-milk.png" alt="Moomoo Milk icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>33</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 100 HP.</strong></p>
<p>Used on a party Pokémon : Restores 100 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>Milk with a very high nutrition content. It restores the HP of one Pokémon by 100 points.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>100</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 100</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Route 206 — R206](../locations/header-350.md) | Visible | (302, 652) |
| [Route 209 — R209](../locations/header-356.md) | Hidden | (565, 694) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Veilstone Store — C07R0201](../locations/header-137.md) | Specialty | ₽500 | Always |
| [Sunyshore Market — C08R0101](../locations/header-157.md) | Seal | ₽50 | Always |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `33` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `33`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/33/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../lemonade/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lemonade.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Lemonade</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../energy-powder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/energy-powder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Energy Powder →</span></a>
</nav>
