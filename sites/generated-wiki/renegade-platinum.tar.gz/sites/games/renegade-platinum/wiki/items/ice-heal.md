# Ice Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ice-heal.png" alt="Ice Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>20</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽250</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures freezing.</strong></p>
<p>Used on a party Pokémon : Cures freezing.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It defrosts a Pokémon that has been frozen solid.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures freeze</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Eterna Forest — D03R0101](../locations/header-203.md) | Visible | (50, 85) |
| [Route 212 — R212B](../locations/header-371.md) | Hidden | (471, 856) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City — C01FS0101](../locations/header-004.md) | Common | ₽250 | 1 badge |
| [Canalave City — C02FS0101](../locations/header-034.md) | Common | ₽250 | 1 badge |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Common | ₽250 | 1 badge |
| [Eterna City — C04FS0101](../locations/header-066.md) | Common | ₽250 | 1 badge |
| [Hearthome City — C05FS0101](../locations/header-087.md) | Common | ₽250 | 1 badge |
| [Pastoria City — C06FS0101](../locations/header-121.md) | Common | ₽250 | 1 badge |
| [Veilstone Store — C07R0201](../locations/header-137.md) | Specialty | ₽250 | Always |
| [Sunyshore City — C08FS0101](../locations/header-153.md) | Common | ₽250 | 1 badge |
| [Sunyshore Market — C08R0101](../locations/header-157.md) | Seal | ₽100 | Always |
| [Snowpoint City — C09FS0101](../locations/header-166.md) | Common | ₽250 | 1 badge |
| [Pokémon League — C10PC0101](../locations/header-173.md) | Common | ₽250 | 1 badge |
| [Pokémon League — C10R0101](../locations/header-175.md) | Common | ₽250 | 1 badge |
| [Fight Area — C11FS0101](../locations/header-191.md) | Common | ₽250 | 1 badge |
| [Sandgem Town — T02FS0101](../locations/header-419.md) | Common | ₽250 | 1 badge |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Common | ₽250 | 1 badge |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Common | ₽250 | 1 badge |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽250 | 1 badge |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽250 | 1 badge |
| [Survival Area — T06FS0101](../locations/header-451.md) | Common | ₽250 | 1 badge |
| [Resort Area — T07FS0101](../locations/header-458.md) | Common | ₽250 | 1 badge |
| [Veilstone Store — C07R0207](../locations/header-566.md) | Specialty | ₽250 | Always |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `20` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `20`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/20/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../burn-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/burn-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Burn Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../awakening/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/awakening.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Awakening →</span></a>
</nav>
