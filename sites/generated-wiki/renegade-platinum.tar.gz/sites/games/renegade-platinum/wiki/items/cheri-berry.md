# Cheri Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cheri-berry.png" alt="Cheri Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>149</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Medicine</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when paralyzed to cure paralysis.</strong></p>
<p>Held in battle : When the holder is paralyzed, it consumes this item to cure the paralysis. Used on a party Pokémon : Cures paralysis.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. It may be used or held by a Pokémon to recover from paralysis.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>5</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>1</dd></div>
<div><dt>Fling effect ID</dt><dd>1</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>cures paralysis</dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Soft</dd></div>
<div><dt>Size</dt><dd>20 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>3 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>15</dd></div>
</dl>

**Contest flavor:**

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>10</dd></div>
<div><dt>Dry</dt><dd>0</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>0</dd></div>
<div><dt>Sour</dt><dd>0</dd></div>
<div><dt>Smoothness</dt><dd>25</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Mt. Coronet](../locations/header-218.md) | D05R0112 | `header-218` | Visible | (28, 43) |
| [Route 210](../locations/header-362.md) | R210A | `header-362` | Hidden | (555, 562) |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Glameow</li><li>Purugly</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `127` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `127`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/126/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../brick-mail/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/brick-mail.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Brick Mail</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../chesto-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chesto-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Chesto Berry →</span></a>
</nav>
