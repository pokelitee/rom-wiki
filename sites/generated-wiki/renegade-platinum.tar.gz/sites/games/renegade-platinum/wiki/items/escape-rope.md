# Escape Rope

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/escape-rope.png" alt="Escape Rope icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>78</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Spelunking</dd></div>
<div><dt>Base price</dt><dd>₽550</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Transports user to the outside entrance of a cave.</strong></p>
<p>Used outside of battle : Transports the trainer to the last-entered dungeon entrance. Cannot be used outside, in buildings, or in Distortion World, Hall Of Origin, Spear Pillar, or Turnback Cave.</p>

<figure class="rw-pokedex-entry">
<blockquote>A long, durable rope. Use it to escape instantly from a cave or a dungeon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Escape Rope</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>21</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Galactic HQ — D26R0103](../locations/header-307.md) | Hidden | (39, 21) |
| [Route 213 — R213](../locations/header-373.md) | Visible | (686, 851) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City — C01FS0101](../locations/header-004.md) | Common | ₽550 | 1 badge |
| [Canalave City — C02FS0101](../locations/header-034.md) | Common | ₽550 | 1 badge |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Common | ₽550 | 1 badge |
| [Eterna City — C04FS0101](../locations/header-066.md) | Common | ₽550 | 1 badge |
| [Hearthome City — C05FS0101](../locations/header-087.md) | Common | ₽550 | 1 badge |
| [Pastoria City — C06FS0101](../locations/header-121.md) | Common | ₽550 | 1 badge |
| [Sunyshore City — C08FS0101](../locations/header-153.md) | Common | ₽550 | 1 badge |
| [Snowpoint City — C09FS0101](../locations/header-166.md) | Common | ₽550 | 1 badge |
| [Pokémon League — C10PC0101](../locations/header-173.md) | Common | ₽550 | 1 badge |
| [Pokémon League — C10R0101](../locations/header-175.md) | Common | ₽550 | 1 badge |
| [Fight Area — C11FS0101](../locations/header-191.md) | Common | ₽550 | 1 badge |
| [Sandgem Town — T02FS0101](../locations/header-419.md) | Common | ₽550 | 1 badge |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Common | ₽550 | 1 badge |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Common | ₽550 | 1 badge |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽550 | 1 badge |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽550 | 1 badge |
| [Survival Area — T06FS0101](../locations/header-451.md) | Common | ₽550 | 1 badge |
| [Resort Area — T07FS0101](../locations/header-458.md) | Common | ₽550 | 1 badge |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `78` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `78`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/78/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-repel/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Repel</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../repel/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repel.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Repel →</span></a>
</nav>
