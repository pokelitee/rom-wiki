# Ice Stone

<section class="rw-summary">
<div class="rw-summary__media"><span class="rw-summary__placeholder">Icon unavailable</span></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>457</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

No PokéDB reference data is available for this item.

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>triggers evolution</dd></div>
</dl>

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/471.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glaceon](../pokemon/glaceon.md)</span> | Use Item |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>11 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Name</p>
<div class="rw-change__value">Contest Pass<span class="rw-diff-arrow">→</span>Ice Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>2100</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Pocket</p>
<div class="rw-change__value">Key Items<span class="rw-diff-arrow">→</span>Items</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field pocket</p>
<div class="rw-change__value">7<span class="rw-diff-arrow">→</span>0</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field use</p>
<div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field-use function</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fling power</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>30</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party use</p>
<div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party effects</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Evolve: No<span class="rw-diff-arrow">→</span>Yes</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Prevents tossing</p>
<div class="rw-change__value">Yes<span class="rw-diff-arrow">→</span>No</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Evolutions</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Glaceon — use-item</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `435` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `435`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../tea/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tea.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Tea</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../magma-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/magma-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Magma Stone →</span></a>
</nav>
