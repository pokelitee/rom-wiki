# Oran Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/oran-berry.png" alt="Oran Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>155</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Medicine</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed at 1/2 max HP to recover 10 HP.</strong></p>
<p>Held in battle : When the holder has 1/2 its max HP remaining or less, it consumes this item to restore 10 HP. Used on a party Pokémon : Restores 10 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. It may be used or held by a Pokémon to heal the user by just 10 HP.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>1</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>7</dd></div>
<div><dt>Fling effect ID</dt><dd>7</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 10</dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Super Hard</dd></div>
<div><dt>Size</dt><dd>35 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>4 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>15</dd></div>
</dl>

### Contest flavor

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>10</dd></div>
<div><dt>Dry</dt><dd>10</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>10</dd></div>
<div><dt>Sour</dt><dd>10</dd></div>
<div><dt>Smoothness</dt><dd>20</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Fuego Ironworks](../locations/header-204.md) | D04 | `header-204` | Hidden | (177, 578) |
| [Mt. Coronet](../locations/header-219.md) | D05R0113 | `header-219` | Visible | (26, 17) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/316.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gulpin](../pokemon/gulpin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/317.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swalot](../pokemon/swalot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | Common |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Cedric](../trainers/trainer-0247.md) | Held by Turtwig |
| [Pokémon Trainer Cedric](../trainers/trainer-0248.md) | Held by Chimchar |
| [Pokémon Trainer Cedric](../trainers/trainer-0249.md) | Held by Piplup |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Sentret</li><li>Furret</li><li>Pichu</li><li>Shuckle</li><li>Shuckle</li><li>Pikachu</li><li>Raichu</li><li>Zigzagoon</li><li>Linoone</li><li>Bibarel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gulpin</li><li>Swalot</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/purugly/">Purugly</a></li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/turtwig/">Turtwig</a></li><li><a href="../../pokemon/chimchar/">Chimchar</a></li><li><a href="../../pokemon/piplup/">Piplup</a></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trades</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/abra/">ABRA</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `133` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `133`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/132/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../leppa-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leppa-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Leppa Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../persim-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/persim-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Persim Berry →</span></a>
</nav>
