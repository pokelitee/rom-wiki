# Armor Fossil

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/armor-fossil.png" alt="Armor Fossil icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>104</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Dex Completion</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">100</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Can be revived into a Shieldon.</strong></p>
<p>Give to a scientist in the Mining Museum in Oreburgh City or the Museum of Science in Pewter City to receive a Shieldon.</p>

<figure class="rw-pokedex-entry">
<blockquote>A fossil from a prehistoric Pokémon that lived on the land. It appears to be part of a collar.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Eterna City](../locations/header-084.md) | C04R0801 | `header-084` | Script Awarded | — |
| [Mt. Coronet](../locations/header-216.md) | D05R0110 | `header-216` | Hidden | (16, 35) |
| [Route 215](../locations/header-382.md) | R215 | `header-382` | Visible | (620, 580) |

## Fossil revival

Reviving this fossil produces:

<span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/410.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shieldon](../pokemon/shieldon.md)</span>

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Eterna City</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `104` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `104`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/104/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../old-amber/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/old-amber.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Old Amber</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../skull-fossil/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/skull-fossil.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Skull Fossil →</span></a>
</nav>
