# Leftovers

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leftovers.png" alt="Leftovers icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>234</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Restores 1/16 (6.25%) holder’s max HP at the end of each turn.</strong></p>
<p>Held: Heals the holder by 1/16 its max HP at the end of each turn.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. The holder’s HP is gradually restored during battle.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>69</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Floaroma Meadow — D13R0101](../locations/header-256.md) | Visible | (46, 28) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/143.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorlax](../pokemon/snorlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/143.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorlax](../pokemon/snorlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/446.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/446.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | Held by Cradily |
| [Leader Byron](../trainers/trainer-0250.md) | Held by Bastiodon |
| [Elite Four Aaron](../trainers/trainer-0261.md) | Held by Vespiquen |
| [Elite Four Bertha](../trainers/trainer-0262.md) | Held by Hippowdon |
| [Elite Four Lucian](../trainers/trainer-0264.md) | Held by Bronzong |
| [Champion Cynthia](../trainers/trainer-0267.md) | Held by Milotic |
| [Leader Gardenia](../trainers/trainer-0315.md) | Held by Grotle |
| [Leader Fantina](../trainers/trainer-0318.md) | Held by Dusclops |
| [Commander Mars](../trainers/trainer-0405.md) | Held by Bronzong |
| [Commander Jupiter](../trainers/trainer-0407.md) | Held by Bronzong |
| [Pokémon Trainer Cedric](../trainers/trainer-0470.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0471.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0472.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0473.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0474.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0475.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0476.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0479.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0480.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0481.md) | Held by Snorlax |
| [Commander Mars](../trainers/trainer-0528.md) | Held by Bronzong |
| [Pokémon Trainer Cedric](../trainers/trainer-0607.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0619.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0620.md) | Held by Snorlax |
| [Leader Candice](../trainers/trainer-0853.md) | Held by Abomasnow |
| [Leader Volkner](../trainers/trainer-0855.md) | Held by Rotom Heat |
| [Leader Byron](../trainers/trainer-0856.md) | Held by Bronzong |
| [Leader Gardenia](../trainers/trainer-0857.md) | Held by Tangrowth |
| [Leader Roark](../trainers/trainer-0858.md) | Held by Probopass |
| [Leader Wake](../trainers/trainer-0859.md) | Held by Poliwrath |
| [Leader Fantina](../trainers/trainer-0860.md) | Held by Spiritomb |
| [Pokémon Trainer Riley](../trainers/trainer-0861.md) | Held by Slaking |
| [Pokémon Trainer Buck](../trainers/trainer-0862.md) | Held by Umbreon |
| [Pokémon Trainer Cheryl](../trainers/trainer-0865.md) | Held by Wobbuffet |
| [Elite Four Bertha](../trainers/trainer-0867.md) | Held by Hippowdon |
| [Champion Cynthia](../trainers/trainer-0870.md) | Held by Togekiss |
| [Pokémon Trainer Cedric](../trainers/trainer-0871.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0872.md) | Held by Snorlax |
| [Pokémon Trainer Cedric](../trainers/trainer-0873.md) | Held by Snorlax |
| [Commander Mars](../trainers/trainer-0926.md) | Held by Bronzong |
| [Commander Jupiter](../trainers/trainer-0927.md) | Held by Bronzong |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | Held by Tropius |
| [Pokémon Trainer Dawn](../trainers/trainer-0940.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0941.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0942.md) | Held by Clefable |
| [Pokémon Trainer Lucas](../trainers/trainer-0943.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0944.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0945.md) | Held by Lickilicky |
| [Elite Four Aaron](../trainers/trainer-0946.md) | Held by Dustox |
| [Commander Saturn](../trainers/trainer-0959.md) | Held by Bronzong |
| [Pokémon Trainer Dawn](../trainers/trainer-0963.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0964.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0965.md) | Held by Clefable |
| [Pokémon Trainer Lucas](../trainers/trainer-0966.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0967.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0968.md) | Held by Lickilicky |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | Held by Cresselia |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | Held by Clefable |
| [Pokémon Trainer Lucas](../trainers/trainer-0978.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0979.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-0980.md) | Held by Lickilicky |
| [Elite Four Aaron](../trainers/trainer-0981.md) | Held by Forretress |
| [Elite Four Bertha](../trainers/trainer-0984.md) | Held by Torterra |
| [Elite Four Bertha](../trainers/trainer-0986.md) | Held by Torterra |
| [Elite Four Lucian](../trainers/trainer-0991.md) | Held by Slowbro |
| [Champion Cynthia](../trainers/trainer-0993.md) | Held by Milotic |
| [Champion Cynthia](../trainers/trainer-0994.md) | Held by Milotic |
| [Champion Cynthia](../trainers/trainer-0995.md) | Held by Milotic |
| [Pokémon Trainer Buck](../trainers/trainer-1023.md) | Held by Claydol |
| [Ace Trainer Wyver](../trainers/trainer-1024.md) | Held by Altaria |
| [Ace Trainer Shade](../trainers/trainer-1026.md) | Held by Spiritomb |
| [Ace Trainer Gene](../trainers/trainer-1027.md) | Held by Snorlax |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Held by Clefable |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Held by Ampharos |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-1055.md) | Held by Clefable |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | Held by Clefable |
| [Pokémon Trainer Lucas](../trainers/trainer-1057.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-1058.md) | Held by Lickilicky |
| [Pokémon Trainer Lucas](../trainers/trainer-1059.md) | Held by Lickilicky |
| [Commander Mars](../trainers/trainer-1060.md) | Held by Bronzong |
| [Commander Jupiter](../trainers/trainer-1061.md) | Held by Bronzong |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">86 entries added</p><ul class="rw-comparison-list"><li>Ampharos</li><li>Snorlax</li><li>Tropius</li><li>Clefable</li><li>Spiritomb</li><li>Altaria</li><li>Milotic</li><li>Milotic</li><li>Milotic</li><li>Milotic</li><li>Togekiss</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Bronzong</li><li>Forretress</li><li>Dustox</li><li>Vespiquen</li><li>Torterra</li><li>Torterra</li><li>Hippowdon</li><li>Hippowdon</li><li>Bronzong</li><li>Slowbro</li><li>Bastiodon</li><li>Bronzong</li><li>Abomasnow</li><li>Dusclops</li><li>Spiritomb</li><li>Grotle</li><li>Tangrowth</li><li>Probopass</li><li>Rotom Heat</li><li>Poliwrath</li><li>Umbreon</li><li>Claydol</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Snorlax</li><li>Wobbuffet</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Clefable</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Lickilicky</li><li>Slaking</li><li>Cradily</li><li>Cresselia</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `212` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `212`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/211/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../metal-coat/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/metal-coat.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Metal Coat</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../dragon-scale/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dragon-scale.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Dragon Scale →</span></a>
</nav>
