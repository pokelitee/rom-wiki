# Focus Sash

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-sash.png" alt="Focus Sash icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>275</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder survives any single-hit attack at 1 HP if at max HP, then the item is consumed.</strong></p>
<p>Held: If the holder has full HP and is attacked for regular damage that would faint it, this item is consumed and prevents the holder’s HP from lowering below 1. This effect works against multi-hit attacks, but does not work against the effects of Doom Desire or Future Sight.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. If it has full HP, the holder will endure one potential KO attack, leaving 1 HP.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>103</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 212](../locations/header-371.md) | R212B | `header-371` | Visible | (531, 849) |
| [Mt. Coronet](../locations/header-589.md) | D35R0103 | `header-589` | Hidden | (6, 5) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽200 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 48 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 48 BP | Always |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Steven](../trainers/trainer-0005.md) | Held by Aggron |
| [Leader Byron](../trainers/trainer-0250.md) | Held by Aggron |
| [Elite Four Bertha](../trainers/trainer-0262.md) | Held by Golem |
| [Leader Gardenia](../trainers/trainer-0315.md) | Held by Cherrim |
| [Leader Wake](../trainers/trainer-0316.md) | Held by Sharpedo |
| [Leader Maylene](../trainers/trainer-0317.md) | Held by Lucario |
| [Leader Candice](../trainers/trainer-0319.md) | Held by Weavile |
| [Leader Volkner](../trainers/trainer-0320.md) | Held by Jolteon |
| [Galactic Boss Cyrus](../trainers/trainer-0404.md) | Held by Weavile |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Toxicroak |
| [Pokémon Trainer Cedric](../trainers/trainer-0474.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0475.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0477.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0478.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0619.md) | Held by Breloom |
| [Pokémon Trainer Cedric](../trainers/trainer-0620.md) | Held by Breloom |
| [Leader Byron](../trainers/trainer-0856.md) | Held by Bastiodon |
| [Leader Gardenia](../trainers/trainer-0857.md) | Held by Breloom |
| [Leader Roark](../trainers/trainer-0858.md) | Held by Golem |
| [Leader Wake](../trainers/trainer-0859.md) | Held by Gyarados |
| [Leader Wake](../trainers/trainer-0859.md) | Held by Sharpedo |
| [Leader Fantina](../trainers/trainer-0860.md) | Held by Mismagius |
| [Pokémon Trainer Marley](../trainers/trainer-0863.md) | Held by Electrode |
| [Elite Four Bertha](../trainers/trainer-0867.md) | Held by Rhyperior |
| [Champion Cynthia](../trainers/trainer-0870.md) | Held by Rayquaza |
| [Pokémon Trainer Cedric](../trainers/trainer-0871.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0872.md) | Held by Heracross |
| [Pokémon Trainer Cedric](../trainers/trainer-0873.md) | Held by Heracross |
| [Ace Trainer Heather](../trainers/trainer-0938.md) | Held by Pelipper |
| [Pokémon Trainer Dawn](../trainers/trainer-0940.md) | Held by Piloswine |
| [Pokémon Trainer Dawn](../trainers/trainer-0941.md) | Held by Piloswine |
| [Pokémon Trainer Dawn](../trainers/trainer-0942.md) | Held by Piloswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0943.md) | Held by Piloswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0944.md) | Held by Piloswine |
| [Pokémon Trainer Lucas](../trainers/trainer-0945.md) | Held by Piloswine |
| [Elite Four Aaron](../trainers/trainer-0946.md) | Held by Beautifly |
| [Galactic Grunt](../trainers/trainer-0953.md) | Held by Ninjask |
| [Galactic Grunt](../trainers/trainer-0954.md) | Held by Shedinja |
| [Arcade Star Dahlia](../trainers/trainer-0973.md) | Held by Blaziken |
| [Pokémon Trainer Dawn](../trainers/trainer-0975.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0976.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-0977.md) | Held by Lopunny |
| [Elite Four Aaron](../trainers/trainer-0982.md) | Held by Beautifly |
| [Elite Four Bertha](../trainers/trainer-0984.md) | Held by Camerupt |
| [Elite Four Flint](../trainers/trainer-0987.md) | Held by Lopunny |
| [Elite Four Flint](../trainers/trainer-0988.md) | Held by Magcargo |
| [Elite Four Flint](../trainers/trainer-0989.md) | Held by Torkoal |
| [Elite Four Lucian](../trainers/trainer-0992.md) | Held by Alakazam |
| [Ace Trainer Wyver](../trainers/trainer-1024.md) | Held by Salamence |
| [Ace Trainer Luna](../trainers/trainer-1028.md) | Held by Mawile |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Held by Roserade |
| [Pokémon Trainer Dawn](../trainers/trainer-1054.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-1055.md) | Held by Lopunny |
| [Pokémon Trainer Dawn](../trainers/trainer-1056.md) | Held by Lopunny |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Toxicroak |
| [Galactic Boss Cyrus](../trainers/trainer-1063.md) | Held by Weavile |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">56 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/roserade/">Roserade</a></li><li><a href="../../pokemon/pelipper/">Pelipper</a></li><li><a href="../../pokemon/mawile/">Mawile</a></li><li><a href="../../pokemon/salamence/">Salamence</a></li><li><a href="../../pokemon/blaziken/">Blaziken</a></li><li><a href="../../pokemon/rayquaza/">Rayquaza</a></li><li><a href="../../pokemon/toxicroak/">Toxicroak</a></li><li><a href="../../pokemon/toxicroak/">Toxicroak</a></li><li><a href="../../pokemon/beautifly/">Beautifly</a></li><li><a href="../../pokemon/beautifly/">Beautifly</a></li><li><a href="../../pokemon/camerupt/">Camerupt</a></li><li><a href="../../pokemon/rhyperior/">Rhyperior</a></li><li><a href="../../pokemon/golem/">Golem</a></li><li><a href="../../pokemon/magcargo/">Magcargo</a></li><li><a href="../../pokemon/torkoal/">Torkoal</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/alakazam/">Alakazam</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/ninjask/">Ninjask</a></li><li><a href="../../pokemon/shedinja/">Shedinja</a></li><li><a href="../../pokemon/aggron/">Aggron</a></li><li><a href="../../pokemon/bastiodon/">Bastiodon</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/mismagius/">Mismagius</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/cherrim/">Cherrim</a></li><li><a href="../../pokemon/lucario/">Lucario</a></li><li><a href="../../pokemon/golem/">Golem</a></li><li><a href="../../pokemon/jolteon/">Jolteon</a></li><li><a href="../../pokemon/gyarados/">Gyarados</a></li><li><a href="../../pokemon/sharpedo/">Sharpedo</a></li><li><a href="../../pokemon/sharpedo/">Sharpedo</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/heracross/">Heracross</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/electrode/">Electrode</a></li><li><a href="../../pokemon/aggron/">Aggron</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `253` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `253`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/252/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../quick-powder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-powder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Quick Powder</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../zoom-lens/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/zoom-lens.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Zoom Lens →</span></a>
</nav>
