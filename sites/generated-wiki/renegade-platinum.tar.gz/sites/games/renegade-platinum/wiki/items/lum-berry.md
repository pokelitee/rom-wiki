# Lum Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lum-berry.png" alt="Lum Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>157</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Medicine</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed to cure any status condition or confusion.</strong></p>
<p>Held in battle : When the holder is afflicted with a major status ailment, it consumes this item to cure the ailment. Used on a party Pokémon : Cures any major status ailment.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. It may be used or held by a Pokémon to recover from any status problem.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>12</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>9</dd></div>
<div><dt>Fling effect ID</dt><dd>9</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span></span></dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Super Hard</dd></div>
<div><dt>Size</dt><dd>34 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>12 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>8</dd></div>
</dl>

**Contest flavor:**

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>10</dd></div>
<div><dt>Dry</dt><dd>10</dd></div>
<div><dt>Sweet</dt><dd>10</dd></div>
<div><dt>Bitter</dt><dd>10</dd></div>
<div><dt>Sour</dt><dd>0</dd></div>
<div><dt>Smoothness</dt><dd>20</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 216](../locations/header-383.md) | R216 | `header-383` | Visible | (377, 392) |
| [Route 222](../locations/header-395.md) | R222 | `header-395` | Hidden | (813, 792) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/151.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mew](../pokemon/mew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/151.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mew](../pokemon/mew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/251.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Celebi](../pokemon/celebi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--grass">Grass</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/251.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Celebi](../pokemon/celebi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--grass">Grass</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/492.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shaymin](../pokemon/shaymin-land.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/492.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shaymin](../pokemon/shaymin-land.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/10006.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shaymin Sky](../pokemon/shaymin-sky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/10006.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shaymin Sky](../pokemon/shaymin-sky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Champion Cynthia](../trainers/trainer-0267.md) | Held by Spiritomb |
| [Pokémon Trainer Buck](../trainers/trainer-0862.md) | Held by Shuckle |
| [Pokémon Trainer Cheryl](../trainers/trainer-0865.md) | Held by Snorlax |
| [Champion Cynthia](../trainers/trainer-0870.md) | Held by Spiritomb |
| [Arcade Star Dahlia](../trainers/trainer-0973.md) | Held by Dusknoir |
| [Elite Four Bertha](../trainers/trainer-0985.md) | Held by Swampert |
| [Pokémon Trainer Buck](../trainers/trainer-1023.md) | Held by Shuckle |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">7 entries added</p><ul class="rw-comparison-list"><li>Dusknoir</li><li>Spiritomb</li><li>Spiritomb</li><li>Swampert</li><li>Shuckle</li><li>Shuckle</li><li>Snorlax</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trades</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>MAGIKARP</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `135` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `135`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/134/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../persim-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/persim-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Persim Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sitrus-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/sitrus-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Sitrus Berry →</span></a>
</nav>
