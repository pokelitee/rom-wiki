# Explorer Kit

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/explorer-kit.png" alt="Explorer Kit icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>428</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Gameplay</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>Yes</dd></div>
<div><dt>Can be discarded</dt><dd>No</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Allows visiting the Underground.</strong></p>
<p>Sends the trainer to the Underground. Only usable outside.</p>

<figure class="rw-pokedex-entry">
<blockquote>A bag filled with convenient tools for exploring. It provides access to the Underground.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Explorer Kit</dd></div>
<div><dt>Field pocket ID</dt><dd>7</dd></div>
<div><dt>Field use function ID</dt><dd>3</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `406` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `406`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/405/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hm08/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hm-normal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← HM08</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../prism-scale/"><span class="rw-record-nav__label">Prism Scale →</span></a>
</nav>
