# Bright Powder

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/bright-powder.png" alt="Bright Powder icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>213</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽10</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases the holder’s evasion by 1/9 (11 1/9%).</strong></p>
<p>Held in battle : Moves targeting the holder have 0.9× chance to hit.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It casts a tricky glare that lowers the opponent’s accuracy.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>48</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Stark Mountain](../locations/header-263.md) | D16R0101 | `header-263` | Visible | (8, 23) |
| [Great Marsh](../locations/header-507.md) | D06R0204 | `header-507` | Hidden | (74, 76) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Specialty | ₽10 | Always |
| [Battle Park](../locations/header-323.md) | D31R0101 | `header-323` | Frontier | 48 BP | Always |
| [Battle Frontier](../locations/header-559.md) | D32 | `header-559` | Frontier | 48 BP | Always |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/313.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Volbeat](../pokemon/volbeat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--electric">Electric</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/314.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Illumise](../pokemon/illumise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fairy">Fairy</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Candice](../trainers/trainer-0319.md) | Held by Glaceon |
| [Commander Mars](../trainers/trainer-0405.md) | Held by Crobat |
| [Commander Jupiter](../trainers/trainer-0407.md) | Held by Crobat |
| [Commander Saturn](../trainers/trainer-0408.md) | Held by Bronzong |
| [Leader Candice](../trainers/trainer-0853.md) | Held by Weavile |
| [Leader Fantina](../trainers/trainer-0860.md) | Held by Banette |
| [Pokémon Trainer Buck](../trainers/trainer-0862.md) | Held by Dusknoir |
| [Commander Jupiter](../trainers/trainer-0927.md) | Held by Crobat |
| [Tower Tycoon Palmer](../trainers/trainer-0971.md) | Held by Regigigas |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Held by Crobat |
| [Commander Jupiter](../trainers/trainer-1061.md) | Held by Crobat |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Name</p>
<div class="rw-change__value">BrightPowder<span class="rw-diff-arrow">→</span>Bright Powder</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Wurmple</li><li>Volbeat</li><li>Illumise</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/bronzong/">Bronzong</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/glaceon/">Glaceon</a></li><li><a href="../../pokemon/banette/">Banette</a></li><li><a href="../../pokemon/dusknoir/">Dusknoir</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/regigigas/">Regigigas</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `191` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `191`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/190/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rowap-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rowap-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Rowap Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../white-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/white-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">White Herb →</span></a>
</nav>
