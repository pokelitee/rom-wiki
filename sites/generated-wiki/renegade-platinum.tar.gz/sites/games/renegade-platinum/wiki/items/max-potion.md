# Max Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="Max Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>24</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽2,500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full.</strong></p>
<p>Used on a party Pokémon : Restores HP to full.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It completely restores the HP of a single Pokémon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Eterna City — C04](../locations/header-065.md) | Visible | (327, 516) |
| [Route 212 — R212B](../locations/header-371.md) | Hidden | (571, 839) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City — C01FS0101](../locations/header-004.md) | Common | ₽2,500 | 4 badges |
| [Canalave City — C02FS0101](../locations/header-034.md) | Common | ₽2,500 | 4 badges |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Common | ₽2,500 | 4 badges |
| [Eterna City — C04FS0101](../locations/header-066.md) | Common | ₽2,500 | 4 badges |
| [Hearthome City — C05FS0101](../locations/header-087.md) | Common | ₽2,500 | 4 badges |
| [Pastoria City — C06FS0101](../locations/header-121.md) | Common | ₽2,500 | 4 badges |
| [Sunyshore City — C08FS0101](../locations/header-153.md) | Common | ₽2,500 | 4 badges |
| [Sunyshore Market — C08R0101](../locations/header-157.md) | Seal | ₽100 | Always |
| [Snowpoint City — C09FS0101](../locations/header-166.md) | Common | ₽2,500 | 4 badges |
| [Pokémon League — C10PC0101](../locations/header-173.md) | Common | ₽2,500 | 4 badges |
| [Pokémon League — C10R0101](../locations/header-175.md) | Common | ₽2,500 | 4 badges |
| [Fight Area — C11FS0101](../locations/header-191.md) | Common | ₽2,500 | 4 badges |
| [Sandgem Town — T02FS0101](../locations/header-419.md) | Common | ₽2,500 | 4 badges |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Common | ₽2,500 | 4 badges |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Common | ₽2,500 | 4 badges |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Specialty | ₽2,500 | Always |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽2,500 | 4 badges |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽2,500 | 4 badges |
| [Survival Area — T06FS0101](../locations/header-451.md) | Common | ₽2,500 | 4 badges |
| [Resort Area — T07FS0101](../locations/header-458.md) | Common | ₽2,500 | 4 badges |
| [Veilstone Store — C07R0207](../locations/header-566.md) | Specialty | ₽2,500 | Always |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `24` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `24`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/24/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../full-restore/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Full Restore</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../hyper-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Hyper Potion →</span></a>
</nav>
