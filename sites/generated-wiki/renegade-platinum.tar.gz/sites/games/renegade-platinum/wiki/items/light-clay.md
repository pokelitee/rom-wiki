# Light Clay

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="Light Clay icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>269</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Light Screen and Reflect used by the holder last 8 rounds instead of 5.</strong></p>
<p>Held: The holder’s Reflect and Light Screen will create effects lasting for eight turns rather than five. As this item affects the move rather than the barrier itself, the effect is not lost if the holder leaves battle or drops this item.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Pokémon hold item that extends the duration of barrier moves like Light Screen and Reflect used by the holder.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>97</dd></div>
<div><dt>Held effect parameter</dt><dd>3</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Mt. Coronet](../locations/header-211.md) | D05R0105 | `header-211` | Hidden | (34, 13) |
| [Solaceon Town](../locations/header-433.md) | T04 | `header-433` | Visible | (584, 662) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/343.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Baltoy](../pokemon/baltoy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Byron](../trainers/trainer-0250.md) | Held by Bronzong |
| [Elite Four Lucian](../trainers/trainer-0264.md) | Held by Mr. Mime |
| [Leader Maylene](../trainers/trainer-0317.md) | Held by Gallade |
| [Commander Saturn](../trainers/trainer-0409.md) | Held by Bronzong |
| [Elite Four Lucian](../trainers/trainer-0869.md) | Held by Mr. Mime |
| [Pokémon Trainer Marley](../trainers/trainer-0974.md) | Held by Electrode |
| [Elite Four Aaron](../trainers/trainer-0982.md) | Held by Dustox |
| [Elite Four Bertha](../trainers/trainer-0985.md) | Held by Claydol |
| [Elite Four Lucian](../trainers/trainer-0990.md) | Held by Espeon |
| [Elite Four Lucian](../trainers/trainer-0991.md) | Held by Hypno |
| [Champion Cynthia](../trainers/trainer-0994.md) | Held by Togekiss |
| [Champion Cynthia](../trainers/trainer-0995.md) | Held by Clefable |
| [Ace Trainer Dray](../trainers/trainer-1053.md) | Held by Togekiss |
| [Commander Saturn](../trainers/trainer-1062.md) | Held by Bronzong |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Baltoy</li><li>Claydol</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">14 entries added</p><ul class="rw-comparison-list"><li>Togekiss</li><li>Clefable</li><li>Togekiss</li><li>Bronzong</li><li>Bronzong</li><li>Dustox</li><li>Claydol</li><li>Mr. Mime</li><li>Mr. Mime</li><li>Espeon</li><li>Hypno</li><li>Bronzong</li><li>Gallade</li><li>Electrode</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `247` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `247`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/246/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../expert-belt/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/expert-belt.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Expert Belt</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../life-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/life-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Life Orb →</span></a>
</nav>
