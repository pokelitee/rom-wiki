# Route 212

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>160</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 212](../locations/header-367.md) | `header-367` | 27 | `R212A` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 25 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/281.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kirlia](../pokemon/kirlia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 25 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/235.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24–25 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 20–30 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/184.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Azumarill](../pokemon/azumarill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 30–40 | 5% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 45% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 45% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 45% |

## Special encounters

### Swarm

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 20% |

### Day replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 25 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 10% |

### Night replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 25 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 10% |

### Dual-slot: Ruby

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 8% |

### Dual-slot: Sapphire

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 8% |

### Dual-slot: Emerald

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 8% |

### Dual-slot: Fire Red

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 8% |

### Dual-slot: Leaf Green

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 25–26 | 8% |

### Poké Radar

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> |

## Hack changes

<details markdown="1">
<summary>6 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 21</li><li><a href="../../pokemon/kirlia/">Kirlia</a> — Lv. 22</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 22</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 23</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 21</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 23</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li><li><a href="../../pokemon/kirlia/">Kirlia</a> — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li><li><a href="../../pokemon/kirlia/">Kirlia</a> — Lv. 25</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 25</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 26</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 26</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 24</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 24</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 20–40</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 20–30</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 20–40</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 20–40</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 20–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/azumarill/">Azumarill</a> — Lv. 30–40</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 20–30</li><li><a href="../../pokemon/azumarill/">Azumarill</a> — Lv. 30–40</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 20–30</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 20–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 4–6</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 15–20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40–55</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 40–55</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40–55</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 30–40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 22</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 23</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 25</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 26</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 26</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 22</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 23</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 25</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 26</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Smeargle</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Farfetch&#x27;d</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 21</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 23</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 24</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 25</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `160`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-159/"><span class="rw-record-nav__label">← Route 211</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-161/"><span class="rw-record-nav__label">Route 212 →</span></a>
</nav>
