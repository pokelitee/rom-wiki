# Great Marsh

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>23</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Great Marsh](../locations/header-504.md) | `header-504` | 52 | `D06R0201` |

## Walking

Encounter rate: 35

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 34–36 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 33–35 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/455.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carnivine](../pokemon/carnivine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 34 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–30 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–40 | 10% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/318.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carvanha](../pokemon/carvanha.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 10 | 20% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/318.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carvanha](../pokemon/carvanha.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 25 | 20% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/319.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sharpedo](../pokemon/sharpedo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 50 | 20% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 34 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 35 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 33 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 35 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 33 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 35 | 8% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 35 | 8% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 35 | 8% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 35 | 8% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 35 | 8% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/455.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carnivine](../pokemon/carnivine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> |

## Hack changes

<details markdown="1">
<summary>5 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 31</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 31</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 28</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 29</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 30</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 30</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 28</li><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 28</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 30</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 30</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 28</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 30</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 36</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 33</li><li><a href="../../pokemon/carnivine/">Carnivine</a> — Lv. 34</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 35</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 36</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 34</li><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 34</li><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 34</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 3–6</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 4–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 10</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 10</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 15–20</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 25</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 25</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 40–55</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 20–50</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 40–55</li><li><a href="../../pokemon/carvanha/">Carvanha</a> — Lv. 30–40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 30–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sharpedo/">Sharpedo</a> — Lv. 50</li><li><a href="../../pokemon/sharpedo/">Sharpedo</a> — Lv. 50</li><li><a href="../../pokemon/sharpedo/">Sharpedo</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 28</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 30</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 33</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 35</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 30</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 30</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 30</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 30</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 30</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 30</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 30</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 30</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 30</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 35</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 28</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 30</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 33</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 35</li></ul></li><li>Radar: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Tangela</li><li>Yanma</li><li>Wooper</li><li>Quagsire</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Tropius</li><li>Bibarel</li><li>Carnivine</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 28</li><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 28</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 34</li><li><a href="../../pokemon/bibarel/">Bibarel</a> — Lv. 34</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `23`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-009/"><span class="rw-record-nav__label">← Fuego Ironworks</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-024/"><span class="rw-record-nav__label">Great Marsh →</span></a>
</nav>
