# Route 202

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>141</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 202](../locations/header-343.md) | 343 | 17 | `R202` |

## Walking

Encounter rate: 30

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 5 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/161.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sentret](../pokemon/sentret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 5 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/261.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poochyena](../pokemon/poochyena.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 5 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/261.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poochyena](../pokemon/poochyena.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 6 | 5% |

## Special encounters

**Swarm:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 5 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 20% |

**Day replacements:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/161.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sentret](../pokemon/sentret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/161.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sentret](../pokemon/sentret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 10% |

**Night replacements:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 5 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 6 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/228.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Houndour](../pokemon/houndour.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li><li>Bidoof — Lv. 3</li><li>Kricketot — Lv. 3</li><li>Starly — Lv. 4</li><li>Shinx — Lv. 4</li><li>Bidoof — Lv. 3</li><li>Shinx — Lv. 3</li><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li><li>Starly — Lv. 4</li><li>Bidoof — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Poochyena — Lv. 6</li><li>Growlithe — Lv. 6</li><li>Sentret — Lv. 5</li><li>Rattata — Lv. 5</li><li>Burmy — Lv. 5</li><li>Zigzagoon — Lv. 5</li><li>Shinx — Lv. 5</li><li>Poochyena — Lv. 6</li><li>Growlithe — Lv. 6</li><li>Poochyena — Lv. 5</li><li>Growlithe — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof — Lv. 3</li><li>Starly — Lv. 4</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Sentret — Lv. 5</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Burmy — Lv. 6</li><li>Growlithe — Lv. 6</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Growlithe — Lv. 2</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Burmy — Lv. 6</li><li>Growlithe — Lv. 6</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Burmy — Lv. 6</li><li>Growlithe — Lv. 6</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Burmy — Lv. 6</li><li>Growlithe — Lv. 6</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Starly — Lv. 2</li><li>Bidoof — Lv. 2</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Burmy — Lv. 6</li><li>Growlithe — Lv. 6</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof — Lv. 3</li><li>Kricketot — Lv. 4</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hoothoot — Lv. 5</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Sentret</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Houndour</li></ul></li><li>Swarm: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Zigzagoon — Lv. 3</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Zigzagoon — Lv. 5</li><li>Shinx — Lv. 5</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `141`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-140/"><span class="rw-record-nav__label">← Route 201</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-142/"><span class="rw-record-nav__label">Route 203 →</span></a>
</nav>
