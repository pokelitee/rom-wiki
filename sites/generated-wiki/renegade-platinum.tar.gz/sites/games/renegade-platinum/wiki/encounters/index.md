# Wild encounters

Exact encounter tables linked to their in-game map headers.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Acuity Lakefront](area-139.md)
- [Canalave City](area-000.md)
- [Celestic Town](area-177.md)
- [Eterna City](area-001.md)
- [Eterna Forest](area-008.md)
- [Fuego Ironworks](area-009.md)
- [Great Marsh — D06R0201](area-023.md)
- [Great Marsh — D06R0202](area-024.md)
- [Great Marsh — D06R0203](area-025.md)
- [Great Marsh — D06R0204](area-026.md)
- [Great Marsh — D06R0205](area-027.md)
- [Great Marsh — D06R0206](area-028.md)
- [Iron Island — D24](area-118.md)
- [Iron Island — D24R0101](area-119.md)
- [Iron Island — D24R0102](area-120.md)
- [Iron Island — D24R0103](area-121.md)
- [Iron Island — D24R0104](area-122.md)
- [Iron Island — D24R0105](area-123.md)
- [Iron Island — D24R0106](area-124.md)
- [Lake Acuity](area-137.md)
- [Lake Valor](area-136.md)
- [Lake Verity](area-134.md)
- [Maniac Tunnel](area-116.md)
- [Mt. Coronet — D05R0101](area-010.md)
- [Mt. Coronet — D05R0102](area-011.md)
- [Mt. Coronet — D05R0103](area-012.md)
- [Mt. Coronet — D05R0104](area-013.md)
- [Mt. Coronet — D05R0105](area-014.md)
- [Mt. Coronet — D05R0106](area-015.md)
- [Mt. Coronet — D05R0107](area-016.md)
- [Mt. Coronet — D05R0108](area-017.md)
- [Mt. Coronet — D05R0109](area-018.md)
- [Mt. Coronet — D05R0110](area-019.md)
- [Mt. Coronet — D05R0111](area-020.md)
- [Mt. Coronet — D05R0112](area-021.md)
- [Mt. Coronet — D05R0113](area-022.md)
- [Old Chateau — D25R0101](area-125.md)
- [Old Chateau — D25R0102](area-126.md)
- [Old Chateau — D25R0103](area-127.md)
- [Old Chateau — D25R0104](area-128.md)
- [Old Chateau — D25R0105](area-129.md)
- [Old Chateau — D25R0106](area-130.md)
- [Old Chateau — D25R0107](area-131.md)
- [Old Chateau — D25R0108](area-132.md)
- [Old Chateau — D25R0109](area-133.md)
- [Oreburgh Gate — D14R0101](area-054.md)
- [Oreburgh Gate — D14R0102](area-055.md)
- [Oreburgh Mine — D01R0101](area-005.md)
- [Oreburgh Mine — D01R0102](area-006.md)
- [Pastoria City](area-002.md)
- [Pokémon League](area-004.md)
- [Ravaged Path](area-053.md)
- [Resort Area](area-178.md)
- [Route 201](area-140.md)
- [Route 202](area-141.md)
- [Route 203](area-142.md)
- [Route 204 — R204A](area-143.md)
- [Route 204 — R204B](area-144.md)
- [Route 205 — R205A](area-145.md)
- [Route 205 — R205B](area-146.md)
- [Route 206](area-147.md)
- [Route 207](area-148.md)
- [Route 208](area-149.md)
- [Route 209 — R209](area-150.md)
- [Route 209 — R209R0101](area-151.md)
- [Route 209 — R209R0102](area-152.md)
- [Route 209 — R209R0103](area-153.md)
- [Route 209 — R209R0104](area-154.md)
- [Route 209 — R209R0105](area-155.md)
- [Route 210 — R210A](area-156.md)
- [Route 210 — R210B](area-157.md)
- [Route 211 — R211A](area-158.md)
- [Route 211 — R211B](area-159.md)
- [Route 212 — R212A](area-160.md)
- [Route 212 — R212B](area-161.md)
- [Route 213](area-162.md)
- [Route 214](area-163.md)
- [Route 215](area-164.md)
- [Route 216](area-165.md)
- [Route 217](area-166.md)
- [Route 218](area-167.md)
- [Route 219](area-168.md)
- [Route 220](area-179.md)
- [Route 221](area-169.md)
- [Route 222](area-170.md)
- [Route 223](area-180.md)
- [Route 224](area-171.md)
- [Route 225](area-172.md)
- [Route 226](area-181.md)
- [Route 227](area-173.md)
- [Route 228](area-174.md)
- [Route 229](area-175.md)
- [Route 230](area-182.md)
- [Ruin Maniac Cave — D22R0101](area-114.md)
- [Ruin Maniac Cave — D22R0102](area-115.md)
- [Sendoff Spring](area-059.md)
- [Snowpoint Temple — D20R0101](area-106.md)
- [Snowpoint Temple — D20R0102](area-107.md)
- [Snowpoint Temple — D20R0103](area-108.md)
- [Snowpoint Temple — D20R0104](area-109.md)
- [Snowpoint Temple — D20R0105](area-110.md)
- [Snowpoint Temple — D20R0106](area-111.md)
- [Solaceon Ruins — D07R0101](area-029.md)
- [Solaceon Ruins — D07R0103](area-030.md)
- [Solaceon Ruins — D07R0104](area-031.md)
- [Solaceon Ruins — D07R0105](area-032.md)
- [Solaceon Ruins — D07R0106](area-033.md)
- [Solaceon Ruins — D07R0107](area-034.md)
- [Solaceon Ruins — D07R0108](area-035.md)
- [Solaceon Ruins — D07R0109](area-036.md)
- [Solaceon Ruins — D07R0110](area-037.md)
- [Solaceon Ruins — D07R0111](area-038.md)
- [Solaceon Ruins — D07R0112](area-039.md)
- [Solaceon Ruins — D07R0113](area-040.md)
- [Solaceon Ruins — D07R0114](area-041.md)
- [Solaceon Ruins — D07R0115](area-042.md)
- [Solaceon Ruins — D07R0116](area-043.md)
- [Solaceon Ruins — D07R0117](area-044.md)
- [Solaceon Ruins — D07R0118](area-045.md)
- [Solaceon Ruins — D07R0119](area-046.md)
- [Stark Mountain — D16](area-056.md)
- [Stark Mountain — D16R0101](area-057.md)
- [Stark Mountain — D16R0102](area-058.md)
- [Sunyshore City](area-003.md)
- [Trophy Garden](area-117.md)
- [Turnback Cave](area-061.md)
- [Twinleaf Town](area-176.md)
- [Valley Windworks](area-007.md)
- [Valor Lakefront](area-138.md)
- [Victory Road — D09R0101](area-047.md)
- [Victory Road — D09R0102](area-048.md)
- [Victory Road — D09R0103](area-049.md)
- [Victory Road — D09R0104](area-050.md)
- [Victory Road — D09R0105](area-051.md)
- [Victory Road — D09R0106](area-052.md)
- [Wayward Cave — D21R0101](area-112.md)
- [Wayward Cave — D21R0102](area-113.md)

</div>
