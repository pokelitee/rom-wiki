# Route 227

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>173</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Route 227](../locations/header-403.md) | `header-403` | 42 | `R227` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 67 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 66–67 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 65–67 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/327.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinda](../pokemon/spinda.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/110.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weezing](../pokemon/weezing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 66–67 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 65–67 | 100% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 45% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 45% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 45% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 67 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/327.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinda](../pokemon/spinda.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>6 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li><li>Fearow — Lv. 51</li><li>Graveler — Lv. 51</li><li>Weezing — Lv. 52</li><li>Fearow — Lv. 53</li><li>Camerupt — Lv. 53</li><li>Rhydon — Lv. 54</li><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li><li>Skarmory — Lv. 53</li><li>Graveler — Lv. 53</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 67</li><li>Skarmory — Lv. 67</li><li>Gligar — Lv. 65</li><li>Spinda — Lv. 65</li><li>Skarmory — Lv. 66</li><li>Torkoal — Lv. 66</li><li>Rhydon — Lv. 67</li><li>Camerupt — Lv. 67</li><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li><li>Weezing — Lv. 66</li><li>Weezing — Lv. 67</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 35–55</li><li>Poliwag — Lv. 35–45</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 5–15</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 4–6</li><li>Magikarp — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Barboach — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Barboach — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Barboach — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Barboach — Lv. 10–25</li><li>Magikarp — Lv. 10–25</li><li>Barboach — Lv. 10–25</li><li>Magikarp — Lv. 15–20</li><li>Barboach — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Barboach — Lv. 25</li><li>Magikarp — Lv. 25</li><li>Barboach — Lv. 25</li><li>Magikarp — Lv. 25</li><li>Barboach — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 40–55</li><li>Gyarados — Lv. 40–55</li><li>Whiscash — Lv. 40–55</li><li>Gyarados — Lv. 30–40</li><li>Whiscash — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 65</li><li>Gyarados — Lv. 65</li><li>Whiscash — Lv. 65</li><li>Gyarados — Lv. 65</li><li>Whiscash — Lv. 65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Fearow — Lv. 51</li><li>Graveler — Lv. 51</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 65</li><li>Skarmory — Lv. 66</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel — Lv. 51</li><li>Rhyhorn — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 66</li><li>Skarmory — Lv. 67</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 51</li><li>Graveler — Lv. 51</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gligar — Lv. 65</li><li>Skarmory — Lv. 66</li></ul></li><li>Radar: <p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Gligar</li><li>Skarmory</li><li>Spinda</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Spinda — Lv. 53</li><li>Spinda — Lv. 54</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Rhydon — Lv. 67</li><li>Camerupt — Lv. 67</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `173`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-181/"><span class="rw-record-nav__label">← Route 226</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-174/"><span class="rw-record-nav__label">Route 228 →</span></a>
</nav>
