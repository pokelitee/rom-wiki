# Trophy Garden

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>117</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Trophy Garden](../locations/header-287.md) | `header-287` | 68 | `D23R0101` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/172.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/173.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cleffa](../pokemon/cleffa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/137.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon](../pokemon/porygon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/175.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togepi](../pokemon/togepi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/174.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Igglybuff](../pokemon/igglybuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 25–26 | 10% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/172.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/173.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cleffa](../pokemon/cleffa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/137.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon](../pokemon/porygon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/173.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cleffa](../pokemon/cleffa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/137.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon](../pokemon/porygon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 10% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 4% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/351.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Castform](../pokemon/castform.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 22</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 23</li><li><a href="../../pokemon/kricketune/">Kricketune</a> — Lv. 23</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 24</li><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 21</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 22</li><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li><li><a href="../../pokemon/cleffa/">Cleffa</a> — Lv. 24</li><li><a href="../../pokemon/igglybuff/">Igglybuff</a> — Lv. 24</li><li><a href="../../pokemon/togepi/">Togepi</a> — Lv. 24</li><li><a href="../../pokemon/porygon/">Porygon</a> — Lv. 26</li><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 24</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 26</li><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 22</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 23</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cleffa/">Cleffa</a> — Lv. 24</li><li><a href="../../pokemon/porygon/">Porygon</a> — Lv. 26</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 22</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/happiny/">Happiny</a> — Lv. 24</li><li><a href="../../pokemon/eevee/">Eevee</a> — Lv. 26</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kricketune/">Kricketune</a> — Lv. 22</li><li><a href="../../pokemon/kricketune/">Kricketune</a> — Lv. 23</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cleffa/">Cleffa</a> — Lv. 24</li><li><a href="../../pokemon/porygon/">Porygon</a> — Lv. 26</li></ul></li><li>Radar: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Pichu</li><li>Pikachu</li><li>Roselia</li><li>Staravia</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Castform</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 21</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 22</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pichu/">Pichu</a> — Lv. 24</li><li><a href="../../pokemon/pikachu/">Pikachu</a> — Lv. 26</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[100, 100, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `117`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-003/"><span class="rw-record-nav__label">← Sunyshore City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-061/"><span class="rw-record-nav__label">Turnback Cave →</span></a>
</nav>
