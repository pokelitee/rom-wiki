# Oreburgh Gate

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>55</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Oreburgh Gate](../locations/header-259.md) | `header-259` | 59 | `D14R0102` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 8–10 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 8–10 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8–10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 9 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 20–30 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 20–40 | 10% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 55% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 60% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 15% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 8 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 9 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 9 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 9 | 8% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 9 | 8% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 9 | 8% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 9 | 8% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 9 | 8% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

<details markdown="1">
<summary>6 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 6</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 9</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 8</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 10</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 9</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 9</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 20–40</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 20–30</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 20–40</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 20–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 4–6</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 15–20</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 40–55</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 40–55</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 40–55</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 30–40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 30–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 50</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 50</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 9</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 9</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 10</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 9</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 9</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Golbat</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Diglett</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 8</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `55`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-054/"><span class="rw-record-nav__label">← Oreburgh Gate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-005/"><span class="rw-record-nav__label">Oreburgh Mine →</span></a>
</nav>
