# Route 212

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>161</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Route 212](../locations/header-371.md) | `header-371` | 27 | `R212B` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/453.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Croagunk](../pokemon/croagunk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 33 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33–34 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33–34 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/271.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/422.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellos](../pokemon/shellos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–30 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–40 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–40 | 5% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 20% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 20% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/224.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 20% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/453.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Croagunk](../pokemon/croagunk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 33 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 33 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 36 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/110.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weezing](../pokemon/weezing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>6 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Buizel — Lv. 23</li><li>Shellos — Lv. 26</li><li>Shellos — Lv. 24</li><li>Buizel — Lv. 25</li><li>Shellos — Lv. 25</li><li>Quagsire — Lv. 26</li><li>Shellos — Lv. 23</li><li>Quagsire — Lv. 24</li><li>Buizel — Lv. 23</li><li>Shellos — Lv. 26</li><li>Croagunk — Lv. 24</li><li>Croagunk — Lv. 25</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li><li>Koffing — Lv. 33</li><li>Ekans — Lv. 33</li><li>Lombre — Lv. 36</li><li>Weepinbell — Lv. 36</li><li>Croagunk — Lv. 33</li><li>Grimer — Lv. 33</li><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li><li>Koffing — Lv. 34</li><li>Ekans — Lv. 34</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Tentacruel — Lv. 20–40</li><li>Tentacool — Lv. 20–30</li><li>Gastrodon — Lv. 20–40</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Quagsire — Lv. 20–40</li><li>Wooper — Lv. 20–30</li><li>Quagsire — Lv. 20–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 5–15</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 4–6</li><li>Magikarp — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Remoraid — Lv. 10</li><li>Remoraid — Lv. 10</li><li>Remoraid — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Barboach — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Remoraid — Lv. 10–25</li><li>Magikarp — Lv. 10–25</li><li>Remoraid — Lv. 10–25</li><li>Magikarp — Lv. 15–20</li><li>Remoraid — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Remoraid — Lv. 25</li><li>Remoraid — Lv. 25</li><li>Remoraid — Lv. 25</li><li>Magikarp — Lv. 25</li><li>Barboach — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Octillery — Lv. 40–55</li><li>Gyarados — Lv. 40–55</li><li>Octillery — Lv. 40–55</li><li>Gyarados — Lv. 30–40</li><li>Octillery — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Octillery — Lv. 50</li><li>Octillery — Lv. 50</li><li>Octillery — Lv. 50</li><li>Gyarados — Lv. 50</li><li>Whiscash — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Shellos — Lv. 24</li><li>Buizel — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Koffing — Lv. 33</li><li>Ekans — Lv. 33</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Buizel — Lv. 23</li><li>Shellos — Lv. 26</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Ekans — Lv. 23</li><li>Ekans — Lv. 26</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Buizel — Lv. 23</li><li>Shellos — Lv. 26</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Buizel — Lv. 23</li><li>Shellos — Lv. 26</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Lombre — Lv. 23</li><li>Lotad — Lv. 26</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 36</li><li>Toxicroak — Lv. 36</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Shellos — Lv. 24</li><li>Buizel — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Koffing — Lv. 33</li><li>Ekans — Lv. 33</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Grimer</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Weezing</li><li>Muk</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Shellos — Lv. 23</li><li>Quagsire — Lv. 24</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Croagunk — Lv. 33</li><li>Grimer — Lv. 33</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `161`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-160/"><span class="rw-record-nav__label">← Route 212</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-162/"><span class="rw-record-nav__label">Route 213 →</span></a>
</nav>
