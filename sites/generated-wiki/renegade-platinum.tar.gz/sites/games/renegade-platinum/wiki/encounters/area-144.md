# Route 204

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>144</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 204](../locations/header-346.md) | `header-346` | 19 | `R204B` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 11 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 11–12 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 11–12 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–30 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 20–40 | 10% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 100% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 45% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 45% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 11 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/191.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sunkern](../pokemon/sunkern.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 11 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/43.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Oddish](../pokemon/oddish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/167.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 12 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 12 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 12 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 12 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 12 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 12 | 4% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 12 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 12 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 12 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 12 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

<details markdown="1">
<summary>5 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/starly/">Starly</a> — Lv. 11</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 11</li><li><a href="../../pokemon/kricketot/">Kricketot</a> — Lv. 8</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 9</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 9</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 9</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 9</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 9</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 10</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 10</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 10</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 10</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 11</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 11</li><li><a href="../../pokemon/ledyba/">Ledyba</a> — Lv. 11</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 11</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 11</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 11</li><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 11</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 11</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 4–6</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 3–7</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 15–20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 25</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40–55</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 40–55</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40–55</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 30–40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/budew/">Budew</a> — Lv. 8</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 9</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sunkern/">Sunkern</a> — Lv. 11</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 11</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pineco/">Pineco</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li></ul></li><li>Ruby: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seedot/">Seedot</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li></ul></li><li>Sapphire: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lotad/">Lotad</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ralts/">Ralts</a> — Lv. 12</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 12</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/kricketot/">Kricketot</a> — Lv. 9</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 11</li><li><a href="../../pokemon/oddish/">Oddish</a> — Lv. 11</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Sunkern</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Roselia</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/starly/">Starly</a> — Lv. 9</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 9</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/starly/">Starly</a> — Lv. 11</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 11</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[0, 0, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `144`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-143/"><span class="rw-record-nav__label">← Route 204</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-145/"><span class="rw-record-nav__label">Route 205 →</span></a>
</nav>
