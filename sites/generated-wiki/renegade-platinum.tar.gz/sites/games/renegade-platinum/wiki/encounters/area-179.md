# Route 220

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>179</dd></div>
<div><dt>Methods</dt><dd><a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 220](../locations/header-467.md) | `header-467` | 35 | `W220` |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/278.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wingull](../pokemon/wingull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 30–40 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/458.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mantyke](../pokemon/mantyke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 30–40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/279.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pelipper](../pokemon/pelipper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 35–45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/226.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mantine](../pokemon/mantine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 35–45 | 5% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 10 | 20% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 25 | 20% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 50 | 20% |

## Hack changes

<details markdown="1">
<summary>4 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pelipper/">Pelipper</a> — Lv. 20–40</li><li><a href="../../pokemon/wingull/">Wingull</a> — Lv. 20–30</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 20–40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 20–40</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/mantine/">Mantine</a> — Lv. 35–45</li><li><a href="../../pokemon/mantyke/">Mantyke</a> — Lv. 30–40</li><li><a href="../../pokemon/mantine/">Mantine</a> — Lv. 35–45</li><li><a href="../../pokemon/pelipper/">Pelipper</a> — Lv. 35–45</li><li><a href="../../pokemon/wingull/">Wingull</a> — Lv. 30–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 4–6</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 10</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 10</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 10</li><li><a href="../../pokemon/horsea/">Horsea</a> — Lv. 10</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lumineon/">Lumineon</a> — Lv. 25–35</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–25</li><li><a href="../../pokemon/lumineon/">Lumineon</a> — Lv. 25–35</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 15–20</li><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 25</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 25</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 25</li><li><a href="../../pokemon/horsea/">Horsea</a> — Lv. 25</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lumineon/">Lumineon</a> — Lv. 40–55</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20–50</li><li><a href="../../pokemon/lumineon/">Lumineon</a> — Lv. 40–55</li><li><a href="../../pokemon/lumineon/">Lumineon</a> — Lv. 30–40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 30–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 50</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 50</li><li><a href="../../pokemon/corsola/">Corsola</a> — Lv. 50</li><li><a href="../../pokemon/seadra/">Seadra</a> — Lv. 50</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 50</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[0, 0, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `179`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-168/"><span class="rw-record-nav__label">← Route 219</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-169/"><span class="rw-record-nav__label">Route 221 →</span></a>
</nav>
