# Maniac Tunnel

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>116</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Maniac Tunnel](../locations/header-513.md) | `header-513` | 67 | `D22R0103` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 28–29 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/293.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 29–30 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 28–29 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/294.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 5% |

## Special encounters

### Swarm

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/293.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |

### Day replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 10% |

### Night replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 10% |

### Dual-slot: Ruby

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 4% |

### Dual-slot: Sapphire

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 4% |

### Dual-slot: Emerald

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 4% |

### Dual-slot: Fire Red

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 4% |

### Dual-slot: Leaf Green

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 29 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 32 | 4% |

### Poké Radar

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/294.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 26</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 25</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 25</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 28</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 29</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 29</li><li><a href="../../pokemon/loudred/">Loudred</a> — Lv. 31</li><li><a href="../../pokemon/whismur/">Whismur</a> — Lv. 28</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 28</li><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 29</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 28</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 29</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 29</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 32</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/trapinch/">Trapinch</a> — Lv. 28</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 29</li></ul></li><li>Radar: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Hippopotas</li><li>Geodude</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Ditto</li><li>Loudred</li><li>Trapinch</li><li>Dugtrio</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 25</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/whismur/">Whismur</a> — Lv. 28</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 28</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[100, 100, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `116`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-134/"><span class="rw-record-nav__label">← Lake Verity</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-010/"><span class="rw-record-nav__label">Mt. Coronet →</span></a>
</nav>
