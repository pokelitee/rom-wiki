# Route 228

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>174</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 228](../locations/header-406.md) | 406 | 43 | `R228` |

## Walking

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/332.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cacturne](../pokemon/cacturne.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 66 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 67 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 65 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/444.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gabite](../pokemon/gabite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 8% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 2% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 65–67 | 100% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 45% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25 | 5% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 45% |

## Special encounters

**Swarm:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/332.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cacturne](../pokemon/cacturne.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 66 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 20% |

**Day replacements:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 10% |

**Night replacements:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 67 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--dragon">Dragon</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>6 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li><li>Rhydon — Lv. 50</li><li>Hippowdon — Lv. 50</li><li>Hippowdon — Lv. 51</li><li>Rhydon — Lv. 52</li><li>Dugtrio — Lv. 51</li><li>Cacturne — Lv. 52</li><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li><li>Dugtrio — Lv. 50</li><li>Dugtrio — Lv. 52</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 67</li><li>Vibrava — Lv. 65</li><li>Dugtrio — Lv. 65</li><li>Claydol — Lv. 67</li><li>Dugtrio — Lv. 67</li><li>Sandslash — Lv. 66</li><li>Cacturne — Lv. 66</li><li>Hippowdon — Lv. 66</li><li>Metang — Lv. 65</li><li>Gabite — Lv. 65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 35–55</li><li>Poliwag — Lv. 35–45</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li><li>Poliwhirl — Lv. 65–67</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 5–15</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 4–6</li><li>Magikarp — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Barboach — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Barboach — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Barboach — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 25–35</li><li>Magikarp — Lv. 10–25</li><li>Whiscash — Lv. 25–35</li><li>Magikarp — Lv. 15–20</li><li>Barboach — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 25</li><li>Magikarp — Lv. 25</li><li>Whiscash — Lv. 25</li><li>Magikarp — Lv. 25</li><li>Barboach — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 40–55</li><li>Gyarados — Lv. 40–55</li><li>Whiscash — Lv. 40–55</li><li>Gyarados — Lv. 30–40</li><li>Whiscash — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 65</li><li>Gyarados — Lv. 65</li><li>Whiscash — Lv. 65</li><li>Gyarados — Lv. 65</li><li>Whiscash — Lv. 65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Rhydon — Lv. 50</li><li>Hippowdon — Lv. 50</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Dugtrio — Lv. 65</li><li>Dugtrio — Lv. 67</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 66</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 66</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Sandslash — Lv. 49</li><li>Sandslash — Lv. 50</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 66</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 66</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Diglett — Lv. 49</li><li>Cacnea — Lv. 50</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon — Lv. 66</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Cacturne — Lv. 50</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Dugtrio — Lv. 65</li><li>Dugtrio — Lv. 67</li></ul></li><li>Radar: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Rhydon</li><li>Cacnea</li><li>Diglett</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Vibrava</li><li>Claydol</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Beldum — Lv. 51</li><li>Beldum — Lv. 52</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Sandslash — Lv. 66</li><li>Cacturne — Lv. 66</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `174`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-173/"><span class="rw-record-nav__label">← Route 227</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-175/"><span class="rw-record-nav__label">Route 229 →</span></a>
</nav>
