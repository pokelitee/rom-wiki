# Mt. Coronet

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>15</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map header | Location-name index | Internal map |
| -------- | ---------- | ------------------: | ------------ |
| [Mt. Coronet](../locations/header-212.md) | `header-212` | 50 | `D05R0106` |

## Walking

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/358.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51–52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51–52 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51–52 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 35–45 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–55 | 10% |

## Old Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 10 | 20% |

## Good Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 25 | 20% |

## Super Rod

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/148.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 50 | 20% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 50 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 50 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/358.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>6 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 10<span class="rw-diff-arrow">→</span>5</li><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 38</li><li>Chingling — Lv. 38</li><li>Clefairy — Lv. 36</li><li>Medicham — Lv. 37</li><li>Medicham — Lv. 39</li><li>Machoke — Lv. 39</li><li>Bronzong — Lv. 37</li><li>Graveler — Lv. 38</li><li>Golbat — Lv. 38</li><li>Chingling — Lv. 38</li><li>Chingling — Lv. 36</li><li>Nosepass — Lv. 37</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 52</li><li>Solrock — Lv. 52</li><li>Nosepass — Lv. 50</li><li>Clefairy — Lv. 50</li><li>Chimecho — Lv. 51</li><li>Golbat — Lv. 51</li><li>Graveler — Lv. 51</li><li>Bronzong — Lv. 52</li><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li><li>Metang — Lv. 51</li><li>Metang — Lv. 52</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 20–40</li><li>Zubat — Lv. 20–30</li><li>Golbat — Lv. 20–40</li><li>Golbat — Lv. 20–40</li><li>Zubat — Lv. 20–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Golbat — Lv. 45–55</li><li>Zubat — Lv. 35–45</li><li>Golbat — Lv. 45–55</li><li>Golbat — Lv. 45–55</li><li>Zubat — Lv. 35–45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 5–15</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 5–10</li><li>Magikarp — Lv. 4–6</li><li>Magikarp — Lv. 3–7</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 10</li><li>Dratini — Lv. 10</li><li>Dratini — Lv. 10</li><li>Horsea — Lv. 10</li><li>Magikarp — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Barboach — Lv. 10–25</li><li>Magikarp — Lv. 10–25</li><li>Barboach — Lv. 10–25</li><li>Magikarp — Lv. 15–20</li><li>Barboach — Lv. 15–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 25</li><li>Dratini — Lv. 25</li><li>Dratini — Lv. 25</li><li>Horsea — Lv. 25</li><li>Magikarp — Lv. 25</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 75<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Dragonair — Lv. 35–55</li><li>Whiscash — Lv. 20–50</li><li>Dragonair — Lv. 20–40</li><li>Dratini — Lv. 15–25</li><li>Gyarados — Lv. 30–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dragonair — Lv. 50</li><li>Dragonair — Lv. 50</li><li>Dragonair — Lv. 50</li><li>Seadra — Lv. 50</li><li>Gyarados — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Graveler — Lv. 36</li><li>Medicham — Lv. 37</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Nosepass — Lv. 50</li><li>Clefairy — Lv. 50</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 38</li><li>Chingling — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 38</li><li>Chingling — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Golbat — Lv. 38</li><li>Chingling — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li></ul></li><li>Ruby: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Solrock — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li></ul></li><li>Sapphire: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone — Lv. 51</li><li>Solrock — Lv. 51</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Clefairy — Lv. 36</li><li>Golbat — Lv. 37</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Nosepass — Lv. 50</li><li>Clefairy — Lv. 50</li></ul></li><li>Radar: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Medicham</li><li>Chingling</li><li>Machoke</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Lunatone</li><li>Solrock</li><li>Chimecho</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bronzong — Lv. 37</li><li>Graveler — Lv. 38</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Graveler — Lv. 51</li><li>Bronzong — Lv. 52</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `15`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-014/"><span class="rw-record-nav__label">← Mt. Coronet</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-016/"><span class="rw-record-nav__label">Mt. Coronet →</span></a>
</nav>
