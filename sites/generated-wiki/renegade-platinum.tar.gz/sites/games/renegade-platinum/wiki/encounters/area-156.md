# Route 210

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>156</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 210](../locations/header-362.md) | `header-362` | 25 | `R210A` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/402.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketune](../pokemon/kricketune.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 30 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–30 | 15% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/402.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketune](../pokemon/kricketune.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 28 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 29 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 10% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–29 | 8% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–29 | 8% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–29 | 8% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–29 | 8% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 28–29 | 8% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 21</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 19</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 20</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 20</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 21</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 18</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 19</li><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 19</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 19</li><li><a href="../../pokemon/roselia/">Roselia</a> — Lv. 21</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 30</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 28</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 29</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 29</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 29</li><li><a href="../../pokemon/nuzleaf/">Nuzleaf</a> — Lv. 28</li><li><a href="../../pokemon/kricketune/">Kricketune</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 20</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 28</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 29</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pineco/">Pineco</a> — Lv. 19</li><li><a href="../../pokemon/pineco/">Pineco</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 19</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 19</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/nuzleaf/">Nuzleaf</a> — Lv. 19</li><li><a href="../../pokemon/seedot/">Seedot</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 19</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 28</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 29</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 20</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 21</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 28</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 29</li></ul></li><li>Radar: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Tauros</li><li>Miltank</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Kecleon</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 18</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 19</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/nuzleaf/">Nuzleaf</a> — Lv. 28</li><li><a href="../../pokemon/kricketune/">Kricketune</a> — Lv. 28</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[100, 100, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `156`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-155/"><span class="rw-record-nav__label">← Route 209</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-157/"><span class="rw-record-nav__label">Route 210 →</span></a>
</nav>
