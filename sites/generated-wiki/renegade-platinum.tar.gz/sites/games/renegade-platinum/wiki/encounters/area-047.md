# Victory Road

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>47</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Victory Road](../locations/header-244.md) | `header-244` | 54 | `D09R0101` |

## Walking

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/67.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/308.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/297.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/444.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gabite](../pokemon/gabite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 10% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/67.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 59 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/308.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 59 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/308.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 59 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 4% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 59 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 59 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/297.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/444.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gabite](../pokemon/gabite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 41</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 41</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 42</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 40</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 41</li><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 43</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 43</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li><li><a href="../../pokemon/hariyama/">Hariyama</a> — Lv. 59</li><li><a href="../../pokemon/medicham/">Medicham</a> — Lv. 59</li><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 59</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 59</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 59</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 59</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/onix/">Onix</a> — Lv. 41</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/medicham/">Medicham</a> — Lv. 59</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 59</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gabite/">Gabite</a> — Lv. 41</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 59</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 59</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/onix/">Onix</a> — Lv. 41</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 42</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/medicham/">Medicham</a> — Lv. 59</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 59</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Onix</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hariyama</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 40</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 41</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 59</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 59</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `47`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-138/"><span class="rw-record-nav__label">← Valor Lakefront</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-048/"><span class="rw-record-nav__label">Victory Road →</span></a>
</nav>
