# Oreburgh Gate

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>54</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Oreburgh Gate](../locations/header-258.md) | `header-258` | 59 | `D14R0101` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 7–9 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 7–9 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 7–9 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 8 | 10% |

## Special encounters

### Swarm

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 7 | 20% |

### Day replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 8 | 10% |

### Night replacements

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 8 | 10% |

### Dual-slot: Ruby

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 8% |

### Dual-slot: Sapphire

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 8% |

### Dual-slot: Emerald

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 8% |

### Dual-slot: Fire Red

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 8% |

### Dual-slot: Leaf Green

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 8 | 8% |

### Poké Radar

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 5</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 5</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 6</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 5</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 5</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 7</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 7</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 9</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 7</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 9</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 9</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 6</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 7</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 8</li></ul></li><li>Dual Slot: <p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Emerald: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li></ul></li><li>Fire-Red: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li></ul></li><li>Leaf-Green: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li></ul></li><li>Ruby: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li></ul></li><li>Sapphire: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 8</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 6</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 7</li><li><a href="../../pokemon/riolu/">Riolu</a> — Lv. 8</li></ul></li><li>Radar: <p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Diglett</li></ul></li><li>Swarm: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 5</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 5</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 7</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 7</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `54`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-133/"><span class="rw-record-nav__label">← Old Chateau</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-055/"><span class="rw-record-nav__label">Oreburgh Gate →</span></a>
</nav>
