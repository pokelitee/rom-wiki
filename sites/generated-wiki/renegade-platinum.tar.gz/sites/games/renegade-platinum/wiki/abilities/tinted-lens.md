# Tinted Lens

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>110</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">8</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Doubles damage inflicted with not-very-effective moves.</strong></p>
<p>This Pokémon deals twice as much damage with moves that are not very effective against the target.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up “not very effective” moves.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/48.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venonat](../pokemon/venonat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/49.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/314.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Illumise](../pokemon/illumise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/414.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mothim](../pokemon/mothim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/469.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yanmega](../pokemon/yanmega.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/venonat/">Venonat</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/venomoth/">Venomoth</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/illumise/">Illumise</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li></ul><p class="rw-comparison-count">4 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a></li><li><a href="../../pokemon/hoothoot/">Hoothoot</a></li><li><a href="../../pokemon/noctowl/">Noctowl</a></li><li><a href="../../pokemon/mothim/">Mothim</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/110/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../unaware/"><span class="rw-record-nav__label">← Unaware</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../filter/"><span class="rw-record-nav__label">Filter →</span></a>
</nav>
