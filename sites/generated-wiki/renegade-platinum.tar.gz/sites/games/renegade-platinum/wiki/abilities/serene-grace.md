# Serene Grace

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>32</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">12</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Doubles the chance of moves&#x27; extra effects occurring.</strong></p>
<p>This Pokémon&#x27;s moves have twice their usual effect chance. An effect chance is a move&#x27;s chance to inflict a status ailment, cause a stat change, or make the target flinch in addition to the move&#x27;s main effect. For example, Flamethrower&#x27;s chance of burning the target is doubled, but Protect&#x27;s chance of success and Air Cutter&#x27;s increased critical hit rate are unaffected. Secret Power is unaffected.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the likelihood of added effects appearing.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/152.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chikorita](../pokemon/chikorita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/153.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bayleef](../pokemon/bayleef.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/154.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meganium](../pokemon/meganium.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/175.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togepi](../pokemon/togepi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/176.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togetic](../pokemon/togetic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/206.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dunsparce](../pokemon/dunsparce.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/242.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blissey](../pokemon/blissey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/385.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jirachi](../pokemon/jirachi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/468.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togekiss](../pokemon/togekiss.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/10006.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shaymin Sky](../pokemon/shaymin-sky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">6 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/togepi/">Togepi</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/togetic/">Togetic</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/blissey/">Blissey</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/happiny/">Happiny</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/togekiss/">Togekiss</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li></ul><p class="rw-comparison-count">3 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chikorita/">Chikorita</a></li><li><a href="../../pokemon/bayleef/">Bayleef</a></li><li><a href="../../pokemon/meganium/">Meganium</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/32/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../lightning-rod/"><span class="rw-record-nav__label">← Lightningrod</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../swift-swim/"><span class="rw-record-nav__label">Swift Swim →</span></a>
</nav>
