# Shadow Tag

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>23</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents opponents from fleeing or switching out.</strong></p>
<p>While this Pokémon is in battle, opposing Pokémon cannot flee or switch out. Other Pokémon with this ability are unaffected. Pokémon with Run Away can still flee. Pokémon can still switch out with the use of a move or item.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents the foe from escaping.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/202.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/360.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wynaut](../pokemon/wynaut.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **platinum-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/23/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../intimidate/"><span class="rw-record-nav__label">← Intimidate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rough-skin/"><span class="rw-record-nav__label">Rough Skin →</span></a>
</nav>
