# Sticky Hold

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>60</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents a held item from being removed by other Pokémon.</strong></p>
<p>This Pokémon&#x27;s hold item cannot be removed by other Pokémon. Damaging moves that would remove this Pokémon&#x27;s item can still inflict damage against this Pokémon, e.g. Knock Off or Pluck. This Pokémon can still use moves that involve the loss of its own item, e.g. Fling or Trick. Overworld: If the lead Pokémon has this ability, the encounter rate while fishing is increased.</p>

<figure class="rw-pokedex-entry">
<blockquote>Protects the Pokémon from item theft.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/316.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gulpin](../pokemon/gulpin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/317.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swalot](../pokemon/swalot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/422.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellos](../pokemon/shellos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/60/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../forecast/"><span class="rw-record-nav__label">← Forecast</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../shed-skin/"><span class="rw-record-nav__label">Shed Skin →</span></a>
</nav>
