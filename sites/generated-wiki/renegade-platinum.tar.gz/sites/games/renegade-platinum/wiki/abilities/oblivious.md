# Oblivious

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>12</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents infatuation and protects against Captivate.</strong></p>
<p>This Pokémon cannot be infatuated and is immune to Captivate. If a Pokémon is infatuated and acquires this ability, its infatuation is cleared.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents the Pokémon from becoming infatuated.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/79.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowpoke](../pokemon/slowpoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/80.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowbro](../pokemon/slowbro.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/108.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/199.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowking](../pokemon/slowking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/314.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Illumise](../pokemon/illumise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/320.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailmer](../pokemon/wailmer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/321.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailord](../pokemon/wailord.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/463.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lickilicky](../pokemon/lickilicky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/illumise/">Illumise</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/numel/">Numel</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li></ul><p class="rw-comparison-count">5 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a></li><li><a href="../../pokemon/swinub/">Swinub</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/smoochum/">Smoochum</a></li><li><a href="../../pokemon/mamoswine/">Mamoswine</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/12/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../water-absorb/"><span class="rw-record-nav__label">← Water Absorb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../cloud-nine/"><span class="rw-record-nav__label">Cloud Nine →</span></a>
</nav>
