# Magic Guard

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>98</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">10</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Protects against damage not directly caused by a move.</strong></p>
<p>Paralysis cannot prevent the Pokémon from moving, though the Speed cut is unaffected. Poison still damages the Pokémon outside of battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon only takes damage from attacks.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/36.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefable](../pokemon/clefable.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/40.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wigglytuff](../pokemon/wigglytuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/173.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cleffa](../pokemon/cleffa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/174.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Igglybuff](../pokemon/igglybuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/302.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">7 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a></li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a></li><li><a href="../../pokemon/abra/">Abra</a></li><li><a href="../../pokemon/kadabra/">Kadabra</a></li><li><a href="../../pokemon/alakazam/">Alakazam</a></li><li><a href="../../pokemon/igglybuff/">Igglybuff</a></li><li><a href="../../pokemon/sableye/">Sableye</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/98/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sniper/"><span class="rw-record-nav__label">← Sniper</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../no-guard/"><span class="rw-record-nav__label">No Guard →</span></a>
</nav>
