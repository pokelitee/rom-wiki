# Klutz

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>103</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">0</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents the Pokémon from using its held item in battle.</strong></p>
<p>Fling can be used as usual.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon can’t use any held items.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

No Pokémon are assigned this ability.

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/buneary/">Buneary</a></li><li><a href="../../pokemon/lopunny/">Lopunny</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/103/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../leaf-guard/"><span class="rw-record-nav__label">← Leaf Guard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../mold-breaker/"><span class="rw-record-nav__label">Mold Breaker →</span></a>
</nav>
