# Download

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>88</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">3</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Raises the attack stat corresponding to the opponents&#x27; weaker defense one stage upon entering battle.</strong></p>
<p>When this Pokémon enters battle, its Attack or Special Attack, whichever corresponds to its opponents&#x27; weaker total defensive stat, rises one stage. In the event of a tie, Special Attack is raised. This ability also takes effect when acquired during a battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>Adjusts power according to the foe’s ability.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/137.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon](../pokemon/porygon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/233.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon2](../pokemon/porygon2.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/474.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon-Z](../pokemon/porygon-z.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

## Hack changes

Verified unchanged from **platinum-us** for all compared fields.

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/88/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../dry-skin/"><span class="rw-record-nav__label">← Dry Skin</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../iron-fist/"><span class="rw-record-nav__label">Iron Fist →</span></a>
</nav>
