# Sand Veil

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>8</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases evasion to 1.25× during a sandstorm. Protects against sandstorm damage.</strong></p>
<p>During a sandstorm, this Pokémon has 1.25× its evasion, and it does not take sandstorm damage regardless of type. The evasion bonus does not count as a stat modifier. Overworld: If the lead Pokémon has this ability, the wild encounter rate is halved in a sandstorm.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the Pokémon’s evasion in a sandstorm.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/27.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandshrew](../pokemon/sandshrew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/231.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/331.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cacnea](../pokemon/cacnea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/332.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cacturne](../pokemon/cacturne.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/443.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gible](../pokemon/gible.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/444.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gabite](../pokemon/gabite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/445.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Garchomp](../pokemon/garchomp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **platinum-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cacnea/">Cacnea</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/cacturne/">Cacturne</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/gible/">Gible</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/gabite/">Gabite</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/garchomp/">Garchomp</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li></ul><p class="rw-comparison-count">2 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gligar/">Gligar</a></li><li><a href="../../pokemon/gliscor/">Gliscor</a></li></ul><p class="rw-comparison-count">2 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/phanpy/">Phanpy</a></li><li><a href="../../pokemon/donphan/">Donphan</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/8/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../limber/"><span class="rw-record-nav__label">← Limber</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../static/"><span class="rw-record-nav__label">Static →</span></a>
</nav>
