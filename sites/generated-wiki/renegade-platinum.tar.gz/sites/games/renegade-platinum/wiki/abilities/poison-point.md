# Poison Point

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>38</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">9</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 30% chance of poisoning attacking Pokémon on contact.</strong></p>
<p>Whenever a move makes contact with this Pokémon, the move&#x27;s user has a 30% chance of being poisoned.</p>

<figure class="rw-pokedex-entry">
<blockquote>Contact with the Pokémon may poison the foe.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/29.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidoran♀](../pokemon/nidoran-f.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/31.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidoqueen](../pokemon/nidoqueen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/32.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidoran♂](../pokemon/nidoran-m.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/34.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidoking](../pokemon/nidoking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 1 |

## Hack changes

Compared with **platinum-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/roselia/">Roselia</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/budew/">Budew</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li></ul><p class="rw-comparison-count">2 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/qwilfish/">Qwilfish</a></li><li><a href="../../pokemon/roserade/">Roserade</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/38/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../huge-power/"><span class="rw-record-nav__label">← Huge Power</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../inner-focus/"><span class="rw-record-nav__label">Inner Focus →</span></a>
</nav>
