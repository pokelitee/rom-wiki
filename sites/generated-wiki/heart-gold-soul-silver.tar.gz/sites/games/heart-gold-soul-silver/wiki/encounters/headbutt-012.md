# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 4](../locations/header-012.md) | `header-012` | `R04` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–7 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6–7 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6–7 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 9–10 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 9–10 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (1234, 115), (1234, 114), (1235, 115), (1235, 114) |
| 1 | Regular | (1244, 120), (1245, 120), (1245, 121), (1245, 122), (1244, 122) |
| 2 | Regular | (1264, 112), (1265, 112), (1264, 114), (1265, 114) |
| 3 | Regular | (1270, 110), (1271, 110) |
| 4 | Regular | (1266, 124), (1267, 124), (1267, 123) |
| 5 | Regular | (1264, 120), (1264, 119) |
| 6 | Regular | (1255, 126), (1255, 125) |
| 7 | Regular | (1242, 124), (1243, 124) |
| 8 | Regular | (1256, 112), (1257, 112), (1256, 113), (1256, 114), (1257, 114) |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `12`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-011/"><span class="rw-record-nav__label">← Headbutt encounters — Route 3</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-013/"><span class="rw-record-nav__label">Headbutt encounters — Route 5 →</span></a>
</nav>
