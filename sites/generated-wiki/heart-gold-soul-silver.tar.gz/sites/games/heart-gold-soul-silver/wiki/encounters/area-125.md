# Route 16

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>125</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 16](../locations/header-422.md) | 422 | 164 | `R16R0301` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 27 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 28 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 29 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 30 | 5% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 27 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 28 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 29 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 30 | 5% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 26 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 27 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 28 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 29 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 30 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `125`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-124/"><span class="rw-record-nav__label">← Route 15</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-126/"><span class="rw-record-nav__label">Route 17 →</span></a>
</nav>
