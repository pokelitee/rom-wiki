# Cerulean Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>140</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Cerulean Cave](../locations/header-450.md) | `header-450` | 199 | `D03R0102` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 39–42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 42 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 41 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 39–42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 42 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 41 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41–42 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 42 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 41 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 42 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–40 | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 45% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 15% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 30% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bronzor](../pokemon/bronzor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Night fishing:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Fishing swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `140`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-139/"><span class="rw-record-nav__label">← Cerulean Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-141/"><span class="rw-record-nav__label">Cerulean Cave →</span></a>
</nav>
