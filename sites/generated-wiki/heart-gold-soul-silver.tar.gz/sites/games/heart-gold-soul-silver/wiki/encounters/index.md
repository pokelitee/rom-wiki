# Wild encounters

Exact encounter tables linked to their in-game map headers.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Bell Tower — D17R0102](area-030.md)
- [Bell Tower — D17R0103](area-031.md)
- [Bell Tower — D17R0104](area-032.md)
- [Bell Tower — D17R0105](area-033.md)
- [Bell Tower — D17R0106](area-034.md)
- [Bell Tower — D17R0107](area-035.md)
- [Bell Tower — D17R0108](area-036.md)
- [Bell Tower — D17R0109](area-037.md)
- [Bell Tower — D17R0112](area-084.md)
- [Blackthorn City](area-065.md)
- [Burned Tower — D18R0101](area-028.md)
- [Burned Tower — D18R0102](area-029.md)
- [Celadon City](area-099.md)
- [Cerulean Cave — D03R0101](area-139.md)
- [Cerulean Cave — D03R0102](area-140.md)
- [Cerulean Cave — D03R0103](area-141.md)
- [Cerulean City](area-097.md)
- [Cherrygrove City](area-002.md)
- [Cianwood City](area-051.md)
- [Cinnabar Island](area-101.md)
- [Cliff Cave](area-083.md)
- [Cliff Edge Gate](area-082.md)
- [DIGLETT's Cave](area-133.md)
- [Dark Cave — D42R0102](area-069.md)
- [Dark Cave — D42R0101](area-070.md)
- [Dragon's Den](area-066.md)
- [Ecruteak City](area-027.md)
- [Fuchsia City](area-100.md)
- [Ice Path — D39R0101](area-060.md)
- [Ice Path — D39R0102](area-061.md)
- [Ice Path — D39R0103](area-062.md)
- [Ice Path — D39R0104](area-063.md)
- [Ilex Forest](area-020.md)
- [Lake of Rage](area-058.md)
- [Mt. Moon — D02R0103](area-072.md)
- [Mt. Moon — D02R0104](area-073.md)
- [Mt. Moon — D02R0101](area-106.md)
- [Mt. Moon — D02R0102](area-107.md)
- [Mt. Mortar — D38R0101](area-053.md)
- [Mt. Mortar — D38R0102](area-054.md)
- [Mt. Mortar — D38R0103](area-055.md)
- [Mt. Mortar — D38R0104](area-056.md)
- [Mt. Silver](area-085.md)
- [Mt. Silver Cave — D41R0105](area-079.md)
- [Mt. Silver Cave — D41R0106](area-080.md)
- [Mt. Silver Cave — D41R0107](area-081.md)
- [Mt. Silver Cave — D41R0101](area-086.md)
- [Mt. Silver Cave — D41R0103](area-087.md)
- [Mt. Silver Cave — D41R0104](area-088.md)
- [Mt. Silver Cave — D41R0102](area-089.md)
- [National Park — D22R0101](area-023.md)
- [National Park — D22R0102](area-024.md)
- [New Bark Town](area-000.md)
- [Olivine City](area-040.md)
- [Pallet Town](area-095.md)
- [Rock Tunnel — D05R0101](area-108.md)
- [Rock Tunnel — D05R0102](area-109.md)
- [Route 1](area-111.md)
- [Route 10](area-120.md)
- [Route 11](area-121.md)
- [Route 12](area-092.md)
- [Route 13](area-122.md)
- [Route 14](area-123.md)
- [Route 15](area-124.md)
- [Route 16](area-125.md)
- [Route 17](area-126.md)
- [Route 18](area-127.md)
- [Route 19](area-093.md)
- [Route 2 — R02](area-112.md)
- [Route 2 — R02R0101](area-136.md)
- [Route 20](area-094.md)
- [Route 21](area-128.md)
- [Route 22](area-129.md)
- [Route 24](area-130.md)
- [Route 25](area-131.md)
- [Route 26](area-103.md)
- [Route 27](area-104.md)
- [Route 28](area-105.md)
- [Route 29](area-001.md)
- [Route 3](area-113.md)
- [Route 30](area-003.md)
- [Route 31](area-004.md)
- [Route 32](area-008.md)
- [Route 33](area-017.md)
- [Route 34](area-021.md)
- [Route 35](area-022.md)
- [Route 36](area-025.md)
- [Route 37](area-026.md)
- [Route 38](area-038.md)
- [Route 39](area-039.md)
- [Route 4](area-114.md)
- [Route 40](area-041.md)
- [Route 41](area-042.md)
- [Route 42](area-052.md)
- [Route 43](area-057.md)
- [Route 44](area-059.md)
- [Route 45](area-067.md)
- [Route 46](area-068.md)
- [Route 47](area-071.md)
- [Route 48](area-102.md)
- [Route 5](area-115.md)
- [Route 6](area-116.md)
- [Route 7](area-117.md)
- [Route 8](area-118.md)
- [Route 9](area-119.md)
- [Ruins of Alph — D24R0101](area-009.md)
- [Ruins of Alph — D24R0205](area-010.md)
- [Ruins of Alph — D24R0216](area-011.md)
- [Ruins of Alph — D24R0218](area-012.md)
- [Ruins of Alph — D24R0217](area-013.md)
- [SLOWPOKE Well — D26R0102](area-018.md)
- [SLOWPOKE Well — D26R0103](area-019.md)
- [Safari Zone](area-091.md)
- [Seafoam Islands — D11R0101](area-074.md)
- [Seafoam Islands — D11R0102](area-075.md)
- [Seafoam Islands — D11R0103](area-076.md)
- [Seafoam Islands — D11R0104](area-077.md)
- [Seafoam Islands — D11R0105](area-078.md)
- [Sprout Tower — D15R0102](area-006.md)
- [Sprout Tower — D15R0103](area-007.md)
- [Tohjo Falls](area-132.md)
- [Union Cave — D25R0101](area-014.md)
- [Union Cave — D25R0102](area-015.md)
- [Union Cave — D25R0103](area-016.md)
- [Vermilion City](area-098.md)
- [Victory Road — D43R0101](area-110.md)
- [Victory Road — D43R0102](area-134.md)
- [Victory Road — D43R0103](area-135.md)
- [Violet City](area-005.md)
- [Viridian City](area-096.md)
- [Viridian Forest](area-137.md)
- [Whirl Islands — D40R0101](area-043.md)
- [Whirl Islands — D40R0102](area-044.md)
- [Whirl Islands — D40R0104](area-046.md)
- [Whirl Islands — D40R0106](area-048.md)
- [Encounter Area 045](area-045.md)
- [Encounter Area 047](area-047.md)
- [Encounter Area 049](area-049.md)
- [Encounter Area 050](area-050.md)
- [Encounter Area 064](area-064.md)
- [Encounter Area 090](area-090.md)
- [Encounter Area 138](area-138.md)

</div>
