# Route 25

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>131</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 25](../locations/header-029.md) | `header-029` | 173 | `R25` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 8 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/48.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venonat](../pokemon/venonat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 10 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 14 | 5% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 8 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 10 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 14 | 5% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/48.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venonat](../pokemon/venonat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/43.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Oddish](../pokemon/oddish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/49.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 14 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–10 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 85% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 60% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 70% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/427.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buneary](../pokemon/buneary.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/293.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Night fishing:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Fishing swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `131`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-130/"><span class="rw-record-nav__label">← Route 24</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-103/"><span class="rw-record-nav__label">Route 26 →</span></a>
</nav>
