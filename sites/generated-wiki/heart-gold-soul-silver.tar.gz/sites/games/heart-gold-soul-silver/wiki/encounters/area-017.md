# Route 33

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>17</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 33](../locations/header-037.md) | `header-037` | 181 | `R33` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 6–7 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4–7 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6 | 20% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–8 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 6–7 | 60% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `17`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-008/"><span class="rw-record-nav__label">← Route 32</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-021/"><span class="rw-record-nav__label">Route 34 →</span></a>
</nav>
