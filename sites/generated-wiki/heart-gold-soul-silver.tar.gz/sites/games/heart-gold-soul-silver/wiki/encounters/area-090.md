# Encounter Area 090

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>90</dd></div>
<div><dt>Methods</dt><dd>None</dd></div>
</dl>
</section>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `90`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-064/"><span class="rw-record-nav__label">← Encounter Area 064</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-138/"><span class="rw-record-nav__label">Encounter Area 138 →</span></a>
</nav>
