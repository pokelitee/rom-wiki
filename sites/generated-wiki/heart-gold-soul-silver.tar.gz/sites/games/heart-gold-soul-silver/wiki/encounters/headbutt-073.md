# Headbutt encounters { #headbutt-encounters }

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2–3 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 10 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–10 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 10 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (510, 276), (510, 277) |
| 1 | Regular | (506, 265), (507, 265) |
| 2 | Regular | (504, 265), (505, 265) |
| 3 | Regular | (500, 279), (501, 279) |
| 4 | Regular | (496, 279), (496, 280), (496, 281), (497, 279) |
| 5 | Regular | (490, 283), (491, 283) |
| 6 | Regular | (481, 281), (481, 280) |
| 7 | Regular | (487, 273), (487, 272) |
| 8 | Regular | (484, 265), (485, 265) |
| 9 | Regular | (470, 272), (470, 273), (471, 273) |
| 10 | Regular | (468, 279), (469, 279), (469, 280), (469, 281) |
| 11 | Regular | (465, 274), (465, 275) |
| 12 | Regular | (465, 272), (465, 273) |
| 13 | Regular | (462, 265), (463, 265) |
| 14 | Regular | (460, 261), (461, 261), (461, 262), (461, 263) |
| 15 | Regular | (468, 250), (468, 251) |
| 16 | Regular | (468, 246), (468, 247) |
| 17 | Regular | (466, 243), (467, 243) |
| 18 | Regular | (504, 235), (505, 235) |
| 19 | Regular | (506, 236) |
| 20 | Regular | (506, 237), (506, 238) |
| 21 | Regular | (506, 239), (506, 240) |
| 22 | Regular | (457, 230) |
| 23 | Regular | (457, 228), (457, 229) |
| 24 | Regular | (458, 227) |
| 25 | Regular | (459, 227), (460, 227) |
| 26 | Regular | (461, 227), (462, 227) |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Violet City](../locations/header-073.md) | `header-073` | `T22` |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `73`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-067/"><span class="rw-record-nav__label">← Headbutt encounters — Cherrygrove City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-074/"><span class="rw-record-nav__label">Headbutt encounters — Azalea Town →</span></a>
</nav>
