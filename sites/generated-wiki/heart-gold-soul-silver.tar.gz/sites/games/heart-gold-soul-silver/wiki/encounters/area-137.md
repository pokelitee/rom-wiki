# Viridian Forest

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>137</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Viridian Forest](../locations/header-147.md) | `header-147` | 224 | `D46R0101` |

## Walking (Morning)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 4–7 | 6% |

## Walking (Day)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3–7 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 4–7 | 6% |

## Walking (Night)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3–5 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 4 | 5% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/401.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/325.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spoink](../pokemon/spoink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/455.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carnivine](../pokemon/carnivine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `137`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-096/"><span class="rw-record-nav__label">← Viridian City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-043/"><span class="rw-record-nav__label">Whirl Islands →</span></a>
</nav>
