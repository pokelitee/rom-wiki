# Encounter Area 047

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>47</dd></div>
<div><dt>Methods</dt><dd>None</dd></div>
</dl>
</section>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `47`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-045/"><span class="rw-record-nav__label">← Encounter Area 045</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-049/"><span class="rw-record-nav__label">Encounter Area 049 →</span></a>
</nav>
