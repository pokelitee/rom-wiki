# DIGLETT's Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>133</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [DIGLETT's Cave](../locations/header-106.md) | 106 | 197 | `D01R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 15 (30%); 17 (30%); 19 (20%); 13 (10%) | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 19 (5%); 24 (4%); 29 (1%) | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 15 (30%); 17 (30%); 19 (20%); 13 (10%) | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 19 (5%); 24 (4%); 29 (1%) | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 15 (30%); 17 (30%); 19 (20%); 13 (10%) | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 19 (5%); 24 (4%); 29 (1%) | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bronzor](../pokemon/bronzor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `133`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-082/"><span class="rw-record-nav__label">← Cliff Edge Gate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-069/"><span class="rw-record-nav__label">Dark Cave →</span></a>
</nav>
