# Antidote

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/antidote.png" alt="Antidote icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>18</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures poison.</strong></p>
<p>Used on a party Pokémon : Cures poison.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It lifts the effect of poison from one Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures poison</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Burned Tower](../locations/header-007.md) | D18R0101 | `header-007` | Visible | (15, 9) |
| [Route 30](../locations/header-034.md) | R30 | `header-034` | Visible | (554, 342) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Visible | (20, 30) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Hidden | (15, 37) |
| [Goldenrod City](../locations/header-200.md) | D37R0103 | `header-200` | Hidden | (20, 11) |
| [Burned Tower](../locations/header-217.md) | D18R0102 | `header-217` | Hidden | (10, 7) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Mahogany After Hideout | ₽100 | Main game |
| Goldenrod Department Store Healing | ₽100 | Main game |
| Celadon Department Store Healing | ₽100 | Post-game |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `18` |

Source: exact ROM record from `a/0/1/7` member `18`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/18/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../burn-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/burn-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Burn Heal →</span></a>
</nav>
