# Hyper Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="Hyper Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>25</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 200 HP.</strong></p>
<p>Used on a party Pokémon : Restores 200 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>200</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 200</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 3](../locations/header-011.md) | R03 | `header-011` | Hidden | (1160, 105) |
| [Route 36](../locations/header-040.md) | R36 | `header-040` | Visible | (393, 237) |
| [Violet City](../locations/header-073.md) | T22 | `header-073` | Hidden | (505, 254) |
| [Ecruteak City](../locations/header-078.md) | T27 | `header-078` | Hidden | (385, 170) |
| [Route 40](../locations/header-094.md) | W40 | `header-094` | Hidden | (252, 300) |
| [Ruins of Alph](../locations/header-113.md) | D24R0101 | `header-113` | Visible | (418, 273) |
| [Mt. Mortar](../locations/header-119.md) | D38R0101 | `header-119` | Hidden | (27, 42) |
| [Dark Cave](../locations/header-123.md) | D42R0101 | `header-123` | Hidden | (9, 52) |
| [Cerulean Cave](../locations/header-145.md) | D03R0101 | `header-145` | Hidden | (4, 40) |
| [Union Cave](../locations/header-154.md) | D25R0103 | `header-154` | Visible | (17, 73) |
| [Dark Cave](../locations/header-176.md) | D42R0102 | `header-176` | Visible | (51, 15) |
| [Victory Road](../locations/header-179.md) | D43R0103 | `header-179` | Hidden | (59, 40) |
| [Lighthouse](../locations/header-222.md) | D27R0104 | `header-222` | Hidden | (5, 14) |
| [Team Rocket HQ](../locations/header-247.md) | D35R0102 | `header-247` | Visible | (52, 11) |
| [Mt. Mortar](../locations/header-251.md) | D38R0103 | `header-251` | Hidden | (42, 48) |
| [Mt. Mortar](../locations/header-252.md) | D38R0104 | `header-252` | Visible | (40, 39) |
| [Mt. Silver Cave](../locations/header-459.md) | D41R0102 | `header-459` | Hidden | (20, 40) |
| [Mt. Silver Cave](../locations/header-462.md) | D41R0105 | `header-462` | Hidden | (2, 1) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Cianwood Pharmacy | ₽1,200 | Main game |
| Mahogany After Hideout | ₽1,200 | Main game |
| Goldenrod Department Store Healing | ₽1,200 | Main game |
| Celadon Department Store Healing | ₽1,200 | Post-game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Morty](../trainers/trainer-0031.md) | AI battle item |
| [Leader Pryce](../trainers/trainer-0032.md) | AI battle item |
| [Leader Jasmine](../trainers/trainer-0033.md) | AI battle item |
| [Leader Chuck](../trainers/trainer-0034.md) | AI battle item |
| [Leader Clair](../trainers/trainer-0035.md) | AI battle item |
| [School Kid Jack](../trainers/trainer-0503.md) | AI battle item |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `25` |

Source: exact ROM record from `a/0/1/7` member `25`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/25/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Potion →</span></a>
</nav>
