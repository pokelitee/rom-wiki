# Dire Hit

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dire-hit.png" alt="Dire Hit icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>56</dd></div>
<div><dt>Pocket</dt><dd>Battle Items</dd></div>
<div><dt>Category</dt><dd>Stat Boosts</dd></div>
<div><dt>Base price</dt><dd>₽650</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Increases the chance of a critical hit in battle. Raises happiness.</strong></p>
<p>Used on a party Pokémon in battle : Increases the target’s critical hit chance by one stage until it leaves the field. Increases happiness by 1/1/0.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item that raises the critical-hit ratio of a Pokémon in battle. It wears off if the Pokémon is withdrawn.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>6</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x02</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Critical-hit rate +1 stage, friendship (low +1, medium +1)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Mt. Silver Cave](../locations/header-122.md) | D41R0101 | `header-122` | Hidden | (45, 45) |
| [Viridian Forest](../locations/header-147.md) | D46R0101 | `header-147` | Visible | (23, 17) |
| [Dark Cave](../locations/header-176.md) | D42R0102 | `header-176` | Visible | (46, 51) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store X Items | ₽650 | Main game |
| Celadon Department Store X Items | ₽650 | Post-game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Ace Trainer French](../trainers/trainer-0545.md) | AI battle item |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `56` |

Source: exact ROM record from `a/0/1/7` member `56`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/56/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../guard-spec/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/guard-spec.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Guard Spec.</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../x-attack/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/x-attack.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">X Attack →</span></a>
</nav>
