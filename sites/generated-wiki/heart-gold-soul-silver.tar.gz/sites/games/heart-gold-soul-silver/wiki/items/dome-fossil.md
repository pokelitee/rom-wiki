# Dome Fossil

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dome-fossil.png" alt="Dome Fossil icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>102</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Dex Completion</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">100</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Can be revived into a Kabuto.</strong></p>
<p>Give to a scientist in the Mining Museum in Oreburgh City or the Museum of Science in Pewter City to receive a Kabuto.</p>

<figure class="rw-pokedex-entry">
<blockquote>A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a shell.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `102` |

Source: exact ROM record from `a/0/1/7` member `102`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/102/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../helix-fossil/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/helix-fossil.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Helix Fossil</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../old-amber/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/old-amber.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Old Amber →</span></a>
</nav>
