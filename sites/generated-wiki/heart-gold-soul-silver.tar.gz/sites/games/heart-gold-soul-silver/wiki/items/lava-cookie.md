# Lava Cookie

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lava-cookie.png" alt="Lava Cookie icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>42</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>Lavaridge Town’s local specialty. It heals all the status problems of one Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 42](../locations/header-044.md) | R42 | `header-044` | Hidden | (480, 182) |
| [SLOWPOKE Well](../locations/header-181.md) | D26R0103 | `header-181` | Visible | (25, 9) |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `42` |

Source: exact ROM record from `a/0/1/7` member `42`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/42/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-elixir/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-elixir.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Elixir</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../berry-juice/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/berry-juice.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Berry Juice →</span></a>
</nav>
