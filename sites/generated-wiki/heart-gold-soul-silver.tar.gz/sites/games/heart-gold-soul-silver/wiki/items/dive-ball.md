# Dive Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dive-ball.png" alt="Dive Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>7</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Special Balls</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Success rate is 3.5× when underwater, fishing, or surfing.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon. If the wild Pokémon was encountered by surfing or fishing, this ball has a catch rate of 3.5×. Otherwise, it has a catch rate of 1×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A somewhat different Poké Ball that works especially well on Pokémon that live in the sea.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `7` |

Source: exact ROM record from `a/0/1/7` member `7`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/7/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../net-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/net-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Net Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../nest-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/nest-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Nest Ball →</span></a>
</nav>
