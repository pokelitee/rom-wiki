# Max Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="Max Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>24</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽2,500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full.</strong></p>
<p>Used on a party Pokémon : Restores HP to full.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It completely restores the HP of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 9](../locations/header-017.md) | R09 | `header-017` | Visible | (1356, 154) |
| [Route 38](../locations/header-042.md) | R38 | `header-042` | Visible | (329, 177) |
| [Route 42](../locations/header-044.md) | R42 | `header-044` | Hidden | (480, 182) |
| [Route 45](../locations/header-047.md) | R45 | `header-047` | Visible | (662, 242) |
| [Lake of Rage](../locations/header-088.md) | T29 | `header-088` | Hidden | (542, 37) |
| [Ice Path](../locations/header-120.md) | D39R0101 | `header-120` | Hidden | (17, 18) |
| [Victory Road](../locations/header-124.md) | D43R0101 | `header-124` | Hidden | (18, 33) |
| [Goldenrod City](../locations/header-202.md) | D37R0105 | `header-202` | Hidden | (12, 11) |
| [Ice Path](../locations/header-238.md) | D39R0103 | `header-238` | Visible | (5, 12) |
| [Mt. Mortar](../locations/header-250.md) | D38R0102 | `header-250` | Visible | (51, 43) |
| [Mt. Mortar](../locations/header-251.md) | D38R0103 | `header-251` | Visible | (45, 38) |
| [Dragon's Den](../locations/header-253.md) | D44R0102 | `header-253` | Hidden | (8, 22) |
| [Bell Tower](../locations/header-333.md) | D17R0103 | `header-333` | Hidden | (16, 8) |
| [Bell Tower](../locations/header-336.md) | D17R0106 | `header-336` | Visible | (13, 16) |
| [Rock Tunnel](../locations/header-452.md) | D05R0102 | `header-452` | Hidden | (38, 34) |
| [Mt. Silver Cave](../locations/header-463.md) | D41R0106 | `header-463` | Hidden | (2, 19) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store Healing | ₽2,500 | Main game |
| Celadon Department Store Healing | ₽2,500 | Post-game |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `24` |

Source: exact ROM record from `a/0/1/7` member `24`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/24/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../full-restore/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Full Restore</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../hyper-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Hyper Potion →</span></a>
</nav>
