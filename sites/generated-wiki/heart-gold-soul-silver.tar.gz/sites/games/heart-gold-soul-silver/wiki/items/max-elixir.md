# Max Elixir

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-elixir.png" alt="Max Elixir icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>41</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Pp Recovery</dd></div>
<div><dt>Base price</dt><dd>₽4,500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores PP to full for each move.</strong></p>
<p>Used on a party Pokémon : Restores PP to full for each move.</p>

<figure class="rw-pokedex-entry">
<blockquote>It fully restores the PP of all the moves learned by the targeted Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x10</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores all PP, PP amount 127</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 17](../locations/header-025.md) | R17 | `header-025` | Hidden | (1129, 390) |
| [Route 26](../locations/header-030.md) | R26 | `header-030` | Visible | (910, 314) |
| [Route 19](../locations/header-091.md) | W19 | `header-091` | Hidden | (1209, 460) |
| [Cerulean Cave](../locations/header-145.md) | D03R0101 | `header-145` | Visible | (43, 18) |
| [Whirl Islands](../locations/header-243.md) | D40R0104 | `header-243` | Visible | (25, 30) |
| [Dragon's Den](../locations/header-253.md) | D44R0102 | `header-253` | Visible | (7, 33) |
| [Dragon's Den](../locations/header-253.md) | D44R0102 | `header-253` | Hidden | (32, 49) |
| [Bell Tower](../locations/header-338.md) | D17R0108 | `header-338` | Visible | (17, 14) |
| [Mt. Silver Cave](../locations/header-463.md) | D41R0106 | `header-463` | Visible | (17, 11) |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `41` |

Source: exact ROM record from `a/0/1/7` member `41`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/41/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../elixir/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/elixir.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Elixir</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../lava-cookie/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lava-cookie.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Lava Cookie →</span></a>
</nav>
