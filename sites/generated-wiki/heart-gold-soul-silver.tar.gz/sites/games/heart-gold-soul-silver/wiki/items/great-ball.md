# Great Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="Great Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>3</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Standard Balls</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Success rate is 1.5×.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1.5×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A good, high-performance Ball that provides a higher Pokémon catch rate than a standard Poké Ball.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 32](../locations/header-036.md) | R32 | `header-036` | Visible | (459, 382) |
| [Route 32](../locations/header-036.md) | R32 | `header-036` | Hidden | (460, 432) |
| [Union Cave](../locations/header-099.md) | D25R0101 | `header-099` | Visible | (29, 72) |
| [Union Cave](../locations/header-099.md) | D25R0101 | `header-099` | Hidden | (30, 58) |
| [Ruins of Alph](../locations/header-113.md) | D24R0101 | `header-113` | Hidden | (442, 296) |
| [SLOWPOKE Well](../locations/header-114.md) | D26R0101 | `header-114` | Hidden | (17, 8) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Mahogany After Hideout | ₽600 | Main game |
| Goldenrod Department Store Balls Etc. | ₽600 | Main game |
| Celadon Department Store Balls Etc. | ₽600 | Post-game |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `3` |

Source: exact ROM record from `a/0/1/7` member `3`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/3/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ultra-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ultra Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../poke-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Poké Ball →</span></a>
</nav>
