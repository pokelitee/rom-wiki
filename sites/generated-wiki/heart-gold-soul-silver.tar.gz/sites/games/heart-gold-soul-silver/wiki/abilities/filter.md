# Filter

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>111</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Decreases damage taken from super-effective moves by 1/4.</strong></p>
<p>This Pokémon takes 0.75× as much damage from moves that are super effective against it. This ability functions identically to Solid Rock.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers down super­ effective moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mr. Mime](../pokemon/mr-mime.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/111/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../tinted-lens/"><span class="rw-record-nav__label">← Tinted Lens</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../slow-start/"><span class="rw-record-nav__label">Slow Start →</span></a>
</nav>
