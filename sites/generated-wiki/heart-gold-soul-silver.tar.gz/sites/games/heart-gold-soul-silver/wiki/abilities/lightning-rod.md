# Lightningrod

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>31</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">7</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Redirects single-target Electric moves to this Pokémon where possible. Absorbs Electric moves, raising Special Attack one stage.</strong></p>
<p>Redirects Electric moves without negating them or granting any Special Attack boost. Does not redirect Hidden Power.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon draws in all Electric-type moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrike](../pokemon/electrike.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyperior](../pokemon/rhyperior.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/31/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../natural-cure/"><span class="rw-record-nav__label">← Natural Cure</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../serene-grace/"><span class="rw-record-nav__label">Serene Grace →</span></a>
</nav>
