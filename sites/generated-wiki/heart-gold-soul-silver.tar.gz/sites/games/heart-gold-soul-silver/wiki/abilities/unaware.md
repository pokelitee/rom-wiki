# Unaware

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>109</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Ignores other Pokémon&#x27;s stat modifiers for damage and accuracy calculation.</strong></p>
<p>This Pokémon ignores other Pokémon&#x27;s stat modifiers for the purposes of damage and accuracy calculation. Effectively, this affects modifiers of every stat except Speed. The power of Punishment and Stored Power is calculated as usual. When this Pokémon hurts itself in confusion, its stat modifiers affect damage as usual.</p>

<figure class="rw-pokedex-entry">
<blockquote>Ignores any change in ability by the foe.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 2 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/109/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../forewarn/"><span class="rw-record-nav__label">← Forewarn</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../tinted-lens/"><span class="rw-record-nav__label">Tinted Lens →</span></a>
</nav>
