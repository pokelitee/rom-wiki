# Gluttony

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>82</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">3</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Makes the Pokémon eat any held Berry triggered by low HP below 1/2 its max HP.</strong></p>
<p>This Pokémon eats any held Berry triggered by low HP when it falls below 50% of its HP, regardless of the Berry&#x27;s usual threshold.</p>

<figure class="rw-pokedex-entry">
<blockquote>Encourages the early use of a held Berry.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shuckle](../pokemon/shuckle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/82/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../snow-cloak/"><span class="rw-record-nav__label">← Snow Cloak</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../anger-point/"><span class="rw-record-nav__label">Anger Point →</span></a>
</nav>
