# Inner Focus

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>39</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">14</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents flinching.</strong></p>
<p>This Pokémon cannot flinch.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected from flinching.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Alakazam](../pokemon/alakazam.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Crobat](../pokemon/crobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lucario](../pokemon/lucario.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--steel">Steel</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/39/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../poison-point/"><span class="rw-record-nav__label">← Poison Point</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../magma-armor/"><span class="rw-record-nav__label">Magma Armor →</span></a>
</nav>
