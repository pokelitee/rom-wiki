# Reckless

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>120</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Strengthens recoil moves to 1.2× their power.</strong></p>
<p>This Pokémon&#x27;s recoil moves and crash moves have 1.2× their base power. Struggle is unaffected. The &quot;crash moves&quot; are the moves that damage the user upon missing: Jump Kick and High Jump Kick.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up moves that have recoil damage.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hitmonlee](../pokemon/hitmonlee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/120/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../frisk/"><span class="rw-record-nav__label">← Frisk</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../multitype/"><span class="rw-record-nav__label">Multitype →</span></a>
</nav>
