# Color Change

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>16</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Changes type to match when hit by a damaging move.</strong></p>
<p>Triggers on every hit of multiple-hit moves.</p>

<figure class="rw-pokedex-entry">
<blockquote>Changes the Pokémon’s type to the foe’s move.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/16/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../insomnia/"><span class="rw-record-nav__label">← Insomnia</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../immunity/"><span class="rw-record-nav__label">Immunity →</span></a>
</nav>
