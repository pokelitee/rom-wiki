# Normalize

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>96</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Makes the Pokémon&#x27;s moves all act Normal-type.</strong></p>
<p>This Pokémon&#x27;s moves all act as if they were Normal-type. Moves that inflict typeless damage do so as usual. Moves of variable type, such as Hidden Power, are affected. They otherwise work as usual, however; Weather Ball, for example, is always forced to be Normal, but it still has doubled power and looks different during weather. As Thunder Wave is prevented by immunities, unlike most non-damaging moves, it does not affect Ghost-type Pokémon under the effect of this ability.</p>

<figure class="rw-pokedex-entry">
<blockquote>All the Pokémon’s moves become the Normal type.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delcatty](../pokemon/delcatty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/96/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../quick-feet/"><span class="rw-record-nav__label">← Quick Feet</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sniper/"><span class="rw-record-nav__label">Sniper →</span></a>
</nav>
