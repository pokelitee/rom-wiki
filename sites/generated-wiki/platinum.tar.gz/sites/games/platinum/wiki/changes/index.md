# Changes from base game

This wiki was generated without a clean-ROM comparison.
