# Route 204

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>144</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 204](../locations/header-346.md) | `header-346` | 19 | `R204B` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 9–11 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 9–11 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/401.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 8 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 9–10 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 9–10 | 15% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–30 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–40 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3–15 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 45% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 30–55 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–55 | 45% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 9 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 9 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/401.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 9 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 8 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 10 | 8% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 10 | 8% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 10 | 8% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 10 | 8% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 8% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/191.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sunkern](../pokemon/sunkern.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `144`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-143/"><span class="rw-record-nav__label">← Route 204</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-145/"><span class="rw-record-nav__label">Route 205 →</span></a>
</nav>
