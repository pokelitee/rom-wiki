# Canalave City

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>0</dd></div>
<div><dt>Methods</dt><dd><a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Canalave City](../locations/header-033.md) | `header-033` | 7 | `C02` |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 20–30 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/422.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellos](../pokemon/shellos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/73.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 20–40 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20–40 | 1% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3–15 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 45% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 30–55 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/457.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lumineon](../pokemon/lumineon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–55 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/120.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staryu](../pokemon/staryu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–50 | 15% |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(0, 0, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `0`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-139/"><span class="rw-record-nav__label">← Acuity Lakefront</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-177/"><span class="rw-record-nav__label">Celestic Town →</span></a>
</nav>
