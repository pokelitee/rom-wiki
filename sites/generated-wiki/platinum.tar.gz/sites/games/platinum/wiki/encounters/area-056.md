# Stark Mountain

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>56</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Stark Mountain](../locations/header-262.md) | `header-262` | 84 | `D16` |

## Walking

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 54 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 51–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 51–53 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/110.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weezing](../pokemon/weezing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 5% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 54 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 10% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 4% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 4% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/322.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 51 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 52 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `[100, 100, 0, 0, 0]` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `56`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-046/"><span class="rw-record-nav__label">← Solaceon Ruins</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-057/"><span class="rw-record-nav__label">Stark Mountain →</span></a>
</nav>
