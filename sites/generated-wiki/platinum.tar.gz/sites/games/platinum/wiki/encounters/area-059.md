# Sendoff Spring

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>59</dd></div>
<div><dt>Methods</dt><dd><a href="#walking">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Sendoff Spring](../locations/header-267.md) | `header-267` | 61 | `D17R0101` |

## Walking

Encounter rate: 30

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 37–39 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 37–38 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 38–40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/433.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 37–39 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–40 | 100% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3–15 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–25 | 45% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 30–55 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–55 | 45% |

## Special encounters

**Swarm:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 38 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 37 | 20% |

**Day replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 39 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 10% |

**Night replacements:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 39 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 10% |

**Dual-slot: Ruby:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 39–40 | 8% |

**Dual-slot: Sapphire:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 39–40 | 8% |

**Dual-slot: Emerald:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/433.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 39 | 4% |

**Dual-slot: Fire Red:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/433.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 39 | 4% |

**Dual-slot: Leaf Green:**

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/433.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 39 | 4% |

**Poké Radar:**

Only appears for one specific Poké Radar shake outcome; most radar encounters instead continue the current chain's species rather than drawing from this table, so no fixed level or chance applies here.

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/433.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chingling](../pokemon/chingling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Unown table ID | `0` |
| Encounter form rates | `(100, 100, 0, 0, 0)` |

Source: exact ROM record from `fielddata/encountdata/pl_enc_data.narc` member `59`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III/IV engine weights applied by slot position.
Swarm, Day/Night, and Dual-slot replacements substitute a walking slot's species only; the level and chance shown for them are the replaced slot's own level and chance, per the wild-encounter routine in the Pokémon Platinum decompilation.
Encounter form rates is a raw ROM value whose exact purpose isn't fully understood; it is not a Pokémon species reference (unlike most other numeric fields on this page) and stays constant across every encounter area regardless of location.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-115/"><span class="rw-record-nav__label">← Ruin Maniac Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-106/"><span class="rw-record-nav__label">Snowpoint Temple →</span></a>
</nav>
