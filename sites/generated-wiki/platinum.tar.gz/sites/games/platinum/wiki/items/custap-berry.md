# Custap Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/custap-berry.png" alt="Custap Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>210</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>In A Pinch</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed at 1/4 max HP when using a move to go first.</strong></p>
<p>Held in battle : When the holder has 1/4 its max HP remaining or less, it consumes this item. On the following turn, the holder will act first among moves with the same priority, regardless of Speed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. If held by a Pokémon, it gets to move first just once in a pinch.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>45</dd></div>
<div><dt>Held effect parameter</dt><dd>4</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>80 power, <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span></dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Super Hard</dd></div>
<div><dt>Size</dt><dd>267 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>24 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>7</dd></div>
</dl>

**Contest flavor:**

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>0</dd></div>
<div><dt>Dry</dt><dd>0</dd></div>
<div><dt>Sweet</dt><dd>40</dd></div>
<div><dt>Bitter</dt><dd>10</dd></div>
<div><dt>Sour</dt><dd>0</dd></div>
<div><dt>Smoothness</dt><dd>60</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Stark Mountain](../locations/header-262.md) | D16 | `header-262` | Visible | (762, 232) |
| [Great Marsh](../locations/header-504.md) | D06R0201 | `header-504` | Hidden | (33, 37) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `188` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `188`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/187/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../micle-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/micle-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Micle Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../jaboca-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/jaboca-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Jaboca Berry →</span></a>
</nav>
