# Antidote

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/antidote.png" alt="Antidote icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>18</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures poison.</strong></p>
<p>Used on a party Pokémon : Cures poison.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It lifts the effect of poison from one Pokémon.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures poison</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Eterna Forest](../locations/header-203.md) | D03R0101 | `header-203` | Visible | (15, 81) |
| [Route 212](../locations/header-367.md) | R212A | `header-367` | Hidden | (475, 803) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | C01FS0101 | `header-004` | Common | ₽100 | Start |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Common | ₽100 | Start |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Common | ₽100 | Start |
| [Eterna City](../locations/header-066.md) | C04FS0101 | `header-066` | Common | ₽100 | Start |
| [Hearthome City](../locations/header-087.md) | C05FS0101 | `header-087` | Common | ₽100 | Start |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Common | ₽100 | Start |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Specialty | ₽100 | Always |
| [Sunyshore City](../locations/header-153.md) | C08FS0101 | `header-153` | Common | ₽100 | Start |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽100 | Always |
| [Snowpoint City](../locations/header-166.md) | C09FS0101 | `header-166` | Common | ₽100 | Start |
| [Pokémon League](../locations/header-173.md) | C10PC0101 | `header-173` | Common | ₽100 | Start |
| [Pokémon League](../locations/header-175.md) | C10R0101 | `header-175` | Common | ₽100 | Start |
| [Fight Area](../locations/header-191.md) | C11FS0101 | `header-191` | Common | ₽100 | Start |
| [Sandgem Town](../locations/header-419.md) | T02FS0101 | `header-419` | Common | ₽100 | Start |
| [Floaroma Town](../locations/header-427.md) | T03FS0101 | `header-427` | Common | ₽100 | Start |
| [Solaceon Town](../locations/header-434.md) | T04FS0101 | `header-434` | Common | ₽100 | Start |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽100 | Start |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽100 | Start |
| [Survival Area](../locations/header-451.md) | T06FS0101 | `header-451` | Common | ₽100 | Start |
| [Resort Area](../locations/header-458.md) | T07FS0101 | `header-458` | Common | ₽100 | Start |
| [Veilstone Store](../locations/header-566.md) | C07R0207 | `header-566` | Specialty | ₽100 | Always |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `18` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `18`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/18/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../burn-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/burn-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Burn Heal →</span></a>
</nav>
