# Mental Herb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/mental-herb.png" alt="Mental Herb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>219</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed to cure infatuation. Gen V: Also removes Taunt, Encore, Torment, Disable, and Cursed Body.</strong></p>
<p>Held in battle : When the holder is attracted, it consumes this item to cure the attraction.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It snaps the holder out of infatuation. It can be used only once.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>54</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>25</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Floaroma Meadow — D13R0101](../locations/header-256.md) | Hidden | (48, 24) |
| [Stark Mountain — D16R0102](../locations/header-264.md) | Visible | (92, 3) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `197` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `197`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/196/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../soothe-bell/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/soothe-bell.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Soothe Bell</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../choice-band/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-band.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Choice Band →</span></a>
</nav>
