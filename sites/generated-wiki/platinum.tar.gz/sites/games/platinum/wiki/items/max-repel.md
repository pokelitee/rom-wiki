# Max Repel

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="Max Repel icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>77</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Spelunking</dd></div>
<div><dt>Base price</dt><dd>₽700</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>For 250 steps, prevents wild encounters of level lower than your party’s lead Pokémon.</strong></p>
<p>Used outside of battle : Trainer will skip encounters with wild Pokémon of a lower level than the lead party Pokémon. This effect wears off after the trainer takes 250 steps.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item that prevents weak wild Pokémon from appearing for 250 steps after its use.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Bag Message</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>19</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>250</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Galactic HQ](../locations/header-307.md) | D26R0103 | `header-307` | Hidden | (2, 18) |
| [Route 213](../locations/header-373.md) | R213 | `header-373` | Visible | (700, 818) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | C01FS0101 | `header-004` | Common | ₽700 | 3 badges |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Common | ₽700 | 3 badges |
| [Oreburgh City](../locations/header-046.md) | C03FS0101 | `header-046` | Common | ₽700 | 3 badges |
| [Eterna City](../locations/header-066.md) | C04FS0101 | `header-066` | Common | ₽700 | 3 badges |
| [Hearthome City](../locations/header-087.md) | C05FS0101 | `header-087` | Common | ₽700 | 3 badges |
| [Pastoria City](../locations/header-121.md) | C06FS0101 | `header-121` | Common | ₽700 | 3 badges |
| [Sunyshore City](../locations/header-153.md) | C08FS0101 | `header-153` | Common | ₽700 | 3 badges |
| [Snowpoint City](../locations/header-166.md) | C09FS0101 | `header-166` | Common | ₽700 | 3 badges |
| [Pokémon League](../locations/header-173.md) | C10PC0101 | `header-173` | Common | ₽700 | 3 badges |
| [Pokémon League](../locations/header-175.md) | C10R0101 | `header-175` | Common | ₽700 | 3 badges |
| [Fight Area](../locations/header-191.md) | C11FS0101 | `header-191` | Common | ₽700 | 3 badges |
| [Sandgem Town](../locations/header-419.md) | T02FS0101 | `header-419` | Common | ₽700 | 3 badges |
| [Floaroma Town](../locations/header-427.md) | T03FS0101 | `header-427` | Common | ₽700 | 3 badges |
| [Solaceon Town](../locations/header-434.md) | T04FS0101 | `header-434` | Common | ₽700 | 3 badges |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽700 | 3 badges |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Common | ₽700 | 3 badges |
| [Survival Area](../locations/header-451.md) | T06FS0101 | `header-451` | Common | ₽700 | 3 badges |
| [Resort Area](../locations/header-458.md) | T07FS0101 | `header-458` | Common | ₽700 | 3 badges |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `77` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `77`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/77/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-repel/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Super Repel</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../escape-rope/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/escape-rope.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Escape Rope →</span></a>
</nav>
