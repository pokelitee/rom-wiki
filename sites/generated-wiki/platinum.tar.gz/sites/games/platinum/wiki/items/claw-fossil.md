# Claw Fossil

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/claw-fossil.png" alt="Claw Fossil icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>100</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Dex Completion</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">100</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Can be revived into an Anorith.</strong></p>
<p>Give to a scientist in the Mining Museum in Oreburgh City or the Museum of Science in Pewter City to receive an Anorith.</p>

<figure class="rw-pokedex-entry">
<blockquote>A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a claw.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Mt. Coronet](../locations/header-213.md) | D05R0107 | `header-213` | Hidden | (11, 8) |
| [Route 210](../locations/header-362.md) | R210A | `header-362` | Visible | (546, 578) |

## Fossil revival

Reviving this fossil produces:

<span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/347.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Anorith](../pokemon/anorith.md)</span>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `100` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `100`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/100/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../root-fossil/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/root-fossil.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Root Fossil</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../helix-fossil/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/helix-fossil.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Helix Fossil →</span></a>
</nav>
