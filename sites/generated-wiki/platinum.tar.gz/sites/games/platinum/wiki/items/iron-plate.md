# Iron Plate

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iron-plate.png" alt="Iron Plate icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>313</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Plates</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">90</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Steel-Type moves from holder do 20% more damage. Changes Arceus’s and Judgment’s type to Steel.</strong></p>
<p>Held: Increases the power of the holder’s Steel moves by 20%. Held by a Multitype Pokémon: Holder’s type becomes Steel.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a stone tablet that boosts the power of Steel-type moves.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>141</dd></div>
<div><dt>Held effect parameter</dt><dd>20</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Victory Road](../locations/header-246.md) | D09R0103 | `header-246` | Visible | (35, 39) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `291` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `291`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/290/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../dread-plate/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dread-plate.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Dread Plate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../odd-incense/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/odd-incense.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Odd Incense →</span></a>
</nav>
