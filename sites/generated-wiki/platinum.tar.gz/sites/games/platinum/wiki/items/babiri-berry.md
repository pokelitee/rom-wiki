# Babiri Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/babiri-berry.png" alt="Babiri Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>199</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Type Protection</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when struck by a super-effective Steel-type attack to halve the damage.</strong></p>
<p>Held in battle : When the holder would take super-effective Steel-type damage, it consumes this item to halve the amount of damage taken.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. If held by a Pokémon, it weakens a foe’s supereffective Steel-type attack.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>34</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span></dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Super Hard</dd></div>
<div><dt>Size</dt><dd>265 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>18 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>6</dd></div>
</dl>

### Contest flavor

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>25</dd></div>
<div><dt>Dry</dt><dd>10</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>0</dd></div>
<div><dt>Sour</dt><dd>0</dd></div>
<div><dt>Smoothness</dt><dd>35</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 217](../locations/header-385.md) | R217 | `header-385` | Hidden | (314, 348) |
| [Route 225](../locations/header-400.md) | R225 | `header-400` | Visible | (637, 394) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/361.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/478.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Froslass](../pokemon/froslass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ghost">Ghost</span></span> | Rare |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `177` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `177`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/176/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../colbur-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/colbur-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Colbur Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../chilan-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chilan-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Chilan Berry →</span></a>
</nav>
