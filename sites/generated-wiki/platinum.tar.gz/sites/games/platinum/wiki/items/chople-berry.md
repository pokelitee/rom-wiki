# Chople Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chople-berry.png" alt="Chople Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>189</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Type Protection</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when struck by a super-effective Fighting-type attack to halve the damage.</strong></p>
<p>Held in battle : When the holder would take super-effective Fighting-type damage, it consumes this item to halve the amount of damage taken.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Poffin ingredient. If held by a Pokémon, it weakens a foe’s supereffective Fighting-type attack.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>24</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span></dd></div>
</dl>

## Berry mechanics

<dl class="rw-data-grid">
<div><dt>Firmness</dt><dd>Soft</dd></div>
<div><dt>Size</dt><dd>77 mm</dd></div>
<div><dt>Base yield</dt><dd>1</dd></div>
<div><dt>Growth stage duration</dt><dd>18 hours</dd></div>
<div><dt>Moisture drain rate</dt><dd>6</dd></div>
</dl>

### Contest flavor

<dl class="rw-data-grid">
<div><dt>Spicy</dt><dd>15</dd></div>
<div><dt>Dry</dt><dd>0</dd></div>
<div><dt>Sweet</dt><dd>0</dd></div>
<div><dt>Bitter</dt><dd>10</dd></div>
<div><dt>Sour</dt><dd>0</dd></div>
<div><dt>Smoothness</dt><dd>30</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Victory Road](../locations/header-245.md) | D09R0102 | `header-245` | Visible | (43, 12) |
| [Route 210](../locations/header-362.md) | R210A | `header-362` | Hidden | (566, 571) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/427.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buneary](../pokemon/buneary.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/428.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lopunny](../pokemon/lopunny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `167` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `167`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/166/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../yache-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yache-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Yache Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../kebia-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/kebia-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Kebia Berry →</span></a>
</nav>
