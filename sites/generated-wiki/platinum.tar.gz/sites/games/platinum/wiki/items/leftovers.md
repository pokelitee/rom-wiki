# Leftovers

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leftovers.png" alt="Leftovers icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>234</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Restores 1/16 (6.25%) holder’s max HP at the end of each turn.</strong></p>
<p>Held: Heals the holder by 1/16 its max HP at the end of each turn.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. The holder’s HP is gradually restored during battle.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>69</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Floaroma Meadow](../locations/header-256.md) | D13R0101 | `header-256` | Visible | (46, 28) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/143.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorlax](../pokemon/snorlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/143.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorlax](../pokemon/snorlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/446.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/446.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | Rare |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `212` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `212`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/211/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../metal-coat/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/metal-coat.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Metal Coat</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../dragon-scale/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dragon-scale.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Dragon Scale →</span></a>
</nav>
