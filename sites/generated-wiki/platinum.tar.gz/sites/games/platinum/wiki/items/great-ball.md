# Great Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="Great Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>3</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Standard Balls</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Success rate is 1.5×.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1.5×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A good, high-performance Ball that provides a higher Pokémon catch rate than a standard Poké Ball.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Eterna City — C04](../locations/header-065.md) | Hidden | (355, 521) |
| [Oreburgh Gate — D14R0102](../locations/header-259.md) | Visible | (8, 9) |
| [Route 211 — R211A](../locations/header-365.md) | Hidden | (355, 521) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City — C01FS0101](../locations/header-004.md) | Common | ₽600 | 2 badges |
| [Canalave City — C02FS0101](../locations/header-034.md) | Common | ₽600 | 2 badges |
| [Oreburgh City — C03FS0101](../locations/header-046.md) | Common | ₽600 | 2 badges |
| [Eterna City — C04FS0101](../locations/header-066.md) | Common | ₽600 | 2 badges |
| [Hearthome City — C05FS0101](../locations/header-087.md) | Common | ₽600 | 2 badges |
| [Pastoria City — C06FS0101](../locations/header-121.md) | Common | ₽600 | 2 badges |
| [Sunyshore City — C08FS0101](../locations/header-153.md) | Common | ₽600 | 2 badges |
| [Sunyshore Market — C08R0101](../locations/header-157.md) | Seal | ₽50 | Always |
| [Snowpoint City — C09FS0101](../locations/header-166.md) | Common | ₽600 | 2 badges |
| [Pokémon League — C10PC0101](../locations/header-173.md) | Common | ₽600 | 2 badges |
| [Pokémon League — C10R0101](../locations/header-175.md) | Common | ₽600 | 2 badges |
| [Fight Area — C11FS0101](../locations/header-191.md) | Common | ₽600 | 2 badges |
| [Sandgem Town — T02FS0101](../locations/header-419.md) | Common | ₽600 | 2 badges |
| [Floaroma Town — T03FS0101](../locations/header-427.md) | Common | ₽600 | 2 badges |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Common | ₽600 | 2 badges |
| [Solaceon Town — T04FS0101](../locations/header-434.md) | Specialty | ₽600 | Always |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽600 | 2 badges |
| [Celestic Town — T05R0201](../locations/header-446.md) | Common | ₽600 | 2 badges |
| [Survival Area — T06FS0101](../locations/header-451.md) | Common | ₽600 | 2 badges |
| [Resort Area — T07FS0101](../locations/header-458.md) | Common | ₽600 | 2 badges |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `3` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `3`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/3/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ultra-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ultra Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../poke-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Poké Ball →</span></a>
</nav>
