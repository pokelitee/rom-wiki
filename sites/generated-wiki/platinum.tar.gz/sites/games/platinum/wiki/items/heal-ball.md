# Heal Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/heal-ball.png" alt="Heal Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>14</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Special Balls</dd></div>
<div><dt>Base price</dt><dd>₽300</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Caught Pokémon are immediately healed.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1×. The caught Pokémon’s HP is immediately restored, PP for all its moves is restored, and any status ailment is cured. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A remedial Poké Ball that restores the caught Pokémon’s HP and eliminates any status problem.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Route 204](../locations/header-346.md) | R204B | `header-346` | Visible | (162, 682) |
| [Route 208](../locations/header-354.md) | R208 | `header-354` | Hidden | (389, 717) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Canalave City](../locations/header-034.md) | C02FS0101 | `header-034` | Specialty | ₽300 | Always |
| [Veilstone Store](../locations/header-138.md) | C07R0202 | `header-138` | Specialty | ₽300 | Always |
| [Veilstone Store](../locations/header-138.md) | C07R0202 | `header-138` | Specialty | ₽300 | Always |
| [Veilstone Store](../locations/header-139.md) | C07R0203 | `header-139` | Specialty | ₽300 | Always |
| [Veilstone Store](../locations/header-139.md) | C07R0203 | `header-139` | Specialty | ₽300 | Always |
| [Sunyshore Market](../locations/header-157.md) | C08R0101 | `header-157` | Seal | ₽100 | Always |
| [Celestic Town](../locations/header-446.md) | T05R0201 | `header-446` | Specialty | ₽300 | Always |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `14` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `14`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/14/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../dusk-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dusk-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Dusk Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../quick-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Quick Ball →</span></a>
</nav>
