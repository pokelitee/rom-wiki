# Brick Mail

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/brick-mail.png" alt="Brick Mail icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>148</dd></div>
<div><dt>Pocket</dt><dd>Mail</dd></div>
<div><dt>Category</dt><dd>All Mail</dd></div>
<div><dt>Base price</dt><dd>₽50</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Lets a Trainer write a message and send it via Pokémon trade.</strong></p>
<p>Used to send short messages to other players via Pokémon trading. Trainer may compose a message from a finite list of words when giving this item to a Pokémon. Once taken and read, a message may be erased and this item can be reused, or the message may be stored in the trainer’s PC. Held : Holder cannot be placed in the PC. Any move attempting to remove this item from the holder will fail.</p>

<figure class="rw-pokedex-entry">
<blockquote>Stationery featuring a print of a tough-looking brick pattern. Let a Pokémon hold it for delivery.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Mail</dd></div>
<div><dt>Field pocket ID</dt><dd>5</dd></div>
<div><dt>Field use function ID</dt><dd>7</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Mt. Coronet](../locations/header-218.md) | D05R0112 | `header-218` | Visible | (2, 31) |
| [Route 230](../locations/header-471.md) | W230 | `header-471` | Hidden | (725, 427) |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `126` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `126`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/125/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../mosaic-mail/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/mosaic-mail.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Mosaic Mail</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../cheri-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cheri-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Cheri Berry →</span></a>
</nav>
