# Adamant Orb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/adamant-orb.png" alt="Adamant Orb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>135</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Species Specific</dd></div>
<div><dt>Base price</dt><dd>₽10,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">60</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Boosts the damage from Dialga’s Dragon-type and Steel-type moves by 20%.</strong></p>
<p>Held by Dialga : Holder’s Dragon- and Steel-type moves have 1.2× their usual power.</p>

<figure class="rw-pokedex-entry">
<blockquote>A brightly gleaming orb to be held by DIALGA. It boosts the power of Dragon-​ and Steel-type moves.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>3</dd></div>
<div><dt>Held effect parameter</dt><dd>20</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Iron Island](../locations/header-290.md) | Visible | (5, 6) |
| [Route 226](../locations/header-469.md) | Hidden | (715, 345) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `113` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `113`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/112/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../griseous-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/griseous-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Griseous Orb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../lustrous-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lustrous-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Lustrous Orb →</span></a>
</nav>
