# Burn Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/burn-heal.png" alt="Burn Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>19</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽250</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures a burn.</strong></p>
<p>Used on a party Pokémon : Cures a burn.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It heals a single Pokémon that is suffering from a burn.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures burn</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Eterna Forest](../locations/header-203.md) | Visible | (41, 59) |
| [Route 212](../locations/header-371.md) | Hidden | (493, 858) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Jubilife City](../locations/header-004.md) | Common | ₽250 | 1 badge |
| [Canalave City](../locations/header-034.md) | Common | ₽250 | 1 badge |
| [Oreburgh City](../locations/header-046.md) | Common | ₽250 | 1 badge |
| [Eterna City](../locations/header-066.md) | Common | ₽250 | 1 badge |
| [Hearthome City](../locations/header-087.md) | Common | ₽250 | 1 badge |
| [Pastoria City](../locations/header-121.md) | Common | ₽250 | 1 badge |
| [Veilstone Store](../locations/header-137.md) | Specialty | ₽250 | Always |
| [Sunyshore City](../locations/header-153.md) | Common | ₽250 | 1 badge |
| [Sunyshore Market](../locations/header-157.md) | Seal | ₽100 | Always |
| [Snowpoint City](../locations/header-166.md) | Common | ₽250 | 1 badge |
| [Pokémon League](../locations/header-173.md) | Common | ₽250 | 1 badge |
| [Pokémon League](../locations/header-175.md) | Common | ₽250 | 1 badge |
| [Fight Area](../locations/header-191.md) | Common | ₽250 | 1 badge |
| [Sandgem Town](../locations/header-419.md) | Common | ₽250 | 1 badge |
| [Floaroma Town](../locations/header-427.md) | Common | ₽250 | 1 badge |
| [Solaceon Town](../locations/header-434.md) | Common | ₽250 | 1 badge |
| [Celestic Town](../locations/header-446.md) | Common | ₽250 | 1 badge |
| [Celestic Town](../locations/header-446.md) | Common | ₽250 | 1 badge |
| [Survival Area](../locations/header-451.md) | Common | ₽250 | 1 badge |
| [Resort Area](../locations/header-458.md) | Common | ₽250 | 1 badge |
| [Veilstone Store](../locations/header-566.md) | Specialty | ₽250 | Always |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `19` |

Source: exact ROM record from `itemtool/itemdata/pl_item_data.narc` member `19`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
Item name source: ROM message table `msgdata/pl_msg.narc` member `392`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/19/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../antidote/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/antidote.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Antidote</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../ice-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ice-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Ice Heal →</span></a>
</nav>
