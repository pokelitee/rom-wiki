# Data downloads

These deterministic gzip files contain the complete normalized datasets used to build this wiki. They include ROM-derived facts and PokéDB reference data, but never ROM or patch bytes.

| Dataset | Download | Records | Schema |
| ------- | -------- | ------: | -----: |
| Abilities | [abilities.json.gz](abilities.json.gz) | 123 | 4 |
| Wild Encounters | [encounters.json.gz](encounters.json.gz) | 183 | 3 |
| Items | [items.json.gz](items.json.gz) | 445 | 8 |
| Locations | [locations.json.gz](locations.json.gz) | 593 | 11 |
| Moves | [moves.json.gz](moves.json.gz) | 471 | 1 |
| Pokemon | [pokemon.json.gz](pokemon.json.gz) | 508 | 2 |
| Trainers | [trainers.json.gz](trainers.json.gz) | 928 | 6 |
| Types | [types.json.gz](types.json.gz) | 17 | 2 |

File sizes and SHA-256 checksums are listed in [the machine-readable manifest](manifest.json).
