# Limber

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>7</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">4</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents paralysis.</strong></p>
<p>This Pokémon cannot be paralyzed. If a Pokémon is paralyzed and acquires this ability, its paralysis is healed; this includes when regaining a lost ability upon leaving battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected from paralysis.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/53.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Persian](../pokemon/persian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/106.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonlee](../pokemon/hitmonlee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/431.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glameow](../pokemon/glameow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/7/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../damp/"><span class="rw-record-nav__label">← Damp</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sand-veil/"><span class="rw-record-nav__label">Sand Veil →</span></a>
</nav>
