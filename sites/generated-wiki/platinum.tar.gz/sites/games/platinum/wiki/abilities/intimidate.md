# Intimidate

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>22</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">19</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Lowers opponents&#x27; Attack one stage upon entering battle.</strong></p>
<p>When this Pokémon enters battle, the opponent&#x27;s Attack is lowered by one stage. In a double battle, both opponents are affected. This ability also takes effect when acquired during a battle, but will not take effect again if lost and reobtained without leaving battle. This ability has no effect on an opponent that has a Substitute. Overworld: If the first Pokémon in the party has this ability, any random encounter with a Pokémon five or more levels lower than it has a 50% chance of being skipped.</p>

<figure class="rw-pokedex-entry">
<blockquote>Lowers the foe’s Attack stat.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/59.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arcanine](../pokemon/arcanine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/209.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snubbull](../pokemon/snubbull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/210.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Granbull](../pokemon/granbull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/237.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmontop](../pokemon/hitmontop.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/262.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mightyena](../pokemon/mightyena.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/284.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Masquerain](../pokemon/masquerain.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/303.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/373.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Salamence](../pokemon/salamence.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/398.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staraptor](../pokemon/staraptor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/404.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/405.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxray](../pokemon/luxray.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/22/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../suction-cups/"><span class="rw-record-nav__label">← Suction Cups</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../shadow-tag/"><span class="rw-record-nav__label">Shadow Tag →</span></a>
</nav>
