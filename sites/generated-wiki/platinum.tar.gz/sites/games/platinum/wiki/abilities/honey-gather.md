# Honey Gather

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>118</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>The Pokémon may pick up Honey after battle.</strong></p>
<p>This Pokémon has a chance of picking up Honey after each battle. This chance starts at 5% and rises another 5% after every tenth level: 5% from level 1–10, 10% from 11–20, and so on, up to 50% from 91–100. This ability is checked after the battle ends, at which point any temporary ability changes have worn off.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon may gather Honey from somewhere.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Honey generation chance

At the end of a battle, each Pokémon with Honey Gather has a chance to generate Honey, scaling with its level.

| Level | Chance |
| ----: | -----: |
| 1–10 | 5% |
| 11–20 | 10% |
| 21–30 | 15% |
| 31–40 | 20% |
| 41–50 | 25% |
| 51–60 | 30% |
| 61–70 | 35% |
| 71–80 | 40% |
| 81–90 | 45% |
| 91–100 | 50% |

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/118/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../snow-warning/"><span class="rw-record-nav__label">← Snow Warning</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../frisk/"><span class="rw-record-nav__label">Frisk →</span></a>
</nav>
