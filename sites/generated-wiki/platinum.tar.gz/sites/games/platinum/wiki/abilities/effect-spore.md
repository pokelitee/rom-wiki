# Effect Spore

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>27</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">4</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 30% chance of inflcting either paralysis, poison, or sleep on attacking Pokémon on contact.</strong></p>
<p>Whenever a move makes contact with this Pokémon, the move&#x27;s user has a 30% chance of being paralyzed, poisoned, or put to sleep, chosen at random. Nothing is done to compensate if the move&#x27;s user is immune to one of these ailments; there is simply a lower chance that the move&#x27;s user will be affected.</p>

<figure class="rw-pokedex-entry">
<blockquote>Contact may paralyze, poison, or cause sleep.</blockquote>
<figcaption>Platinum Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/46.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Paras](../pokemon/paras.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/285.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shroomish](../pokemon/shroomish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/platinum/286.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Breloom](../pokemon/breloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `msgdata/pl_msg.narc` member `610`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/27/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../levitate/"><span class="rw-record-nav__label">← Levitate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../synchronize/"><span class="rw-record-nav__label">Synchronize →</span></a>
</nav>
