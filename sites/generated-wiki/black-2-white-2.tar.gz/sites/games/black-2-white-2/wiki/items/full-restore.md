# Full Restore

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="Full Restore icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>23</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full and cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Restores HP to full and cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A medicine that fully restores the HP and heals any status problems of a single Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x0c</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Twist Mountain](../locations/header-201.md) | — | `header-201` | Hidden | (55, 60) |
| [Twist Mountain](../locations/header-202.md) | — | `header-202` | Visible | (58, 48) |
| [Nimbasa City](../locations/header-289.md) | — | `header-289` | Hidden | (406, 468) |
| [Route 1](../locations/header-317.md) | — | `header-317` | Visible | (759, 759) |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden | (697, 558) |
| [Seaside Cave](../locations/header-515.md) | — | `header-515` | Visible | (22, 51) |
| [Victory Road](../locations/header-589.md) | — | `header-589` | Visible | (41, 11) |
| [Victory Road](../locations/header-590.md) | — | `header-590` | Hidden | (58, 20) |
| [Victory Road](../locations/header-592.md) | — | `header-592` | Visible | (44, 37) |
| [Victory Road](../locations/header-595.md) | — | `header-595` | Visible | (41, 11) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [⒆⒇ Trainer N](../trainers/trainer-0005.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0006.md) | AI battle item |
| [Socialite Cassandra](../trainers/trainer-0036.md) | AI battle item |
| [Gentleman Robert](../trainers/trainer-0037.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0038.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0039.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0040.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0041.md) | AI battle item |
| [Socialite Emilia](../trainers/trainer-0103.md) | AI battle item |
| [Gentleman Renaud](../trainers/trainer-0104.md) | AI battle item |
| [GAME FREAK Morimoto](../trainers/trainer-0140.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0144.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0145.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0146.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0341.md) | AI battle item |
| [Team Plasma Colress](../trainers/trainer-0344.md) | AI battle item |
| [Team Plasma Ghetsis](../trainers/trainer-0345.md) | AI battle item |
| [⒆⒇ Trainer Cynthia](../trainers/trainer-0456.md) | AI battle item |
| [⒆⒇ Trainer Chili](../trainers/trainer-0494.md) | AI battle item |
| [⒆⒇ Trainer Cress](../trainers/trainer-0495.md) | AI battle item |
| [⒆⒇ Trainer Cilan](../trainers/trainer-0496.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0536.md) | AI battle item |
| [⒆⒇ Trainer Alder](../trainers/trainer-0582.md) | AI battle item |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | AI battle item |
| [Pokéfan Elliot](../trainers/trainer-0652.md) | AI battle item |
| [Pokéfan Lydia](../trainers/trainer-0653.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0693.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0694.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0695.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0696.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0697.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0698.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0706.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0707.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0708.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0709.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0710.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0711.md) | AI battle item |
| [Nurse Carol](../trainers/trainer-0725.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0772.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0773.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0774.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0775.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0776.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0777.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0778.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0779.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0780.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0781.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0782.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0783.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0784.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0785.md) | AI battle item |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | AI battle item |
| [Nurse Kirsten](../trainers/trainer-0119.md) | Victory reward |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `23` |

Source: exact ROM record from `a/0/2/4` member `23`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/23/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../parlyz-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/paralyze-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Parlyz Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Potion →</span></a>
</nav>
