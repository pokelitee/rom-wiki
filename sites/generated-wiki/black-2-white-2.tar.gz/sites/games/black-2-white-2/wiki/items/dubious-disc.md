# Dubious Disc

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dubious-disc.png" alt="Dubious Disc icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>324</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">50</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Traded on a Porygon2: Holder evolves into Porygon-Z.</strong></p>
<p>Held by Porygon2: Evolves the holder into Porygon-Z when traded.</p>

<figure class="rw-pokedex-entry">
<blockquote>A transparent device overflowing with dubious data. Its producer is unknown.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>145</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Plasma Frigate](../locations/header-552.md) | — | `header-552` | Visible | (18, 7) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | — | `header-005` | Black City market store 4 | ₽60,000 | Weekends |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/233.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon2](../pokemon/porygon2.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/474.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon-Z](../pokemon/porygon-z.md)</span> | Trade Held Item |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `324` |

Source: exact ROM record from `a/0/2/4` member `324`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/301/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../magmarizer/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/magmarizer.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Magmarizer</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../reaper-cloth/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/reaper-cloth.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Reaper Cloth →</span></a>
</nav>
