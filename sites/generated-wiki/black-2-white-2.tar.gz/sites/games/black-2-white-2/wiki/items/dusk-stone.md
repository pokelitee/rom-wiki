# Dusk Stone

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dusk-stone.png" alt="Dusk Stone icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>108</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">80</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Evolves a Lampent into Chandelure, a Misdreavus into Mismagius, or a Murkrow into Honchkrow.</strong></p>
<p>Used on a party Pokémon : Evolves a Lampent into Chandelure, a Misdreavus into Mismagius, or a Murkrow into Honchkrow.</p>

<figure class="rw-pokedex-entry">
<blockquote>A peculiar stone that makes certain species of Pokémon evolve. It is as dark as dark can be.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Celestial Tower](../locations/header-339.md) | map_339 | `header-339` | Hidden | (21, 22) |
| [Strange House](../locations/header-510.md) | map_510 | `header-510` | Visible | (8, 16) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | map_5 | `header-005` | Black City market store 3 | ₽40,000 | Weekdays |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/198.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/430.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Honchkrow](../pokemon/honchkrow.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/200.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Misdreavus](../pokemon/misdreavus.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/429.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mismagius](../pokemon/mismagius.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/608.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lampent](../pokemon/lampent.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/609.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chandelure](../pokemon/chandelure.md)</span> | Use Item |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `108` |

Source: exact ROM record from `a/0/2/4` member `108`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/108/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../shiny-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/shiny-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Shiny Stone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../dawn-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dawn-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Dawn Stone →</span></a>
</nav>
