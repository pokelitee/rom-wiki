# Earth Plate

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/earth-plate.png" alt="Earth Plate icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>305</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Plates</dd></div>
<div><dt>Base price</dt><dd>₽1,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">90</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Ground-Type moves from holder do 20% more damage. Changes Arceus’s and Judgment’s type to Ground.</strong></p>
<p>Held: Increases the power of the holder’s Ground moves by 20%. Held by a Multitype Pokémon: Holder’s type becomes Ground.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a stone tablet that boosts the power of Ground-type moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>133</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Route 23](../locations/header-475.md) | map_475 | `header-475` | Visible | (796, 633) |
| [Pokéstar Studios](../locations/header-574.md) | map_574 | `header-574` | Visible | (796, 633) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `305` |

Source: exact ROM record from `a/0/2/4` member `305`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/282/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../toxic-plate/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/toxic-plate.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Toxic Plate</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sky-plate/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/sky-plate.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Sky Plate →</span></a>
</nav>
