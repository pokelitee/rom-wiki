# Expert Belt

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/expert-belt.png" alt="Expert Belt icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>268</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s Super Effective moves do 20% extra damage.</strong></p>
<p>Held: When the holder hits with a super-effective move, its power is raised by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a well-worn belt that slightly boosts the power of supereffective moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>96</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Twist Mountain — map_203](../locations/header-203.md) | Visible | (587, 618) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Boss Trainer Brent](../trainers/trainer-0185.md) | Held by Audino |
| [Elite Four Shauntal](../trainers/trainer-0772.md) | Held by Golurk |
| [Elite Four Grimsley](../trainers/trainer-0773.md) | Held by Krookodile |
| [Elite Four Marshal](../trainers/trainer-0774.md) | Held by Mienshao |
| [Elite Four Caitlin](../trainers/trainer-0775.md) | Held by Sigilyph |
| [Elite Four Shauntal](../trainers/trainer-0777.md) | Held by Gengar |
| [Elite Four Marshal](../trainers/trainer-0779.md) | Held by Machamp |
| [Elite Four Caitlin](../trainers/trainer-0780.md) | Held by Alakazam |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `268` |

Source: exact ROM record from `a/0/2/4` member `268`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/245/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../wise-glasses/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wise-glasses.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Wise Glasses</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Light Clay →</span></a>
</nav>
