# Carbos

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="Carbos icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>48</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Speed effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Speed effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Speed stat of a single Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Speed EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Chargestone Cave](../locations/header-195.md) | — | `header-195` | Visible | (51, 51) |
| [Chargestone Cave](../locations/header-196.md) | — | `header-196` | Hidden | (42, 40) |
| [Dragonspiral Tower](../locations/header-210.md) | — | `header-210` | Visible | (23, 7) |
| [Dragonspiral Tower](../locations/header-211.md) | — | `header-211` | Visible | (45, 1) |
| [Village Bridge](../locations/header-255.md) | — | `header-255` | Visible | (84, 8) |
| [Wellspring Cave](../locations/header-325.md) | — | `header-325` | Hidden | (22, 5) |
| [Humilau City](../locations/header-465.md) | — | `header-465` | Visible | (797, 136) |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden | (738, 146) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 1 BP | Main game |
| [PWT](../locations/header-192.md) | — | `header-192` | Battle Point item exchange | 1 BP | Main game |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F3 Left | ₽9,800 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Striker Marco](../trainers/trainer-0058.md) | Victory reward |
| [Striker Tony](../trainers/trainer-0061.md) | Victory reward |
| [Striker Roberto](../trainers/trainer-0062.md) | Victory reward |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `48` |

Source: exact ROM record from `a/0/2/4` member `48`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/48/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../iron/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iron.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Iron</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../calcium/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/calcium.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Calcium →</span></a>
</nav>
