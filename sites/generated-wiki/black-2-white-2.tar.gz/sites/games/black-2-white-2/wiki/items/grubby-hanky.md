# Grubby Hanky

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grubby-hanky.png" alt="Grubby Hanky icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>634</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Plot Advancement</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>No</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Appears in the Café Warehouse on Sunday; return to the customer with a Patrat on Thursday.</strong></p>

<figure class="rw-pokedex-entry">
<blockquote>A handkerchief dropped by a regular at Café Warehouse. It smells faintly like a Pokémon.</blockquote>
<figcaption>Black 2 White 2 Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `634` |

Source: exact ROM record from `a/0/2/4` member `634`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/677/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../plasma-card/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/plasma-card.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Plasma Card</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../colress-mchn/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/colress-machine.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Colress MCHN →</span></a>
</nav>
