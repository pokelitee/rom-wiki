# Absorb Bulb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/absorb-bulb.png" alt="Absorb Bulb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>545</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Raises the holder’s Special Attack by one stage when it takes Water-type damage.</strong></p>
<p>Held : When the holder takes Water-type damage from a move, its Special Attack rises by one stage and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A consumable bulb. If the holder is hit by a Water-type move, its Sp. Atk will rise.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | map_67 | `header-067` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-068.md) | map_68 | `header-068` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-069.md) | map_69 | `header-069` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-070.md) | map_70 | `header-070` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-071.md) | map_71 | `header-071` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-072.md) | map_72 | `header-072` | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-073.md) | map_73 | `header-073` | Battle Point item exchange | 16 BP | Main game |
| [PWT](../locations/header-192.md) | map_192 | `header-192` | Battle Point item exchange | 16 BP | Main game |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/315.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roselia](../pokemon/roselia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | Dark_Grass |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/407.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roserade](../pokemon/roserade.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | Dark_Grass |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `545` |

Source: exact ROM record from `a/0/2/4` member `545`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/588/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../binding-band/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/binding-band.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Binding Band</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../cell-battery/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cell-battery.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Cell Battery →</span></a>
</nav>
