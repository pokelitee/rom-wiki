# Speed Boost

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>3</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">8</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Raises Speed one stage after each turn.</strong></p>
<p>This Pokémon&#x27;s Speed rises one stage after each turn.</p>

<figure class="rw-pokedex-entry">
<blockquote>Its Speed stat is gradually boosted.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/193.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yanma](../pokemon/yanma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/255.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torchic](../pokemon/torchic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/256.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combusken](../pokemon/combusken.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/257.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blaziken](../pokemon/blaziken.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/291.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ninjask](../pokemon/ninjask.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/318.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carvanha](../pokemon/carvanha.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/319.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sharpedo](../pokemon/sharpedo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/469.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yanmega](../pokemon/yanmega.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/3/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../drizzle/"><span class="rw-record-nav__label">← Drizzle</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../battle-armor/"><span class="rw-record-nav__label">Battle Armor →</span></a>
</nav>
