# Inner Focus

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>39</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">26</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents flinching.</strong></p>
<p>This Pokémon cannot flinch.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected from flinching.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/96.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drowzee](../pokemon/drowzee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/97.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hypno](../pokemon/hypno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/107.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonchan](../pokemon/hitmonchan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/115.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/169.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crobat](../pokemon/crobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/197.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Umbreon](../pokemon/umbreon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/361.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/447.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Riolu](../pokemon/riolu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/448.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lucario](../pokemon/lucario.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--steel">Steel</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/554.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Darumaka](../pokemon/darumaka.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/619.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienfoo](../pokemon/mienfoo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/620.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienshao](../pokemon/mienshao.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/624.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pawniard](../pokemon/pawniard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--steel">Steel</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/625.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bisharp](../pokemon/bisharp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--steel">Steel</span></span> | 2 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/39/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../poison-point/"><span class="rw-record-nav__label">← Poison Point</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../magma-armor/"><span class="rw-record-nav__label">Magma Armor →</span></a>
</nav>
