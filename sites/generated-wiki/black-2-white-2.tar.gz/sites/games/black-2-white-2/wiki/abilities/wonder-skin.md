# Wonder Skin

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>147</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">4</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Lowers incoming non-damaging moves&#x27; base accuracy to exactly 50%.</strong></p>
<p>Non-damaging moves have exactly 50% base accuracy against this Pokémon.</p>

<figure class="rw-pokedex-entry">
<blockquote>Makes status-changing moves more likely to miss.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/49.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/300.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/301.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delcatty](../pokemon/delcatty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/561.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sigilyph](../pokemon/sigilyph.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/147/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sand-rush/"><span class="rw-record-nav__label">← Sand Rush</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../analytic/"><span class="rw-record-nav__label">Analytic →</span></a>
</nav>
