# Multitype

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>121</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Changes Arceus&#x27;s type and form to match its held Plate.</strong></p>
<p>If this Pokémon is holding an elemental Plate, its type and form change to match the Plate. This Pokémon&#x27;s held item, whether or not it is a Plate, cannot be taken by Covet or Thief, nor removed by Knock Off, nor traded by Switcheroo or Trick. Covet, Thief, and Knock Off still inflict damage against this Pokémon. Unlike with Sticky Hold, this Pokémon cannot use Fling, Switcheroo, or Trick to lose its item itself, nor gain an item through Switcheroo or Trick if it does not have one. This ability has no effect for any Pokémon other than Arceus. This ability cannot be traded with Skill Swap, nor copied with Role Play or Trace, nor disabled with Gastro Acid, nor changed with Worry Seed. This Pokémon cannot use Skill Swap or Role Play to lose its ability itself. Mold Breaker cannot ignore this ability. If a Pokémon Transforms into an Arceus with this ability, it will Transform into Arceus&#x27;s default, Normal-type form. If the Transforming Pokémon is holding a Plate, this ability will then activate and change the Pokémon into the corresponding form.</p>

<figure class="rw-pokedex-entry">
<blockquote>Changes type to match the held Plate.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/493.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arceus](../pokemon/arceus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/121/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../reckless/"><span class="rw-record-nav__label">← Reckless</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../flower-gift/"><span class="rw-record-nav__label">Flower Gift →</span></a>
</nav>
