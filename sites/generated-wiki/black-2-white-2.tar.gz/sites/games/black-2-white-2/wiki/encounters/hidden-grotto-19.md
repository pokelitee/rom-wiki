# Hidden Grotto 19 — Route 18 { #hidden-grotto-19 }

The ROM chooses one of four groups independently from the listed pool. Pool chance and group chance are kept separate.

## Pokémon

| Pokémon | Type | Levels | Female | Pool | Group |
| ------- | ---- | -----: | -----: | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 10% | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 10% | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 10% | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 10% | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/441.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chatot](../pokemon/chatot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 30% | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/441.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chatot](../pokemon/chatot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 30% | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/441.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chatot](../pokemon/chatot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 30% | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/441.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chatot](../pokemon/chatot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55–60 | 30% | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 55–60 | 30% | 15% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 55–60 | 30% | 15% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 55–60 | 60% | 15% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 55–60 | 60% | 15% | D |

## Visible items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fire Stone](../items/fire-stone.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Water Stone](../items/water-stone.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Thunderstone](../items/thunder-stone.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leaf-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leaf Stone](../items/leaf-stone.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Max Repel](../items/max-repel.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hyper Potion](../items/hyper-potion.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Repel](../items/super-repel.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Potion](../items/super-potion.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Repel](../items/repel.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Potion](../items/potion.md)</span> | 25% | D |

## Hidden items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rare Candy](../items/rare-candy.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-max.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Max](../items/pp-max.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Red Shard](../items/red-shard.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blue Shard](../items/blue-shard.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yellow Shard](../items/yellow-shard.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Green Shard](../items/green-shard.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Big Mushroom](../items/big-mushroom.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/growth-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growth Mulch](../items/growth-mulch.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Damp Mulch](../items/damp-mulch.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/stable-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stable Mulch](../items/stable-mulch.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gooey-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gooey Mulch](../items/gooey-mulch.md)</span> | 25% | D |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 18](../locations/header-387.md) | `header-387` | `map_387` |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/7/3` member `19`.
Hidden Grotto Pokémon, levels, gender percentages, forms, and item IDs come from the Grotto record.
The exterior-map relationship comes from its ROM furniture dispatch ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hidden-grotto-18/"><span class="rw-record-nav__label">← Hidden Grotto 18 — Route 2</span></a>
<span></span>
</nav>
