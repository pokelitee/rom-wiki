# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/317.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swalot](../pokemon/swalot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 40–55 |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 9](../locations/header-348.md) | `header-348` | `map_348` |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C1C`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-321/"><span class="rw-record-nav__label">← Daily Swarm — Route 3</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-158/"><span class="rw-record-nav__label">Daily Swarm — Desert Resort →</span></a>
</nav>
