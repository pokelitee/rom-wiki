# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 8](../locations/header-345.md) | `header-345` | `map_345` |

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40–55 |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C44`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-368/"><span class="rw-record-nav__label">← Daily Swarm — Route 12</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-365/"><span class="rw-record-nav__label">Daily Swarm — Route 11 →</span></a>
</nav>
