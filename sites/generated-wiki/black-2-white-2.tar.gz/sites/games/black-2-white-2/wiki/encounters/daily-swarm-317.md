# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–55 |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 1](../locations/header-317.md) | `header-317` | `map_317` |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50BFC`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<span></span>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-152/"><span class="rw-record-nav__label">Daily Swarm — Dreamyard →</span></a>
</nav>
