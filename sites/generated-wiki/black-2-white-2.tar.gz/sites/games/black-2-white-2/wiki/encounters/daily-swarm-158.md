# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 40–55 |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Desert Resort](../locations/header-158.md) | `header-158` | `map_158` |

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C24`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-348/"><span class="rw-record-nav__label">← Daily Swarm — Route 9</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-329/"><span class="rw-record-nav__label">Daily Swarm — Route 5 →</span></a>
</nav>
