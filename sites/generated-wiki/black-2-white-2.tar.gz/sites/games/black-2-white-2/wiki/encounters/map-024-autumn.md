# Twist Mountain

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>32</dd></div>
<div><dt>Map index</dt><dd>24</dd></div>
<div><dt>Season</dt><dd>Autumn</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Twist Mountain](../locations/header-201.md) | 201 | Black 2 / White 2 |

## Grass/Cave

Encounter rate: 7

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 54 (20%); 55 (20%) | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/533.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gurdurr](../pokemon/gurdurr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/527.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Woobat](../pokemon/woobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 54 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 56 (10%); 57 (5%) | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 56 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/631.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heatmor](../pokemon/heatmor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 56 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/615.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cryogonal](../pokemon/cryogonal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/95.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Onix](../pokemon/onix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 57 | 5% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 54 (20%); 55 (20%); 56 (20%); 57 (15%) | 75% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/95.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Onix](../pokemon/onix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 54 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 57 | 5% |

## Seasonal variants

These encounter records use the same verified wild-encounter map index.

| Season | Encounter table |
| ------ | --------------- |
| Spring | [Spring](map-024-spring.md) |
| Summer | [Summer](map-024-summer.md) |
| Winter | [Winter](map-024-winter.md) |

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `24`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-024-summer/"><span class="rw-record-nav__label">← Map 024 (Summer)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-024-winter/"><span class="rw-record-nav__label">Map 024 (Winter) →</span></a>
</nav>
