# Moor of Icirrus

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>150</dd></div>
<div><dt>Map index</dt><dd>117</dd></div>
<div><dt>Season</dt><dd>Spring</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Moor of Icirrus](../locations/header-346.md) | 346 | Blaze Black 2 Redux / Volt White 2 Redux |

## Grass/Cave

Encounter rate: 12

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/536.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Palpitoad](../pokemon/palpitoad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 64 (20%); 65 (20%) | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/588.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Karrablast](../pokemon/karrablast.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 63 (10%); 64 (5%) | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/616.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shelmet](../pokemon/shelmet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 63 (10%); 64 (5%) | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/454.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Toxicroak](../pokemon/toxicroak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 65 (4%); 66 (1%) | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 65 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 66 | 1% |

## Surfing

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 50 (60%); 55–65 (36%) | 96% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 55–65 | 4% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 60–70 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 60–70 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/537.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seismitoad](../pokemon/seismitoad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 60–70 | 5% |

## Fishing

Encounter rate: 255

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 35–55 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 45–55 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 55–65 | 10% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–65 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 60–70 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 60–70 | 10% |

## Seasonal variants

These encounter records use the same verified wild-encounter map index.

| Season | Encounter table |
| ------ | --------------- |
| Summer | [Summer](map-117-summer.md) |
| Autumn | [Autumn](map-117-autumn.md) |
| Winter | [Winter](map-117-winter.md) |

## Hack changes

### Blaze Black 2 Redux

Compared with **black-2-us**.

<details markdown="1">
<summary>5 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Palpitoad — Lv. 57</li><li>Karrablast — Lv. 57</li><li>Croagunk — Lv. 55</li><li>Palpitoad — Lv. 55</li><li>Stunfisk — Lv. 55</li><li>Stunfisk — Lv. 56</li><li>Palpitoad — Lv. 54</li><li>Shelmet — Lv. 54</li><li>Palpitoad — Lv. 57</li><li>Karrablast — Lv. 57</li><li>Croagunk — Lv. 56</li><li>Palpitoad — Lv. 56</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Toxicroak — Lv. 66</li><li>Gastrodon — Lv. 66</li><li>Karrablast — Lv. 63</li><li>Shelmet — Lv. 63</li><li>Quagsire — Lv. 66</li><li>Stunfisk — Lv. 66</li><li>Palpitoad — Lv. 64</li><li>Palpitoad — Lv. 65</li><li>Gastrodon — Lv. 65</li><li>Toxicroak — Lv. 65</li><li>Karrablast — Lv. 64</li><li>Shelmet — Lv. 64</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Stunfisk — Lv. 55–65</li><li>Stunfisk — Lv. 55–65</li><li>Gastrodon — Lv. 55–65</li><li>Stunfisk — Lv. 55–65</li><li>Stunfisk — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seismitoad — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Seismitoad — Lv. 60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seismitoad — Lv. 60–70</li><li>Gastrodon — Lv. 60–70</li><li>Seismitoad — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Barboach — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Barboach — Lv. 60</li><li>Barboach — Lv. 60</li><li>Barboach — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 55–65</li><li>Stunfisk — Lv. 45–55</li><li>Whiscash — Lv. 55–65</li><li>Whiscash — Lv. 55–65</li><li>Barboach — Lv. 35–55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Whiscash — Lv. 60</li><li>Whiscash — Lv. 60</li><li>Barboach — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li><li>Whiscash — Lv. 60–70</li><li>Whiscash — Lv. 60–70</li><li>Barboach — Lv. 45–65</li></ul></li></ul></div>
</section>
</div>

</details>

### Volt White 2 Redux

Compared with **white-2-us**.

<details markdown="1">
<summary>5 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Palpitoad — Lv. 57</li><li>Shelmet — Lv. 57</li><li>Croagunk — Lv. 55</li><li>Palpitoad — Lv. 55</li><li>Stunfisk — Lv. 55</li><li>Stunfisk — Lv. 56</li><li>Palpitoad — Lv. 54</li><li>Karrablast — Lv. 54</li><li>Palpitoad — Lv. 57</li><li>Shelmet — Lv. 57</li><li>Croagunk — Lv. 56</li><li>Palpitoad — Lv. 56</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Toxicroak — Lv. 66</li><li>Gastrodon — Lv. 66</li><li>Karrablast — Lv. 63</li><li>Shelmet — Lv. 63</li><li>Quagsire — Lv. 66</li><li>Stunfisk — Lv. 66</li><li>Palpitoad — Lv. 64</li><li>Palpitoad — Lv. 65</li><li>Gastrodon — Lv. 65</li><li>Toxicroak — Lv. 65</li><li>Karrablast — Lv. 64</li><li>Shelmet — Lv. 64</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Stunfisk — Lv. 55–65</li><li>Stunfisk — Lv. 55–65</li><li>Gastrodon — Lv. 55–65</li><li>Stunfisk — Lv. 55–65</li><li>Stunfisk — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seismitoad — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Seismitoad — Lv. 60</li><li>Stunfisk — Lv. 60</li><li>Stunfisk — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seismitoad — Lv. 60–70</li><li>Gastrodon — Lv. 60–70</li><li>Seismitoad — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 50<span class="rw-diff-arrow">→</span>255</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Barboach — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Barboach — Lv. 60</li><li>Barboach — Lv. 60</li><li>Barboach — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 55–65</li><li>Stunfisk — Lv. 45–55</li><li>Whiscash — Lv. 55–65</li><li>Whiscash — Lv. 55–65</li><li>Barboach — Lv. 35–55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 60</li><li>Stunfisk — Lv. 45–60</li><li>Whiscash — Lv. 60</li><li>Whiscash — Lv. 60</li><li>Barboach — Lv. 45–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 60–70</li><li>Stunfisk — Lv. 60–70</li><li>Whiscash — Lv. 60–70</li><li>Whiscash — Lv. 60–70</li><li>Barboach — Lv. 45–65</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `117`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-116-winter/"><span class="rw-record-nav__label">← Map 116 (Winter)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-117-summer/"><span class="rw-record-nav__label">Map 117 (Summer) →</span></a>
</nav>
