# Hidden Grotto 06 — Route 13 { #hidden-grotto-06 }

The ROM chooses one of four groups independently from the listed pool. Pool chance and group chance are kept separate.

## Pokémon

| Pokémon | Type | Levels | Female | Pool | Group |
| ------- | ---- | -----: | -----: | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/120.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staryu](../pokemon/staryu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 50% | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/258.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mudkip](../pokemon/mudkip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 50% | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/120.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staryu](../pokemon/staryu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 50% | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/393.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piplup](../pokemon/piplup.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 50% | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–45 | 50% | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/276.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Taillow](../pokemon/taillow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–45 | 50% | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 40–45 | 50% | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/278.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wingull](../pokemon/wingull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–45 | 50% | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–45 | 50% | 15% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40–45 | 50% | 15% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 40–45 | 50% | 15% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 40–45 | 50% | 15% | D |

## Visible items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fire Stone](../items/fire-stone.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Water Stone](../items/water-stone.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Thunder Stone](../items/thunder-stone.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leaf-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leaf Stone](../items/leaf-stone.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Max Repel](../items/max-repel.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hyper Potion](../items/hyper-potion.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Repel](../items/super-repel.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Potion](../items/super-potion.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Repel](../items/repel.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Potion](../items/potion.md)</span> | 25% | D |

## Hidden items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rare Candy](../items/rare-candy.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-max.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Max](../items/pp-max.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Red Shard](../items/red-shard.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blue Shard](../items/blue-shard.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yellow Shard](../items/yellow-shard.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Green Shard](../items/green-shard.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Big Mushroom](../items/big-mushroom.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/growth-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growth Mulch](../items/growth-mulch.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Damp Mulch](../items/damp-mulch.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/stable-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stable Mulch](../items/stable-mulch.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gooey-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gooey Mulch](../items/gooey-mulch.md)</span> | 25% | D |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 13](../locations/header-370.md) | `header-370` | `map_370` |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 35–40</li><li><a href="../../pokemon/skorupi/">Skorupi</a> — Lv. 35–40</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 35–40</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 35–40</li><li><a href="../../pokemon/skorupi/">Skorupi</a> — Lv. 35–40</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 35–40</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 35–40</li><li><a href="../../pokemon/skorupi/">Skorupi</a> — Lv. 35–40</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 35–40</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 35–40</li><li><a href="../../pokemon/skorupi/">Skorupi</a> — Lv. 35–40</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 35–40</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 40–45</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 40–45</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 40–45</li><li><a href="../../pokemon/mudkip/">Mudkip</a> — Lv. 40–45</li><li><a href="../../pokemon/zigzagoon/">Zigzagoon</a> — Lv. 40–45</li><li><a href="../../pokemon/taillow/">Taillow</a> — Lv. 40–45</li><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 40–45</li><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 40–45</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 40–45</li><li><a href="../../pokemon/wingull/">Wingull</a> — Lv. 40–45</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 40–45</li><li><a href="../../pokemon/piplup/">Piplup</a> — Lv. 40–45</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/7/3` member `6`.
Hidden Grotto Pokémon, levels, gender percentages, forms, and item IDs come from the Grotto record.
The exterior-map relationship comes from its ROM furniture dispatch ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hidden-grotto-05/"><span class="rw-record-nav__label">← Hidden Grotto 05 — Route 7</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../hidden-grotto-07/"><span class="rw-record-nav__label">Hidden Grotto 07 — Route 13 →</span></a>
</nav>
