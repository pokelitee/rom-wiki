# Hidden Grotto 02 — Lostlorn Forest { #hidden-grotto-02 }

The ROM chooses one of four groups independently from the listed pool. Pool chance and group chance are kept separate.

## Pokémon

| Pokémon | Type | Levels | Female | Pool | Group |
| ------- | ---- | -----: | -----: | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 24–29 | 50% | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/1.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bulbasaur](../pokemon/bulbasaur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 24–29 | 50% | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 24–29 | 50% | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/252.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Treecko](../pokemon/treecko.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 24–29 | 50% | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 24–29 | 50% | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 24–29 | 50% | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 24–29 | 50% | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/511.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pansage](../pokemon/pansage.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 24–29 | 50% | 15% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/513.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pansear](../pokemon/pansear.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 24–29 | 50% | 15% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/515.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Panpour](../pokemon/panpour.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 15% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/412.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 24–29 | 50% | 15% | D |

## Visible items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fire Stone](../items/fire-stone.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Water Stone](../items/water-stone.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Thunder Stone](../items/thunder-stone.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leaf-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leaf Stone](../items/leaf-stone.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Max Repel](../items/max-repel.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hyper Potion](../items/hyper-potion.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Repel](../items/super-repel.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Potion](../items/super-potion.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Repel](../items/repel.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Potion](../items/potion.md)</span> | 25% | D |

## Hidden items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rare Candy](../items/rare-candy.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-max.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Max](../items/pp-max.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Red Shard](../items/red-shard.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blue Shard](../items/blue-shard.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yellow Shard](../items/yellow-shard.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Green Shard](../items/green-shard.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Big Mushroom](../items/big-mushroom.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tiny Mushroom](../items/tiny-mushroom.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/growth-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growth Mulch](../items/growth-mulch.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Damp Mulch](../items/damp-mulch.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/stable-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stable Mulch](../items/stable-mulch.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gooey-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gooey Mulch](../items/gooey-mulch.md)</span> | 25% | D |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Lostlorn Forest](../locations/header-385.md) | `header-385` | `map_385` |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

=== "Blaze Black 2 Redux"

    Compared with **black-2-us**.

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Pokémon</p>
    <div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 24–29</li><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 24–29</li><li><a href="../../pokemon/pansage/">Pansage</a> — Lv. 24–29</li><li><a href="../../pokemon/bulbasaur/">Bulbasaur</a> — Lv. 24–29</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 24–29</li><li><a href="../../pokemon/pansear/">Pansear</a> — Lv. 24–29</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 24–29</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 24–29</li><li><a href="../../pokemon/panpour/">Panpour</a> — Lv. 24–29</li><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 24–29</li><li><a href="../../pokemon/treecko/">Treecko</a> — Lv. 24–29</li><li><a href="../../pokemon/burmy/">Burmy</a> — Lv. 24–29</li></ul></div>
    </section>
    </div>

=== "Volt White 2 Redux"

    Compared with **white-2-us**.

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Pokémon</p>
    <div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 20–25</li><li><a href="../../pokemon/leavanny/">Leavanny</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 20–25</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 24–29</li><li><a href="../../pokemon/heracross/">Heracross</a> — Lv. 24–29</li><li><a href="../../pokemon/pansage/">Pansage</a> — Lv. 24–29</li><li><a href="../../pokemon/bulbasaur/">Bulbasaur</a> — Lv. 24–29</li><li><a href="../../pokemon/pinsir/">Pinsir</a> — Lv. 24–29</li><li><a href="../../pokemon/pansear/">Pansear</a> — Lv. 24–29</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 24–29</li><li><a href="../../pokemon/scyther/">Scyther</a> — Lv. 24–29</li><li><a href="../../pokemon/panpour/">Panpour</a> — Lv. 24–29</li><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 24–29</li><li><a href="../../pokemon/treecko/">Treecko</a> — Lv. 24–29</li><li><a href="../../pokemon/burmy/">Burmy</a> — Lv. 24–29</li></ul></div>
    </section>
    </div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/7/3` member `2`.
Hidden Grotto Pokémon, levels, gender percentages, forms, and item IDs come from the Grotto record.
The exterior-map relationship comes from its ROM furniture dispatch ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hidden-grotto-01/"><span class="rw-record-nav__label">← Hidden Grotto 01 — Route 5</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../hidden-grotto-03/"><span class="rw-record-nav__label">Hidden Grotto 03 — Route 6 →</span></a>
</nav>
