# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

=== "Blaze Black 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 40–55 |

=== "Volt White 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 40–55 |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 6](../locations/header-331.md) | `header-331` | `map_331` |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C00`.
Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C0C`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-152/"><span class="rw-record-nav__label">← Daily Swarm — Dreamyard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-321/"><span class="rw-record-nav__label">Daily Swarm — Route 3 →</span></a>
</nav>
