# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City](map-000.md)
- [Map 001](map-001.md)
- [Icirrus City](map-002-spring.md)
- [Icirrus City](map-002-summer.md)
- [Icirrus City](map-002-autumn.md)
- [Icirrus City](map-002-winter.md)
- [Aspertia City](map-003.md)
- [Virbank City](map-004.md)
- [Map 005](map-005.md)
- [Map 006](map-006.md)
- [Dreamyard](map-007.md)
- [Map 008](map-008.md)
- [Map 009](map-009.md)
- [Map 010](map-010.md)
- [Map 011](map-011.md)
- [Map 012](map-012.md)
- [Map 013](map-013.md)
- [Map 014](map-014.md)
- [Map 015](map-015.md)
- [Map 016](map-016.md)
- [Map 017](map-017.md)
- [Map 018](map-018.md)
- [Map 019](map-019.md)
- [Map 020](map-020.md)
- [Map 021](map-021.md)
- [Map 022](map-022.md)
- [Map 023 (Spring)](map-023-spring.md)
- [Map 023 (Summer)](map-023-summer.md)
- [Map 023 (Autumn)](map-023-autumn.md)
- [Map 023 (Winter)](map-023-winter.md)
- [Map 024 (Spring)](map-024-spring.md)
- [Map 024 (Summer)](map-024-summer.md)
- [Map 024 (Autumn)](map-024-autumn.md)
- [Map 024 (Winter)](map-024-winter.md)
- [Map 025 (Spring)](map-025-spring.md)
- [Map 025 (Summer)](map-025-summer.md)
- [Map 025 (Autumn)](map-025-autumn.md)
- [Map 025 (Winter)](map-025-winter.md)
- [Map 026 (Spring)](map-026-spring.md)
- [Map 026 (Summer)](map-026-summer.md)
- [Map 026 (Autumn)](map-026-autumn.md)
- [Map 026 (Winter)](map-026-winter.md)
- [Map 027 (Spring)](map-027-spring.md)
- [Map 027 (Summer)](map-027-summer.md)
- [Map 027 (Autumn)](map-027-autumn.md)
- [Map 027 (Winter)](map-027-winter.md)
- [Map 028 (Spring)](map-028-spring.md)
- [Map 028 (Summer)](map-028-summer.md)
- [Map 028 (Autumn)](map-028-autumn.md)
- [Map 028 (Winter)](map-028-winter.md)
- [Map 029](map-029.md)
- [Map 030](map-030.md)
- [Map 031](map-031.md)
- [Map 032](map-032.md)
- [Map 033](map-033.md)
- [Map 034](map-034.md)
- [Map 035](map-035.md)
- [Map 036](map-036.md)
- [Castelia Sewers](map-037.md)
- [Map 038](map-038.md)
- [Map 039](map-039.md)
- [Map 040](map-040.md)
- [Map 041](map-041.md)
- [Map 042](map-042.md)
- [Map 043 (Spring)](map-043-spring.md)
- [Map 043 (Summer)](map-043-summer.md)
- [Map 043 (Autumn)](map-043-autumn.md)
- [Map 043 (Winter)](map-043-winter.md)
- [Map 044](map-044.md)
- [Map 045](map-045.md)
- [Map 046](map-046.md)
- [Map 047](map-047.md)
- [Map 048](map-048.md)
- [Map 049](map-049.md)
- [Map 050](map-050.md)
- [Map 051](map-051.md)
- [Map 052](map-052.md)
- [Map 053](map-053.md)
- [Map 054](map-054.md)
- [Map 055](map-055.md)
- [Map 056](map-056.md)
- [Map 057](map-057.md)
- [Map 058](map-058.md)
- [Map 059](map-059.md)
- [Map 060](map-060.md)
- [Map 061](map-061.md)
- [Map 062](map-062.md)
- [Map 063](map-063.md)
- [Map 064](map-064.md)
- [Map 065](map-065.md)
- [Map 066](map-066.md)
- [Strange House](map-067.md)
- [Map 068](map-068.md)
- [Map 069](map-069.md)
- [Strange House](map-070.md)
- [Map 071](map-071.md)
- [Map 072](map-072.md)
- [Map 073](map-073.md)
- [Map 074](map-074.md)
- [Map 075](map-075.md)
- [Map 076](map-076.md)
- [Map 077](map-077.md)
- [Map 078](map-078.md)
- [Map 079](map-079.md)
- [Map 080](map-080.md)
- [Map 081](map-081.md)
- [Map 082](map-082.md)
- [Map 083](map-083.md)
- [Map 084](map-084.md)
- [Map 085](map-085.md)
- [Map 086](map-086.md)
- [Map 087](map-087.md)
- [Map 088](map-088.md)
- [Map 089](map-089.md)
- [Map 090](map-090.md)
- [Map 091](map-091.md)
- [Map 092](map-092.md)
- [Map 093](map-093.md)
- [Map 094](map-094.md)
- [Map 095](map-095.md)
- [Driftveil Drawbridge](map-096.md)
- [Village Bridge](map-097.md)
- [Marvelous Bridge](map-098.md)
- [Map 099](map-099.md)
- [Map 100](map-100.md)
- [Map 101](map-101.md)
- [Map 102](map-102.md)
- [Map 103](map-103.md)
- [Map 104](map-104.md)
- [Map 105](map-105.md)
- [Map 106](map-106.md)
- [Map 107 (Spring)](map-107-spring.md)
- [Map 107 (Summer)](map-107-summer.md)
- [Map 107 (Autumn)](map-107-autumn.md)
- [Map 107 (Winter)](map-107-winter.md)
- [Map 108](map-108.md)
- [Map 109](map-109.md)
- [Map 110](map-110.md)
- [Map 111 (Spring)](map-111-spring.md)
- [Map 111 (Summer)](map-111-summer.md)
- [Map 111 (Autumn)](map-111-autumn.md)
- [Map 111 (Winter)](map-111-winter.md)
- [Map 112](map-112.md)
- [Map 113](map-113.md)
- [Map 114](map-114.md)
- [Map 115](map-115.md)
- [Map 116 (Spring)](map-116-spring.md)
- [Map 116 (Summer)](map-116-summer.md)
- [Map 116 (Autumn)](map-116-autumn.md)
- [Map 116 (Winter)](map-116-winter.md)
- [Map 117 (Spring)](map-117-spring.md)
- [Map 117 (Summer)](map-117-summer.md)
- [Map 117 (Autumn)](map-117-autumn.md)
- [Map 117 (Winter)](map-117-winter.md)
- [Map 118](map-118.md)
- [Map 119](map-119.md)
- [Map 120](map-120.md)
- [Map 121](map-121.md)
- [Map 122](map-122.md)
- [Map 123](map-123.md)
- [Map 124](map-124.md)
- [Map 125](map-125.md)
- [Map 126](map-126.md)
- [Map 127](map-127.md)
- [Map 128](map-128.md)
- [Map 129 (Spring)](map-129-spring.md)
- [Map 129 (Summer)](map-129-summer.md)
- [Map 129 (Autumn)](map-129-autumn.md)
- [Map 129 (Winter)](map-129-winter.md)
- [Map 130](map-130.md)
- [Map 131](map-131.md)
- [Undella Town](map-132.md)
- [Map 133](map-133.md)
- [Map 134](map-134.md)

</div>
