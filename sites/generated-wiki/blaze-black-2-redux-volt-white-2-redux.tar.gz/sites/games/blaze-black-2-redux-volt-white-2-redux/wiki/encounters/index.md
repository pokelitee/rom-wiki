# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City — map_6](map-000.md)
- [Castelia Gardens — map_500](map-001.md)
- [Icirrus City — map_113](map-002.md)
- [Aspertia City — map_427](map-003.md)
- [Virbank City — map_448](map-004.md)
- [Humilau City — map_465](map-005.md)
- [Dreamyard — map_152](map-006.md)
- [Dreamyard — map_153](map-007.md)
- [Pinwheel Forest — map_154](map-008.md)
- [Pinwheel Forest — map_155](map-009.md)
- [Desert Resort — map_157](map-010.md)
- [Desert Resort — map_158](map-011.md)
- [Relic Castle — map_160](map-012.md)
- [Relic Castle — map_161](map-013.md)
- [Relic Castle — map_175](map-014.md)
- [Relic Castle — map_176](map-015.md)
- [Relic Castle — map_178](map-016.md)
- [Relic Castle — map_180](map-017.md)
- [Relic Castle — map_181](map-018.md)
- [Relic Castle — map_182](map-019.md)
- [Chargestone Cave — map_195](map-020.md)
- [Chargestone Cave — map_196](map-021.md)
- [Chargestone Cave — map_197](map-022.md)
- [Twist Mountain — map_200](map-023.md)
- [Twist Mountain — map_201](map-024.md)
- [Twist Mountain — map_202](map-025.md)
- [Twist Mountain — map_203](map-026.md)
- [Dragonspiral Tower — map_205](map-027.md)
- [Dragonspiral Tower — map_206](map-028.md)
- [Dragonspiral Tower — map_207](map-029.md)
- [Dragonspiral Tower — map_208](map-030.md)
- [Victory Road — map_228](map-031.md)
- [Giant Chasm — map_230](map-032.md)
- [Giant Chasm — map_231](map-033.md)
- [Giant Chasm — map_232](map-034.md)
- [Giant Chasm — map_233](map-035.md)
- [Giant Chasm — map_234](map-036.md)
- [Castelia Sewers — map_495](map-037.md)
- [Castelia Sewers — map_496](map-038.md)
- [Castelia Sewers — map_497](map-039.md)
- [Castelia Sewers — map_498](map-040.md)
- [Castelia Sewers — map_499](map-041.md)
- [P2 Laboratory — map_238](map-042.md)
- [Undella Bay — map_240](map-043.md)
- [Floccesy Ranch — map_444](map-044.md)
- [Floccesy Ranch — map_445](map-045.md)
- [Virbank Complex — map_456](map-046.md)
- [Inner Complex — map_457](map-047.md)
- [Reversal Mountain — map_461](map-048.md)
- [Reversal Mountain — map_531](map-049.md)
- [Reversal Mountain — map_532](map-050.md)
- [Reversal Mountain — map_533](map-051.md)
- [Reversal Mountain — map_534](map-052.md)
- [Reversal Mountain — map_535](map-053.md)
- [Reversal Mountain — map_536](map-054.md)
- [Reversal Mountain — map_537](map-055.md)
- [Reversal Mountain — map_538](map-056.md)
- [Reversal Mountain — map_539](map-057.md)
- [Reversal Mountain — map_540](map-058.md)
- [Reversal Mountain — map_541](map-059.md)
- [Reversal Mountain — map_542](map-060.md)
- [Strange House — map_462](map-061.md)
- [Strange House — map_510](map-062.md)
- [Strange House — map_511](map-063.md)
- [Strange House — map_512](map-064.md)
- [Strange House — map_513](map-065.md)
- [Strange House — map_514](map-066.md)
- [Strange House — map_569](map-067.md)
- [Strange House — map_570](map-068.md)
- [Strange House — map_571](map-069.md)
- [Strange House — map_572](map-070.md)
- [Victory Road — map_587](map-071.md)
- [Victory Road — map_588](map-072.md)
- [Victory Road — map_589](map-073.md)
- [Victory Road — map_590](map-074.md)
- [Victory Road — map_591](map-075.md)
- [Victory Road — map_592](map-076.md)
- [Victory Road — map_593](map-077.md)
- [Victory Road — map_594](map-078.md)
- [Victory Road — map_595](map-079.md)
- [Victory Road — map_596](map-080.md)
- [Relic Passage — map_503](map-081.md)
- [Relic Passage — map_504](map-082.md)
- [Relic Passage — map_505](map-083.md)
- [Clay Tunnel — map_506](map-084.md)
- [Clay Tunnel — map_507](map-085.md)
- [Clay Tunnel — map_508](map-086.md)
- [Underground Ruins — map_565](map-087.md)
- [Underground Ruins — map_609](map-088.md)
- [Underground Ruins — map_610](map-089.md)
- [Rock Peak Chamber — map_611](map-090.md)
- [Iceberg Chamber — map_612](map-091.md)
- [Iron Chamber — map_613](map-092.md)
- [Seaside Cave — map_515](map-093.md)
- [Seaside Cave — map_516](map-094.md)
- [Nature Preserve — map_584](map-095.md)
- [Driftveil Drawbridge — map_253](map-096.md)
- [Village Bridge — map_255](map-097.md)
- [Marvelous Bridge — map_263](map-098.md)
- [Route 1 — map_317](map-099.md)
- [Route 2 — map_319](map-100.md)
- [Route 3 — map_321](map-101.md)
- [Wellspring Cave — map_324](map-102.md)
- [Wellspring Cave — map_325](map-103.md)
- [Route 4 — map_326](map-104.md)
- [Route 4 — map_551](map-105.md)
- [Route 5 — map_329](map-106.md)
- [Route 6 — map_331](map-107.md)
- [Mistralton Cave — map_333](map-108.md)
- [Mistralton Cave — map_334](map-109.md)
- [Mistralton Cave — map_335](map-110.md)
- [Route 7 — map_337](map-111.md)
- [Celestial Tower — map_339](map-112.md)
- [Celestial Tower — map_340](map-113.md)
- [Celestial Tower — map_341](map-114.md)
- [Celestial Tower — map_342](map-115.md)
- [Route 8 — map_345](map-116.md)
- [Moor of Icirrus — map_346](map-117.md)
- [Route 9 — map_348](map-118.md)
- [Route 11 — map_365](map-119.md)
- [Route 12 — map_368](map-120.md)
- [Route 13 — map_370](map-121.md)
- [Route 14 — map_374](map-122.md)
- [Abundant Shrine — map_376](map-123.md)
- [Route 15 — map_378](map-124.md)
- [Route 16 — map_383](map-125.md)
- [Lostlorn Forest — map_385](map-126.md)
- [Route 18 — map_387](map-127.md)
- [Route 19 — map_437](map-128.md)
- [Route 20 — map_446](map-129.md)
- [Route 22 — map_474](map-130.md)
- [Route 23 — map_475](map-131.md)
- [Undella Town — map_412](map-132.md)
- [Route 17 — map_423](map-133.md)
- [Route 21 — map_463](map-134.md)

</div>
