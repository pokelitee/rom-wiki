# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City](map-000.md)
- [Castelia Gardens](map-001.md)
- [Icirrus City](map-002.md)
- [Aspertia City](map-003.md)
- [Virbank City](map-004.md)
- [Humilau City](map-005.md)
- [Dreamyard](map-006.md)
- [Dreamyard](map-007.md)
- [Pinwheel Forest](map-008.md)
- [Pinwheel Forest](map-009.md)
- [Desert Resort](map-010.md)
- [Desert Resort](map-011.md)
- [Relic Castle](map-012.md)
- [Relic Castle](map-013.md)
- [Relic Castle](map-014.md)
- [Relic Castle](map-015.md)
- [Relic Castle](map-016.md)
- [Relic Castle](map-017.md)
- [Relic Castle](map-018.md)
- [Relic Castle](map-019.md)
- [Chargestone Cave](map-020.md)
- [Chargestone Cave](map-021.md)
- [Chargestone Cave](map-022.md)
- [Twist Mountain](map-023.md)
- [Twist Mountain](map-024.md)
- [Twist Mountain](map-025.md)
- [Twist Mountain](map-026.md)
- [Dragonspiral Tower](map-027.md)
- [Dragonspiral Tower](map-028.md)
- [Dragonspiral Tower](map-029.md)
- [Dragonspiral Tower](map-030.md)
- [Victory Road](map-031.md)
- [Giant Chasm](map-032.md)
- [Giant Chasm](map-033.md)
- [Giant Chasm](map-034.md)
- [Giant Chasm](map-035.md)
- [Giant Chasm](map-036.md)
- [Castelia Sewers](map-037.md)
- [Castelia Sewers](map-038.md)
- [Castelia Sewers](map-039.md)
- [Castelia Sewers](map-040.md)
- [Castelia Sewers](map-041.md)
- [P2 Laboratory](map-042.md)
- [Undella Bay](map-043.md)
- [Floccesy Ranch](map-044.md)
- [Floccesy Ranch](map-045.md)
- [Virbank Complex](map-046.md)
- [Inner Complex](map-047.md)
- [Reversal Mountain](map-048.md)
- [Reversal Mountain](map-049.md)
- [Reversal Mountain](map-050.md)
- [Reversal Mountain](map-051.md)
- [Reversal Mountain](map-052.md)
- [Reversal Mountain](map-053.md)
- [Reversal Mountain](map-054.md)
- [Reversal Mountain](map-055.md)
- [Reversal Mountain](map-056.md)
- [Reversal Mountain](map-057.md)
- [Reversal Mountain](map-058.md)
- [Reversal Mountain](map-059.md)
- [Reversal Mountain](map-060.md)
- [Strange House](map-061.md)
- [Strange House](map-062.md)
- [Strange House](map-063.md)
- [Strange House](map-064.md)
- [Strange House](map-065.md)
- [Strange House](map-066.md)
- [Strange House](map-067.md)
- [Strange House](map-068.md)
- [Strange House](map-069.md)
- [Strange House](map-070.md)
- [Victory Road](map-071.md)
- [Victory Road](map-072.md)
- [Victory Road](map-073.md)
- [Victory Road](map-074.md)
- [Victory Road](map-075.md)
- [Victory Road](map-076.md)
- [Victory Road](map-077.md)
- [Victory Road](map-078.md)
- [Victory Road](map-079.md)
- [Victory Road](map-080.md)
- [Relic Passage](map-081.md)
- [Relic Passage](map-082.md)
- [Relic Passage](map-083.md)
- [Clay Tunnel](map-084.md)
- [Clay Tunnel](map-085.md)
- [Clay Tunnel](map-086.md)
- [Underground Ruins](map-087.md)
- [Underground Ruins](map-088.md)
- [Underground Ruins](map-089.md)
- [Rock Peak Chamber](map-090.md)
- [Iceberg Chamber](map-091.md)
- [Iron Chamber](map-092.md)
- [Seaside Cave](map-093.md)
- [Seaside Cave](map-094.md)
- [Nature Preserve](map-095.md)
- [Driftveil Drawbridge](map-096.md)
- [Village Bridge](map-097.md)
- [Marvelous Bridge](map-098.md)
- [Route 1](map-099.md)
- [Route 2](map-100.md)
- [Route 3](map-101.md)
- [Wellspring Cave](map-102.md)
- [Wellspring Cave](map-103.md)
- [Route 4](map-104.md)
- [Route 4](map-105.md)
- [Route 5](map-106.md)
- [Route 6](map-107.md)
- [Mistralton Cave](map-108.md)
- [Mistralton Cave](map-109.md)
- [Mistralton Cave](map-110.md)
- [Route 7](map-111.md)
- [Celestial Tower](map-112.md)
- [Celestial Tower](map-113.md)
- [Celestial Tower](map-114.md)
- [Celestial Tower](map-115.md)
- [Route 8](map-116.md)
- [Moor of Icirrus](map-117.md)
- [Route 9](map-118.md)
- [Route 11](map-119.md)
- [Route 12](map-120.md)
- [Route 13](map-121.md)
- [Route 14](map-122.md)
- [Abundant Shrine](map-123.md)
- [Route 15](map-124.md)
- [Route 16](map-125.md)
- [Lostlorn Forest](map-126.md)
- [Route 18](map-127.md)
- [Route 19](map-128.md)
- [Route 20](map-129.md)
- [Route 22](map-130.md)
- [Route 23](map-131.md)
- [Undella Town](map-132.md)
- [Route 17](map-133.md)
- [Route 21](map-134.md)
- [Floccesy Ranch](../locations/header-445.md#hidden-grotto-00)
- [Route 5](../locations/header-329.md#hidden-grotto-01)
- [Lostlorn Forest](../locations/header-385.md#hidden-grotto-02)
- [Route 6](../locations/header-331.md#hidden-grotto-03)
- [Route 6](../locations/header-331.md#hidden-grotto-04)
- [Route 7](../locations/header-337.md#hidden-grotto-05)
- [Route 13](../locations/header-370.md#hidden-grotto-06)
- [Route 13](../locations/header-370.md#hidden-grotto-07)
- [Route 9](../locations/header-348.md#hidden-grotto-08)
- [Giant Chasm](../locations/header-232.md#hidden-grotto-09)
- [Route 22](../locations/header-474.md#hidden-grotto-10)
- [Route 23](../locations/header-475.md#hidden-grotto-11)
- [Abundant Shrine](../locations/header-376.md#hidden-grotto-12)
- [Abundant Shrine](../locations/header-376.md#hidden-grotto-13)
- [Pinwheel Forest](../locations/header-155.md#hidden-grotto-14)
- [Pinwheel Forest](../locations/header-154.md#hidden-grotto-15)
- [Route 3](../locations/header-321.md#hidden-grotto-16)
- [Route 3](../locations/header-321.md#hidden-grotto-17)
- [Route 2](../locations/header-319.md#hidden-grotto-18)
- [Route 18](../locations/header-387.md#hidden-grotto-19)
- [Route 1 Daily Swarm](../locations/header-317.md#daily-swarm)
- [Dreamyard Daily Swarm](../locations/header-152.md#daily-swarm)
- [Route 6 Daily Swarm](../locations/header-331.md#daily-swarm)
- [Route 3 Daily Swarm](../locations/header-321.md#daily-swarm)
- [Route 9 Daily Swarm](../locations/header-348.md#daily-swarm)
- [Desert Resort Daily Swarm](../locations/header-158.md#daily-swarm)
- [Route 5 Daily Swarm](../locations/header-329.md#daily-swarm)
- [Route 7 Daily Swarm](../locations/header-337.md#daily-swarm)
- [Route 12 Daily Swarm](../locations/header-368.md#daily-swarm)
- [Route 8 Daily Swarm](../locations/header-345.md#daily-swarm)
- [Route 11 Daily Swarm](../locations/header-365.md#daily-swarm)
- [Route 13 Daily Swarm](../locations/header-370.md#daily-swarm)
- [Abundant Shrine Daily Swarm](../locations/header-376.md#daily-swarm)
- [Route 15 Daily Swarm](../locations/header-378.md#daily-swarm)
- [Route 16 Daily Swarm](../locations/header-383.md#daily-swarm)
- [Route 18 Daily Swarm](../locations/header-387.md#daily-swarm)
- [Reversal Mountain Daily Swarm](../locations/header-461.md#daily-swarm)
- [Route 20 Daily Swarm](../locations/header-446.md#daily-swarm)

</div>
