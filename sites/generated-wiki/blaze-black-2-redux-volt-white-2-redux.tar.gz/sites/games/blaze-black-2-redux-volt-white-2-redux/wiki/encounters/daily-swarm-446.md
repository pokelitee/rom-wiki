# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 20](../locations/header-446.md) | `header-446` | `map_446` |

=== "Blaze Black 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/185.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sudowoodo](../pokemon/sudowoodo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 40–55 |

=== "Volt White 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/122.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mr. Mime](../pokemon/mr-mime.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 40–55 |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C78`.
Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C84`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-461/"><span class="rw-record-nav__label">← Daily Swarm — Reversal Mountain</span></a>
<span></span>
</nav>
