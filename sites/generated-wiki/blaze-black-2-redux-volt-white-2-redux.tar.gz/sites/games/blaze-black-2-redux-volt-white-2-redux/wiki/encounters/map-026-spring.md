# Map 026 (Spring)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>38</dd></div>
<div><dt>Map index</dt><dd>26</dd></div>
<div><dt>Season</dt><dd>Spring</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Twist Mountain](../locations/header-203.md) | 203 | Blaze Black 2 Redux / Volt White 2 Redux |

## Grass/Cave

Encounter rate: 7

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/615.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cryogonal](../pokemon/cryogonal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 68 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/615.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cryogonal](../pokemon/cryogonal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 69 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--ground">Ground</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 66 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 66 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 70 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 68 | 5% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 68 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 69 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 70 | 10% |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Cryogonal — Lv. 57</li><li>Onix — Lv. 57</li><li>Woobat — Lv. 54</li><li>Gurdurr — Lv. 55</li><li>Beartic — Lv. 56</li><li>Durant — Lv. 56</li><li>Boldore — Lv. 54</li><li>Boldore — Lv. 55</li><li>Cryogonal — Lv. 57</li><li>Onix — Lv. 57</li><li>Heatmor — Lv. 56</li><li>Durant — Lv. 57</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Vanillish — Lv. 68</li><li>Beartic — Lv. 70</li><li>Glalie — Lv. 68</li><li>Ursaring — Lv. 69</li><li>Glalie — Lv. 69</li><li>Beartic — Lv. 69</li><li>Cryogonal — Lv. 68</li><li>Cryogonal — Lv. 69</li><li>Vanillish — Lv. 68</li><li>Beartic — Lv. 70</li><li>Boldore — Lv. 66</li><li>Vanillish — Lv. 66</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Steelix — Lv. 57</li><li>Excadrill — Lv. 57</li><li>Excadrill — Lv. 55</li><li>Excadrill — Lv. 56</li><li>Excadrill — Lv. 54</li><li>Onix — Lv. 54</li><li>Steelix — Lv. 57</li><li>Excadrill — Lv. 57</li><li>Excadrill — Lv. 57</li></ul><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li>Steelix — Lv. 70</li><li>Steelix — Lv. 68</li><li>Steelix — Lv. 69</li><li>Steelix — Lv. 68</li><li>Steelix — Lv. 70</li><li>Steelix — Lv. 69</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `26`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-025-winter/"><span class="rw-record-nav__label">← Map 025 (Winter)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-026-summer/"><span class="rw-record-nav__label">Map 026 (Summer) →</span></a>
</nav>
