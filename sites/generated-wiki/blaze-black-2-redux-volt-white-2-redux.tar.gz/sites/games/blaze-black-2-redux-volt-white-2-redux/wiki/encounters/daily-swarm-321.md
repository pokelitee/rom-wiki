# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 3](../locations/header-321.md) | `header-321` | `map_321` |

=== "Blaze Black 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/313.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Volbeat](../pokemon/volbeat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--electric">Electric</span></span> | 40–55 |

=== "Volt White 2 Redux"

    | Pokémon | Type | Levels |
    | ------- | ---- | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/314.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Illumise](../pokemon/illumise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 40–55 |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C14`.
Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C70`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-331/"><span class="rw-record-nav__label">← Daily Swarm — Route 6</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-348/"><span class="rw-record-nav__label">Daily Swarm — Route 9 →</span></a>
</nav>
