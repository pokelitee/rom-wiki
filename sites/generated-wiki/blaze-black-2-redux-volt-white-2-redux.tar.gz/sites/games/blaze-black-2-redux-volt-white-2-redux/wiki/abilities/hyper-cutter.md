# Hyper Cutter

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>52</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents Attack from being lowered by other Pokémon.</strong></p>
<p>This Pokémon&#x27;s Attack cannot be lowered by other Pokémon. This ability does not prevent any Attack losses other than stat modifiers, such as the Attack cut from a burn. This Pokémon can still be passed negative Attack modifiers through Heart Swap or Power Swap.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents other Pokémon from lowering Attack stat.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/328.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trapinch](../pokemon/trapinch.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/341.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corphish](../pokemon/corphish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/342.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crawdaunt](../pokemon/crawdaunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/472.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gliscor](../pokemon/gliscor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/475.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gallade](../pokemon/gallade.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/corphish/">Corphish</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/crawdaunt/">Crawdaunt</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li></ul><p class="rw-comparison-count">4 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/krabby/">Krabby</a></li><li><a href="../../pokemon/kingler/">Kingler</a></li><li><a href="../../pokemon/pinsir/">Pinsir</a></li><li><a href="../../pokemon/mawile/">Mawile</a></li></ul><p class="rw-comparison-count">1 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gallade/">Gallade</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/52/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../keen-eye/"><span class="rw-record-nav__label">← Keen Eye</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../pickup/"><span class="rw-record-nav__label">Pickup →</span></a>
</nav>
