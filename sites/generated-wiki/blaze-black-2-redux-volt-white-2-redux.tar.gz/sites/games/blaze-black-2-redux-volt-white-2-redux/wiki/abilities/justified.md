# Justified

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>154</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">10</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Raises Attack one stage upon taking damage from a Dark move.</strong></p>
<p>Whenever a Dark-type move hits this Pokémon, its Attack rises one stage. The move is not negated in any way.</p>

<figure class="rw-pokedex-entry">
<blockquote>Raises Attack when hit by a Dark-type move.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/59.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arcanine](../pokemon/arcanine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/448.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lucario](../pokemon/lucario.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/475.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gallade](../pokemon/gallade.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/638.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cobalion](../pokemon/cobalion.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/639.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Terrakion](../pokemon/terrakion.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/640.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Virizion](../pokemon/virizion.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/647.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Keldeo](../pokemon/keldeo-ordinary.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10024.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Keldeo Resolute](../pokemon/keldeo-resolute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/absol/">Absol</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/lucario/">Lucario</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/gallade/">Gallade</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/154/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../moxie/"><span class="rw-record-nav__label">← Moxie</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rattled/"><span class="rw-record-nav__label">Rattled →</span></a>
</nav>
