# Iron Barbs

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>160</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Damages attacking Pokémon for 1/8 their max HP on contact.</strong></p>
<p>Whenever a move makes contact with this Pokémon, the move&#x27;s user takes 1/8 of its maximum HP in damage. This ability functions identically to Rough Skin.</p>

<figure class="rw-pokedex-entry">
<blockquote>Inflicts damage to the Pokémon on contact.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/597.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ferroseed](../pokemon/ferroseed.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/598.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ferrothorn](../pokemon/ferrothorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |

## Hack changes

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/160/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sand-force/"><span class="rw-record-nav__label">← Sand Force</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../zen-mode/"><span class="rw-record-nav__label">Zen Mode →</span></a>
</nav>
