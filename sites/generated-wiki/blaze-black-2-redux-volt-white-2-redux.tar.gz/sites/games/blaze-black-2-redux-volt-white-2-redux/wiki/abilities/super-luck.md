# Super Luck

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>105</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">10</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Raises moves&#x27; critical hit rates one stage.</strong></p>
<p>This Pokémon&#x27;s moves have critical hit rates one stage higher than normal.</p>

<figure class="rw-pokedex-entry">
<blockquote>Heightens the critical- hit ratios of moves.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/175.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togepi](../pokemon/togepi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fairy">Fairy</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/176.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togetic](../pokemon/togetic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/198.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/430.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Honchkrow](../pokemon/honchkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/468.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togekiss](../pokemon/togekiss.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/470.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leafeon](../pokemon/leafeon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/520.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tranquill](../pokemon/tranquill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/521.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unfezant](../pokemon/unfezant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/togepi/">Togepi</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/togetic/">Togetic</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/togekiss/">Togekiss</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul><p class="rw-comparison-count">1 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/leafeon/">Leafeon</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/105/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../mold-breaker/"><span class="rw-record-nav__label">← Mold Breaker</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../aftermath/"><span class="rw-record-nav__label">Aftermath →</span></a>
</nav>
