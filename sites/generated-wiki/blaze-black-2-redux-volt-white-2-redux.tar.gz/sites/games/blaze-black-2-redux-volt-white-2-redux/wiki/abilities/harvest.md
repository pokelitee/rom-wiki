# Harvest

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>139</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">3</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 50% chance of restoring a used Berry after each turn if the Pokémon has held no items in the meantime.</strong></p>
<p>After each turn, if the last item this Pokémon consumed was a Berry and it is not currently holding an item, it has a 50% chance of regaining that Berry, or a 100% chance during strong sunlight.</p>

<figure class="rw-pokedex-entry">
<blockquote>May create another Berry after one is used.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/103.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggutor](../pokemon/exeggutor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/exeggcute/">Exeggcute</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/exeggutor/">Exeggutor</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/139/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../flare-boost/"><span class="rw-record-nav__label">← Flare Boost</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../telepathy/"><span class="rw-record-nav__label">Telepathy →</span></a>
</nav>
