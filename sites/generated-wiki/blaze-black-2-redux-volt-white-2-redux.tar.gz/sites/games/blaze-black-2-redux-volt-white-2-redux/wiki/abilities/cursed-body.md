# Cursed Body

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>130</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">9</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 30% chance of Disabling any move that hits the Pokémon.</strong></p>
<p>Moves that hit this Pokémon have a 30% chance of being Disabled afterward.</p>

<figure class="rw-pokedex-entry">
<blockquote>May disable a move used on the Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/92.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastly](../pokemon/gastly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/94.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gengar](../pokemon/gengar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/354.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Banette](../pokemon/banette.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--normal">Normal</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/477.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusknoir](../pokemon/dusknoir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/478.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Froslass](../pokemon/froslass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/592.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Frillish](../pokemon/frillish-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/593.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jellicent](../pokemon/jellicent-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuppet/">Shuppet</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/banette/">Banette</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/froslass/">Froslass</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul><p class="rw-comparison-count">4 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gastly/">Gastly</a></li><li><a href="../../pokemon/haunter/">Haunter</a></li><li><a href="../../pokemon/gengar/">Gengar</a></li><li><a href="../../pokemon/dusknoir/">Dusknoir</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/130/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../defeatist/"><span class="rw-record-nav__label">← Defeatist</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../healer/"><span class="rw-record-nav__label">Healer →</span></a>
</nav>
