# Abilities

Abilities extracted from the ROM, with every Pokémon and form that can have them.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="abilities" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [#001 Stench](stench.md)
- [#002 Drizzle](drizzle.md)
- [#003 Speed Boost](speed-boost.md)
- [#004 Battle Armor](battle-armor.md)
- [#005 Sturdy](sturdy.md)
- [#006 Damp](damp.md)
- [#007 Limber](limber.md)
- [#008 Sand Veil](sand-veil.md)
- [#009 Static](static.md)
- [#010 Volt Absorb](volt-absorb.md)
- [#011 Water Absorb](water-absorb.md)
- [#012 Oblivious](oblivious.md)
- [#013 Cloud Nine](cloud-nine.md)
- [#014 Compoundeyes](compound-eyes.md)
- [#015 Insomnia](insomnia.md)
- [#016 Color Change](color-change.md)
- [#017 Immunity](immunity.md)
- [#018 Flash Fire](flash-fire.md)
- [#019 Shield Dust](shield-dust.md)
- [#020 Own Tempo](own-tempo.md)
- [#021 Suction Cups](suction-cups.md)
- [#022 Intimidate](intimidate.md)
- [#023 Shadow Tag](shadow-tag.md)
- [#024 Rough Skin](rough-skin.md)
- [#025 Wonder Guard](wonder-guard.md)
- [#026 Levitate](levitate.md)
- [#027 Effect Spore](effect-spore.md)
- [#028 Synchronize](synchronize.md)
- [#029 Clear Body](clear-body.md)
- [#030 Natural Cure](natural-cure.md)
- [#031 Lightningrod](lightning-rod.md)
- [#032 Serene Grace](serene-grace.md)
- [#033 Swift Swim](swift-swim.md)
- [#034 Chlorophyll](chlorophyll.md)
- [#035 Illuminate](illuminate.md)
- [#036 Trace](trace.md)
- [#037 Huge Power](huge-power.md)
- [#038 Poison Point](poison-point.md)
- [#039 Inner Focus](inner-focus.md)
- [#040 Magma Armor](magma-armor.md)
- [#041 Water Veil](water-veil.md)
- [#042 Magnet Pull](magnet-pull.md)
- [#043 Soundproof](soundproof.md)
- [#044 Rain Dish](rain-dish.md)
- [#045 Sand Stream](sand-stream.md)
- [#046 Pressure](pressure.md)
- [#047 Thick Fat](thick-fat.md)
- [#048 Early Bird](early-bird.md)
- [#049 Flame Body](flame-body.md)
- [#050 Run Away](run-away.md)
- [#051 Keen Eye](keen-eye.md)
- [#052 Hyper Cutter](hyper-cutter.md)
- [#053 Pickup](pickup.md)
- [#054 Truant](truant.md)
- [#055 Hustle](hustle.md)
- [#056 Cute Charm](cute-charm.md)
- [#057 Plus](plus.md)
- [#058 Minus](minus.md)
- [#059 Forecast](forecast.md)
- [#060 Sticky Hold](sticky-hold.md)
- [#061 Shed Skin](shed-skin.md)
- [#062 Guts](guts.md)
- [#063 Marvel Scale](marvel-scale.md)
- [#064 Liquid Ooze](liquid-ooze.md)
- [#065 Overgrow](overgrow.md)
- [#066 Blaze](blaze.md)
- [#067 Torrent](torrent.md)
- [#068 Swarm](swarm.md)
- [#069 Rock Head](rock-head.md)
- [#070 Drought](drought.md)
- [#071 Arena Trap](arena-trap.md)
- [#072 Vital Spirit](vital-spirit.md)
- [#073 White Smoke](white-smoke.md)
- [#074 Pure Power](pure-power.md)
- [#075 Shell Armor](shell-armor.md)
- [#076 Air Lock](air-lock.md)
- [#077 Tangled Feet](tangled-feet.md)
- [#078 Motor Drive](motor-drive.md)
- [#079 Rivalry](rivalry.md)
- [#080 Steadfast](steadfast.md)
- [#081 Snow Cloak](snow-cloak.md)
- [#082 Gluttony](gluttony.md)
- [#083 Anger Point](anger-point.md)
- [#084 Unburden](unburden.md)
- [#085 Heatproof](heatproof.md)
- [#086 Simple](simple.md)
- [#087 Dry Skin](dry-skin.md)
- [#088 Download](download.md)
- [#089 Iron Fist](iron-fist.md)
- [#090 Poison Heal](poison-heal.md)
- [#091 Adaptability](adaptability.md)
- [#092 Skill Link](skill-link.md)
- [#093 Hydration](hydration.md)
- [#094 Solar Power](solar-power.md)
- [#095 Quick Feet](quick-feet.md)
- [#096 Normalize](normalize.md)
- [#097 Sniper](sniper.md)
- [#098 Magic Guard](magic-guard.md)
- [#099 No Guard](no-guard.md)
- [#100 Stall](stall.md)
- [#101 Technician](technician.md)
- [#102 Leaf Guard](leaf-guard.md)
- [#103 Klutz](klutz.md)
- [#104 Mold Breaker](mold-breaker.md)
- [#105 Super Luck](super-luck.md)
- [#106 Aftermath](aftermath.md)
- [#107 Anticipation](anticipation.md)
- [#108 Forewarn](forewarn.md)
- [#109 Unaware](unaware.md)
- [#110 Tinted Lens](tinted-lens.md)
- [#111 Filter](filter.md)
- [#112 Slow Start](slow-start.md)
- [#113 Scrappy](scrappy.md)
- [#114 Storm Drain](storm-drain.md)
- [#115 Ice Body](ice-body.md)
- [#116 Solid Rock](solid-rock.md)
- [#117 Snow Warning](snow-warning.md)
- [#118 Honey Gather](honey-gather.md)
- [#119 Frisk](frisk.md)
- [#120 Reckless](reckless.md)
- [#121 Multitype](multitype.md)
- [#122 Flower Gift](flower-gift.md)
- [#123 Bad Dreams](bad-dreams.md)
- [#124 Pickpocket](pickpocket.md)
- [#125 Sheer Force](sheer-force.md)
- [#126 Contrary](contrary.md)
- [#127 Unnerve](unnerve.md)
- [#128 Defiant](defiant.md)
- [#129 Defeatist](defeatist.md)
- [#130 Cursed Body](cursed-body.md)
- [#131 Healer](healer.md)
- [#132 Friend Guard](friend-guard.md)
- [#133 Weak Armor](weak-armor.md)
- [#134 Heavy Metal](heavy-metal.md)
- [#135 Light Metal](light-metal.md)
- [#136 Multiscale](multiscale.md)
- [#137 Toxic Boost](toxic-boost.md)
- [#138 Flare Boost](flare-boost.md)
- [#139 Harvest](harvest.md)
- [#140 Telepathy](telepathy.md)
- [#141 Moody](moody.md)
- [#142 Overcoat](overcoat.md)
- [#143 Poison Touch](poison-touch.md)
- [#144 Regenerator](regenerator.md)
- [#145 Big Pecks](big-pecks.md)
- [#146 Sand Rush](sand-rush.md)
- [#147 Wonder Skin](wonder-skin.md)
- [#148 Analytic](analytic.md)
- [#149 Illusion](illusion.md)
- [#150 Imposter](imposter.md)
- [#151 Infiltrator](infiltrator.md)
- [#152 Mummy](mummy.md)
- [#153 Moxie](moxie.md)
- [#154 Justified](justified.md)
- [#155 Rattled](rattled.md)
- [#156 Magic Bounce](magic-bounce.md)
- [#157 Sap Sipper](sap-sipper.md)
- [#158 Prankster](prankster.md)
- [#159 Sand Force](sand-force.md)
- [#160 Iron Barbs](iron-barbs.md)
- [#161 Zen Mode](zen-mode.md)
- [#162 Victory Star](victory-star.md)
- [#163 Turboblaze](turboblaze.md)
- [#164 Teravolt](teravolt.md)

</div>
