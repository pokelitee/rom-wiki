# Sand Veil

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>8</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">10</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases evasion to 1.25× during a sandstorm. Protects against sandstorm damage.</strong></p>
<p>During a sandstorm, this Pokémon has 1.25× its evasion, and it does not take sandstorm damage regardless of type. The evasion bonus does not count as a stat modifier. Overworld: If the lead Pokémon has this ability, the wild encounter rate is halved in a sandstorm.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the Pokémon&#x27;s evasion in a sandstorm.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/231.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/246.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Larvitar](../pokemon/larvitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/443.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gible](../pokemon/gible.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/444.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gabite](../pokemon/gabite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/445.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Garchomp](../pokemon/garchomp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/618.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunfisk](../pokemon/stunfisk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--electric">Electric</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">8 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandshrew/">Sandshrew</a></li><li><a href="../../pokemon/sandslash/">Sandslash</a></li><li><a href="../../pokemon/diglett/">Diglett</a></li><li><a href="../../pokemon/dugtrio/">Dugtrio</a></li><li><a href="../../pokemon/gligar/">Gligar</a></li><li><a href="../../pokemon/cacnea/">Cacnea</a></li><li><a href="../../pokemon/cacturne/">Cacturne</a></li><li><a href="../../pokemon/gliscor/">Gliscor</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/8/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../limber/"><span class="rw-record-nav__label">← Limber</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../static/"><span class="rw-record-nav__label">Static →</span></a>
</nav>
