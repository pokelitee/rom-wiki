# Filter

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>111</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Decreases damage taken from super-effective moves by 1/4.</strong></p>
<p>This Pokémon takes 0.75× as much damage from moves that are super effective against it. This ability functions identically to Solid Rock.</p>

<figure class="rw-pokedex-entry">
<blockquote>Reduces damage from supereffective attacks.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/122.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mr. Mime](../pokemon/mr-mime.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/304.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/306.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aggron](../pokemon/aggron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/378.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Regice](../pokemon/regice.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/439.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fairy">Fairy</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/aron/">Aron</a></li><li><a href="../../pokemon/lairon/">Lairon</a></li><li><a href="../../pokemon/aggron/">Aggron</a></li><li><a href="../../pokemon/regice/">Regice</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/111/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../tinted-lens/"><span class="rw-record-nav__label">← Tinted Lens</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../slow-start/"><span class="rw-record-nav__label">Slow Start →</span></a>
</nav>
