# Minus

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>58</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases Special Attack to 1.5× when a friendly Pokémon has Plus or Minus.</strong></p>
<p>This Pokémon has 1.5× its Special Attack if any friendly Pokémon has Plus or Minus. This bonus does not count as a stat modifier. If either ability is disabled by Gastro Acid, both lose their effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>Ups Sp. Atk if another Pokémon has Plus or Minus.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/electrike/">Electrike</a></li><li><a href="../../pokemon/manectric/">Manectric</a></li><li><a href="../../pokemon/klink/">Klink</a></li><li><a href="../../pokemon/klang/">Klang</a></li><li><a href="../../pokemon/klinklang/">Klinklang</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/58/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../plus/"><span class="rw-record-nav__label">← Plus</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../forecast/"><span class="rw-record-nav__label">Forecast →</span></a>
</nav>
