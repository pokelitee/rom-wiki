# Blaze

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>66</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">17</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Strengthens Fire moves to inflict 1.5× damage at 1/3 max HP or less.</strong></p>
<p>When this Pokémon has 1/3 or less of its HP remaining, its Fire-type moves inflict 1.5× as much regular damage.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers up Fire-type moves in a pinch.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/4.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Charmander](../pokemon/charmander.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/5.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Charmeleon](../pokemon/charmeleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/6.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Charizard](../pokemon/charizard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/155.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cyndaquil](../pokemon/cyndaquil.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/156.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quilava](../pokemon/quilava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/157.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Typhlosion](../pokemon/typhlosion.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/255.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torchic](../pokemon/torchic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/256.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combusken](../pokemon/combusken.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/257.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blaziken](../pokemon/blaziken.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/390.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimchar](../pokemon/chimchar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/391.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Monferno](../pokemon/monferno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/392.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Infernape](../pokemon/infernape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/498.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tepig](../pokemon/tepig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/499.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pignite](../pokemon/pignite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/500.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emboar](../pokemon/emboar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/513.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pansear](../pokemon/pansear.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/514.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Simisear](../pokemon/simisear.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">17 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/charmander/">Charmander</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/charmeleon/">Charmeleon</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/charizard/">Charizard</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/cyndaquil/">Cyndaquil</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/quilava/">Quilava</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/typhlosion/">Typhlosion</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/torchic/">Torchic</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/combusken/">Combusken</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/blaziken/">Blaziken</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/chimchar/">Chimchar</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/monferno/">Monferno</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/infernape/">Infernape</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/tepig/">Tepig</a>: Slots 1, 2<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/pignite/">Pignite</a>: Slots 1, 2<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/emboar/">Emboar</a>: Slots 1, 2<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/pansear/">Pansear</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/simisear/">Simisear</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `374`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/66/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../overgrow/"><span class="rw-record-nav__label">← Overgrow</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../torrent/"><span class="rw-record-nav__label">Torrent →</span></a>
</nav>
