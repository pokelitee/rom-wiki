# Iron Fist

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>89</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">14</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Strengthens punch-based moves to 1.2× their power.</strong></p>
<p>Moves flagged as being punch-based have 1.2× their base power for this Pokémon. Sucker Punch is not flagged as punch-based; its original, Japanese name only means &quot;surprise attack&quot;.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the power of punching moves.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/107.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonchan](../pokemon/hitmonchan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/166.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/376.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metagross](../pokemon/metagross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/390.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimchar](../pokemon/chimchar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/391.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Monferno](../pokemon/monferno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/392.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Infernape](../pokemon/infernape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/477.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusknoir](../pokemon/dusknoir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/532.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Timburr](../pokemon/timburr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/533.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gurdurr](../pokemon/gurdurr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/534.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Conkeldurr](../pokemon/conkeldurr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/622.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golett](../pokemon/golett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/623.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golurk](../pokemon/golurk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">8 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hitmonchan/">Hitmonchan</a>: Slot 2<span class="rw-diff-arrow">→</span>Slot 1</li><li><a href="../../pokemon/ledian/">Ledian</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/chimchar/">Chimchar</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/monferno/">Monferno</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/infernape/">Infernape</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/timburr/">Timburr</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/gurdurr/">Gurdurr</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 2</li><li><a href="../../pokemon/conkeldurr/">Conkeldurr</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 2</li></ul><p class="rw-comparison-count">4 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ledyba/">Ledyba</a></li><li><a href="../../pokemon/metang/">Metang</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/dusknoir/">Dusknoir</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/89/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../download/"><span class="rw-record-nav__label">← Download</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../poison-heal/"><span class="rw-record-nav__label">Poison Heal →</span></a>
</nav>
