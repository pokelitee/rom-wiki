# Limber

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>7</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">4</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents paralysis.</strong></p>
<p>This Pokémon cannot be paralyzed. If a Pokémon is paralyzed and acquires this ability, its paralysis is healed; this includes when regaining a lost ability upon leaving battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected from paralysis.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/106.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonlee](../pokemon/hitmonlee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/427.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buneary](../pokemon/buneary.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/428.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lopunny](../pokemon/lopunny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/431.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glameow](../pokemon/glameow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hitmonlee/">Hitmonlee</a>: Slot 1<span class="rw-diff-arrow">→</span>Slot 3</li><li><a href="../../pokemon/buneary/">Buneary</a>: Slot 3<span class="rw-diff-arrow">→</span>Slot 2</li></ul><p class="rw-comparison-count">5 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/persian/">Persian</a></li><li><a href="../../pokemon/ditto/">Ditto</a></li><li><a href="../../pokemon/purrloin/">Purrloin</a></li><li><a href="../../pokemon/liepard/">Liepard</a></li><li><a href="../../pokemon/stunfisk/">Stunfisk</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/7/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../damp/"><span class="rw-record-nav__label">← Damp</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sand-veil/"><span class="rw-record-nav__label">Sand Veil →</span></a>
</nav>
