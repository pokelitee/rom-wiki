# Electirizer

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/electirizer.png" alt="Electirizer icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>322</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">80</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Traded on an Electabuzz: Holder evolves into Electivire.</strong></p>
<p>Held by Electabuzz: Evolves the holder into Electivire when traded.</p>

<figure class="rw-pokedex-entry">
<blockquote>A box packed with a tremendous amount of electric energy. It is loved by a certain Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>143</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Village Bridge](../locations/header-255.md) | — | `header-255` | Visible | (40, 12) |
| [Route 13](../locations/header-370.md) | — | `header-370` | Visible | (703, 277) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Route 9](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F2 | ₽2,100 | Main game |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/466.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electivire](../pokemon/electivire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/125.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/466.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electivire](../pokemon/electivire.md)</span> | Use Item |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Field use</p>
<div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field-use function</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party use</p>
<div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party effects</p>
<div class="rw-change__value">—<span class="rw-diff-arrow">→</span>Structured value<details><summary>Exact data</summary><code>{&quot;attack_ev_amount&quot;:0,&quot;defense_ev_amount&quot;:0,&quot;friendship_high_amount&quot;:0,&quot;friendship_low_amount&quot;:0,&quot;friendship_medium_amount&quot;:0,&quot;heal_burn&quot;:false,&quot;heal_confusion&quot;:false,&quot;heal_freeze&quot;:false,&quot;heal_paralysis&quot;:false,&quot;heal_poison&quot;:false,&quot;heal_sleep&quot;:false,&quot;hp_ev_amount&quot;:0,&quot;hp_restored&quot;:0,&quot;level_up&quot;:false,&quot;pp_restored&quot;:0,&quot;revive&quot;:false,&quot;revive_all&quot;:false,&quot;special_attack_ev_amount&quot;:0,&quot;special_defense_ev_amount&quot;:0,&quot;speed_ev_amount&quot;:0}</code></details></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plasma Frigate</li><li>Plasma Frigate</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Village Bridge</li><li>Route 13</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 9</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Evolutions</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/electivire/">Electivire</a> — trade-held-item</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/electivire/">Electivire</a> — use-item</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `322` |

Source: exact ROM record from `a/0/2/4` member `322`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/299/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../protector/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/protector.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Protector</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../magmarizer/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/magmarizer.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Magmarizer →</span></a>
</nav>
