# Choice Scarf

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-scarf.png" alt="Choice Scarf icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>287</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Choice</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases Speed by 50%, but restricts the holder to only one move.</strong></p>
<p>Held: Increases the holder’s Speed by 50%, but restricts it to the first move it uses until it leaves battle or loses this item. If this item is swapped for another Choice item via Trick or Switcheroo, the holder’s restriction is still lifted, but it will again be restricted to the next move it uses. (Quirk: If the holder is switched in by U-Turn and it also knows U-Turn, U-Turn becomes its restricted move.)</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. This scarf boosts Speed, but allows the use of only one of its moves.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>115</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 8](../locations/header-345.md) | — | `header-345` | Visible | (228, 187) |
| [Aspertia City](../locations/header-428.md) | — | `header-428` | Script Awarded | — |
| [Aspertia City](../locations/header-428.md) | — | `header-428` | Script Awarded | — |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 24 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 24 BP | Main game |
| [PWT](../locations/header-192.md) | — | `header-192` | Battle Point item exchange | 24 BP | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Grimsley](../trainers/trainer-0040.md) | Held by Krookodile |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | Held by Jellicent |
| [Elite Four Grimsley](../trainers/trainer-0145.md) | Held by Krookodile |
| [Boss Trainer Elie](../trainers/trainer-0191.md) | Held by Heatran |
| [Scientist Jacques](../trainers/trainer-0263.md) | Held by Ditto |
| [Scientist Marissa](../trainers/trainer-0264.md) | Held by Ditto |
| [Veteran Rayne](../trainers/trainer-0404.md) | Held by Typhlosion |
| [Ace Trainer Kathrine](../trainers/trainer-0636.md) | Held by Wailord |
| [Guitarist Tina](../trainers/trainer-0756.md) | Held by Typhlosion |
| [Veteran Ernest](../trainers/trainer-0757.md) | Held by Tangrowth |
| [Leader Clay](../trainers/trainer-0818.md) | Held by Mamoswine |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Aspertia City</li><li>Aspertia City</li><li>Route 8</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jellicent-male/">Jellicent</a></li><li><a href="../../pokemon/golurk/">Golurk</a></li><li><a href="../../pokemon/rampardos/">Rampardos</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/wailord/">Wailord</a></li><li><a href="../../pokemon/heatran/">Heatran</a></li><li><a href="../../pokemon/krookodile/">Krookodile</a></li><li><a href="../../pokemon/krookodile/">Krookodile</a></li><li><a href="../../pokemon/jellicent-male/">Jellicent</a></li><li><a href="../../pokemon/typhlosion/">Typhlosion</a></li><li><a href="../../pokemon/mamoswine/">Mamoswine</a></li><li><a href="../../pokemon/ditto/">Ditto</a></li><li><a href="../../pokemon/ditto/">Ditto</a></li><li><a href="../../pokemon/typhlosion/">Typhlosion</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `287` |

Source: exact ROM record from `a/0/2/4` member `287`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/264/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../grip-claw/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grip-claw.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Grip Claw</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sticky-barb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/sticky-barb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Sticky Barb →</span></a>
</nav>
