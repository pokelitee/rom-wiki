# Dubious Disc

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dubious-disc.png" alt="Dubious Disc icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>324</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">50</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Traded on a Porygon2: Holder evolves into Porygon-Z.</strong></p>
<p>Held by Porygon2: Evolves the holder into Porygon-Z when traded.</p>

<figure class="rw-pokedex-entry">
<blockquote>A transparent device overflowing with dubious data. Its producer is unknown.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>145</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Driftveil Drawbridge](../locations/header-301.md) | map_301 | `header-301` | Visible | (60, 83) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | map_5 | `header-005` | Black City market store 4 | ₽60,000 | Weekends |
| [Route 9](../locations/header-350.md) | map_350 | `header-350` | Shopping Mall 9 F2 | ₽2,100 | Main game |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/233.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon2](../pokemon/porygon2.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/474.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Porygon-Z](../pokemon/porygon-z.md)</span> | Use Item |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>6 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Field use</p>
<div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field-use function</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party use</p>
<div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party effects</p>
<div class="rw-change__value">—<span class="rw-diff-arrow">→</span>Structured value<details><summary>Exact data</summary><code>{&quot;attack_ev_amount&quot;:0,&quot;defense_ev_amount&quot;:0,&quot;friendship_high_amount&quot;:0,&quot;friendship_low_amount&quot;:0,&quot;friendship_medium_amount&quot;:0,&quot;heal_burn&quot;:false,&quot;heal_confusion&quot;:false,&quot;heal_freeze&quot;:false,&quot;heal_paralysis&quot;:false,&quot;heal_poison&quot;:false,&quot;heal_sleep&quot;:false,&quot;hp_ev_amount&quot;:0,&quot;hp_restored&quot;:0,&quot;level_up&quot;:false,&quot;pp_restored&quot;:0,&quot;revive&quot;:false,&quot;revive_all&quot;:false,&quot;special_attack_ev_amount&quot;:0,&quot;special_defense_ev_amount&quot;:0,&quot;speed_ev_amount&quot;:0}</code></details></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 9</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Evolutions</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Porygon-Z — trade-held-item</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Porygon-Z — use-item</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `324` |

Source: exact ROM record from `a/0/2/4` member `324`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/301/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../magmarizer/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/magmarizer.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Magmarizer</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../reaper-cloth/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/reaper-cloth.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Reaper Cloth →</span></a>
</nav>
