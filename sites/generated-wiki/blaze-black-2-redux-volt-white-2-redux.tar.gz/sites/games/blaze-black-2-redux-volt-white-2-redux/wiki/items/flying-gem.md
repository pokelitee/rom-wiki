# Flying Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/flying-gem.png" alt="Flying Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>556</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an essence of air. When held, it strengthens the power of a Flying-type move only once.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Aspertia City](../locations/header-428.md) | — | `header-428` | Script Awarded | — |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Marshal](../trainers/trainer-0039.md) | Held by Mienshao |
| [Pilot Winslow](../trainers/trainer-0150.md) | Held by Farfetch&#x27;d |
| [Leader Elesa](../trainers/trainer-0153.md) | Held by Emolga |
| [Leader Skyla](../trainers/trainer-0155.md) | Held by Gliscor |
| [Leader Skyla](../trainers/trainer-0155.md) | Held by Archeops |
| [Boss Trainer Abigail](../trainers/trainer-0183.md) | Held by Archeops |
| [Boss Trainer Frederick](../trainers/trainer-0193.md) | Held by Tornadus Therian |
| [Pilot Elron](../trainers/trainer-0332.md) | Held by Jumpluff |
| [Champion Iris](../trainers/trainer-0341.md) | Held by Archeops |
| [Team Plasma Zinzolin](../trainers/trainer-0347.md) | Held by Drifblim |
| [Team Plasma Shadow](../trainers/trainer-0348.md) | Held by Crobat |
| [Motorcyclist Charles](../trainers/trainer-0366.md) | Held by Archeops |
| [Motorcyclist Charles](../trainers/trainer-0367.md) | Held by Archeops |
| [Team Plasma Shadow](../trainers/trainer-0583.md) | Held by Crobat |
| [Team Plasma Zinzolin](../trainers/trainer-0584.md) | Held by Drifblim |
| [GAME FREAK Morimoto](../trainers/trainer-0592.md) | Held by Swoobat |
| [Team Plasma Shadow](../trainers/trainer-0687.md) | Held by Crobat |
| [Leader Skyla](../trainers/trainer-0769.md) | Held by Jumpluff |
| [Leader Roxie](../trainers/trainer-0815.md) | Held by Crobat |
| [Leader Elesa](../trainers/trainer-0817.md) | Held by Emolga |
| [Leader Skyla](../trainers/trainer-0819.md) | Held by Archeops |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0822.md) | Held by Archeops |
| [⒆⒇ Trainer Juan](../trainers/trainer-0835.md) | Held by Pelipper |
| [⒆⒇ Trainer Winona](../trainers/trainer-0837.md) | Held by Dragonite |
| [⒆⒇ Trainer Tate](../trainers/trainer-0840.md) | Held by Solrock |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Mistralton City</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Aspertia City</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li></ul><p class="rw-comparison-count">25 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/tornadus-incarnate/">Tornadus Therian</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/mienshao/">Mienshao</a></li><li><a href="../../pokemon/swoobat/">Swoobat</a></li><li><a href="../../pokemon/emolga/">Emolga</a></li><li><a href="../../pokemon/emolga/">Emolga</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/jumpluff/">Jumpluff</a></li><li><a href="../../pokemon/gliscor/">Gliscor</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/jumpluff/">Jumpluff</a></li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/crobat/">Crobat</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li><li><a href="../../pokemon/archeops/">Archeops</a></li><li><a href="../../pokemon/pelipper/">Pelipper</a></li><li><a href="../../pokemon/solrock/">Solrock</a></li><li><a href="../../pokemon/dragonite/">Dragonite</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `556` |

Source: exact ROM record from `a/0/2/4` member `556`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/599/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ground-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ground-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ground Gem</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../psychic-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/psychic-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Psychic Gem →</span></a>
</nav>
