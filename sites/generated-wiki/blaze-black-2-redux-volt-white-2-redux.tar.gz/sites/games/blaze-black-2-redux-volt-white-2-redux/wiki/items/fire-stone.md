# Fire Stone

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="Fire Stone icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>82</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Evolves an Eevee into Flareon, a Growlithe into Arcanine, a Pansear into Simisear, or a Vulpix into Ninetales.</strong></p>
<p>Used on a party Pokémon : Evolves an Eevee into Flareon, a Growlithe into Arcanine, a Pansear into Simisear, or a Vulpix into Ninetales.</p>

<figure class="rw-pokedex-entry">
<blockquote>A peculiar stone that makes certain species of Pokémon evolve. It is colored orange.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Castelia City](../locations/header-044.md) | — | `header-044` | Script Awarded | — |
| [Desert Resort](../locations/header-158.md) | — | `header-158` | Hidden | (76, 24) |
| [Castelia Gardens](../locations/header-500.md) | — | `header-500` | Script Awarded | — |
| [Strange House](../locations/header-510.md) | — | `header-510` | Visible | (13, 10) |
| [Floccesy Ranch](../locations/header-445.md) | — | `header-445` | Hidden Grotto Visible | — |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden Grotto Visible | — |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden Grotto Visible | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Visible | — |
| [Route 7](../locations/header-337.md) | — | `header-337` | Hidden Grotto Visible | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Visible | — |
| [Route 9](../locations/header-348.md) | — | `header-348` | Hidden Grotto Visible | — |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Hidden Grotto Visible | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden Grotto Visible | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden Grotto Visible | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-154.md) | — | `header-154` | Hidden Grotto Visible | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Visible | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Hidden Grotto Visible | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Hidden Grotto Visible | — |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | — | `header-005` | Black City market store 2 | ₽20,000 | Weekdays |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 3 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 3 BP | Main game |
| [Driftveil City](../locations/header-105.md) | — | `header-105` | Driftveil Incense Salesman | ₽2,100 | Main game |
| [PWT](../locations/header-192.md) | — | `header-192` | Battle Point item exchange | 3 BP | Main game |
| [Route 9](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F1 | ₽2,100 | Main game |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/38.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ninetales](../pokemon/ninetales.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/59.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arcanine](../pokemon/arcanine.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/133.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Eevee](../pokemon/eevee.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/136.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Flareon](../pokemon/flareon.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/513.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pansear](../pokemon/pansear.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/514.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Simisear](../pokemon/simisear.md)</span> | Use Item |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Castelia Gardens</li><li>Castelia City</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Driftveil City</li><li>Route 9</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `82` |

Source: exact ROM record from `a/0/2/4` member `82`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/82/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../moon-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moon-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Moon Stone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../thunder-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Thunder Stone →</span></a>
</nav>
