# Full Restore

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="Full Restore icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>23</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full and cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Restores HP to full and cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A medicine that fully restores the HP and heals any status problems of a single Pokémon.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x0c</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Castelia City](../locations/header-048.md) | map_48 | `header-048` | Visible | (1, 11) |
| [Virbank City](../locations/header-449.md) | map_449 | `header-449` | Hidden | (439, 173) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [⒆⒇ Trainer N](../trainers/trainer-0005.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0006.md) | AI battle item |
| [Socialite Cassandra](../trainers/trainer-0036.md) | AI battle item |
| [Gentleman Robert](../trainers/trainer-0037.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0038.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0039.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0040.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0041.md) | AI battle item |
| [Socialite Emilia](../trainers/trainer-0103.md) | AI battle item |
| [Gentleman Renaud](../trainers/trainer-0104.md) | AI battle item |
| [GAME FREAK Morimoto](../trainers/trainer-0140.md) | AI battle item |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | AI battle item |
| [Elite Four Marshal](../trainers/trainer-0144.md) | AI battle item |
| [Elite Four Grimsley](../trainers/trainer-0145.md) | AI battle item |
| [Elite Four Caitlin](../trainers/trainer-0146.md) | AI battle item |
| [Leader Marlon](../trainers/trainer-0160.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0341.md) | AI battle item |
| [⒆⒇ Trainer Cynthia](../trainers/trainer-0456.md) | AI battle item |
| [⒆⒇ Trainer Chili](../trainers/trainer-0494.md) | AI battle item |
| [⒆⒇ Trainer Cress](../trainers/trainer-0495.md) | AI battle item |
| [⒆⒇ Trainer Cilan](../trainers/trainer-0496.md) | AI battle item |
| [Champion Iris](../trainers/trainer-0536.md) | AI battle item |
| [⒆⒇ Trainer Alder](../trainers/trainer-0582.md) | AI battle item |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | AI battle item |
| [Veteran Hugo](../trainers/trainer-0612.md) | AI battle item |
| [Pokéfan Elliot](../trainers/trainer-0652.md) | AI battle item |
| [Pokéfan Lydia](../trainers/trainer-0653.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0693.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0694.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0695.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0696.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0697.md) | AI battle item |
| [⒆⒇ Trainer Rival](../trainers/trainer-0698.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0706.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0707.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0708.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0709.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0710.md) | AI battle item |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0711.md) | AI battle item |
| [Nurse Carol](../trainers/trainer-0725.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0782.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0783.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0784.md) | AI battle item |
| [⒆⒇ Trainer N](../trainers/trainer-0785.md) | AI battle item |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | AI battle item |
| [Leader Cheren](../trainers/trainer-0814.md) | AI battle item |
| [Leader Roxie](../trainers/trainer-0815.md) | AI battle item |
| [Leader Burgh](../trainers/trainer-0816.md) | AI battle item |
| [Leader Elesa](../trainers/trainer-0817.md) | AI battle item |
| [Leader Clay](../trainers/trainer-0818.md) | AI battle item |
| [Leader Skyla](../trainers/trainer-0819.md) | AI battle item |
| [Leader Drayden](../trainers/trainer-0820.md) | AI battle item |
| [Leader Marlon](../trainers/trainer-0821.md) | AI battle item |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0822.md) | AI battle item |
| [⒆⒇ Trainer Hilda](../trainers/trainer-0823.md) | AI battle item |
| [⒆⒇ Trainer Wallace](../trainers/trainer-0843.md) | AI battle item |
| [Nurse Kirsten](../trainers/trainer-0119.md) | Victory reward |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Iris</li><li>Iris</li><li>Caitlin</li><li>Caitlin</li><li>Grimsley</li><li>Grimsley</li><li>Marshal</li><li>Marshal</li><li>Shauntal</li><li>Shauntal</li><li>Colress</li><li>Ghetsis</li></ul><p class="rw-comparison-count">13 entries added</p><ul class="rw-comparison-list"><li>Burgh</li><li>Cheren</li><li>Clay</li><li>Drayden</li><li>Elesa</li><li>Marlon</li><li>Marlon</li><li>Roxie</li><li>Skyla</li><li>Hugo</li><li>Hilbert</li><li>Hilda</li><li>Wallace</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `23` |

Source: exact ROM record from `a/0/2/4` member `23`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/23/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../paralyze-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/paralyze-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Paralyze Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Potion →</span></a>
</nav>
