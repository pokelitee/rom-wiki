# Expert Belt

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/expert-belt.png" alt="Expert Belt icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>268</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s Super Effective moves do 20% extra damage.</strong></p>
<p>Held: When the holder hits with a super-effective move, its power is raised by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a well-worn belt that slightly boosts the power of supereffective moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>96</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Twist Mountain](../locations/header-203.md) | map_203 | `header-203` | Visible | (587, 618) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Shauntal](../trainers/trainer-0038.md) | Held by Golurk |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | Held by Golurk |
| [Gentleman Stonewall](../trainers/trainer-0177.md) | Held by Breloom |
| [Boss Trainer Danelle](../trainers/trainer-0190.md) | Held by Heatmor |
| [Boss Trainer Frederick](../trainers/trainer-0193.md) | Held by Meloetta |
| [Veteran Rayne](../trainers/trainer-0404.md) | Held by Sudowoodo |
| [Veteran Chester](../trainers/trainer-0421.md) | Held by Infernape |
| [Veteran Carter](../trainers/trainer-0534.md) | Held by Venusaur |
| [Battle Girl Chalina](../trainers/trainer-0609.md) | Held by Hitmonchan |
| [Leader Cheren](../trainers/trainer-0764.md) | Held by Doduo |
| [Elite Four Marshal](../trainers/trainer-0779.md) | Held by Keldeo Resolute |
| [Leader Elesa](../trainers/trainer-0817.md) | Held by Electivire |
| [Leader Elesa](../trainers/trainer-0817.md) | Held by Eelektross |
| [Leader Clay](../trainers/trainer-0818.md) | Held by Golurk |
| [Ace Trainer Drayano](../trainers/trainer-0865.md) | Held by Gardevoir |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Audino</li><li>Sigilyph</li><li>Alakazam</li><li>Krookodile</li><li>Mienshao</li><li>Machamp</li><li>Golurk</li><li>Gengar</li></ul><p class="rw-comparison-count">15 entries added</p><ul class="rw-comparison-list"><li>Gardevoir</li><li>Hitmonchan</li><li>Heatmor</li><li>Meloetta</li><li>Keldeo Resolute</li><li>Golurk</li><li>Golurk</li><li>Breloom</li><li>Doduo</li><li>Golurk</li><li>Electivire</li><li>Eelektross</li><li>Venusaur</li><li>Infernape</li><li>Sudowoodo</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `268` |

Source: exact ROM record from `a/0/2/4` member `268`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/245/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../wise-glasses/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wise-glasses.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Wise Glasses</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Light Clay →</span></a>
</nav>
