# Greet Mail

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/greet-mail.png" alt="Greet Mail icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>137</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>All Mail</dd></div>
<div><dt>Base price</dt><dd>₽50</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Lets a Trainer write a message and send it via Pokémon trade.</strong></p>
<p>Used to send short messages to other players via Pokémon trading. Trainer may compose a message from a finite list of words when giving this item to a Pokémon. Once taken and read, a message may be erased and this item can be reused, or the message may be stored in the trainer’s PC. Held : Holder cannot be placed in the PC. Any move attempting to remove this item from the holder will fail.</p>

<figure class="rw-pokedex-entry">
<blockquote>Stationery designed for introductory greetings. Let a Pokémon hold it for delivery.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Mail</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>7</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Black City](../locations/header-001.md) | — | `header-001` | Black City/White Forest Secondary | ₽50 | Post-game |
| [Nacrene City](../locations/header-020.md) | — | `header-020` | Nacrene Secondary | ₽50 | Post-game |
| [Icirrus City](../locations/header-115.md) | — | `header-115` | Icirrus Secondary | ₽50 | Post-game |
| [Opelucid City](../locations/header-122.md) | — | `header-122` | Opelucid Secondary | ₽50 | Main game |
| [Accumula Town](../locations/header-398.md) | — | `header-398` | Accumula Secondary | ₽50 | Post-game |
| [Undella Town](../locations/header-413.md) | — | `header-413` | Undella Secondary | ₽50 | Main game |
| [White Forest](../locations/header-425.md) | — | `header-425` | Black City/White Forest Secondary | ₽50 | Post-game |
| [Aspertia City](../locations/header-435.md) | — | `header-435` | Aspertia Secondary | ₽50 | Main game |
| [Floccesy Town](../locations/header-443.md) | — | `header-443` | Floccesy Secondary | ₽50 | Main game |
| [Virbank City](../locations/header-454.md) | — | `header-454` | Virbank Secondary | ₽50 | Main game |
| [Humilau City](../locations/header-472.md) | — | `header-472` | Humilau Secondary | ₽50 | Main game |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Shopping Mall</li><li>Castelia City</li><li>Lentimas Town</li><li>Driftveil City</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `137` |

Source: exact ROM record from `a/0/2/4` member `137`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/568/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../lustrous-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lustrous-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Lustrous Orb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../favored-mail/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/favored-mail.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Favored Mail →</span></a>
</nav>
