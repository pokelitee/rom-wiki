# Elixir

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/elixir.png" alt="Elixir icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>40</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Pp Recovery</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 10 PP for each move.</strong></p>
<p>Used on a party Pokémon : Restores 10 PP for each move.</p>

<figure class="rw-pokedex-entry">
<blockquote>It restores the PP of all the moves learned by the targeted Pokémon by 10 points each.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>PP amount 10</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Dragonspiral Tower](../locations/header-209.md) | — | `header-209` | Visible | (19, 5) |
| [Celestial Tower](../locations/header-339.md) | — | `header-339` | Visible | (7, 16) |
| [Route 9](../locations/header-348.md) | — | `header-348` | Visible | (344, 187) |
| [Reversal Mountain](../locations/header-533.md) | — | `header-533` | Hidden | (89, 57) |
| [Reversal Mountain](../locations/header-539.md) | — | `header-539` | Hidden | (39, 16) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `40` |

Source: exact ROM record from `a/0/2/4` member `40`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/40/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-ether/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-ether.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Ether</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-elixir/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-elixir.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Elixir →</span></a>
</nav>
