# Charcoal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/charcoal.png" alt="Charcoal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>249</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Type Enhancement</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Fire-Type moves from holder do 20% more damage.</strong></p>
<p>Held: Increases the power of the holder’s Fire moves by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a combustible fuel that boosts the power of Fire-type moves.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>84</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Castelia City](../locations/header-038.md) | — | `header-038` | Visible | (19, 26) |
| [Reversal Mountain](../locations/header-531.md) | — | `header-531` | Visible | (15, 15) |
| [Reversal Mountain](../locations/header-537.md) | — | `header-537` | Visible | (15, 15) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Subway Boss Ingo](../trainers/trainer-0732.md) | Held by Chandelure |
| [Team Plasma Grunt](../trainers/trainer-0807.md) | Held by Pidgeot |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Castelia City</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Reversal Mountain</li><li>Reversal Mountain</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/simisear/">Simisear</a></li><li><a href="../../pokemon/pignite/">Pignite</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/simisear/">Simisear</a></li><li><a href="../../pokemon/simisear/">Simisear</a></li><li><a href="../../pokemon/simisear/">Simisear</a></li><li><a href="../../pokemon/simisear/">Simisear</a></li><li><a href="../../pokemon/simisear/">Simisear</a></li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/pidgeot/">Pidgeot</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `249` |

Source: exact ROM record from `a/0/2/4` member `249`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/226/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../twisted-spoon/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/twisted-spoon.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Twisted Spoon</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../dragon-fang/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dragon-fang.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Dragon Fang →</span></a>
</nav>
