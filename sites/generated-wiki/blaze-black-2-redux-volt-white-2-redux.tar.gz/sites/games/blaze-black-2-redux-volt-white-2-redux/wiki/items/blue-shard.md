# Blue Shard

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="Blue Shard icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>73</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Collectibles</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>No effect. Can be traded for items or moves.</strong></p>
<p>No effect. In Diamond and Pearl, trade ten for a Rain Dance TM in the house midway along the southern section of Route 212. In Platinum, trade to move tutors on Route 212, in Snowpoint City, and in the Survival Area. Eight shards total are required per tutelage, but the particular combination of colors varies by move. In HeartGold and SoulSilver, trade one for a Chesto Berry, an Oran Berry, and a Wiki Berry with the Juggler near the Pokémon Center in Violet City. In HeartGold and SoulSilver, trade one for a Bluk Berry, a Cornn Berry, and a Kelpsy Berry with the Juggler near the Pal Park entrance in Fuchsia City.</p>

<figure class="rw-pokedex-entry">
<blockquote>A small blue shard. It appears to be from some sort of implement made long ago.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Dragonspiral Tower](../locations/header-207.md) | — | `header-207` | Hidden | (65, 65) |
| [Route 1](../locations/header-317.md) | — | `header-317` | Hidden | (6, 7) |
| [Route 11](../locations/header-367.md) | — | `header-367` | Hidden | (58, 24) |
| [Bridge Gate](../locations/header-369.md) | — | `header-369` | Hidden | (15, 28) |
| [Accumula Town](../locations/header-401.md) | — | `header-401` | Hidden | (4, 11) |
| [Underground Ruins](../locations/header-610.md) | — | `header-610` | Visible | (1279, 1279) |
| [Underground Ruins](../locations/header-610.md) | — | `header-610` | Hidden | (701, 720) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Driftveil City](../locations/header-099.md) | — | `header-099` | Driftveil Secondary | ₽600 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Worker Matthew](../trainers/trainer-0007.md) | Victory reward |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">200<span class="rw-diff-arrow">→</span>600</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Dragonspiral Tower</li><li>Route 13</li><li>Underground Ruins</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Underground Ruins</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Driftveil City</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `73` |

Source: exact ROM record from `a/0/2/4` member `73`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/73/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../red-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Red Shard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../yellow-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Yellow Shard →</span></a>
</nav>
