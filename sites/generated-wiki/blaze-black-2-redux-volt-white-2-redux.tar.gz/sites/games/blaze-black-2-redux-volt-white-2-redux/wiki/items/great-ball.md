# Great Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="Great Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>3</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Standard Balls</dd></div>
<div><dt>Base price</dt><dd>₽150</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Success rate is 1.5×.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1.5×. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A good, high-performance Ball that provides a higher Pokémon catch rate than a standard Poké Ball.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 20](../locations/header-446.md) | — | `header-446` | Visible | (153, 700) |
| [Virbank Gate](../locations/header-447.md) | — | `header-447` | Script Awarded | — |
| [Virbank Complex](../locations/header-456.md) | — | `header-456` | Script Awarded | — |
| [Inner Complex](../locations/header-457.md) | — | `header-457` | Hidden | (26, 29) |
| [Floccesy Ranch](../locations/header-445.md) | — | `header-445` | Hidden Grotto Visible | — |
| [Floccesy Ranch](../locations/header-445.md) | — | `header-445` | Hidden Grotto Visible | — |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden Grotto Visible | — |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden Grotto Visible | — |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden Grotto Visible | — |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden Grotto Visible | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Visible | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Visible | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Visible | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Visible | — |
| [Route 7](../locations/header-337.md) | — | `header-337` | Hidden Grotto Visible | — |
| [Route 7](../locations/header-337.md) | — | `header-337` | Hidden Grotto Visible | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Visible | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Visible | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Visible | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Visible | — |
| [Route 9](../locations/header-348.md) | — | `header-348` | Hidden Grotto Visible | — |
| [Route 9](../locations/header-348.md) | — | `header-348` | Hidden Grotto Visible | — |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Hidden Grotto Visible | — |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Hidden Grotto Visible | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden Grotto Visible | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden Grotto Visible | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden Grotto Visible | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden Grotto Visible | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Visible | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Visible | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Visible | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-154.md) | — | `header-154` | Hidden Grotto Visible | — |
| [Pinwheel Forest](../locations/header-154.md) | — | `header-154` | Hidden Grotto Visible | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Visible | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Visible | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Visible | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Visible | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Hidden Grotto Visible | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Hidden Grotto Visible | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Hidden Grotto Visible | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Hidden Grotto Visible | — |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">600<span class="rw-diff-arrow">→</span>150</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Virbank Gate</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Virbank Gate</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `3` |

Source: exact ROM record from `a/0/2/4` member `3`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/3/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ultra-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ultra Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../poke-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Poké Ball →</span></a>
</nav>
