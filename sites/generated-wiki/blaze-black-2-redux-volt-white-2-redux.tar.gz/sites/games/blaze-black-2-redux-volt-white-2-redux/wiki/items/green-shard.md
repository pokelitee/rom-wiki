# Green Shard

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="Green Shard icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>75</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Collectibles</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>No effect. Can be traded for items or moves.</strong></p>
<p>No effect. In Diamond and Pearl, trade ten for a Hail TM in the house midway along the southern section of Route 212. In Platinum, trade to move tutors on Route 212, in Snowpoint City, and in the Survival Area. Eight shards total are required per tutelage, but the particular combination of colors varies by move. In HeartGold and SoulSilver, trade one for an Aguav Berry, a Lum Berry, and a Rawst Berry with the Juggler near the Pokémon Center in Violet City. In HeartGold and SoulSilver, trade one for a Durin Berry, a Hondew Berry, and a Wepear Berry with the Juggler near the Pal Park entrance in Fuchsia City.</p>

<figure class="rw-pokedex-entry">
<blockquote>A small green shard. It appears to be from some sort of implement made long ago.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Entree Forest — map_281](../locations/header-281.md) | Hidden | (40, 7) |
| [Route 13 — map_370](../locations/header-370.md) | Visible | (5, 56) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Driftveil City — map_99](../locations/header-099.md) | Driftveil Secondary | ₽600 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Janitor Caleb](../trainers/trainer-0115.md) | Victory reward |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">200<span class="rw-diff-arrow">→</span>600</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Driftveil City</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `75` |

Source: exact ROM record from `a/0/2/4` member `75`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/75/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../yellow-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Yellow Shard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-repel/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Repel →</span></a>
</nav>
