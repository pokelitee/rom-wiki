# Ganlon Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ganlon-berry.png" alt="Ganlon Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>202</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>In A Pinch</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed at 1/4 max HP to boost Defense.</strong></p>
<p>Held in battle : When the holder has 1/4 its max HP remaining or less, it consumes this item to raise its Defense by one stage.</p>

<figure class="rw-pokedex-entry">
<blockquote>If held by a Pokémon, it raises its Defense stat in a pinch.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>3</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>37</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Pluck effect ID</dt><dd>17</dd></div>
<div><dt>Fling effect ID</dt><dd>17</dd></div>
<div><dt>Natural Gift</dt><dd>80 power, <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span></dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Aspertia City](../locations/header-428.md) | — | `header-428` | Script Awarded | — |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Aspertia City</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/suicune/">Suicune</a></li><li><a href="../../pokemon/cresselia/">Cresselia</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `202` |

Source: exact ROM record from `a/0/2/4` member `202`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/179/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../liechi-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/liechi-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Liechi Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../salac-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/salac-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Salac Berry →</span></a>
</nav>
