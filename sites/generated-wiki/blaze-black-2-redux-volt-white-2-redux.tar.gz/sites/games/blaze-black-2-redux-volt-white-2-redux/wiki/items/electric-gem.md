# Electric Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/electric-gem.png" alt="Electric Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>550</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Electric-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Electric-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an essence of electricity. When held, it strengthens the power of an Electric-type move only once.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Aspertia City](../locations/header-428.md) | — | `header-428` | Script Awarded | — |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Boss Trainer Freira](../trainers/trainer-0194.md) | Held by Thundurus Therian |
| [GAME FREAK Morimoto](../trainers/trainer-0592.md) | Held by Blitzle |
| [Ace Trainer Kathrine](../trainers/trainer-0636.md) | Held by Minun |
| [⒆⒇ Trainer Winona](../trainers/trainer-0837.md) | Held by Rotom Fan |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Twist Mountain</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Aspertia City</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/minun/">Minun</a></li><li><a href="../../pokemon/thundurus-incarnate/">Thundurus Therian</a></li><li><a href="../../pokemon/blitzle/">Blitzle</a></li><li><a href="../../pokemon/rotom/">Rotom Fan</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `550` |

Source: exact ROM record from `a/0/2/4` member `550`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/593/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../water-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Water Gem</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../grass-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grass-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Grass Gem →</span></a>
</nav>
