# Eviolite

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/eviolite.png" alt="Eviolite icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>538</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">40</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder has 1.5× Defense and Special Defense, as long as it’s not fully evolved.</strong></p>
<p>Held by a Pokémon that is not fully evolved : Holder has 1.5× Defense and Special Defense.</p>

<figure class="rw-pokedex-entry">
<blockquote>A mysterious evolutionary lump. When held, it raises the Defense and Sp. Def of a Pokémon that can still evolve.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Route 9](../locations/header-350.md) | Shopping Mall 9 F1 | ₽200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Elesa](../trainers/trainer-0154.md) | Held by Dwebble |
| [Leader Skyla](../trainers/trainer-0156.md) | Held by Munchlax |
| [Leader Cheren](../trainers/trainer-0157.md) | Held by Trubbish |
| [⒆⒇ Trainer Nishino](../trainers/trainer-0358.md) | Held by Porygon2 |
| [Veteran Rival](../trainers/trainer-0381.md) | Held by Fraxure |
| [Veteran Rival](../trainers/trainer-0381.md) | Held by Zweilous |
| [Veteran Rival](../trainers/trainer-0381.md) | Held by Servine |
| [Veteran Rival](../trainers/trainer-0381.md) | Held by Vibrava |
| [Veteran Jerry](../trainers/trainer-0383.md) | Held by Dragonair |
| [Veteran Rhona](../trainers/trainer-0384.md) | Held by Gible |
| [Veteran Rhona](../trainers/trainer-0384.md) | Held by Gabite |
| [Veteran Ron](../trainers/trainer-0385.md) | Held by Bagon |
| [Veteran Ron](../trainers/trainer-0385.md) | Held by Shelgon |
| [Ace Trainer Cliff](../trainers/trainer-0493.md) | Held by Dusclops |
| [Veteran Julia](../trainers/trainer-0534.md) | Held by Porygon2 |
| [Veteran Julia](../trainers/trainer-0534.md) | Held by Rhydon |
| [GAME FREAK Rival](../trainers/trainer-0591.md) | Held by Porygon2 |
| [Leader Cheren](../trainers/trainer-0765.md) | Held by Koffing |
| [Leader Cheren](../trainers/trainer-0765.md) | Held by Whirlipede |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Held by Magneton |
| [Veteran Wallace](../trainers/trainer-0844.md) | Held by Loudred |
| [⒆⒇ Trainer Brycen](../trainers/trainer-0848.md) | Held by Spheal |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 9</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Magneton</li><li>Magneton</li></ul><p class="rw-comparison-count">22 entries added</p><ul class="rw-comparison-list"><li>Dusclops</li><li>Porygon2</li><li>Koffing</li><li>Whirlipede</li><li>Trubbish</li><li>Dwebble</li><li>Munchlax</li><li>Dragonair</li><li>Rhydon</li><li>Porygon2</li><li>Gible</li><li>Gabite</li><li>Vibrava</li><li>Servine</li><li>Fraxure</li><li>Zweilous</li><li>Bagon</li><li>Shelgon</li><li>Loudred</li><li>Spheal</li><li>Porygon2</li><li>Magneton</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `538` |

Source: exact ROM record from `a/0/2/4` member `538`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/581/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../prism-scale/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/prism-scale.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Prism Scale</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../float-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/float-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Float Stone →</span></a>
</nav>
