# Bug Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/bug-gem.png" alt="Bug Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>558</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Bug-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Bug-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an insect-like essence. When held, it strengthens the power of a Bug-type move only once.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Team Plasma Zinzolin](../trainers/trainer-0498.md) | Held by Accelgor |
| [Veteran Julia](../trainers/trainer-0534.md) | Held by Scizor |
| [Black Belt Caroll](../trainers/trainer-0607.md) | Held by Pinsir |
| [Leader Roxie](../trainers/trainer-0766.md) | Held by Masquerain |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Pinsir</li><li>Masquerain</li><li>Accelgor</li><li>Scizor</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `558` |

Source: exact ROM record from `a/0/2/4` member `558`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/601/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../psychic-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/psychic-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Psychic Gem</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rock-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rock-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Rock Gem →</span></a>
</nav>
