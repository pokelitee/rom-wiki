# Damp Rock

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-rock.png" alt="Damp Rock icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>285</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">60</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Rain Dance by the holder lasts 8 rounds instead of 5.</strong></p>
<p>Held: The holder’s Rain Dance will create rain lasting for eight turns rather than five. As this item affects the move rather than the weather itself, the effect is not lost if the holder leaves battle or drops this item.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Pokémon held item that extends the duration of the move Rain Dance used by the holder.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>113</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Lentimas Town](../locations/header-460.md) | — | `header-460` | Lentimas Secondary | ₽200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Ace Trainer Jeanne](../trainers/trainer-0353.md) | Held by Mantine |
| [Ace Trainer Jeanne](../trainers/trainer-0353.md) | Held by Ludicolo |
| [⒆⒇ Trainer Juan](../trainers/trainer-0834.md) | Held by Whiscash |
| [⒆⒇ Trainer Clair](../trainers/trainer-0860.md) | Held by Kingdra |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Lentimas Town</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/omastar/">Omastar</a></li><li><a href="../../pokemon/tentacruel/">Tentacruel</a></li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/mantine/">Mantine</a></li><li><a href="../../pokemon/ludicolo/">Ludicolo</a></li><li><a href="../../pokemon/kingdra/">Kingdra</a></li><li><a href="../../pokemon/whiscash/">Whiscash</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `285` |

Source: exact ROM record from `a/0/2/4` member `285`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/262/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../heat-rock/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/heat-rock.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Heat Rock</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../grip-claw/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grip-claw.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Grip Claw →</span></a>
</nav>
