# Growth Mulch

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/growth-mulch.png" alt="Growth Mulch icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>95</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Mulch</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Growing time of berries is reduced, but the soil dries out faster.</strong></p>
<p>Used on a patch of soil : Plant’s growth stages will each last 25% less time. Dries soil out more quickly.</p>

<figure class="rw-pokedex-entry">
<blockquote>A fertilizer to be spread on soft soil in regions where Berries are grown. A maniac will buy it for a high price.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Floccesy Ranch](../locations/header-445.md) | — | `header-445` | Hidden Grotto Hidden | — |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden Grotto Hidden | — |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden Grotto Hidden | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Hidden | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Hidden | — |
| [Route 7](../locations/header-337.md) | — | `header-337` | Hidden Grotto Hidden | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Hidden | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Hidden | — |
| [Route 9](../locations/header-348.md) | — | `header-348` | Hidden Grotto Hidden | — |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Hidden Grotto Hidden | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden Grotto Hidden | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden Grotto Hidden | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Hidden | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Hidden | — |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden Grotto Hidden | — |
| [Pinwheel Forest](../locations/header-154.md) | — | `header-154` | Hidden Grotto Hidden | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Hidden | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Hidden | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Hidden Grotto Hidden | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Hidden Grotto Hidden | — |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `95` |

Source: exact ROM record from `a/0/2/4` member `95`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/95/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../honey/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/honey.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Honey</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../damp-mulch/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Damp Mulch →</span></a>
</nav>
