# Changes from base game

Every supported ROM dataset is compared with the configured clean base ROM. Unchanged records remain visible on their detail pages.

| Section | Unchanged | Changed | Added | Removed |
| ------- | --------: | ------: | ----: | ------: |
| [Pokémon](#pokemon) | 35 | 674 | 0 | 0 |
| [Abilities](#abilities) | 15 | 149 | 0 | 0 |
| [Moves](#moves) | 322 | 238 | 0 | 0 |
| [Items](#items) | 377 | 241 | 1 | 0 |
| [Wild encounters](#wild-encounters) | 0 | 174 | 0 | 0 |
| [Trainers](#trainers) | 60 | 753 | 77 | 0 |
| [Locations](#locations) | 514 | 101 | 2 | 0 |

## Pokémon

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Bulbasaur](../pokemon/bulbasaur.md) | Changed | Abilities, Machines, Level-up moves |
| [Ivysaur](../pokemon/ivysaur.md) | Changed | Abilities, Machines, Level-up moves |
| [Venusaur](../pokemon/venusaur.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Charmander](../pokemon/charmander.md) | Changed | Abilities, Machines, Level-up moves |
| [Charmeleon](../pokemon/charmeleon.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Charizard](../pokemon/charizard.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Squirtle](../pokemon/squirtle.md) | Changed | Abilities, Machines, Level-up moves |
| [Wartortle](../pokemon/wartortle.md) | Changed | Abilities, Machines, Level-up moves |
| [Blastoise](../pokemon/blastoise.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Caterpie](../pokemon/caterpie.md) | Changed | Abilities, Level-up moves |
| [Metapod](../pokemon/metapod.md) | Changed | Abilities, Level-up moves |
| [Butterfree](../pokemon/butterfree.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Weedle](../pokemon/weedle.md) | Changed | Abilities, Level-up moves |
| [Kakuna](../pokemon/kakuna.md) | Changed | Abilities, Level-up moves |
| [Beedrill](../pokemon/beedrill.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pidgey](../pokemon/pidgey.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pidgeotto](../pokemon/pidgeotto.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pidgeot](../pokemon/pidgeot.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Rattata](../pokemon/rattata.md) | Changed | Abilities, Machines, Level-up moves |
| [Raticate](../pokemon/raticate.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Spearow](../pokemon/spearow.md) | Changed | Base stats, Types, Abilities, Evolutions, Machines, Level-up moves |
| [Fearow](../pokemon/fearow.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Ekans](../pokemon/ekans.md) | Changed | Evolutions, Machines, Level-up moves |
| [Arbok](../pokemon/arbok.md) | Changed | Base stats, Machines, Level-up moves |
| [Pikachu](../pokemon/pikachu.md) | Changed | Base stats, Abilities, Base friendship, Machines, Level-up moves |
| [Raichu](../pokemon/raichu.md) | Changed | Base stats, Abilities, Base friendship, Machines, Level-up moves |
| [Sandshrew](../pokemon/sandshrew.md) | Changed | Abilities, Machines, Level-up moves |
| [Sandslash](../pokemon/sandslash.md) | Changed | Abilities, Machines, Level-up moves |
| [Nidoran⑮](../pokemon/nidoran-f.md) | Changed | Abilities, Machines, Level-up moves |
| [Nidorina](../pokemon/nidorina.md) | Changed | Abilities, Machines, Level-up moves |
| [Nidoqueen](../pokemon/nidoqueen.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Nidoran⑭](../pokemon/nidoran-m.md) | Changed | Abilities, Machines, Level-up moves |
| [Nidorino](../pokemon/nidorino.md) | Changed | Abilities, Machines, Level-up moves |
| [Nidoking](../pokemon/nidoking.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Clefairy](../pokemon/clefairy.md) | Changed | Types, Machines, Level-up moves |
| [Clefable](../pokemon/clefable.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Vulpix](../pokemon/vulpix.md) | Changed | Abilities, Machines, Level-up moves |
| [Ninetales](../pokemon/ninetales.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Jigglypuff](../pokemon/jigglypuff.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Wigglytuff](../pokemon/wigglytuff.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Zubat](../pokemon/zubat.md) | Changed | Abilities, Machines, Level-up moves |
| [Golbat](../pokemon/golbat.md) | Changed | Abilities, Machines, Level-up moves |
| [Oddish](../pokemon/oddish.md) | Changed | Abilities, Machines, Level-up moves |
| [Gloom](../pokemon/gloom.md) | Changed | Abilities, Machines, Level-up moves |
| [Vileplume](../pokemon/vileplume.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Paras](../pokemon/paras.md) | Changed | Machines, Level-up moves |
| [Parasect](../pokemon/parasect.md) | Changed | Base stats, Machines, Level-up moves |
| [Venonat](../pokemon/venonat.md) | Changed | Base stats, Evolutions, Machines, Level-up moves |
| [Venomoth](../pokemon/venomoth.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Diglett](../pokemon/diglett.md) | Changed | Abilities, Machines, Level-up moves |
| [Dugtrio](../pokemon/dugtrio.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Meowth](../pokemon/meowth.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Persian](../pokemon/persian.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Psyduck](../pokemon/psyduck.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Golduck](../pokemon/golduck.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Mankey](../pokemon/mankey.md) | Changed | Abilities, Machines, Level-up moves |
| [Primeape](../pokemon/primeape.md) | Changed | Abilities, Machines, Level-up moves |
| [Growlithe](../pokemon/growlithe.md) | Changed | Machines, Level-up moves |
| [Arcanine](../pokemon/arcanine.md) | Changed | Machines, Level-up moves |
| [Poliwag](../pokemon/poliwag.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Poliwhirl](../pokemon/poliwhirl.md) | Changed | Abilities, Evolutions, Machines, Move tutors, Level-up moves |
| [Poliwrath](../pokemon/poliwrath.md) | Changed | Base stats, Abilities, Machines, Move tutors, Level-up moves |
| [Abra](../pokemon/abra.md) | Changed | Abilities, Machines, Level-up moves |
| [Kadabra](../pokemon/kadabra.md) | Changed | Abilities, Sprite orientation, Evolutions, Machines, Level-up moves |
| [Alakazam](../pokemon/alakazam.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Machop](../pokemon/machop.md) | Changed | Abilities, Machines, Level-up moves |
| [Machoke](../pokemon/machoke.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Machamp](../pokemon/machamp.md) | Changed | Sprite orientation, Machines, Level-up moves |
| [Bellsprout](../pokemon/bellsprout.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Weepinbell](../pokemon/weepinbell.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Victreebel](../pokemon/victreebel.md) | Changed | Base stats, Abilities, Machines, Move tutors, Level-up moves |
| [Tentacool](../pokemon/tentacool.md) | Changed | Abilities, Machines, Level-up moves |
| [Tentacruel](../pokemon/tentacruel.md) | Changed | Abilities, Machines, Level-up moves |
| [Geodude](../pokemon/geodude.md) | Changed | Machines, Level-up moves |
| [Graveler](../pokemon/graveler.md) | Changed | Evolutions, Machines, Level-up moves |
| [Golem](../pokemon/golem.md) | Changed | Base stats, Machines, Level-up moves |
| [Ponyta](../pokemon/ponyta.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Rapidash](../pokemon/rapidash.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Slowpoke](../pokemon/slowpoke.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Slowbro](../pokemon/slowbro.md) | Changed | Abilities, Machines, Level-up moves |
| [Magnemite](../pokemon/magnemite.md) | Changed | Abilities, Machines, Level-up moves |
| [Magneton](../pokemon/magneton.md) | Changed | Abilities, Machines, Level-up moves |
| [Farfetch'd](../pokemon/farfetchd.md) | Changed | Base stats, Types, Abilities, Base experience, EV yield, Machines, Level-up moves |
| [Doduo](../pokemon/doduo.md) | Changed | Abilities, Machines, Level-up moves |
| [Dodrio](../pokemon/dodrio.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Seel](../pokemon/seel.md) | Changed | Machines, Level-up moves |
| [Dewgong](../pokemon/dewgong.md) | Changed | Base stats, Machines, Level-up moves |
| [Grimer](../pokemon/grimer.md) | Changed | Base stats, Abilities, Evolutions, Machines, Level-up moves |
| [Muk](../pokemon/muk.md) | Changed | Abilities, Machines, Level-up moves |
| [Shellder](../pokemon/shellder.md) | Changed | Types, Machines, Level-up moves |
| [Cloyster](../pokemon/cloyster.md) | Changed | Machines, Level-up moves |
| [Gastly](../pokemon/gastly.md) | Changed | Abilities, Machines, Level-up moves |
| [Haunter](../pokemon/haunter.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Gengar](../pokemon/gengar.md) | Changed | Abilities, Machines, Level-up moves |
| [Onix](../pokemon/onix.md) | Changed | Base stats, Abilities, Evolutions, Machines, Level-up moves |
| [Drowzee](../pokemon/drowzee.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Hypno](../pokemon/hypno.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Krabby](../pokemon/krabby.md) | Changed | Abilities, Machines, Level-up moves |
| [Kingler](../pokemon/kingler.md) | Changed | Abilities, Machines, Level-up moves |
| [Voltorb](../pokemon/voltorb.md) | Changed | Base stats, Machines, Level-up moves |
| [Electrode](../pokemon/electrode.md) | Changed | Base stats, Machines, Level-up moves |
| [Exeggcute](../pokemon/exeggcute.md) | Changed | Abilities, Machines, Level-up moves |
| [Exeggutor](../pokemon/exeggutor.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Cubone](../pokemon/cubone.md) | Changed | Abilities, Wild held items, Evolutions, Machines, Level-up moves |
| [Marowak](../pokemon/marowak.md) | Changed | Abilities, Machines, Level-up moves |
| [Hitmonlee](../pokemon/hitmonlee.md) | Changed | Abilities, Machines, Level-up moves |
| [Hitmonchan](../pokemon/hitmonchan.md) | Changed | Abilities, Machines, Level-up moves |
| [Lickitung](../pokemon/lickitung.md) | Changed | Abilities, Machines, Level-up moves |
| [Koffing](../pokemon/koffing.md) | Changed | Machines, Level-up moves |
| [Weezing](../pokemon/weezing.md) | Changed | Machines, Level-up moves |
| [Rhyhorn](../pokemon/rhyhorn.md) | Changed | Evolutions, Machines, Level-up moves |
| [Rhydon](../pokemon/rhydon.md) | Changed | Evolutions, Machines, Level-up moves |
| [Chansey](../pokemon/chansey.md) | Changed | Machines, Level-up moves |
| [Tangela](../pokemon/tangela.md) | Changed | Abilities, Machines, Level-up moves |
| [Kangaskhan](../pokemon/kangaskhan.md) | Changed | Machines, Level-up moves |
| [Horsea](../pokemon/horsea.md) | Changed | Machines, Level-up moves |
| [Seadra](../pokemon/seadra.md) | Changed | Evolutions, Machines, Level-up moves |
| [Goldeen](../pokemon/goldeen.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Seaking](../pokemon/seaking.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Staryu](../pokemon/staryu.md) | Changed | Abilities, Machines, Level-up moves |
| [Starmie](../pokemon/starmie.md) | Changed | Abilities, Machines, Level-up moves |
| [Mr. Mime](../pokemon/mr-mime.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Scyther](../pokemon/scyther.md) | Changed | Evolutions, Machines, Level-up moves |
| [Jynx](../pokemon/jynx.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Electabuzz](../pokemon/electabuzz.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Magmar](../pokemon/magmar.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Pinsir](../pokemon/pinsir.md) | Changed | Abilities, Machines, Level-up moves |
| [Tauros](../pokemon/tauros.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Magikarp](../pokemon/magikarp.md) | Changed | Abilities, Level-up moves |
| [Gyarados](../pokemon/gyarados.md) | Changed | Abilities, Machines, Level-up moves |
| [Lapras](../pokemon/lapras.md) | Changed | Machines, Level-up moves |
| [Ditto](../pokemon/ditto.md) | Changed | Abilities |
| [Eevee](../pokemon/eevee.md) | Changed | Abilities, Gender ratio, Evolutions, Machines, Level-up moves |
| [Vaporeon](../pokemon/vaporeon.md) | Changed | Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Jolteon](../pokemon/jolteon.md) | Changed | Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Flareon](../pokemon/flareon.md) | Changed | Base stats, Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Porygon](../pokemon/porygon.md) | Changed | Evolutions, Machines, Level-up moves |
| [Omanyte](../pokemon/omanyte.md) | Changed | Evolutions, Machines, Level-up moves |
| [Omastar](../pokemon/omastar.md) | Changed | Machines, Level-up moves |
| [Kabuto](../pokemon/kabuto.md) | Changed | Evolutions, Machines, Level-up moves |
| [Kabutops](../pokemon/kabutops.md) | Changed | Machines, Level-up moves |
| [Aerodactyl](../pokemon/aerodactyl.md) | Changed | EV yield, Machines, Level-up moves |
| [Snorlax](../pokemon/snorlax.md) | Changed | Wild held items, Machines, Level-up moves |
| [Articuno](../pokemon/articuno.md) | Changed | Abilities, Machines, Level-up moves |
| [Zapdos](../pokemon/zapdos.md) | Changed | Abilities, Machines, Level-up moves |
| [Moltres](../pokemon/moltres.md) | Changed | Abilities, Machines, Level-up moves |
| [Dratini](../pokemon/dratini.md) | Changed | Abilities, Machines, Level-up moves |
| [Dragonair](../pokemon/dragonair.md) | Changed | Abilities, Machines, Level-up moves |
| [Dragonite](../pokemon/dragonite.md) | Changed | Abilities, Machines, Level-up moves |
| [Mewtwo](../pokemon/mewtwo.md) | Changed | Abilities, Machines, Level-up moves |
| [Mew](../pokemon/mew.md) | Changed | Abilities, Level-up moves |
| [Chikorita](../pokemon/chikorita.md) | Changed | Abilities, Machines, Level-up moves |
| [Bayleef](../pokemon/bayleef.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Meganium](../pokemon/meganium.md) | Changed | Base stats, Types, Abilities, Machines, Move tutors, Level-up moves |
| [Cyndaquil](../pokemon/cyndaquil.md) | Changed | Abilities, Machines, Level-up moves |
| [Quilava](../pokemon/quilava.md) | Changed | Abilities, Machines, Level-up moves |
| [Typhlosion](../pokemon/typhlosion.md) | Changed | Base stats, Abilities, Machines, Move tutors, Level-up moves |
| [Totodile](../pokemon/totodile.md) | Changed | Abilities, Machines, Level-up moves |
| [Croconaw](../pokemon/croconaw.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Feraligatr](../pokemon/feraligatr.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Sentret](../pokemon/sentret.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Furret](../pokemon/furret.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Hoothoot](../pokemon/hoothoot.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Noctowl](../pokemon/noctowl.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Ledyba](../pokemon/ledyba.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Ledian](../pokemon/ledian.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Spinarak](../pokemon/spinarak.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Ariados](../pokemon/ariados.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Crobat](../pokemon/crobat.md) | Changed | Abilities, Machines, Level-up moves |
| [Chinchou](../pokemon/chinchou.md) | Changed | Abilities, Machines, Level-up moves |
| [Lanturn](../pokemon/lanturn.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pichu](../pokemon/pichu.md) | Changed | Abilities, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Cleffa](../pokemon/cleffa.md) | Changed | Types, Abilities, Base friendship, Machines, Level-up moves |
| [Igglybuff](../pokemon/igglybuff.md) | Changed | Types, Abilities, Hatch cycles, Base friendship, Machines, Level-up moves |
| [Togepi](../pokemon/togepi.md) | Changed | Types, Abilities, Base friendship, Machines, Level-up moves |
| [Togetic](../pokemon/togetic.md) | Changed | Types, Abilities, Base friendship, Machines, Level-up moves |
| [Natu](../pokemon/natu.md) | Changed | Abilities, Machines, Level-up moves |
| [Xatu](../pokemon/xatu.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mareep](../pokemon/mareep.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Flaaffy](../pokemon/flaaffy.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Ampharos](../pokemon/ampharos.md) | Changed | Base stats, Types, Abilities, Machines, Move tutors, Level-up moves |
| [Bellossom](../pokemon/bellossom.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Marill](../pokemon/marill.md) | Changed | Base stats, Types, Abilities, Base friendship, Evolutions, Machines, Level-up moves |
| [Azumarill](../pokemon/azumarill.md) | Changed | Base stats, Types, Abilities, Base friendship, Machines, Level-up moves |
| [Sudowoodo](../pokemon/sudowoodo.md) | Changed | Base stats, Machines, Level-up moves |
| [Politoed](../pokemon/politoed.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Hoppip](../pokemon/hoppip.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Skiploom](../pokemon/skiploom.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Jumpluff](../pokemon/jumpluff.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Aipom](../pokemon/aipom.md) | Changed | Abilities, Machines, Level-up moves |
| [Sunkern](../pokemon/sunkern.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Sunflora](../pokemon/sunflora.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Yanma](../pokemon/yanma.md) | Changed | Machines, Level-up moves |
| [Wooper](../pokemon/wooper.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Quagsire](../pokemon/quagsire.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Espeon](../pokemon/espeon.md) | Changed | Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Umbreon](../pokemon/umbreon.md) | Changed | Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Murkrow](../pokemon/murkrow.md) | Changed | Abilities, Machines, Level-up moves |
| [Slowking](../pokemon/slowking.md) | Changed | Abilities, Machines, Level-up moves |
| [Misdreavus](../pokemon/misdreavus.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Unown](../pokemon/unown.md) | Changed | Base stats, Catch Rate, Level-up moves |
| [Wobbuffet](../pokemon/wobbuffet.md) | Changed | Abilities, Level-up moves |
| [Girafarig](../pokemon/girafarig.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pineco](../pokemon/pineco.md) | Changed | Abilities, Machines, Level-up moves |
| [Forretress](../pokemon/forretress.md) | Changed | Abilities, Machines, Level-up moves |
| [Dunsparce](../pokemon/dunsparce.md) | Changed | Base stats, Machines, Level-up moves |
| [Gligar](../pokemon/gligar.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Steelix](../pokemon/steelix.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Snubbull](../pokemon/snubbull.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Granbull](../pokemon/granbull.md) | Changed | Types, Machines, Level-up moves |
| [Qwilfish](../pokemon/qwilfish.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Scizor](../pokemon/scizor.md) | Changed | Machines, Level-up moves |
| [Shuckle](../pokemon/shuckle.md) | Changed | Abilities, Machines, Level-up moves |
| [Heracross](../pokemon/heracross.md) | Changed | Abilities, Machines, Level-up moves |
| [Sneasel](../pokemon/sneasel.md) | Changed | Evolutions, Machines, Level-up moves |
| [Teddiursa](../pokemon/teddiursa.md) | Changed | Types, Hatch cycles, Machines, Level-up moves |
| [Ursaring](../pokemon/ursaring.md) | Changed | Types, Machines, Level-up moves |
| [Slugma](../pokemon/slugma.md) | Changed | Base stats, Types, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Magcargo](../pokemon/magcargo.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Swinub](../pokemon/swinub.md) | Changed | Abilities, Growth rate, Evolutions, Machines, Level-up moves |
| [Piloswine](../pokemon/piloswine.md) | Changed | Abilities, Growth rate, Machines, Level-up moves |
| [Corsola](../pokemon/corsola.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Remoraid](../pokemon/remoraid.md) | Changed | Machines, Level-up moves |
| [Octillery](../pokemon/octillery.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Delibird](../pokemon/delibird.md) | Changed | Base stats, Abilities, Base experience, EV yield, Machines, Level-up moves |
| [Mantine](../pokemon/mantine.md) | Changed | Base stats, EV yield, Machines, Level-up moves |
| [Skarmory](../pokemon/skarmory.md) | Changed | Machines, Level-up moves |
| [Houndour](../pokemon/houndour.md) | Changed | Abilities, Machines, Level-up moves |
| [Houndoom](../pokemon/houndoom.md) | Changed | Abilities, Machines, Level-up moves |
| [Kingdra](../pokemon/kingdra.md) | Changed | Machines, Level-up moves |
| [Phanpy](../pokemon/phanpy.md) | Changed | Abilities, Machines, Level-up moves |
| [Donphan](../pokemon/donphan.md) | Changed | Abilities, Machines, Level-up moves |
| [Porygon2](../pokemon/porygon2.md) | Changed | Evolutions, Machines, Level-up moves |
| [Stantler](../pokemon/stantler.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Smeargle](../pokemon/smeargle.md) | Changed | Machines, Level-up moves |
| [Tyrogue](../pokemon/tyrogue.md) | Changed | Hatch cycles, Machines, Level-up moves |
| [Hitmontop](../pokemon/hitmontop.md) | Changed | Machines, Level-up moves |
| [Smoochum](../pokemon/smoochum.md) | Changed | Base stats, Abilities, Hatch cycles, Machines, Level-up moves |
| [Elekid](../pokemon/elekid.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Magby](../pokemon/magby.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Miltank](../pokemon/miltank.md) | Changed | Machines, Level-up moves |
| [Blissey](../pokemon/blissey.md) | Changed | Machines, Level-up moves |
| [Raikou](../pokemon/raikou.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Entei](../pokemon/entei.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Suicune](../pokemon/suicune.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Larvitar](../pokemon/larvitar.md) | Changed | Abilities, Machines, Level-up moves |
| [Pupitar](../pokemon/pupitar.md) | Changed | Abilities, Machines, Level-up moves |
| [Tyranitar](../pokemon/tyranitar.md) | Changed | Abilities, Machines, Level-up moves |
| [Lugia](../pokemon/lugia.md) | Changed | Abilities, Machines, Level-up moves |
| [Ho-Oh](../pokemon/ho-oh.md) | Changed | Abilities, Machines, Level-up moves |
| [Celebi](../pokemon/celebi.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Treecko](../pokemon/treecko.md) | Changed | Abilities, Machines, Level-up moves |
| [Grovyle](../pokemon/grovyle.md) | Changed | Abilities, Machines, Level-up moves |
| [Sceptile](../pokemon/sceptile.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Torchic](../pokemon/torchic.md) | Changed | Abilities, Machines, Level-up moves |
| [Combusken](../pokemon/combusken.md) | Changed | Abilities, Machines, Level-up moves |
| [Blaziken](../pokemon/blaziken.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mudkip](../pokemon/mudkip.md) | Changed | Abilities, Machines, Level-up moves |
| [Marshtomp](../pokemon/marshtomp.md) | Changed | Abilities, Machines, Level-up moves |
| [Swampert](../pokemon/swampert.md) | Changed | Abilities, Machines, Level-up moves |
| [Poochyena](../pokemon/poochyena.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mightyena](../pokemon/mightyena.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Zigzagoon](../pokemon/zigzagoon.md) | Changed | Base stats, Machines, Level-up moves |
| [Linoone](../pokemon/linoone.md) | Changed | Base stats, Machines, Level-up moves |
| [Wurmple](../pokemon/wurmple.md) | Changed | Abilities, Level-up moves |
| [Silcoon](../pokemon/silcoon.md) | Changed | Abilities, Level-up moves |
| [Beautifly](../pokemon/beautifly.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Cascoon](../pokemon/cascoon.md) | Changed | Abilities, Level-up moves |
| [Dustox](../pokemon/dustox.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Lotad](../pokemon/lotad.md) | Changed | Machines, Level-up moves |
| [Lombre](../pokemon/lombre.md) | Changed | Machines, Level-up moves |
| [Ludicolo](../pokemon/ludicolo.md) | Changed | Machines, Level-up moves |
| [Seedot](../pokemon/seedot.md) | Changed | Abilities, Machines, Level-up moves |
| [Nuzleaf](../pokemon/nuzleaf.md) | Changed | Abilities, Machines, Level-up moves |
| [Shiftry](../pokemon/shiftry.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Taillow](../pokemon/taillow.md) | Changed | Abilities, Machines, Level-up moves |
| [Swellow](../pokemon/swellow.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Wingull](../pokemon/wingull.md) | Changed | Abilities, Machines, Level-up moves |
| [Pelipper](../pokemon/pelipper.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Ralts](../pokemon/ralts.md) | Changed | Base stats, Types, Machines, Level-up moves |
| [Kirlia](../pokemon/kirlia.md) | Changed | Base stats, Types, Machines, Level-up moves |
| [Gardevoir](../pokemon/gardevoir.md) | Changed | Types, Machines, Level-up moves |
| [Surskit](../pokemon/surskit.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Masquerain](../pokemon/masquerain.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Shroomish](../pokemon/shroomish.md) | Changed | Evolutions, Machines, Level-up moves |
| [Breloom](../pokemon/breloom.md) | Changed | Abilities, Machines, Level-up moves |
| [Slakoth](../pokemon/slakoth.md) | Changed | Abilities, Machines, Level-up moves |
| [Vigoroth](../pokemon/vigoroth.md) | Changed | Abilities, Machines, Level-up moves |
| [Slaking](../pokemon/slaking.md) | Changed | Abilities, Machines, Level-up moves |
| [Nincada](../pokemon/nincada.md) | Changed | Abilities, Machines, Level-up moves |
| [Ninjask](../pokemon/ninjask.md) | Changed | Abilities, Machines, Level-up moves |
| [Shedinja](../pokemon/shedinja.md) | Changed | Abilities, Machines, Level-up moves |
| [Whismur](../pokemon/whismur.md) | Changed | Abilities, Machines, Level-up moves |
| [Loudred](../pokemon/loudred.md) | Changed | Abilities, Machines, Level-up moves |
| [Exploud](../pokemon/exploud.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Makuhita](../pokemon/makuhita.md) | Changed | Base stats, Machines, Level-up moves |
| [Hariyama](../pokemon/hariyama.md) | Changed | Machines, Level-up moves |
| [Azurill](../pokemon/azurill.md) | Changed | Base stats, Types, Abilities, Base friendship, Machines, Level-up moves |
| [Nosepass](../pokemon/nosepass.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Skitty](../pokemon/skitty.md) | Changed | Base stats, Abilities, Evolutions, Machines, Level-up moves |
| [Delcatty](../pokemon/delcatty.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Sableye](../pokemon/sableye.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mawile](../pokemon/mawile.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Aron](../pokemon/aron.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Lairon](../pokemon/lairon.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Aggron](../pokemon/aggron.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Meditite](../pokemon/meditite.md) | Changed | Base stats, Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Medicham](../pokemon/medicham.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Electrike](../pokemon/electrike.md) | Changed | Abilities, Machines, Level-up moves |
| [Manectric](../pokemon/manectric.md) | Changed | Abilities, Machines, Level-up moves |
| [Plusle](../pokemon/plusle.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Minun](../pokemon/minun.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Volbeat](../pokemon/volbeat.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Illumise](../pokemon/illumise.md) | Changed | Base stats, Types, Abilities, Growth rate, Machines, Level-up moves |
| [Roselia](../pokemon/roselia.md) | Changed | Base friendship, Machines, Level-up moves |
| [Gulpin](../pokemon/gulpin.md) | Changed | Machines, Level-up moves |
| [Swalot](../pokemon/swalot.md) | Changed | Machines, Level-up moves |
| [Carvanha](../pokemon/carvanha.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Sharpedo](../pokemon/sharpedo.md) | Changed | Abilities, Machines, Level-up moves |
| [Wailmer](../pokemon/wailmer.md) | Changed | Abilities, Machines, Level-up moves |
| [Wailord](../pokemon/wailord.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Numel](../pokemon/numel.md) | Changed | Machines, Level-up moves |
| [Camerupt](../pokemon/camerupt.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Torkoal](../pokemon/torkoal.md) | Changed | Abilities, Machines, Level-up moves |
| [Spoink](../pokemon/spoink.md) | Changed | Machines, Level-up moves |
| [Grumpig](../pokemon/grumpig.md) | Changed | Machines, Level-up moves |
| [Spinda](../pokemon/spinda.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Trapinch](../pokemon/trapinch.md) | Changed | Base stats, Types, Abilities, Evolutions, Machines, Level-up moves |
| [Vibrava](../pokemon/vibrava.md) | Changed | Base stats, Types, EV yield, Evolutions, Machines, Level-up moves |
| [Flygon](../pokemon/flygon.md) | Changed | Base stats, Types, EV yield, Machines, Level-up moves |
| [Cacnea](../pokemon/cacnea.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Cacturne](../pokemon/cacturne.md) | Changed | Abilities, Machines, Level-up moves |
| [Swablu](../pokemon/swablu.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Altaria](../pokemon/altaria.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Zangoose](../pokemon/zangoose.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Seviper](../pokemon/seviper.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Lunatone](../pokemon/lunatone.md) | Changed | Base stats, Machines, Level-up moves |
| [Solrock](../pokemon/solrock.md) | Changed | Base stats, Machines, Level-up moves |
| [Barboach](../pokemon/barboach.md) | Changed | Abilities, Machines, Level-up moves |
| [Whiscash](../pokemon/whiscash.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Corphish](../pokemon/corphish.md) | Changed | Abilities, Machines, Level-up moves |
| [Crawdaunt](../pokemon/crawdaunt.md) | Changed | Abilities, Machines, Level-up moves |
| [Baltoy](../pokemon/baltoy.md) | Changed | Machines, Level-up moves |
| [Claydol](../pokemon/claydol.md) | Changed | Machines, Level-up moves |
| [Lileep](../pokemon/lileep.md) | Changed | Abilities, Base experience, Evolutions, Machines, Level-up moves |
| [Cradily](../pokemon/cradily.md) | Changed | Abilities, Machines, Level-up moves |
| [Anorith](../pokemon/anorith.md) | Changed | Abilities, Base experience, Evolutions, Machines, Level-up moves |
| [Armaldo](../pokemon/armaldo.md) | Changed | Abilities, Machines, Level-up moves |
| [Feebas](../pokemon/feebas.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Milotic](../pokemon/milotic.md) | Changed | Abilities, Machines, Level-up moves |
| [Castform](../pokemon/castform.md) | Changed | Base stats, Machines, Level-up moves |
| [Kecleon](../pokemon/kecleon.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Shuppet](../pokemon/shuppet.md) | Changed | Abilities, Evolutions, Machines, Move tutors, Level-up moves |
| [Banette](../pokemon/banette.md) | Changed | Base stats, Types, Abilities, Machines, Move tutors, Level-up moves |
| [Duskull](../pokemon/duskull.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Dusclops](../pokemon/dusclops.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Tropius](../pokemon/tropius.md) | Changed | Base stats, Base experience, Machines, Level-up moves |
| [Chimecho](../pokemon/chimecho.md) | Changed | Base stats, Base friendship, Machines, Level-up moves |
| [Absol](../pokemon/absol.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Wynaut](../pokemon/wynaut.md) | Changed | Abilities, Level-up moves |
| [Snorunt](../pokemon/snorunt.md) | Changed | Evolutions, Machines, Level-up moves |
| [Glalie](../pokemon/glalie.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Spheal](../pokemon/spheal.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Sealeo](../pokemon/sealeo.md) | Changed | Evolutions, Machines, Level-up moves |
| [Walrein](../pokemon/walrein.md) | Changed | Machines, Level-up moves |
| [Clamperl](../pokemon/clamperl.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Huntail](../pokemon/huntail.md) | Changed | Abilities, Machines, Level-up moves |
| [Gorebyss](../pokemon/gorebyss.md) | Changed | Abilities, Machines, Level-up moves |
| [Relicanth](../pokemon/relicanth.md) | Changed | Abilities, Machines, Level-up moves |
| [Luvdisc](../pokemon/luvdisc.md) | Changed | Base stats, Types, Abilities, Base experience, Wild held items, Machines, Level-up moves |
| [Bagon](../pokemon/bagon.md) | Changed | Abilities, Machines, Level-up moves |
| [Shelgon](../pokemon/shelgon.md) | Changed | Abilities, Machines, Level-up moves |
| [Salamence](../pokemon/salamence.md) | Changed | Abilities, Machines, Level-up moves |
| [Beldum](../pokemon/beldum.md) | Changed | Abilities, Catch Rate, Sprite orientation, Level-up moves |
| [Metang](../pokemon/metang.md) | Changed | Abilities, Catch Rate, Machines, Level-up moves |
| [Metagross](../pokemon/metagross.md) | Changed | Abilities, Catch Rate, Machines, Level-up moves |
| [Regirock](../pokemon/regirock.md) | Changed | Abilities, Machines, Level-up moves |
| [Regice](../pokemon/regice.md) | Changed | Abilities, Machines, Level-up moves |
| [Registeel](../pokemon/registeel.md) | Changed | Abilities, Machines, Level-up moves |
| [Latias](../pokemon/latias.md) | Changed | Wild held items, Machines, Level-up moves |
| [Latios](../pokemon/latios.md) | Changed | Wild held items, Machines, Level-up moves |
| [Kyogre](../pokemon/kyogre.md) | Changed | Machines, Level-up moves |
| [Groudon](../pokemon/groudon.md) | Changed | Machines, Level-up moves |
| [Rayquaza](../pokemon/rayquaza.md) | Changed | Machines, Level-up moves |
| [Jirachi](../pokemon/jirachi.md) | Changed | Abilities, Machines, Level-up moves |
| [Deoxys](../pokemon/deoxys-normal.md) | Changed | Abilities, Machines, Level-up moves |
| [Turtwig](../pokemon/turtwig.md) | Changed | Abilities, Machines, Level-up moves |
| [Grotle](../pokemon/grotle.md) | Changed | Abilities, Machines, Level-up moves |
| [Torterra](../pokemon/torterra.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Chimchar](../pokemon/chimchar.md) | Changed | Abilities, Machines, Level-up moves |
| [Monferno](../pokemon/monferno.md) | Changed | Abilities, Machines, Level-up moves |
| [Infernape](../pokemon/infernape.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Piplup](../pokemon/piplup.md) | Changed | Abilities, Machines, Level-up moves |
| [Prinplup](../pokemon/prinplup.md) | Changed | Abilities, Machines, Level-up moves |
| [Empoleon](../pokemon/empoleon.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Starly](../pokemon/starly.md) | Changed | Abilities, Machines, Level-up moves |
| [Staravia](../pokemon/staravia.md) | Changed | Abilities, Machines, Level-up moves |
| [Staraptor](../pokemon/staraptor.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Bidoof](../pokemon/bidoof.md) | Changed | Machines, Level-up moves |
| [Bibarel](../pokemon/bibarel.md) | Changed | Base stats, Machines, Level-up moves |
| [Kricketot](../pokemon/kricketot.md) | Changed | Base stats, Abilities, Level-up moves |
| [Kricketune](../pokemon/kricketune.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Shinx](../pokemon/shinx.md) | Changed | Machines, Level-up moves |
| [Luxio](../pokemon/luxio.md) | Changed | Machines, Level-up moves |
| [Luxray](../pokemon/luxray.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Budew](../pokemon/budew.md) | Changed | Hatch cycles, Base friendship, Evolutions, Machines, Level-up moves |
| [Roserade](../pokemon/roserade.md) | Changed | Base stats, Base friendship, Machines, Level-up moves |
| [Cranidos](../pokemon/cranidos.md) | Changed | Abilities, Machines, Level-up moves |
| [Rampardos](../pokemon/rampardos.md) | Changed | Abilities, Machines, Level-up moves |
| [Shieldon](../pokemon/shieldon.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Bastiodon](../pokemon/bastiodon.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Burmy](../pokemon/burmy.md) | Changed | Base stats, Abilities, Evolutions, Level-up moves |
| [Wormadam](../pokemon/wormadam-plant.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mothim](../pokemon/mothim.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Combee](../pokemon/combee.md) | Changed | Abilities, Gender ratio, Machines, Level-up moves |
| [Vespiquen](../pokemon/vespiquen.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pachirisu](../pokemon/pachirisu.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Buizel](../pokemon/buizel.md) | Changed | Abilities, Machines, Level-up moves |
| [Floatzel](../pokemon/floatzel.md) | Changed | Abilities, Machines, Level-up moves |
| [Cherubi](../pokemon/cherubi.md) | Changed | Base stats, Evolutions, Machines, Level-up moves |
| [Cherrim](../pokemon/cherrim.md) | Changed | Base stats, Machines, Level-up moves |
| [Shellos](../pokemon/shellos.md) | Changed | Machines, Level-up moves |
| [Gastrodon](../pokemon/gastrodon.md) | Changed | Machines, Level-up moves |
| [Ambipom](../pokemon/ambipom.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Drifloon](../pokemon/drifloon.md) | Changed | Abilities, Machines, Level-up moves |
| [Drifblim](../pokemon/drifblim.md) | Changed | Abilities, Machines, Level-up moves |
| [Buneary](../pokemon/buneary.md) | Changed | Abilities, Base friendship, Machines, Level-up moves |
| [Lopunny](../pokemon/lopunny.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Mismagius](../pokemon/mismagius.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Honchkrow](../pokemon/honchkrow.md) | Changed | Abilities, Machines, Level-up moves |
| [Glameow](../pokemon/glameow.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Purugly](../pokemon/purugly.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Chingling](../pokemon/chingling.md) | Changed | Base stats, Base friendship, Evolutions, Machines, Level-up moves |
| [Stunky](../pokemon/stunky.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Skuntank](../pokemon/skuntank.md) | Changed | Base stats, Machines, Level-up moves |
| [Bronzor](../pokemon/bronzor.md) | Changed | Machines, Level-up moves |
| [Bronzong](../pokemon/bronzong.md) | Changed | Machines, Level-up moves |
| [Bonsly](../pokemon/bonsly.md) | Changed | Base stats, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Mime Jr.](../pokemon/mime-jr.md) | Changed | Base stats, Types, Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Happiny](../pokemon/happiny.md) | Changed | Wild held items, Base friendship, Evolutions, Machines, Level-up moves |
| [Chatot](../pokemon/chatot.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Spiritomb](../pokemon/spiritomb.md) | Changed | Abilities, Machines, Level-up moves |
| [Gible](../pokemon/gible.md) | Changed | Abilities, Machines, Level-up moves |
| [Gabite](../pokemon/gabite.md) | Changed | Abilities, Machines, Level-up moves |
| [Garchomp](../pokemon/garchomp.md) | Changed | Abilities, Machines, Level-up moves |
| [Munchlax](../pokemon/munchlax.md) | Changed | Wild held items, Base friendship, Machines, Level-up moves |
| [Riolu](../pokemon/riolu.md) | Changed | Abilities, Base friendship, Evolutions, Machines, Level-up moves |
| [Lucario](../pokemon/lucario.md) | Changed | Abilities, Machines, Level-up moves |
| [Hippopotas](../pokemon/hippopotas.md) | Changed | Abilities, Machines, Level-up moves |
| [Hippowdon](../pokemon/hippowdon.md) | Changed | Abilities, Machines, Level-up moves |
| [Skorupi](../pokemon/skorupi.md) | Changed | Evolutions, Machines, Level-up moves |
| [Drapion](../pokemon/drapion.md) | Changed | Machines, Level-up moves |
| [Croagunk](../pokemon/croagunk.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Toxicroak](../pokemon/toxicroak.md) | Changed | Abilities, Machines, Level-up moves |
| [Carnivine](../pokemon/carnivine.md) | Changed | Base stats, Machines, Level-up moves |
| [Finneon](../pokemon/finneon.md) | Changed | Base stats, Machines, Level-up moves |
| [Lumineon](../pokemon/lumineon.md) | Changed | Base stats, Machines, Level-up moves |
| [Mantyke](../pokemon/mantyke.md) | Changed | Evolutions, Machines, Level-up moves |
| [Snover](../pokemon/snover.md) | Changed | Abilities, Machines, Level-up moves |
| [Abomasnow](../pokemon/abomasnow.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Weavile](../pokemon/weavile.md) | Changed | Machines, Level-up moves |
| [Magnezone](../pokemon/magnezone.md) | Changed | Abilities, Machines, Level-up moves |
| [Lickilicky](../pokemon/lickilicky.md) | Changed | Abilities, Machines, Level-up moves |
| [Rhyperior](../pokemon/rhyperior.md) | Changed | Machines, Level-up moves |
| [Tangrowth](../pokemon/tangrowth.md) | Changed | Abilities, Machines, Level-up moves |
| [Electivire](../pokemon/electivire.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Magmortar](../pokemon/magmortar.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Togekiss](../pokemon/togekiss.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Yanmega](../pokemon/yanmega.md) | Changed | Machines, Level-up moves |
| [Leafeon](../pokemon/leafeon.md) | Changed | Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Glaceon](../pokemon/glaceon.md) | Changed | Base stats, Abilities, Gender ratio, Base friendship, Machines, Level-up moves |
| [Gliscor](../pokemon/gliscor.md) | Changed | Abilities, Machines, Level-up moves |
| [Mamoswine](../pokemon/mamoswine.md) | Changed | Abilities, Growth rate, Machines, Level-up moves |
| [Porygon-Z](../pokemon/porygon-z.md) | Changed | Machines, Level-up moves |
| [Gallade](../pokemon/gallade.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Probopass](../pokemon/probopass.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Dusknoir](../pokemon/dusknoir.md) | Changed | Abilities, Machines, Level-up moves |
| [Froslass](../pokemon/froslass.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Rotom](../pokemon/rotom.md) | Changed | Base stats, Machines, Level-up moves |
| [Uxie](../pokemon/uxie.md) | Changed | Types, Machines, Level-up moves |
| [Mesprit](../pokemon/mesprit.md) | Changed | Types, Machines, Level-up moves |
| [Azelf](../pokemon/azelf.md) | Changed | Types, Machines, Level-up moves |
| [Dialga](../pokemon/dialga.md) | Changed | Abilities, Machines, Level-up moves |
| [Palkia](../pokemon/palkia.md) | Changed | Abilities, Machines, Level-up moves |
| [Heatran](../pokemon/heatran.md) | Changed | Abilities, Machines, Level-up moves |
| [Regigigas](../pokemon/regigigas.md) | Changed | Abilities, Machines, Level-up moves |
| [Giratina](../pokemon/giratina-altered.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Cresselia](../pokemon/cresselia.md) | Changed | Machines, Level-up moves |
| [Phione](../pokemon/phione.md) | Changed | Machines, Level-up moves |
| [Manaphy](../pokemon/manaphy.md) | Changed | Wild held items, Hatch cycles, Machines, Level-up moves |
| [Darkrai](../pokemon/darkrai.md) | Changed | Machines, Level-up moves |
| [Shaymin](../pokemon/shaymin-land.md) | Changed | Wild held items, Machines, Level-up moves |
| [Arceus](../pokemon/arceus.md) | Changed | Wild held items, Machines, Level-up moves |
| [Victini](../pokemon/victini.md) | Changed | Machines, Level-up moves |
| [Snivy](../pokemon/snivy.md) | Changed | Abilities, EV yield, Wild held items, Machines, Level-up moves |
| [Servine](../pokemon/servine.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Serperior](../pokemon/serperior.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Tepig](../pokemon/tepig.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Pignite](../pokemon/pignite.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Emboar](../pokemon/emboar.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Oshawott](../pokemon/oshawott.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Dewott](../pokemon/dewott.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Samurott](../pokemon/samurott.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Patrat](../pokemon/patrat.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Watchog](../pokemon/watchog.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Lillipup](../pokemon/lillipup.md) | Changed | Machines, Level-up moves |
| [Herdier](../pokemon/herdier.md) | Changed | Machines, Level-up moves |
| [Stoutland](../pokemon/stoutland.md) | Changed | Base stats, Machines, Level-up moves |
| [Purrloin](../pokemon/purrloin.md) | Changed | Abilities, Machines, Level-up moves |
| [Liepard](../pokemon/liepard.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pansage](../pokemon/pansage.md) | Changed | Abilities, Growth rate, Machines, Level-up moves |
| [Simisage](../pokemon/simisage.md) | Changed | Base stats, Abilities, Growth rate, Machines, Level-up moves |
| [Pansear](../pokemon/pansear.md) | Changed | Abilities, Growth rate, Machines, Level-up moves |
| [Simisear](../pokemon/simisear.md) | Changed | Base stats, Abilities, Growth rate, Machines, Level-up moves |
| [Panpour](../pokemon/panpour.md) | Changed | Abilities, Growth rate, Machines, Level-up moves |
| [Simipour](../pokemon/simipour.md) | Changed | Base stats, Abilities, Growth rate, Machines, Level-up moves |
| [Munna](../pokemon/munna.md) | Changed | Types, Abilities, Hatch cycles, Machines, Level-up moves |
| [Musharna](../pokemon/musharna.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Pidove](../pokemon/pidove.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Tranquill](../pokemon/tranquill.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Unfezant](../pokemon/unfezant.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Blitzle](../pokemon/blitzle.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Zebstrika](../pokemon/zebstrika.md) | Changed | Abilities, Machines, Level-up moves |
| [Roggenrola](../pokemon/roggenrola.md) | Changed | Abilities, Machines, Level-up moves |
| [Boldore](../pokemon/boldore.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Gigalith](../pokemon/gigalith.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Woobat](../pokemon/woobat.md) | Changed | Base stats, Abilities, Base friendship, Evolutions, Machines, Level-up moves |
| [Swoobat](../pokemon/swoobat.md) | Changed | Base stats, Abilities, Base friendship, Machines, Level-up moves |
| [Drilbur](../pokemon/drilbur.md) | Changed | Abilities, Machines, Level-up moves |
| [Excadrill](../pokemon/excadrill.md) | Changed | Abilities, Machines, Level-up moves |
| [Audino](../pokemon/audino.md) | Changed | Types, Abilities, Wild held items, Machines, Level-up moves |
| [Timburr](../pokemon/timburr.md) | Changed | Abilities, Machines, Level-up moves |
| [Gurdurr](../pokemon/gurdurr.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Conkeldurr](../pokemon/conkeldurr.md) | Changed | Abilities, Machines, Level-up moves |
| [Tympole](../pokemon/tympole.md) | Changed | Abilities, Machines, Level-up moves |
| [Palpitoad](../pokemon/palpitoad.md) | Changed | Abilities, Machines, Level-up moves |
| [Seismitoad](../pokemon/seismitoad.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Throh](../pokemon/throh.md) | Changed | Abilities, Machines, Level-up moves |
| [Sawk](../pokemon/sawk.md) | Changed | Abilities, Machines, Level-up moves |
| [Sewaddle](../pokemon/sewaddle.md) | Changed | Base friendship, Evolutions, Machines, Level-up moves |
| [Swadloon](../pokemon/swadloon.md) | Changed | Base stats, Abilities, Base friendship, Machines, Level-up moves |
| [Leavanny](../pokemon/leavanny.md) | Changed | Base stats, Base friendship, Machines, Level-up moves |
| [Venipede](../pokemon/venipede.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Whirlipede](../pokemon/whirlipede.md) | Changed | Abilities, Machines, Level-up moves |
| [Scolipede](../pokemon/scolipede.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Cottonee](../pokemon/cottonee.md) | Changed | Types, Machines, Level-up moves |
| [Whimsicott](../pokemon/whimsicott.md) | Changed | Types, Machines, Level-up moves |
| [Petilil](../pokemon/petilil.md) | Changed | Machines, Level-up moves |
| [Lilligant](../pokemon/lilligant.md) | Changed | Base stats, Machines, Level-up moves |
| [Basculin](../pokemon/basculin-red-striped.md) | Changed | Base stats, Machines, Level-up moves |
| [Sandile](../pokemon/sandile.md) | Changed | Evolutions, Machines, Level-up moves |
| [Krokorok](../pokemon/krokorok.md) | Changed | Machines, Level-up moves |
| [Krookodile](../pokemon/krookodile.md) | Changed | Base stats, Machines, Level-up moves |
| [Darumaka](../pokemon/darumaka.md) | Changed | Abilities, Machines, Level-up moves |
| [Darmanitan](../pokemon/darmanitan-standard.md) | Changed | Abilities, Machines, Level-up moves |
| [Maractus](../pokemon/maractus.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Dwebble](../pokemon/dwebble.md) | Changed | Machines, Level-up moves |
| [Crustle](../pokemon/crustle.md) | Changed | Base stats, Machines, Level-up moves |
| [Scraggy](../pokemon/scraggy.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Scrafty](../pokemon/scrafty.md) | Changed | Abilities, Machines, Level-up moves |
| [Sigilyph](../pokemon/sigilyph.md) | Changed | Abilities, Machines, Level-up moves |
| [Yamask](../pokemon/yamask.md) | Changed | Machines, Level-up moves |
| [Cofagrigus](../pokemon/cofagrigus.md) | Changed | Base stats, Machines, Level-up moves |
| [Tirtouga](../pokemon/tirtouga.md) | Changed | Machines, Level-up moves |
| [Carracosta](../pokemon/carracosta.md) | Changed | Machines, Level-up moves |
| [Archen](../pokemon/archen.md) | Changed | Base experience, Machines, Level-up moves |
| [Archeops](../pokemon/archeops.md) | Changed | Machines, Level-up moves |
| [Trubbish](../pokemon/trubbish.md) | Changed | Abilities, Machines, Level-up moves |
| [Garbodor](../pokemon/garbodor.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Zorua](../pokemon/zorua.md) | Changed | Machines, Level-up moves |
| [Zoroark](../pokemon/zoroark.md) | Changed | Machines, Level-up moves |
| [Minccino](../pokemon/minccino.md) | Changed | Abilities, Machines, Level-up moves |
| [Cinccino](../pokemon/cinccino.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Gothita](../pokemon/gothita.md) | Changed | Types, Abilities, Evolutions, Machines, Level-up moves |
| [Gothorita](../pokemon/gothorita.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Gothitelle](../pokemon/gothitelle.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Solosis](../pokemon/solosis.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Duosion](../pokemon/duosion.md) | Changed | Abilities, Machines, Level-up moves |
| [Reuniclus](../pokemon/reuniclus.md) | Changed | Abilities, Machines, Level-up moves |
| [Ducklett](../pokemon/ducklett.md) | Changed | Abilities, Machines, Level-up moves |
| [Swanna](../pokemon/swanna.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Vanillite](../pokemon/vanillite.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Vanillish](../pokemon/vanillish.md) | Changed | Abilities, Machines, Level-up moves |
| [Vanilluxe](../pokemon/vanilluxe.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Deerling](../pokemon/deerling.md) | Changed | Machines, Level-up moves |
| [Sawsbuck](../pokemon/sawsbuck.md) | Changed | Base stats, Machines, Level-up moves |
| [Emolga](../pokemon/emolga.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Karrablast](../pokemon/karrablast.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Escavalier](../pokemon/escavalier.md) | Changed | Abilities, Machines, Move tutors, Level-up moves |
| [Foongus](../pokemon/foongus.md) | Changed | Abilities, Machines, Level-up moves |
| [Amoonguss](../pokemon/amoonguss.md) | Changed | Abilities, Machines, Level-up moves |
| [Frillish](../pokemon/frillish-male.md) | Changed | Machines, Level-up moves |
| [Jellicent](../pokemon/jellicent-male.md) | Changed | Machines, Level-up moves |
| [Alomomola](../pokemon/alomomola.md) | Changed | Abilities, Machines, Level-up moves |
| [Joltik](../pokemon/joltik.md) | Changed | Evolutions, Machines, Level-up moves |
| [Galvantula](../pokemon/galvantula.md) | Changed | Base stats, Machines, Level-up moves |
| [Ferroseed](../pokemon/ferroseed.md) | Changed | Machines, Level-up moves |
| [Ferrothorn](../pokemon/ferrothorn.md) | Changed | Machines, Level-up moves |
| [Klink](../pokemon/klink.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Klang](../pokemon/klang.md) | Changed | Abilities, Machines, Level-up moves |
| [Klinklang](../pokemon/klinklang.md) | Changed | Abilities, Machines, Level-up moves |
| [Tynamo](../pokemon/tynamo.md) | Changed | Evolutions, Machines, Level-up moves |
| [Eelektrik](../pokemon/eelektrik.md) | Changed | Machines, Level-up moves |
| [Eelektross](../pokemon/eelektross.md) | Changed | Machines, Level-up moves |
| [Elgyem](../pokemon/elgyem.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Beheeyem](../pokemon/beheeyem.md) | Changed | Abilities, Machines, Level-up moves |
| [Litwick](../pokemon/litwick.md) | Changed | Abilities, Hatch cycles, Evolutions, Machines, Level-up moves |
| [Lampent](../pokemon/lampent.md) | Changed | Abilities, Machines, Level-up moves |
| [Chandelure](../pokemon/chandelure.md) | Changed | Machines, Level-up moves |
| [Axew](../pokemon/axew.md) | Changed | Machines, Level-up moves |
| [Fraxure](../pokemon/fraxure.md) | Changed | Machines, Level-up moves |
| [Haxorus](../pokemon/haxorus.md) | Changed | Machines, Level-up moves |
| [Cubchoo](../pokemon/cubchoo.md) | Changed | Abilities, Hatch cycles, Machines, Level-up moves |
| [Beartic](../pokemon/beartic.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Cryogonal](../pokemon/cryogonal.md) | Changed | Base stats, Machines, Level-up moves |
| [Shelmet](../pokemon/shelmet.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Accelgor](../pokemon/accelgor.md) | Changed | Abilities, Machines, Level-up moves |
| [Stunfisk](../pokemon/stunfisk.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Mienfoo](../pokemon/mienfoo.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Mienshao](../pokemon/mienshao.md) | Changed | Abilities, Machines, Level-up moves |
| [Druddigon](../pokemon/druddigon.md) | Changed | Machines, Level-up moves |
| [Golett](../pokemon/golett.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Golurk](../pokemon/golurk.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pawniard](../pokemon/pawniard.md) | Changed | Evolutions, Machines, Level-up moves |
| [Bisharp](../pokemon/bisharp.md) | Changed | Machines, Level-up moves |
| [Bouffalant](../pokemon/bouffalant.md) | Changed | Machines, Level-up moves |
| [Rufflet](../pokemon/rufflet.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Braviary](../pokemon/braviary.md) | Changed | Abilities, Machines, Level-up moves |
| [Vullaby](../pokemon/vullaby.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Mandibuzz](../pokemon/mandibuzz.md) | Changed | Abilities, Machines, Level-up moves |
| [Heatmor](../pokemon/heatmor.md) | Changed | Abilities, Machines, Level-up moves |
| [Durant](../pokemon/durant.md) | Changed | Abilities, Machines, Level-up moves |
| [Deino](../pokemon/deino.md) | Changed | Evolutions, Machines, Level-up moves |
| [Zweilous](../pokemon/zweilous.md) | Changed | Evolutions, Machines, Level-up moves |
| [Hydreigon](../pokemon/hydreigon.md) | Changed | Machines, Level-up moves |
| [Larvesta](../pokemon/larvesta.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Volcarona](../pokemon/volcarona.md) | Changed | Abilities, Machines, Level-up moves |
| [Cobalion](../pokemon/cobalion.md) | Changed | Machines, Level-up moves |
| [Terrakion](../pokemon/terrakion.md) | Changed | Machines, Level-up moves |
| [Virizion](../pokemon/virizion.md) | Changed | Machines, Level-up moves |
| [Tornadus](../pokemon/tornadus-incarnate.md) | Changed | Abilities, Machines, Level-up moves |
| [Thundurus](../pokemon/thundurus-incarnate.md) | Changed | Abilities, Machines, Level-up moves |
| [Reshiram](../pokemon/reshiram.md) | Changed | Machines, Level-up moves |
| [Zekrom](../pokemon/zekrom.md) | Changed | Machines, Level-up moves |
| [Landorus](../pokemon/landorus-incarnate.md) | Changed | Abilities, Machines, Level-up moves |
| [Kyurem](../pokemon/kyurem.md) | Changed | Abilities, Machines, Level-up moves |
| [Keldeo](../pokemon/keldeo-ordinary.md) | Changed | Machines, Level-up moves |
| [Meloetta](../pokemon/meloetta-aria.md) | Changed | Machines, Level-up moves |
| [Genesect](../pokemon/genesect.md) | Changed | Machines, Level-up moves |
| Pokestar Studios 19 | Changed | Catch Rate, Base experience, Hatch cycles, Base friendship |
| [Deoxys Attack](../pokemon/deoxys-attack.md) | Changed | Abilities, Machines, Level-up moves |
| [Deoxys Defense](../pokemon/deoxys-defense.md) | Changed | Abilities, Machines, Level-up moves |
| [Deoxys Speed](../pokemon/deoxys-speed.md) | Changed | Abilities, Machines, Level-up moves |
| [Wormadam Sandy](../pokemon/wormadam-sandy.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Wormadam Trash](../pokemon/wormadam-trash.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Shaymin Sky](../pokemon/shaymin-sky.md) | Changed | Machines, Level-up moves |
| [Giratina Origin](../pokemon/giratina-origin.md) | Changed | Wild held items, Machines, Level-up moves |
| [Rotom Heat](../pokemon/rotom-heat.md) | Changed | Machines, Level-up moves |
| [Rotom Wash](../pokemon/rotom-wash.md) | Changed | Machines, Level-up moves |
| [Rotom Frost](../pokemon/rotom-frost.md) | Changed | Machines, Level-up moves |
| [Rotom Fan](../pokemon/rotom-fan.md) | Changed | Abilities, Machines, Level-up moves |
| [Rotom Mow](../pokemon/rotom-mow.md) | Changed | Machines, Level-up moves |
| Castform Sunny | Changed | Base stats, Machines, Level-up moves |
| Castform Rainy | Changed | Base stats, Machines, Level-up moves |
| Castform Snowy | Changed | Base stats, Sprite orientation, Machines, Level-up moves |
| [Basculin Blue Striped](../pokemon/basculin-blue-striped.md) | Changed | Base stats, Machines, Level-up moves |
| Darmanitan Zen | Changed | Abilities, Machines, Level-up moves |
| Meloetta Pirouette | Changed | Machines, Level-up moves |
| [Kyurem White](../pokemon/kyurem-white.md) | Changed | Wild held items, Machines, Level-up moves |
| [Kyurem Black](../pokemon/kyurem-black.md) | Changed | Wild held items, Machines, Move tutors, Level-up moves |
| [Keldeo Resolute](../pokemon/keldeo-resolute.md) | Changed | Machines, Level-up moves |
| [Tornadus Therian](../pokemon/tornadus-therian.md) | Changed | Machines, Level-up moves |
| [Thundurus Therian](../pokemon/thundurus-therian.md) | Changed | Machines, Level-up moves |
| [Landorus Therian](../pokemon/landorus-therian.md) | Changed | Machines, Level-up moves |

## Abilities

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Stench](../abilities/stench.md) | Changed | Pokémon |
| [Drizzle](../abilities/drizzle.md) | Changed | Pokémon |
| [Speed Boost](../abilities/speed-boost.md) | Changed | Pokémon |
| [Battle Armor](../abilities/battle-armor.md) | Changed | Pokémon |
| [Sturdy](../abilities/sturdy.md) | Changed | Pokémon |
| [Damp](../abilities/damp.md) | Changed | Pokémon |
| [Limber](../abilities/limber.md) | Changed | Pokémon |
| [Sand Veil](../abilities/sand-veil.md) | Changed | Pokémon |
| [Static](../abilities/static.md) | Changed | Pokémon |
| [Volt Absorb](../abilities/volt-absorb.md) | Changed | Pokémon |
| [Water Absorb](../abilities/water-absorb.md) | Changed | Pokémon |
| [Oblivious](../abilities/oblivious.md) | Changed | Pokémon |
| [Cloud Nine](../abilities/cloud-nine.md) | Changed | Pokémon |
| [Compoundeyes](../abilities/compound-eyes.md) | Changed | Pokémon |
| [Insomnia](../abilities/insomnia.md) | Changed | Pokémon |
| [Immunity](../abilities/immunity.md) | Changed | Pokémon |
| [Flash Fire](../abilities/flash-fire.md) | Changed | Pokémon |
| [Shield Dust](../abilities/shield-dust.md) | Changed | Pokémon |
| [Own Tempo](../abilities/own-tempo.md) | Changed | Pokémon |
| [Suction Cups](../abilities/suction-cups.md) | Changed | Pokémon |
| [Intimidate](../abilities/intimidate.md) | Changed | Pokémon |
| [Shadow Tag](../abilities/shadow-tag.md) | Changed | Pokémon |
| [Rough Skin](../abilities/rough-skin.md) | Changed | Pokémon |
| [Wonder Guard](../abilities/wonder-guard.md) | Changed | Pokémon |
| [Levitate](../abilities/levitate.md) | Changed | Pokémon |
| [Effect Spore](../abilities/effect-spore.md) | Changed | Pokémon |
| [Synchronize](../abilities/synchronize.md) | Changed | Pokémon |
| [Clear Body](../abilities/clear-body.md) | Changed | Pokémon |
| [Natural Cure](../abilities/natural-cure.md) | Changed | Pokémon |
| [Lightningrod](../abilities/lightning-rod.md) | Changed | Pokémon |
| [Serene Grace](../abilities/serene-grace.md) | Changed | Pokémon |
| [Swift Swim](../abilities/swift-swim.md) | Changed | Pokémon |
| [Chlorophyll](../abilities/chlorophyll.md) | Changed | Pokémon |
| [Illuminate](../abilities/illuminate.md) | Changed | Pokémon |
| [Trace](../abilities/trace.md) | Changed | Pokémon |
| [Huge Power](../abilities/huge-power.md) | Changed | Pokémon |
| [Poison Point](../abilities/poison-point.md) | Changed | Pokémon |
| [Inner Focus](../abilities/inner-focus.md) | Changed | Pokémon |
| [Magma Armor](../abilities/magma-armor.md) | Changed | Pokémon |
| [Water Veil](../abilities/water-veil.md) | Changed | Pokémon |
| [Magnet Pull](../abilities/magnet-pull.md) | Changed | Pokémon |
| [Soundproof](../abilities/soundproof.md) | Changed | Pokémon |
| [Rain Dish](../abilities/rain-dish.md) | Changed | Pokémon |
| [Sand Stream](../abilities/sand-stream.md) | Changed | Pokémon |
| [Pressure](../abilities/pressure.md) | Changed | Pokémon |
| [Thick Fat](../abilities/thick-fat.md) | Changed | Pokémon |
| [Early Bird](../abilities/early-bird.md) | Changed | Pokémon |
| [Flame Body](../abilities/flame-body.md) | Changed | Pokémon |
| [Run Away](../abilities/run-away.md) | Changed | Pokémon |
| [Keen Eye](../abilities/keen-eye.md) | Changed | Pokémon |
| [Hyper Cutter](../abilities/hyper-cutter.md) | Changed | Pokémon |
| [Pickup](../abilities/pickup.md) | Changed | Pokémon |
| [Truant](../abilities/truant.md) | Changed | Pokémon |
| [Hustle](../abilities/hustle.md) | Changed | Pokémon |
| [Cute Charm](../abilities/cute-charm.md) | Changed | Pokémon |
| [Plus](../abilities/plus.md) | Changed | Pokémon |
| [Minus](../abilities/minus.md) | Changed | Pokémon |
| [Sticky Hold](../abilities/sticky-hold.md) | Changed | Pokémon |
| [Shed Skin](../abilities/shed-skin.md) | Changed | Pokémon |
| [Guts](../abilities/guts.md) | Changed | Pokémon |
| [Marvel Scale](../abilities/marvel-scale.md) | Changed | Pokémon |
| [Liquid Ooze](../abilities/liquid-ooze.md) | Changed | Pokémon |
| [Overgrow](../abilities/overgrow.md) | Changed | Pokémon |
| [Blaze](../abilities/blaze.md) | Changed | Pokémon |
| [Torrent](../abilities/torrent.md) | Changed | Pokémon |
| [Swarm](../abilities/swarm.md) | Changed | Pokémon |
| [Rock Head](../abilities/rock-head.md) | Changed | Pokémon |
| [Drought](../abilities/drought.md) | Changed | Pokémon |
| [Arena Trap](../abilities/arena-trap.md) | Changed | Pokémon |
| [Vital Spirit](../abilities/vital-spirit.md) | Changed | Pokémon |
| [White Smoke](../abilities/white-smoke.md) | Changed | Pokémon |
| [Pure Power](../abilities/pure-power.md) | Changed | Pokémon |
| [Shell Armor](../abilities/shell-armor.md) | Changed | Pokémon |
| [Tangled Feet](../abilities/tangled-feet.md) | Changed | Pokémon |
| [Motor Drive](../abilities/motor-drive.md) | Changed | Pokémon |
| [Rivalry](../abilities/rivalry.md) | Changed | Pokémon |
| [Steadfast](../abilities/steadfast.md) | Changed | Pokémon |
| [Snow Cloak](../abilities/snow-cloak.md) | Changed | Pokémon |
| [Gluttony](../abilities/gluttony.md) | Changed | Pokémon |
| [Anger Point](../abilities/anger-point.md) | Changed | Pokémon |
| [Unburden](../abilities/unburden.md) | Changed | Pokémon |
| [Heatproof](../abilities/heatproof.md) | Changed | Pokémon |
| [Simple](../abilities/simple.md) | Changed | Pokémon |
| [Dry Skin](../abilities/dry-skin.md) | Changed | Pokémon |
| [Download](../abilities/download.md) | Changed | Pokémon |
| [Iron Fist](../abilities/iron-fist.md) | Changed | Pokémon |
| [Poison Heal](../abilities/poison-heal.md) | Changed | Pokémon |
| [Adaptability](../abilities/adaptability.md) | Changed | Pokémon |
| [Skill Link](../abilities/skill-link.md) | Changed | Pokémon |
| [Hydration](../abilities/hydration.md) | Changed | Pokémon |
| [Solar Power](../abilities/solar-power.md) | Changed | Pokémon |
| [Quick Feet](../abilities/quick-feet.md) | Changed | Pokémon |
| [Sniper](../abilities/sniper.md) | Changed | Pokémon |
| [Magic Guard](../abilities/magic-guard.md) | Changed | Pokémon |
| [No Guard](../abilities/no-guard.md) | Changed | Pokémon |
| [Technician](../abilities/technician.md) | Changed | Pokémon |
| [Leaf Guard](../abilities/leaf-guard.md) | Changed | Pokémon |
| [Klutz](../abilities/klutz.md) | Changed | Pokémon |
| [Mold Breaker](../abilities/mold-breaker.md) | Changed | Pokémon |
| [Super Luck](../abilities/super-luck.md) | Changed | Pokémon |
| [Aftermath](../abilities/aftermath.md) | Changed | Pokémon |
| [Anticipation](../abilities/anticipation.md) | Changed | Pokémon |
| [Forewarn](../abilities/forewarn.md) | Changed | Pokémon |
| [Unaware](../abilities/unaware.md) | Changed | Pokémon |
| [Tinted Lens](../abilities/tinted-lens.md) | Changed | Pokémon |
| [Filter](../abilities/filter.md) | Changed | Pokémon |
| [Slow Start](../abilities/slow-start.md) | Changed | Pokémon |
| [Scrappy](../abilities/scrappy.md) | Changed | Pokémon |
| [Storm Drain](../abilities/storm-drain.md) | Changed | Pokémon |
| [Ice Body](../abilities/ice-body.md) | Changed | Pokémon |
| [Solid Rock](../abilities/solid-rock.md) | Changed | Pokémon |
| [Snow Warning](../abilities/snow-warning.md) | Changed | Pokémon |
| [Frisk](../abilities/frisk.md) | Changed | Pokémon |
| [Reckless](../abilities/reckless.md) | Changed | Pokémon |
| [Bad Dreams](../abilities/bad-dreams.md) | Changed | Pokémon |
| [Pickpocket](../abilities/pickpocket.md) | Changed | Pokémon |
| [Sheer Force](../abilities/sheer-force.md) | Changed | Pokémon |
| [Contrary](../abilities/contrary.md) | Changed | Pokémon |
| [Unnerve](../abilities/unnerve.md) | Changed | Pokémon |
| [Defiant](../abilities/defiant.md) | Changed | Pokémon |
| [Defeatist](../abilities/defeatist.md) | Changed | Pokémon |
| [Cursed Body](../abilities/cursed-body.md) | Changed | Pokémon |
| [Healer](../abilities/healer.md) | Changed | Pokémon |
| [Friend Guard](../abilities/friend-guard.md) | Changed | Pokémon |
| [Weak Armor](../abilities/weak-armor.md) | Changed | Pokémon |
| [Heavy Metal](../abilities/heavy-metal.md) | Changed | Pokémon |
| [Light Metal](../abilities/light-metal.md) | Changed | Pokémon |
| [Multiscale](../abilities/multiscale.md) | Changed | Pokémon |
| [Toxic Boost](../abilities/toxic-boost.md) | Changed | Pokémon |
| [Flare Boost](../abilities/flare-boost.md) | Changed | Pokémon |
| [Harvest](../abilities/harvest.md) | Changed | Pokémon |
| [Telepathy](../abilities/telepathy.md) | Changed | Pokémon |
| [Moody](../abilities/moody.md) | Changed | Pokémon |
| [Overcoat](../abilities/overcoat.md) | Changed | Pokémon |
| [Poison Touch](../abilities/poison-touch.md) | Changed | Pokémon |
| [Regenerator](../abilities/regenerator.md) | Changed | Pokémon |
| [Big Pecks](../abilities/big-pecks.md) | Changed | Pokémon |
| [Sand Rush](../abilities/sand-rush.md) | Changed | Pokémon |
| [Wonder Skin](../abilities/wonder-skin.md) | Changed | Pokémon |
| [Analytic](../abilities/analytic.md) | Changed | Pokémon |
| [Imposter](../abilities/imposter.md) | Changed | Pokémon |
| [Infiltrator](../abilities/infiltrator.md) | Changed | Pokémon |
| [Moxie](../abilities/moxie.md) | Changed | Pokémon |
| [Justified](../abilities/justified.md) | Changed | Pokémon |
| [Rattled](../abilities/rattled.md) | Changed | Pokémon |
| [Magic Bounce](../abilities/magic-bounce.md) | Changed | Pokémon |
| [Sap Sipper](../abilities/sap-sipper.md) | Changed | Pokémon |
| [Prankster](../abilities/prankster.md) | Changed | Pokémon |
| [Sand Force](../abilities/sand-force.md) | Changed | Pokémon |

## Moves

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Double Slap](../moves/double-slap.md) | Changed | Name |
| [Power-Up Punch](../moves/power-up-punch.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Machines |
| [Smart Strike](../moves/smart-strike.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect |
| [Fire Punch](../moves/fire-punch.md) | Changed | Pp |
| [Ice Punch](../moves/ice-punch.md) | Changed | Pp |
| [Thunder Punch](../moves/thunder-punch.md) | Changed | Name, Pp |
| [Dual Wingbeat](../moves/dual-wingbeat.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Flags |
| [Fire Lash](../moves/fire-lash.md) | Changed | Name, Type, Damage class, Pp, Effect, Target, Flags |
| [Swords Dance](../moves/swords-dance.md) | Changed | Pp |
| [Cut](../moves/cut.md) | Changed | Type, Power, Accuracy, Pp, Effect |
| [Gust](../moves/gust.md) | Changed | Pp |
| [Whirlwind](../moves/whirlwind.md) | Changed | Accuracy |
| [Fly](../moves/fly.md) | Changed | Power, Accuracy |
| [Brutal Swing](../moves/brutal-swing.md) | Changed | Name, Type, Power, Accuracy, Target, Machines |
| [Vine Whip](../moves/vine-whip.md) | Changed | Power |
| [High Horsepower](../moves/high-horsepower.md) | Changed | Name, Type, Power, Accuracy, Pp |
| [Headlong Rush](../moves/headlong-rush.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect |
| [Sand Attack](../moves/sand-attack.md) | Changed | Name |
| [Boomburst](../moves/boomburst.md) | Changed | Name, Damage class, Power, Accuracy, Pp, Effect, Target, Flags |
| [Tackle](../moves/tackle.md) | Changed | Pp |
| [Wrap](../moves/wrap.md) | Changed | Power, Accuracy |
| [Raging Fury](../moves/raging-fury.md) | Changed | Name, Type, Power |
| [Poison Sting](../moves/poison-sting.md) | Changed | Power, Pp, Flags |
| [Twineedle](../moves/twineedle.md) | Changed | Power |
| [Pin Missile](../moves/pin-missile.md) | Changed | Power, Accuracy |
| [Bite](../moves/bite.md) | Changed | Pp |
| [Growl](../moves/growl.md) | Changed | Flags |
| [Roar](../moves/roar.md) | Changed | Accuracy |
| [Sing](../moves/sing.md) | Changed | Flags |
| [Supersonic](../moves/supersonic.md) | Changed | Flags |
| [Sonic Boom](../moves/sonic-boom.md) | Changed | Name |
| [Acid](../moves/acid.md) | Changed | Power |
| [Flamethrower](../moves/flamethrower.md) | Changed | Power, Pp |
| [Hydro Pump](../moves/hydro-pump.md) | Changed | Power |
| [Surf](../moves/surf.md) | Changed | Power |
| [Ice Beam](../moves/ice-beam.md) | Changed | Power |
| [Blizzard](../moves/blizzard.md) | Changed | Power |
| [Bubble Beam](../moves/bubble-beam.md) | Changed | Name, Power |
| [Aurora Beam](../moves/aurora-beam.md) | Changed | Power |
| [Play Rough](../moves/play-rough.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Flags, Machines |
| [Low Kick](../moves/low-kick.md) | Changed | Tutors |
| [Strength](../moves/strength.md) | Changed | Power, Pp, Effect, Flags |
| [Absorb](../moves/absorb.md) | Changed | Power |
| [Mega Drain](../moves/mega-drain.md) | Changed | Power |
| [Growth](../moves/growth.md) | Changed | Pp |
| [Solar Beam](../moves/solar-beam.md) | Changed | Name |
| [Poison Powder](../moves/poison-powder.md) | Changed | Name, Pp |
| [Stun Spore](../moves/stun-spore.md) | Changed | Accuracy, Pp |
| [String Shot](../moves/string-shot.md) | Changed | Effect |
| [Thunder Shock](../moves/thunder-shock.md) | Changed | Name, Pp |
| [Thunderbolt](../moves/thunderbolt.md) | Changed | Power, Pp |
| [Thunder Wave](../moves/thunder-wave.md) | Changed | Accuracy |
| [Thunder](../moves/thunder.md) | Changed | Power, Pp |
| [Confusion](../moves/confusion.md) | Changed | Pp |
| [Quick Attack](../moves/quick-attack.md) | Changed | Pp |
| [Screech](../moves/screech.md) | Changed | Flags |
| [Double Team](../moves/double-team.md) | Changed | Machines |
| [Minimize](../moves/minimize.md) | Changed | Pp |
| [Smokescreen](../moves/smokescreen.md) | Changed | Name |
| [Barrier](../moves/barrier.md) | Changed | Pp |
| [Focus Energy](../moves/focus-energy.md) | Changed | Pp |
| [Self-Destruct](../moves/self-destruct.md) | Changed | Name |
| [Psychic Fangs](../moves/psychic-fangs.md) | Changed | Name, Type, Power, Accuracy, Effect, Flags |
| [Lick](../moves/lick.md) | Changed | Power, Pp |
| [Smog](../moves/smog.md) | Changed | Power, Accuracy |
| [Sludge](../moves/sludge.md) | Changed | Power, Pp |
| [Fire Blast](../moves/fire-blast.md) | Changed | Power |
| [Waterfall](../moves/waterfall.md) | Changed | Pp |
| [Clamp](../moves/clamp.md) | Changed | Type, Power, Accuracy, Pp, Effect, Effect chance, Target |
| [Skull Bash](../moves/skull-bash.md) | Changed | Power, Pp |
| [Breaking Swipe](../moves/breaking-swipe.md) | Changed | Name, Type, Power, Effect, Target, Flags |
| [Infestation](../moves/infestation.md) | Changed | Name, Type, Damage class, Power, Pp, Effect, Effect chance, Flags, Machines |
| [Kinesis](../moves/kinesis.md) | Changed | Target |
| [Soft-Boiled](../moves/soft-boiled.md) | Changed | Name |
| [High Jump Kick](../moves/high-jump-kick.md) | Changed | Name |
| [Glare](../moves/glare.md) | Changed | Accuracy |
| [Dream Eater](../moves/dream-eater.md) | Changed | Machines |
| [Poison Gas](../moves/poison-gas.md) | Changed | Accuracy, Pp |
| [Lunge](../moves/lunge.md) | Changed | Name, Type, Power, Accuracy, Pp, Effect, Flags |
| [Leech Life](../moves/leech-life.md) | Changed | Power, Pp |
| [Esper Wing](../moves/esper-wing.md) | Changed | Name, Type, Power, Pp, Priority, Effect, Target |
| [Spore](../moves/spore.md) | Changed | Pp |
| [Psywave](../moves/psywave.md) | Changed | Accuracy |
| [Acid Armor](../moves/acid-armor.md) | Changed | Pp |
| [Crabhammer](../moves/crabhammer.md) | Changed | Power, Effect |
| [Nuzzle](../moves/nuzzle.md) | Changed | Name, Type, Damage class, Power, Accuracy, Pp, Effect, Effect chance, Target, Flags |
| [Tri Attack](../moves/tri-attack.md) | Changed | Machines |
| [Slash](../moves/slash.md) | Changed | Pp |
| [Triple Axel](../moves/triple-axel.md) | Changed | Name, Type, Power |
| [Thief](../moves/thief.md) | Changed | Power, Pp, Machines |
| [Spider Web](../moves/spider-web.md) | Changed | Flags |
| [Flame Wheel](../moves/flame-wheel.md) | Changed | Power, Pp |
| [Snore](../moves/snore.md) | Changed | Damage class, Power, Pp, Effect, Flags |
| [Mach Punch](../moves/mach-punch.md) | Changed | Pp |
| [Feint Attack](../moves/feint-attack.md) | Changed | Name |
| [Draining Kiss](../moves/draining-kiss.md) | Changed | Name, Type, Damage class, Power, Accuracy, Effect, Flags |
| [Mud-Slap](../moves/mud-slap.md) | Changed | Power, Pp |
| [Octazooka](../moves/octazooka.md) | Changed | Power, Pp |
| [Giga Drain](../moves/giga-drain.md) | Changed | Power, Machines |
| [Charm](../moves/charm.md) | Changed | Type |
| [Rollout](../moves/rollout.md) | Changed | Power |
| [False Swipe](../moves/false-swipe.md) | Changed | Pp |
| [Swagger](../moves/swagger.md) | Changed | Accuracy, Machines |
| [Fury Cutter](../moves/fury-cutter.md) | Changed | Power |
| [Mean Look](../moves/mean-look.md) | Changed | Flags |
| [Attract](../moves/attract.md) | Changed | Machines |
| [Return](../moves/return.md) | Changed | Power |
| [Frustration](../moves/frustration.md) | Changed | Power |
| [Safeguard](../moves/safeguard.md) | Changed | Machines |
| [Mystical Fire](../moves/mystical-fire.md) | Changed | Name, Damage class, Power, Accuracy, Pp, Effect, Effect chance, Flags, Machines |
| [Magnitude](../moves/magnitude.md) | Changed | Power |
| [Dynamic Punch](../moves/dynamic-punch.md) | Changed | Name |
| [Dragon Breath](../moves/dragon-breath.md) | Changed | Name, Power |
| [Rapid Spin](../moves/rapid-spin.md) | Changed | Power |
| [Sweet Scent](../moves/sweet-scent.md) | Changed | Type, Damage class, Power, Effect, Flags |
| [Moonlight](../moves/moonlight.md) | Changed | Type |
| [Hidden Power](../moves/hidden-power.md) | Changed | Power |
| [Twister](../moves/twister.md) | Changed | Power |
| [Crunch](../moves/crunch.md) | Changed | Pp |
| [Extreme Speed](../moves/extreme-speed.md) | Changed | Name |
| [Ancient Power](../moves/ancient-power.md) | Changed | Name |
| [Shadow Ball](../moves/shadow-ball.md) | Changed | Pp |
| [Future Sight](../moves/future-sight.md) | Changed | Power |
| [Rock Smash](../moves/rock-smash.md) | Changed | Power |
| [Uproar](../moves/uproar.md) | Changed | Flags |
| [Heat Wave](../moves/heat-wave.md) | Changed | Tutors |
| [Torment](../moves/torment.md) | Changed | Machines |
| [Will-O-Wisp](../moves/will-o-wisp.md) | Changed | Accuracy |
| [Psyshield Bash](../moves/psyshield-bash.md) | Changed | Name, Type, Power, Accuracy, Effect, Flags |
| [Follow Me](../moves/follow-me.md) | Changed | Priority |
| [Knock Off](../moves/knock-off.md) | Changed | Power |
| [Dive](../moves/dive.md) | Changed | Power |
| [Arm Thrust](../moves/arm-thrust.md) | Changed | Power |
| [Dazzling Gleam](../moves/dazzling-gleam.md) | Changed | Name, Type, Power, Pp, Effect, Target, Machines |
| [Moonblast](../moves/moonblast.md) | Changed | Name, Type, Power, Pp |
| [Feather Dance](../moves/feather-dance.md) | Changed | Name |
| [Blaze Kick](../moves/blaze-kick.md) | Changed | Accuracy |
| [Ice Ball](../moves/ice-ball.md) | Changed | Type, Accuracy, Flags |
| [Needle Arm](../moves/needle-arm.md) | Changed | Power, Flags |
| [Hyper Voice](../moves/hyper-voice.md) | Changed | Flags |
| [Poison Fang](../moves/poison-fang.md) | Changed | Power, Accuracy, Effect chance |
| [Meteor Mash](../moves/meteor-mash.md) | Changed | Power, Accuracy |
| [Astonish](../moves/astonish.md) | Changed | Power |
| [Weather Ball](../moves/weather-ball.md) | Changed | Machines |
| [Air Cutter](../moves/air-cutter.md) | Changed | Power, Pp |
| [Overheat](../moves/overheat.md) | Changed | Power |
| [Rock Tomb](../moves/rock-tomb.md) | Changed | Power, Accuracy, Pp |
| [Scorching Sands](../moves/scorching-sands.md) | Changed | Name, Type, Damage class, Power, Accuracy, Pp, Effect, Effect chance, Flags |
| [Grass Whistle](../moves/grass-whistle.md) | Changed | Name, Accuracy, Flags |
| [Shadow Punch](../moves/shadow-punch.md) | Changed | Power |
| [Extrasensory](../moves/extrasensory.md) | Changed | Pp |
| [Accelerock](../moves/accelerock.md) | Changed | Name, Type, Power, Accuracy, Pp, Priority, Effect, Effect chance, Flags |
| [Muddy Water](../moves/muddy-water.md) | Changed | Power |
| [Howl](../moves/howl.md) | Changed | Flags |
| [Dragon Claw](../moves/dragon-claw.md) | Changed | Power, Pp, Effect |
| [Bulk Up](../moves/bulk-up.md) | Changed | Pp |
| [Bounce](../moves/bounce.md) | Changed | Tutors |
| [Poison Tail](../moves/poison-tail.md) | Changed | Power, Pp |
| [Covet](../moves/covet.md) | Changed | Type, Pp |
| [Water Sport](../moves/water-sport.md) | Changed | Damage class, Power, Accuracy, Effect, Target, Flags |
| [Calm Mind](../moves/calm-mind.md) | Changed | Pp |
| [Wake-Up Slap](../moves/wake-up-slap.md) | Changed | Power |
| [Feint](../moves/feint.md) | Changed | Flags |
| [Tailwind](../moves/tailwind.md) | Changed | Pp |
| [Payback](../moves/payback.md) | Changed | Machines |
| [Assurance](../moves/assurance.md) | Changed | Power |
| [Embargo](../moves/embargo.md) | Changed | Machines |
| [Fling](../moves/fling.md) | Changed | Machines |
| [Psycho Shift](../moves/psycho-shift.md) | Changed | Accuracy |
| [Wave Crash](../moves/wave-crash.md) | Changed | Name, Type, Power, Pp, Effect, Machines |
| [Sucker Punch](../moves/sucker-punch.md) | Changed | Power |
| [Aura Sphere](../moves/aura-sphere.md) | Changed | Machines |
| [Poison Jab](../moves/poison-jab.md) | Changed | Pp |
| [Dark Pulse](../moves/dark-pulse.md) | Changed | Accuracy, Pp |
| [Aqua Tail](../moves/aqua-tail.md) | Changed | Power, Accuracy |
| [Air Slash](../moves/air-slash.md) | Changed | Pp |
| [X-Scissor](../moves/x-scissor.md) | Changed | Pp, Effect |
| [Bug Buzz](../moves/bug-buzz.md) | Changed | Flags, Machines |
| [Dragon Pulse](../moves/dragon-pulse.md) | Changed | Accuracy, Effect, Tutors |
| [Dragon Rush](../moves/dragon-rush.md) | Changed | Accuracy |
| [Power Gem](../moves/power-gem.md) | Changed | Power, Pp, Effect, Machines |
| [Energy Ball](../moves/energy-ball.md) | Changed | Power |
| [Earth Power](../moves/earth-power.md) | Changed | Tutors |
| [Bullet Punch](../moves/bullet-punch.md) | Changed | Pp |
| [Ice Shard](../moves/ice-shard.md) | Changed | Pp |
| [Shadow Claw](../moves/shadow-claw.md) | Changed | Power |
| [Shadow Sneak](../moves/shadow-sneak.md) | Changed | Pp |
| [Psycho Cut](../moves/psycho-cut.md) | Changed | Power, Pp |
| [Zen Headbutt](../moves/zen-headbutt.md) | Changed | Pp |
| [Flash Cannon](../moves/flash-cannon.md) | Changed | Power |
| [Rock Climb](../moves/rock-climb.md) | Changed | Type, Power, Accuracy, Pp, Machines |
| [Trick Room](../moves/trick-room.md) | Changed | Effect |
| [Draco Meteor](../moves/draco-meteor.md) | Changed | Power |
| [Leaf Storm](../moves/leaf-storm.md) | Changed | Power |
| [Cross Poison](../moves/cross-poison.md) | Changed | Power, Pp |
| [Gunk Shot](../moves/gunk-shot.md) | Changed | Accuracy, Tutors |
| [Grass Knot](../moves/grass-knot.md) | Changed | Power, Effect |
| [Chatter](../moves/chatter.md) | Changed | Power, Pp |
| [Judgment](../moves/judgment.md) | Changed | Power |
| [Charge Beam](../moves/charge-beam.md) | Changed | Pp |
| [Head Smash](../moves/head-smash.md) | Changed | Accuracy |
| [Dark Void](../moves/dark-void.md) | Changed | Accuracy |
| [Wonder Room](../moves/wonder-room.md) | Changed | Priority |
| [Venoshock](../moves/venoshock.md) | Changed | Pp |
| [Rage Powder](../moves/rage-powder.md) | Changed | Priority |
| [Telekinesis](../moves/telekinesis.md) | Changed | Machines |
| [Magic Room](../moves/magic-room.md) | Changed | Priority |
| [Storm Throw](../moves/storm-throw.md) | Changed | Power |
| [Synchronoise](../moves/synchronoise.md) | Changed | Power, Pp |
| [Flame Charge](../moves/flame-charge.md) | Changed | Power |
| [Low Sweep](../moves/low-sweep.md) | Changed | Power |
| [Disarming Voice](../moves/disarming-voice.md) | Changed | Name, Type, Power, Accuracy, Effect, Target, Machines |
| [Echoed Voice](../moves/echoed-voice.md) | Changed | Power, Flags |
| [Ally Switch](../moves/ally-switch.md) | Changed | Priority, Machines |
| [Scald](../moves/scald.md) | Changed | Pp, Effect chance |
| [Hex](../moves/hex.md) | Changed | Power, Pp |
| [Sky Drop](../moves/sky-drop.md) | Changed | Machines |
| [Incinerate](../moves/incinerate.md) | Changed | Power |
| [Bestow](../moves/bestow.md) | Changed | Flags |
| [Inferno](../moves/inferno.md) | Changed | Accuracy |
| [Water Pledge](../moves/water-pledge.md) | Changed | Power |
| [Fire Pledge](../moves/fire-pledge.md) | Changed | Power |
| [Grass Pledge](../moves/grass-pledge.md) | Changed | Power |
| [Struggle Bug](../moves/struggle-bug.md) | Changed | Power, Machines |
| [Frost Breath](../moves/frost-breath.md) | Changed | Power |
| [Dragon Tail](../moves/dragon-tail.md) | Changed | Accuracy |
| [Wild Charge](../moves/wild-charge.md) | Changed | Pp, Effect |
| [Drill Run](../moves/drill-run.md) | Changed | Tutors |
| [Heart Stamp](../moves/heart-stamp.md) | Changed | Power, Pp |
| [Sacred Sword](../moves/sacred-sword.md) | Changed | Pp |
| [Razor Shell](../moves/razor-shell.md) | Changed | Accuracy |
| [Leaf Tornado](../moves/leaf-tornado.md) | Changed | Power, Accuracy |
| [Steamroller](../moves/steamroller.md) | Changed | Power, Accuracy, Pp |
| [Hurricane](../moves/hurricane.md) | Changed | Power, Accuracy, Pp, Machines |
| [Gear Grind](../moves/gear-grind.md) | Changed | Power, Accuracy, Pp |
| [Techno Blast](../moves/techno-blast.md) | Changed | Power |
| [Glaciate](../moves/glaciate.md) | Changed | Power, Accuracy |
| [Icicle Crash](../moves/icicle-crash.md) | Changed | Flags |

## Items

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Ultra Ball](../items/ultra-ball.md) | Changed | Price, Shops |
| [Great Ball](../items/great-ball.md) | Changed | Price, Shops |
| [Poké Ball](../items/poke-ball.md) | Changed | Price, Shops |
| [Net Ball](../items/net-ball.md) | Changed | Shops |
| [Dive Ball](../items/dive-ball.md) | Changed | Shops |
| [Nest Ball](../items/nest-ball.md) | Changed | Shops |
| [Timer Ball](../items/timer-ball.md) | Changed | Shops |
| [Luxury Ball](../items/luxury-ball.md) | Changed | Shops |
| [Dusk Ball](../items/dusk-ball.md) | Changed | Shops |
| [Heal Ball](../items/heal-ball.md) | Changed | Shops |
| [Quick Ball](../items/quick-ball.md) | Changed | Shops |
| [Potion](../items/potion.md) | Changed | Shops, Trainer battle items |
| [Antidote](../items/antidote.md) | Changed | Shops |
| [Burn Heal](../items/burn-heal.md) | Changed | Shops |
| [Ice Heal](../items/ice-heal.md) | Changed | Shops |
| [Awakening](../items/awakening.md) | Changed | Shops |
| [Paralyze Heal](../items/paralyze-heal.md) | Changed | Name, Shops |
| [Full Restore](../items/full-restore.md) | Changed | Trainer battle items |
| [Max Potion](../items/max-potion.md) | Changed | Shops, Trainer battle items |
| [Hyper Potion](../items/hyper-potion.md) | Changed | Shops, Trainer battle items |
| [Super Potion](../items/super-potion.md) | Changed | Shops, Trainer battle items |
| [Full Heal](../items/full-heal.md) | Changed | Shops, Trainer battle items |
| [Revive](../items/revive.md) | Changed | Shops |
| [Lemonade](../items/lemonade.md) | Changed | Locations |
| [Energy Powder](../items/energy-powder.md) | Changed | Name |
| [Berry Juice](../items/berry-juice.md) | Changed | Trainer Held By |
| [HP Up](../items/hp-up.md) | Changed | Shops |
| [Protein](../items/protein.md) | Changed | Shops |
| [Iron](../items/iron.md) | Changed | Shops |
| [Carbos](../items/carbos.md) | Changed | Shops |
| [Calcium](../items/calcium.md) | Changed | Shops |
| [PP Up](../items/pp-up.md) | Changed | Shops |
| [Zinc](../items/zinc.md) | Changed | Shops |
| [PP Max](../items/pp-max.md) | Changed | Shops |
| [Guard Spec.](../items/guard-spec.md) | Changed | Shops |
| [Dire Hit](../items/dire-hit.md) | Changed | Shops |
| [X Attack](../items/x-attack.md) | Changed | Shops |
| [X Defend](../items/x-defend.md) | Changed | Shops |
| [X Speed](../items/x-speed.md) | Changed | Shops |
| [X Accuracy](../items/x-accuracy.md) | Changed | Shops |
| [X Sp. Atk](../items/x-sp-atk.md) | Changed | Name, Shops, Trainer battle items |
| [X Sp. Def](../items/x-sp-def.md) | Changed | Shops |
| [Red Shard](../items/red-shard.md) | Changed | Price, Shops |
| [Blue Shard](../items/blue-shard.md) | Changed | Price, Shops |
| [Yellow Shard](../items/yellow-shard.md) | Changed | Price, Shops |
| [Green Shard](../items/green-shard.md) | Changed | Price, Shops |
| [Super Repel](../items/super-repel.md) | Changed | Shops |
| [Max Repel](../items/max-repel.md) | Changed | Shops |
| [Escape Rope](../items/escape-rope.md) | Changed | Shops |
| [Repel](../items/repel.md) | Changed | Shops |
| [Sun Stone](../items/sun-stone.md) | Changed | Shops, Evolutions |
| [Moon Stone](../items/moon-stone.md) | Changed | Shops, Evolutions |
| [Fire Stone](../items/fire-stone.md) | Changed | Shops |
| [Thunder Stone](../items/thunder-stone.md) | Changed | Name, Shops |
| [Water Stone](../items/water-stone.md) | Changed | Shops |
| [Leaf Stone](../items/leaf-stone.md) | Changed | Shops, Evolutions |
| [Tiny Mushroom](../items/tiny-mushroom.md) | Changed | Name |
| [Heart Scale](../items/heart-scale.md) | Changed | Price, Locations, Shops, Wild Held By |
| [Honey](../items/honey.md) | Changed | Shops |
| [Shiny Stone](../items/shiny-stone.md) | Changed | Shops |
| [Dusk Stone](../items/dusk-stone.md) | Changed | Shops |
| [Dawn Stone](../items/dawn-stone.md) | Changed | Shops |
| [Link Cable](../items/link-cable-110.md) | Changed | Name, Shops, Wild Held By, Evolutions |
| [Griseous Orb](../items/griseous-orb.md) | Changed | Wild Held By, Trainer Held By |
| [Douse Drive](../items/douse-drive.md) | Changed | Locations, Trainer Held By |
| [Adamant Orb](../items/adamant-orb.md) | Changed | Trainer Held By |
| [Lustrous Orb](../items/lustrous-orb.md) | Changed | Trainer Held By |
| [Greet Mail](../items/greet-mail.md) | Changed | Shops |
| [Favored Mail](../items/favored-mail.md) | Changed | Shops |
| [RSVP Mail](../items/rsvp-mail.md) | Changed | Shops |
| [Thanks Mail](../items/thanks-mail.md) | Changed | Shops |
| [Inquiry Mail](../items/inquiry-mail.md) | Changed | Shops |
| [Like Mail](../items/like-mail.md) | Changed | Shops |
| [Reply Mail](../items/reply-mail.md) | Changed | Shops |
| [Bridge Mail S](../items/bridge-mail-s.md) | Changed | Name |
| [Bridge Mail D](../items/bridge-mail-d.md) | Changed | Name, Shops |
| [Bridge Mail T](../items/bridge-mail-t.md) | Changed | Name |
| [Bridge Mail V](../items/bridge-mail-v.md) | Changed | Name |
| [Bridge Mail M](../items/bridge-mail-m.md) | Changed | Name |
| [Cheri Berry](../items/cheri-berry.md) | Changed | Trainer Held By |
| [Chesto Berry](../items/chesto-berry.md) | Changed | Shops, Trainer Held By |
| [Pecha Berry](../items/pecha-berry.md) | Changed | Shops |
| [Rawst Berry](../items/rawst-berry.md) | Changed | Shops |
| [Aspear Berry](../items/aspear-berry.md) | Changed | Shops |
| [Leppa Berry](../items/leppa-berry.md) | Changed | Trades |
| [Oran Berry](../items/oran-berry.md) | Changed | Shops, Wild Held By, Trainer Held By |
| [Persim Berry](../items/persim-berry.md) | Changed | Shops, Trainer Held By |
| [Lum Berry](../items/lum-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Sitrus Berry](../items/sitrus-berry.md) | Changed | Shops, Wild Held By, Trainer Held By, Trades |
| [Figy Berry](../items/figy-berry.md) | Changed | Shops |
| [Wiki Berry](../items/wiki-berry.md) | Changed | Shops |
| [Mago Berry](../items/mago-berry.md) | Changed | Shops |
| [Aguav Berry](../items/aguav-berry.md) | Changed | Shops |
| [Iapapa Berry](../items/iapapa-berry.md) | Changed | Shops |
| [Pomeg Berry](../items/pomeg-berry.md) | Changed | Shops |
| [Kelpsy Berry](../items/kelpsy-berry.md) | Changed | Shops |
| [Qualot Berry](../items/qualot-berry.md) | Changed | Shops |
| [Hondew Berry](../items/hondew-berry.md) | Changed | Shops |
| [Grepa Berry](../items/grepa-berry.md) | Changed | Shops |
| [Tamato Berry](../items/tamato-berry.md) | Changed | Shops |
| [Occa Berry](../items/occa-berry.md) | Changed | Trainer Held By |
| [Passho Berry](../items/passho-berry.md) | Changed | Trainer Held By |
| [Wacan Berry](../items/wacan-berry.md) | Changed | Trainer Held By |
| [Rindo Berry](../items/rindo-berry.md) | Changed | Trainer Held By |
| [Yache Berry](../items/yache-berry.md) | Changed | Trainer Held By |
| [Chople Berry](../items/chople-berry.md) | Changed | Trainer Held By |
| [Shuca Berry](../items/shuca-berry.md) | Changed | Trainer Held By |
| [Coba Berry](../items/coba-berry.md) | Changed | Trainer Held By |
| [Payapa Berry](../items/payapa-berry.md) | Changed | Trainer Held By |
| [Tanga Berry](../items/tanga-berry.md) | Changed | Trainer Held By |
| [Charti Berry](../items/charti-berry.md) | Changed | Trainer Held By |
| [Kasib Berry](../items/kasib-berry.md) | Changed | Trainer Held By |
| [Haban Berry](../items/haban-berry.md) | Changed | Trainer Held By |
| [Colbur Berry](../items/colbur-berry.md) | Changed | Trainer Held By |
| [Liechi Berry](../items/liechi-berry.md) | Changed | Trainer Held By |
| [Ganlon Berry](../items/ganlon-berry.md) | Changed | Trainer Held By |
| [Salac Berry](../items/salac-berry.md) | Changed | Trainer Held By |
| [Petaya Berry](../items/petaya-berry.md) | Changed | Trainer Held By |
| [Lansat Berry](../items/lansat-berry.md) | Changed | Wild Held By |
| [Starf Berry](../items/starf-berry.md) | Changed | Locations, Wild Held By |
| [Enigma Berry](../items/enigma-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Micle Berry](../items/micle-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Custap Berry](../items/custap-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Jaboca Berry](../items/jaboca-berry.md) | Changed | Wild Held By |
| [Rowap Berry](../items/rowap-berry.md) | Changed | Wild Held By |
| [Bright Powder](../items/bright-powder.md) | Changed | Name, Trainer Held By |
| [White Herb](../items/white-herb.md) | Changed | Shops, Trainer Held By |
| [Quick Claw](../items/quick-claw.md) | Changed | Trainer Held By |
| [Mental Herb](../items/mental-herb.md) | Changed | Shops, Trainer Held By |
| [Choice Band](../items/choice-band.md) | Changed | Trainer Held By |
| [King's Rock](../items/kings-rock.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Silver Powder](../items/silver-powder.md) | Changed | Name |
| [Soul Dew](../items/soul-dew.md) | Changed | Wild Held By, Trainer Held By |
| [Deep Sea Tooth](../items/deep-sea-tooth.md) | Changed | Name, Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Deep Sea Scale](../items/deep-sea-scale.md) | Changed | Name, Field use, Field-use function, Party use, Party effects, Locations, Shops, Evolutions |
| [Smoke Ball](../items/smoke-ball.md) | Changed | Shops |
| [Everstone](../items/everstone.md) | Changed | Locations, Shops |
| [Focus Band](../items/focus-band.md) | Changed | Trainer Held By |
| [Lucky Egg](../items/lucky-egg.md) | Changed | Wild Held By, Trades |
| [Scope Lens](../items/scope-lens.md) | Changed | Trainer Held By |
| [Metal Coat](../items/metal-coat.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Leftovers](../items/leftovers.md) | Changed | Wild Held By, Trainer Held By |
| [Dragon Scale](../items/dragon-scale.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Light Ball](../items/light-ball.md) | Changed | Shops, Trainer Held By |
| [Hard Stone](../items/hard-stone.md) | Changed | Trainer Held By |
| [Miracle Seed](../items/miracle-seed.md) | Changed | Trainer Held By |
| [Black Glasses](../items/black-glasses.md) | Changed | Name |
| [Magnet](../items/magnet.md) | Changed | Trainer Held By |
| [Mystic Water](../items/mystic-water.md) | Changed | Trainer Held By |
| [Sharp Beak](../items/sharp-beak.md) | Changed | Trainer Held By |
| [Never-Melt Ice](../items/never-melt-ice.md) | Changed | Name, Trainer Held By |
| [Twisted Spoon](../items/twisted-spoon.md) | Changed | Name, Trainer Held By |
| [Charcoal](../items/charcoal.md) | Changed | Trainer Held By |
| [Dragon Fang](../items/dragon-fang.md) | Changed | Trainer Held By |
| [Silk Scarf](../items/silk-scarf.md) | Changed | Trainer Held By |
| [Upgrade](../items/up-grade.md) | Changed | Name, Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Shell Bell](../items/shell-bell.md) | Changed | Trainer Held By |
| [Sea Incense](../items/sea-incense.md) | Changed | Shops |
| [Lax Incense](../items/lax-incense.md) | Changed | Shops |
| [Metal Powder](../items/metal-powder.md) | Changed | Trades |
| [Thick Club](../items/thick-club.md) | Changed | Wild Held By, Trainer Held By |
| [Red Scarf](../items/red-scarf.md) | Changed | Price, Field use, Field-use function, Fling power, Party use, Party effects, Shops |
| [Ice Stone](../items/ice-stone.md) | Changed | Name, Price, Field use, Field-use function, Fling power, Party use, Party effects, Shops, Evolutions |
| [Link Cable](../items/link-cable-262.md) | Changed | Name, Price, Field use, Field-use function, Fling power, Party use, Party effects |
| [Wide Lens](../items/wide-lens.md) | Changed | Trainer Held By |
| [Muscle Band](../items/muscle-band.md) | Changed | Trainer Held By |
| [Wise Glasses](../items/wise-glasses.md) | Changed | Trainer Held By |
| [Expert Belt](../items/expert-belt.md) | Changed | Trainer Held By |
| [Light Clay](../items/light-clay.md) | Changed | Trainer Held By |
| [Life Orb](../items/life-orb.md) | Changed | Trainer Held By |
| [Power Herb](../items/power-herb.md) | Changed | Shops, Wild Held By, Trainer Held By |
| [Toxic Orb](../items/toxic-orb.md) | Changed | Shops, Trainer Held By |
| [Flame Orb](../items/flame-orb.md) | Changed | Shops, Trainer Held By |
| [Quick Powder](../items/quick-powder.md) | Changed | Trainer Held By |
| [Focus Sash](../items/focus-sash.md) | Changed | Trainer Held By |
| [Zoom Lens](../items/zoom-lens.md) | Changed | Trainer Held By |
| [Metronome](../items/metronome.md) | Changed | Trainer Held By, Trades |
| [Iron Ball](../items/iron-ball.md) | Changed | Trainer Held By |
| [Lagging Tail](../items/lagging-tail.md) | Changed | Trainer Held By |
| [Black Sludge](../items/black-sludge.md) | Changed | Trainer Held By |
| [Icy Rock](../items/icy-rock.md) | Changed | Shops, Trainer Held By |
| [Smooth Rock](../items/smooth-rock.md) | Changed | Shops, Trainer Held By |
| [Heat Rock](../items/heat-rock.md) | Changed | Locations, Shops, Trainer Held By |
| [Damp Rock](../items/damp-rock.md) | Changed | Shops, Trainer Held By |
| [Grip Claw](../items/grip-claw.md) | Changed | Locations |
| [Choice Scarf](../items/choice-scarf.md) | Changed | Trainer Held By |
| [Power Anklet](../items/power-anklet.md) | Changed | Trades |
| [Power Weight](../items/power-weight.md) | Changed | Trades |
| [Big Root](../items/big-root.md) | Changed | Trainer Held By |
| [Choice Specs](../items/choice-specs.md) | Changed | Trainer Held By |
| [Spooky Plate](../items/spooky-plate.md) | Changed | Locations |
| [Draco Plate](../items/draco-plate.md) | Changed | Locations |
| [Odd Incense](../items/odd-incense.md) | Changed | Shops |
| [Rock Incense](../items/rock-incense.md) | Changed | Shops |
| [Full Incense](../items/full-incense.md) | Changed | Shops |
| [Wave Incense](../items/wave-incense.md) | Changed | Shops |
| [Rose Incense](../items/rose-incense.md) | Changed | Shops |
| [Luck Incense](../items/luck-incense.md) | Changed | Shops |
| [Pure Incense](../items/pure-incense.md) | Changed | Shops |
| [Protector](../items/protector.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Electirizer](../items/electirizer.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Magmarizer](../items/magmarizer.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Dubious Disc](../items/dubious-disc.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Reaper Cloth](../items/reaper-cloth.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Razor Claw](../items/razor-claw.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Trainer Held By, Evolutions |
| [Razor Fang](../items/razor-fang.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [TM50](../items/tm50.md) | Changed | Locations |
| [Coupon 1](../items/coupon-1.md) | Changed | Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects |
| [Coupon 2](../items/coupon-2.md) | Changed | Price, Pocket, Field pocket, Field use, Field-use function, Battle-use function, Fling power, Party use, Party effects |
| [Coupon 3](../items/coupon-3.md) | Changed | Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects |
| [Secret Potion](../items/secret-potion.md) | Changed | Name |
| [Dowsing Machine](../items/dowsing-machine.md) | Changed | Name |
| [Slowpoke Tail](../items/slowpoke-tail.md) | Changed | Name |
| [Squirt Bottle](../items/squirt-bottle.md) | Changed | Name |
| [Rage Candy Bar](../items/rage-candy-bar.md) | Changed | Name |
| [Prism Scale](../items/prism-scale.md) | Changed | Field use, Field-use function, Party use, Party effects, Shops, Evolutions |
| [Eviolite](../items/eviolite.md) | Changed | Shops, Trainer Held By |
| [Float Stone](../items/float-stone.md) | Changed | Shops |
| [Rocky Helmet](../items/rocky-helmet.md) | Changed | Trainer Held By |
| [Air Balloon](../items/air-balloon.md) | Changed | Trainer Held By |
| [Red Card](../items/red-card.md) | Changed | Trainer Held By |
| [Absorb Bulb](../items/absorb-bulb.md) | Changed | Trainer Held By |
| [Cell Battery](../items/cell-battery.md) | Changed | Trainer Held By |
| [Eject Button](../items/eject-button.md) | Changed | Trainer Held By |
| [Fire Gem](../items/fire-gem.md) | Changed | Trainer Held By |
| [Water Gem](../items/water-gem.md) | Changed | Trainer Held By |
| [Electric Gem](../items/electric-gem.md) | Changed | Trainer Held By |
| [Grass Gem](../items/grass-gem.md) | Changed | Trainer Held By |
| [Ice Gem](../items/ice-gem.md) | Changed | Trainer Held By |
| [Fighting Gem](../items/fighting-gem.md) | Changed | Trainer Held By |
| [Flying Gem](../items/flying-gem.md) | Changed | Trainer Held By |
| [Psychic Gem](../items/psychic-gem.md) | Changed | Trainer Held By |
| [Bug Gem](../items/bug-gem.md) | Changed | Trainer Held By |
| [Rock Gem](../items/rock-gem.md) | Changed | Trainer Held By |
| [Dragon Gem](../items/dragon-gem.md) | Changed | Trainer Held By |
| [Dark Gem](../items/dark-gem.md) | Changed | Trainer Held By |
| [Normal Gem](../items/normal-gem.md) | Changed | Trainer Held By |
| [Poké Toy](../items/poke-toy.md) | Changed | Shops |
| [Balm Mushroom](../items/balm-mushroom.md) | Changed | Name |
| [Old Sea Map](../items/old-sea-map.md) | Added | — |
| [Xtransceiver](../items/xtransceiver-626.md) | Changed | Wild Held By |
| [Colress Machine](../items/colress-machine.md) | Changed | Name |

## Wild encounters

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Striaton City](../encounters/map-000.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 001](../encounters/map-001.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Icirrus City](../encounters/map-002-spring.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002-summer.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002-autumn.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002-winter.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Aspertia City](../encounters/map-003.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Virbank City](../encounters/map-004.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 005](../encounters/map-005.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 006](../encounters/map-006.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Dreamyard](../encounters/map-007.md) | Changed | Doubles Grass |
| [Map 008](../encounters/map-008.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 009](../encounters/map-009.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 010](../encounters/map-010.md) | Changed | Grass/Cave |
| [Map 011](../encounters/map-011.md) | Changed | Grass/Cave |
| [Map 012](../encounters/map-012.md) | Changed | Grass/Cave |
| [Map 013](../encounters/map-013.md) | Changed | Grass/Cave |
| [Map 014](../encounters/map-014.md) | Changed | Grass/Cave |
| [Map 015](../encounters/map-015.md) | Changed | Grass/Cave |
| [Map 016](../encounters/map-016.md) | Changed | Grass/Cave |
| [Map 017](../encounters/map-017.md) | Changed | Grass/Cave |
| [Map 018](../encounters/map-018.md) | Changed | Grass/Cave |
| [Map 019](../encounters/map-019.md) | Changed | Grass/Cave |
| [Map 020](../encounters/map-020.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 021](../encounters/map-021.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 022](../encounters/map-022.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 023 (Spring)](../encounters/map-023-spring.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 023 (Summer)](../encounters/map-023-summer.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 023 (Autumn)](../encounters/map-023-autumn.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 023 (Winter)](../encounters/map-023-winter.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 024 (Spring)](../encounters/map-024-spring.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 024 (Summer)](../encounters/map-024-summer.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 024 (Autumn)](../encounters/map-024-autumn.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 024 (Winter)](../encounters/map-024-winter.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 025 (Spring)](../encounters/map-025-spring.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 025 (Summer)](../encounters/map-025-summer.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 025 (Autumn)](../encounters/map-025-autumn.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 025 (Winter)](../encounters/map-025-winter.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 026 (Spring)](../encounters/map-026-spring.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 026 (Summer)](../encounters/map-026-summer.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 026 (Autumn)](../encounters/map-026-autumn.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 026 (Winter)](../encounters/map-026-winter.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 027 (Spring)](../encounters/map-027-spring.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 027 (Summer)](../encounters/map-027-summer.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 027 (Autumn)](../encounters/map-027-autumn.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 027 (Winter)](../encounters/map-027-winter.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 028 (Spring)](../encounters/map-028-spring.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 028 (Summer)](../encounters/map-028-summer.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 028 (Autumn)](../encounters/map-028-autumn.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 028 (Winter)](../encounters/map-028-winter.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 029](../encounters/map-029.md) | Changed | Grass/Cave |
| [Map 030](../encounters/map-030.md) | Changed | Grass/Cave |
| [Map 031](../encounters/map-031.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 032](../encounters/map-032.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 033](../encounters/map-033.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 034](../encounters/map-034.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 035](../encounters/map-035.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 036](../encounters/map-036.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Castelia Sewers](../encounters/map-037.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 038](../encounters/map-038.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 039](../encounters/map-039.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 040](../encounters/map-040.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 041](../encounters/map-041.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 042](../encounters/map-042.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 043 (Spring)](../encounters/map-043-spring.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 043 (Summer)](../encounters/map-043-summer.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 043 (Autumn)](../encounters/map-043-autumn.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 043 (Winter)](../encounters/map-043-winter.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 044](../encounters/map-044.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 045](../encounters/map-045.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 046](../encounters/map-046.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 047](../encounters/map-047.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 048](../encounters/map-048.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 049](../encounters/map-049.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 050](../encounters/map-050.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 051](../encounters/map-051.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 052](../encounters/map-052.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 053](../encounters/map-053.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 054](../encounters/map-054.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 055](../encounters/map-055.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 056](../encounters/map-056.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 057](../encounters/map-057.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 058](../encounters/map-058.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 059](../encounters/map-059.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 060](../encounters/map-060.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 061](../encounters/map-061.md) | Changed | Grass/Cave |
| [Map 062](../encounters/map-062.md) | Changed | Grass/Cave |
| [Map 063](../encounters/map-063.md) | Changed | Grass/Cave |
| [Map 064](../encounters/map-064.md) | Changed | Grass/Cave |
| [Map 065](../encounters/map-065.md) | Changed | Grass/Cave |
| [Map 066](../encounters/map-066.md) | Changed | Grass/Cave |
| [Strange House](../encounters/map-067.md) | Changed | Grass/Cave |
| [Map 068](../encounters/map-068.md) | Changed | Grass/Cave |
| [Map 069](../encounters/map-069.md) | Changed | Grass/Cave |
| [Strange House](../encounters/map-070.md) | Changed | Grass/Cave |
| [Map 071](../encounters/map-071.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 072](../encounters/map-072.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 073](../encounters/map-073.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 074](../encounters/map-074.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 075](../encounters/map-075.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 076](../encounters/map-076.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 077](../encounters/map-077.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 078](../encounters/map-078.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 079](../encounters/map-079.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 080](../encounters/map-080.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 081](../encounters/map-081.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 082](../encounters/map-082.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 083](../encounters/map-083.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 084](../encounters/map-084.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 085](../encounters/map-085.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 086](../encounters/map-086.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 087](../encounters/map-087.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 088](../encounters/map-088.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 089](../encounters/map-089.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 090](../encounters/map-090.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 091](../encounters/map-091.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 092](../encounters/map-092.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 093](../encounters/map-093.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 094](../encounters/map-094.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 095](../encounters/map-095.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Driftveil Drawbridge](../encounters/map-096.md) | Changed | Shaking Spots |
| [Village Bridge](../encounters/map-097.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Marvelous Bridge](../encounters/map-098.md) | Changed | Shaking Spots |
| [Map 099](../encounters/map-099.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 100](../encounters/map-100.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 101](../encounters/map-101.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 102](../encounters/map-102.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 103](../encounters/map-103.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 104](../encounters/map-104.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 105](../encounters/map-105.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 106](../encounters/map-106.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 107 (Spring)](../encounters/map-107-spring.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 107 (Summer)](../encounters/map-107-summer.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 107 (Autumn)](../encounters/map-107-autumn.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 107 (Winter)](../encounters/map-107-winter.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 108](../encounters/map-108.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 109](../encounters/map-109.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 110](../encounters/map-110.md) | Changed | Grass/Cave, Shaking Spots |
| [Map 111 (Spring)](../encounters/map-111-spring.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 111 (Summer)](../encounters/map-111-summer.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 111 (Autumn)](../encounters/map-111-autumn.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 111 (Winter)](../encounters/map-111-winter.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 112](../encounters/map-112.md) | Changed | Grass/Cave |
| [Map 113](../encounters/map-113.md) | Changed | Grass/Cave |
| [Map 114](../encounters/map-114.md) | Changed | Grass/Cave |
| [Map 115](../encounters/map-115.md) | Changed | Grass/Cave |
| [Map 116 (Spring)](../encounters/map-116-spring.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 116 (Summer)](../encounters/map-116-summer.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 116 (Autumn)](../encounters/map-116-autumn.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 116 (Winter)](../encounters/map-116-winter.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 117 (Spring)](../encounters/map-117-spring.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 117 (Summer)](../encounters/map-117-summer.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 117 (Autumn)](../encounters/map-117-autumn.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 117 (Winter)](../encounters/map-117-winter.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 118](../encounters/map-118.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 119](../encounters/map-119.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 120](../encounters/map-120.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 121](../encounters/map-121.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 122](../encounters/map-122.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 123](../encounters/map-123.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 124](../encounters/map-124.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 125](../encounters/map-125.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Map 126](../encounters/map-126.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 127](../encounters/map-127.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 128](../encounters/map-128.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 129 (Spring)](../encounters/map-129-spring.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 129 (Summer)](../encounters/map-129-summer.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 129 (Autumn)](../encounters/map-129-autumn.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 129 (Winter)](../encounters/map-129-winter.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 130](../encounters/map-130.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 131](../encounters/map-131.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Town](../encounters/map-132.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 133](../encounters/map-133.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Map 134](../encounters/map-134.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |

## Trainers

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Smasher --](../trainers/trainer-0001.md) | Changed | Party |
| [Linebacker Elena](../trainers/trainer-0002.md) | Changed | Party |
| [Smasher Dan](../trainers/trainer-0003.md) | Changed | Party |
| [⒆⒇ Trainer Aspen](../trainers/trainer-0004.md) | Changed | Party, Script references |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0005.md) | Changed | Party |
| [⒆⒇ Trainer N](../trainers/trainer-0006.md) | Changed | Party |
| [Worker N](../trainers/trainer-0007.md) | Changed | Party |
| [Hoopster Matthew](../trainers/trainer-0008.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0009.md) | Changed | Party |
| [Clerk ⑮ John](../trainers/trainer-0010.md) | Changed | Party |
| [Waiter Trisha](../trainers/trainer-0011.md) | Changed | AI flags, Party |
| [Waitress Lou](../trainers/trainer-0012.md) | Changed | AI flags, Party |
| [Striker Olwen](../trainers/trainer-0013.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0014.md) | Changed | Party |
| [Roughneck Roberto](../trainers/trainer-0015.md) | Changed | Party |
| [Youngster Fletcher](../trainers/trainer-0016.md) | Changed | Party |
| [Youngster Abe](../trainers/trainer-0017.md) | Changed | Party |
| [Fisherman Kevin](../trainers/trainer-0018.md) | Changed | Party |
| [Clerk ⑭ Devon](../trainers/trainer-0019.md) | Changed | Party |
| [Clerk ⑭ Chaz](../trainers/trainer-0020.md) | Changed | Party |
| [Backers Joe & Ross](../trainers/trainer-0023.md) | Changed | Party |
| [⒆⒇ Ranger Bob](../trainers/trainer-0027.md) | Changed | Party |
| [⒆⒇ Ranger Alain](../trainers/trainer-0028.md) | Changed | Party |
| [Infielder Heidi](../trainers/trainer-0029.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0030.md) | Changed | Party |
| [Ace Trainer Connor](../trainers/trainer-0031.md) | Changed | Party |
| [Ace Trainer Mariana](../trainers/trainer-0032.md) | Changed | Party |
| [Lass Henry](../trainers/trainer-0033.md) | Changed | Party |
| [Lady Brad](../trainers/trainer-0035.md) | Changed | Party |
| [Socialite Elizandra](../trainers/trainer-0036.md) | Changed | Party |
| [Gentleman Cassandra](../trainers/trainer-0037.md) | Changed | Party |
| [Elite Four Robert](../trainers/trainer-0038.md) | Changed | AI battle items, Party |
| [Elite Four Shauntal](../trainers/trainer-0039.md) | Changed | AI battle items, Party |
| [Elite Four Marshal](../trainers/trainer-0040.md) | Changed | AI battle items, Party |
| [Elite Four Grimsley](../trainers/trainer-0041.md) | Changed | AI battle items, Party |
| [Veteran Caitlin](../trainers/trainer-0042.md) | Changed | Party |
| [Ace Trainer Shaun](../trainers/trainer-0043.md) | Changed | Party |
| [Ace Trainer Lucca](../trainers/trainer-0044.md) | Changed | Party |
| [Ace Trainer Shel](../trainers/trainer-0045.md) | Changed | Party |
| [Rich Boy Austin](../trainers/trainer-0046.md) | Changed | Party |
| [Lass Martin](../trainers/trainer-0047.md) | Changed | Party |
| [Smasher Persephone](../trainers/trainer-0048.md) | Changed | Party |
| [Smasher Elena](../trainers/trainer-0052.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0055.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0056.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0057.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0060.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0061.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0062.md) | Changed | Party |
| [Hoopster Bob](../trainers/trainer-0068.md) | Changed | Party |
| [Hoopster Lamarcus](../trainers/trainer-0069.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0070.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0071.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0072.md) | Changed | Party |
| [Backers Joe & Ross](../trainers/trainer-0077.md) | Changed | Party |
| [Backers Masa & Yas](../trainers/trainer-0078.md) | Changed | Party |
| [Backers Masa & Yas](../trainers/trainer-0079.md) | Changed | Party |
| [Backers Les & Web](../trainers/trainer-0080.md) | Changed | Party |
| [Backers Alf & Fred](../trainers/trainer-0081.md) | Changed | Party |
| [Backers Kay & Ali](../trainers/trainer-0082.md) | Changed | Party |
| [Backers Kay & Ali](../trainers/trainer-0083.md) | Changed | Party |
| [Backers Ami & Eira](../trainers/trainer-0084.md) | Changed | Party |
| [Backers Cam & Abby](../trainers/trainer-0086.md) | Changed | Party |
| [Backers Ai & Ciel](../trainers/trainer-0087.md) | Changed | Party |
| [Lass Kat & Phae](../trainers/trainer-0088.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0090.md) | Changed | Party |
| [Ace Trainer Sally](../trainers/trainer-0091.md) | Changed | Party |
| [Ace Trainer Lucille](../trainers/trainer-0092.md) | Changed | Party |
| [Veteran Arlen](../trainers/trainer-0094.md) | Changed | Party |
| [⒆⒇ Breeder Sayuri](../trainers/trainer-0095.md) | Changed | Party |
| [⒆⒇ Breeder Owen](../trainers/trainer-0096.md) | Changed | Party |
| [Waiter Brooke](../trainers/trainer-0097.md) | Changed | Party |
| [Waitress Clint](../trainers/trainer-0098.md) | Changed | Party |
| [Scientist Bonita](../trainers/trainer-0099.md) | Changed | Party |
| [Lady Blythe](../trainers/trainer-0101.md) | Changed | Party |
| [Rich Boy Sophie](../trainers/trainer-0102.md) | Changed | Party |
| [Socialite Anthony](../trainers/trainer-0103.md) | Changed | Party |
| [Pokéfan Colin](../trainers/trainer-0108.md) | Changed | Party |
| [Pilot Darcy](../trainers/trainer-0109.md) | Changed | Party |
| [Worker Leonard](../trainers/trainer-0110.md) | Changed | Party |
| [Nursery Aide Lilly](../trainers/trainer-0112.md) | Changed | Party |
| [Clerk ⑭ Leah](../trainers/trainer-0113.md) | Changed | Party |
| [Clerk ⑮ Nelson](../trainers/trainer-0114.md) | Changed | Party |
| [Backpacker Caleb](../trainers/trainer-0116.md) | Changed | Party |
| [Backpacker Patty](../trainers/trainer-0117.md) | Changed | Party |
| [Psychic Kirsten](../trainers/trainer-0120.md) | Changed | Party |
| [Psychic Gerard](../trainers/trainer-0121.md) | Changed | Party |
| [Depot Agent Madhu](../trainers/trainer-0122.md) | Changed | Party |
| [Dancer Josh](../trainers/trainer-0123.md) | Changed | Party |
| [Musician Davey](../trainers/trainer-0124.md) | Changed | Party |
| [Harlequin Boris](../trainers/trainer-0125.md) | Changed | Party |
| [Maid Jeff](../trainers/trainer-0128.md) | Changed | Party |
| [Parasol Lady Alica](../trainers/trainer-0129.md) | Changed | Party |
| [Hiker Gwyneth](../trainers/trainer-0130.md) | Changed | Party |
| [Preschooler Russel](../trainers/trainer-0131.md) | Changed | Party |
| [Preschooler Mia](../trainers/trainer-0132.md) | Changed | Party |
| [Ace Trainer Evan](../trainers/trainer-0133.md) | Changed | Party |
| [Ace Trainer Angi](../trainers/trainer-0134.md) | Changed | Party |
| [Scientist Miguel](../trainers/trainer-0135.md) | Changed | Party, Script references |
| [Hiker Dudley](../trainers/trainer-0136.md) | Changed | Party |
| [Dancer Winter](../trainers/trainer-0138.md) | Changed | Party |
| [Waitress Dirk](../trainers/trainer-0139.md) | Changed | Party |
| [GAME FREAK Aurora](../trainers/trainer-0140.md) | Changed | Party |
| [Maid Morimoto](../trainers/trainer-0141.md) | Changed | Party |
| [Veteran Tanya](../trainers/trainer-0142.md) | Changed | Party |
| [Elite Four Murphy](../trainers/trainer-0143.md) | Changed | Party |
| [Elite Four Shauntal](../trainers/trainer-0144.md) | Changed | Party |
| [Elite Four Marshal](../trainers/trainer-0145.md) | Changed | Party |
| [Elite Four Grimsley](../trainers/trainer-0146.md) | Changed | Party |
| [Lady Caitlin](../trainers/trainer-0147.md) | Changed | AI flags, Party |
| [Lady Lina](../trainers/trainer-0148.md) | Changed | AI flags, Party |
| [Pilot Colette](../trainers/trainer-0149.md) | Changed | AI flags, Party |
| [Pilot Flynn](../trainers/trainer-0150.md) | Changed | AI flags, Party |
| [Pilot Winslow](../trainers/trainer-0151.md) | Changed | AI flags, Party |
| [Pilot Ewing](../trainers/trainer-0152.md) | Changed | AI flags, Party |
| [Leader Chase](../trainers/trainer-0153.md) | Changed | Party |
| [Leader Elesa](../trainers/trainer-0154.md) | Changed | Party |
| [Leader Burgh](../trainers/trainer-0155.md) | Changed | Party |
| [Leader Skyla](../trainers/trainer-0156.md) | Changed | Party |
| [Leader Cheren](../trainers/trainer-0157.md) | Changed | Party |
| [Leader Roxie](../trainers/trainer-0158.md) | Changed | Party |
| [Leader Clay](../trainers/trainer-0159.md) | Changed | Party |
| [Leader Drayden](../trainers/trainer-0160.md) | Changed | AI battle items, Party |
| [⒆⒇ Trainer Marlon](../trainers/trainer-0161.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0162.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0163.md) | Changed | Party |
| [Youngster Rival](../trainers/trainer-0164.md) | Changed | Party |
| [Lass Terrell](../trainers/trainer-0165.md) | Changed | Party |
| [⒆⒇ Trainer Isabel](../trainers/trainer-0166.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0167.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0168.md) | Changed | Party, Script references |
| [School Kid Rival](../trainers/trainer-0169.md) | Changed | AI flags, Party |
| [School Kid Seymour](../trainers/trainer-0170.md) | Changed | AI flags, Party |
| [Youngster Cassie](../trainers/trainer-0171.md) | Changed | Party |
| [Lass Pedro](../trainers/trainer-0172.md) | Changed | Party |
| [Preschooler Serena](../trainers/trainer-0173.md) | Changed | Party |
| [Preschooler Albert](../trainers/trainer-0174.md) | Changed | Party |
| [Twins Lin](../trainers/trainer-0175.md) | Changed | AI flags, Party |
| [Nursery Aide Lia & Lily](../trainers/trainer-0176.md) | Changed | AI flags, Party |
| [Gentleman Kimya](../trainers/trainer-0177.md) | Changed | Double Battle, AI flags, Party |
| [Roughneck Stonewall](../trainers/trainer-0178.md) | Changed | Party |
| [Guitarist Nicky](../trainers/trainer-0179.md) | Changed | Party |
| [Youngster Billy Jo](../trainers/trainer-0180.md) | Changed | AI flags, Party |
| [Lass Kenny](../trainers/trainer-0181.md) | Changed | Party |
| [Janitor Molly](../trainers/trainer-0182.md) | Changed | AI flags, Party |
| [Boss Trainer Orville](../trainers/trainer-0183.md) | Changed | Party |
| [Boss Trainer Abigail](../trainers/trainer-0184.md) | Changed | Party |
| [Boss Trainer Abed](../trainers/trainer-0185.md) | Changed | Party |
| [Boss Trainer Brent](../trainers/trainer-0186.md) | Changed | Party |
| [Boss Trainer Bess](../trainers/trainer-0187.md) | Changed | Party |
| [Boss Trainer Carleigh](../trainers/trainer-0188.md) | Changed | Party |
| [Boss Trainer Carlen](../trainers/trainer-0189.md) | Changed | Party |
| [Boss Trainer Daneil](../trainers/trainer-0190.md) | Changed | Party |
| [Boss Trainer Danelle](../trainers/trainer-0191.md) | Changed | Party |
| [Boss Trainer Elie](../trainers/trainer-0192.md) | Changed | Party |
| [Boss Trainer Ellas](../trainers/trainer-0193.md) | Changed | Party |
| [Boss Trainer Frederick](../trainers/trainer-0194.md) | Changed | Party |
| [Boss Trainer Freira](../trainers/trainer-0195.md) | Changed | Party |
| [Boss Trainer Gail](../trainers/trainer-0196.md) | Changed | Party |
| [Boss Trainer Gaius](../trainers/trainer-0197.md) | Changed | Party |
| [Boss Trainer Harmon](../trainers/trainer-0198.md) | Changed | Party |
| [Boss Trainer Harmony](../trainers/trainer-0199.md) | Changed | Party |
| [Boss Trainer Iria](../trainers/trainer-0200.md) | Changed | Party |
| [Boss Trainer Ira](../trainers/trainer-0201.md) | Changed | Party |
| [Boss Trainer Benga](../trainers/trainer-0202.md) | Changed | Party |
| [Worker Benga](../trainers/trainer-0203.md) | Changed | AI flags, Party |
| [Worker Isaac](../trainers/trainer-0204.md) | Changed | AI flags, Party |
| [Worker Mitchell](../trainers/trainer-0205.md) | Changed | AI flags, Party |
| [Hiker Nathan](../trainers/trainer-0206.md) | Changed | AI flags, Party |
| [Beauty Jerome](../trainers/trainer-0207.md) | Changed | AI flags, Party, Script references |
| [Beauty Nikola](../trainers/trainer-0208.md) | Changed | AI flags, Party, Script references |
| [Beauty Fleming](../trainers/trainer-0209.md) | Changed | AI flags, Party, Script references |
| [Fisherman Ampère](../trainers/trainer-0210.md) | Changed | Party |
| [Fisherman Hubert](../trainers/trainer-0211.md) | Changed | Party |
| [Policeman Andrew](../trainers/trainer-0212.md) | Changed | Party |
| [Backpacker Braven](../trainers/trainer-0213.md) | Changed | AI flags, Party |
| [Policeman Clifford](../trainers/trainer-0214.md) | Changed | Party |
| [Policeman Dell](../trainers/trainer-0215.md) | Changed | Party |
| [Roughneck Neagle](../trainers/trainer-0216.md) | Changed | AI flags, Party |
| [Roughneck Joey](../trainers/trainer-0217.md) | Changed | AI flags, Party |
| [Biker Silvester](../trainers/trainer-0218.md) | Changed | AI flags, Party |
| [Biker Stanley](../trainers/trainer-0219.md) | Changed | AI flags, Party |
| [Hooligans Zeke](../trainers/trainer-0220.md) | Changed | AI flags, Party |
| [Rich Boy Rob & Sal](../trainers/trainer-0221.md) | Changed | AI flags, Party |
| [Backpacker Keenan](../trainers/trainer-0222.md) | Changed | AI flags, Party |
| [Backpacker Roland](../trainers/trainer-0223.md) | Changed | AI flags, Party |
| [Pokéfan Rachel](../trainers/trainer-0224.md) | Changed | AI flags, Party |
| [Pokéfan Norbert](../trainers/trainer-0225.md) | Changed | AI flags, Party |
| [Twins Sachiko](../trainers/trainer-0226.md) | Changed | AI flags, Party |
| [Linebacker Tara & Val](../trainers/trainer-0227.md) | Changed | Party |
| [Linebacker Bob](../trainers/trainer-0228.md) | Changed | Party |
| [Linebacker Jonah](../trainers/trainer-0231.md) | Changed | Party |
| [Infielder Jonah](../trainers/trainer-0232.md) | Changed | Party |
| [Infielder Connor](../trainers/trainer-0233.md) | Changed | Party |
| [Infielder Todd](../trainers/trainer-0234.md) | Changed | Party |
| [Striker Todd](../trainers/trainer-0237.md) | Changed | Party |
| [Striker Roberto](../trainers/trainer-0238.md) | Changed | Party |
| [Striker Marco](../trainers/trainer-0239.md) | Changed | Party |
| [Hoopster Marco](../trainers/trainer-0242.md) | Changed | Party |
| [Hoopster John](../trainers/trainer-0243.md) | Changed | Party |
| [Hoopster Lamarcus](../trainers/trainer-0244.md) | Changed | Party |
| [Hoopster John](../trainers/trainer-0245.md) | Changed | Party |
| [Hoopster Lamarcus](../trainers/trainer-0246.md) | Changed | Party |
| [Smasher Lamarcus](../trainers/trainer-0247.md) | Changed | Party |
| [Smasher Aspen](../trainers/trainer-0248.md) | Changed | Party |
| [Smasher Mari](../trainers/trainer-0249.md) | Changed | Party |
| [Backers Mari](../trainers/trainer-0252.md) | Changed | AI flags, Party |
| [Baker Ava & Aya](../trainers/trainer-0253.md) | Changed | AI flags, Party |
| [Artist Jenn](../trainers/trainer-0254.md) | Changed | AI flags, Party |
| [Dancer Horton](../trainers/trainer-0255.md) | Changed | AI flags, Party |
| [Musician Brian](../trainers/trainer-0256.md) | Changed | Party, Script references |
| [Backers Preston](../trainers/trainer-0257.md) | Changed | AI flags, Party |
| [Backpacker Stu & Art](../trainers/trainer-0258.md) | Changed | AI flags, Party |
| [Backpacker Ivan](../trainers/trainer-0259.md) | Changed | AI flags, Party |
| [Cyclist Blossom](../trainers/trainer-0260.md) | Changed | AI flags, Party |
| [Cyclist Hector](../trainers/trainer-0261.md) | Changed | AI flags, Party |
| [Depot Agent Krissa](../trainers/trainer-0262.md) | Changed | AI flags, Party |
| [Scientist Hank](../trainers/trainer-0263.md) | Changed | AI flags, Party |
| [Scientist Jacques](../trainers/trainer-0264.md) | Changed | AI flags, Party |
| [School Kid Marissa](../trainers/trainer-0265.md) | Changed | AI flags, Party |
| [School Kid Alvin](../trainers/trainer-0266.md) | Changed | AI flags, Party |
| [Parasol Lady Mara](../trainers/trainer-0267.md) | Changed | AI flags, Party |
| [Parasol Lady Nicole](../trainers/trainer-0268.md) | Changed | AI flags, Party |
| [Lass Tihana](../trainers/trainer-0269.md) | Changed | AI flags, Party |
| [Youngster Flo](../trainers/trainer-0270.md) | Changed | AI flags, Party |
| [Nursery Aide Cody](../trainers/trainer-0271.md) | Changed | AI flags, Party |
| [Preschooler Hollie](../trainers/trainer-0272.md) | Changed | Party |
| [Preschooler Greg](../trainers/trainer-0273.md) | Changed | Party |
| [Twins Chrissy](../trainers/trainer-0274.md) | Changed | AI flags, Party |
| [Harlequin Sola & Ana](../trainers/trainer-0275.md) | Changed | AI flags, Party |
| [Harlequin Pat](../trainers/trainer-0276.md) | Changed | Party |
| [Gentleman Ian](../trainers/trainer-0277.md) | Changed | AI flags, Party |
| [Socialite Sheldon](../trainers/trainer-0278.md) | Changed | AI flags, Party |
| [Ace Trainer Marian](../trainers/trainer-0279.md) | Changed | Party |
| [Ace Trainer Kipp](../trainers/trainer-0280.md) | Changed | Party |
| [Black Belt Junko](../trainers/trainer-0281.md) | Changed | Party |
| [Battle Girl Jay](../trainers/trainer-0282.md) | Changed | Party |
| [Fisherman Glinda](../trainers/trainer-0283.md) | Changed | Party |
| [Youngster Sid](../trainers/trainer-0284.md) | Changed | AI flags, Party |
| [Backpacker Sinclair](../trainers/trainer-0285.md) | Changed | Party |
| [Fisherman Reece](../trainers/trainer-0286.md) | Changed | AI flags, Party |
| [Fisherman Jones](../trainers/trainer-0287.md) | Changed | AI flags, Party |
| [Fisherman Damon](../trainers/trainer-0288.md) | Changed | Party |
| [Fisherman Leroy](../trainers/trainer-0289.md) | Changed | Party |
| [Parasol Lady Vince](../trainers/trainer-0290.md) | Changed | Party |
| [Backers Laura](../trainers/trainer-0291.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Cleo & Rio](../trainers/trainer-0292.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Richard](../trainers/trainer-0293.md) | Changed | Party |
| [⒆⒇ Ranger Lois](../trainers/trainer-0294.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Daryl](../trainers/trainer-0295.md) | Changed | AI flags, Party |
| [⒆⒇ Breeder Dianne](../trainers/trainer-0296.md) | Changed | Party |
| [⒆⒇ Ranger Irene](../trainers/trainer-0297.md) | Changed | Party |
| [⒆⒇ Ranger Serenity](../trainers/trainer-0298.md) | Changed | Party |
| [⒆⒇ Breeder Forrest](../trainers/trainer-0299.md) | Changed | AI flags, Party |
| [Black Belt Galen](../trainers/trainer-0300.md) | Changed | Party |
| [Battle Girl Jeriel](../trainers/trainer-0301.md) | Changed | Party |
| [⒆⒇ Breeder Azra](../trainers/trainer-0302.md) | Changed | Party |
| [⒆⒇ Breeder Marcus](../trainers/trainer-0303.md) | Changed | Party |
| [⒆⒇ Ranger Magnolia](../trainers/trainer-0304.md) | Changed | Party |
| [⒆⒇ Ranger Thalia](../trainers/trainer-0305.md) | Changed | Party |
| [Backpacker Crofton](../trainers/trainer-0306.md) | Changed | AI flags, Party |
| [Backpacker Myra](../trainers/trainer-0307.md) | Changed | AI flags, Party |
| [Swimmer ⑭ Lowell](../trainers/trainer-0308.md) | Changed | AI flags, Party |
| [Swimmer ⑮ Kyle](../trainers/trainer-0309.md) | Changed | AI flags, Party |
| [Swimmer ⑭ Kaoru](../trainers/trainer-0310.md) | Changed | AI flags, Party |
| [Swimmer ⑮ Harold](../trainers/trainer-0311.md) | Changed | Party |
| [Fisherman Desiree](../trainers/trainer-0312.md) | Changed | Party |
| [Ace Trainer Kenzo](../trainers/trainer-0313.md) | Changed | Party |
| [Swimmer ⑭ Summer](../trainers/trainer-0314.md) | Changed | Party |
| [Swimmer ⑭ Matt](../trainers/trainer-0315.md) | Changed | Party |
| [Swimmer ⑭ Bart](../trainers/trainer-0316.md) | Changed | Party |
| [Swimmer ⑮ Tim](../trainers/trainer-0317.md) | Changed | AI flags, Party |
| [Swimmer ⑮ Arissa](../trainers/trainer-0318.md) | Changed | Party |
| [Worker Mitzi](../trainers/trainer-0319.md) | Changed | AI flags, Party, Script references |
| [Worker Maynard](../trainers/trainer-0320.md) | Changed | AI flags, Party, Script references |
| [Worker Pasqual](../trainers/trainer-0321.md) | Changed | AI flags, Party, Script references |
| [Worker Tibor](../trainers/trainer-0322.md) | Changed | AI flags, Party, Script references |
| [Worker Niel](../trainers/trainer-0323.md) | Changed | AI flags, Party, Script references |
| [Worker Tavarius](../trainers/trainer-0324.md) | Changed | AI flags, Party, Script references |
| [Worker Noel](../trainers/trainer-0325.md) | Changed | AI flags, Party, Script references |
| [Black Belt Friedrich](../trainers/trainer-0326.md) | Changed | AI flags, Party |
| [Doctor Kenneth](../trainers/trainer-0327.md) | Changed | Party |
| [Hooligans Braid](../trainers/trainer-0328.md) | Changed | AI flags, Party |
| [Roughneck Jim & Cas](../trainers/trainer-0329.md) | Changed | AI flags, Party |
| [Roughneck Chance](../trainers/trainer-0330.md) | Changed | AI flags, Party |
| [Biker Reese](../trainers/trainer-0331.md) | Changed | AI flags, Party |
| [Pilot Phillip](../trainers/trainer-0332.md) | Changed | AI flags, Party |
| [⒆⒇ Breeder Elron](../trainers/trainer-0333.md) | Changed | Party |
| [Hiker Addison](../trainers/trainer-0334.md) | Changed | AI flags, Party |
| [Baker Justin](../trainers/trainer-0335.md) | Changed | Party |
| [Youngster Chris](../trainers/trainer-0336.md) | Changed | AI flags, Party |
| [Lass Karl](../trainers/trainer-0337.md) | Changed | Party |
| [Artist Shannon](../trainers/trainer-0338.md) | Changed | AI flags, Party |
| [Motorcyclist Gough](../trainers/trainer-0339.md) | Changed | AI flags, Party |
| [Motorcyclist Charles](../trainers/trainer-0340.md) | Changed | Party |
| [Champion Charles](../trainers/trainer-0341.md) | Changed | AI battle items, Party |
| [Team Plasma Iris](../trainers/trainer-0342.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0343.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0344.md) | Changed | AI flags, AI battle items, Party |
| [Team Plasma Colress](../trainers/trainer-0345.md) | Changed | AI battle items, Party |
| [⒆⒇ Trainer Ghetsis](../trainers/trainer-0346.md) | Changed | AI flags, Party, Script references |
| [Team Plasma Rood](../trainers/trainer-0347.md) | Changed | Party |
| [Team Plasma Zinzolin](../trainers/trainer-0348.md) | Changed | Double Battle, AI flags, Party |
| [Fisherman Shadow](../trainers/trainer-0349.md) | Changed | Party |
| [Ace Trainer Dean](../trainers/trainer-0350.md) | Changed | Party |
| [Ace Trainer Doyle](../trainers/trainer-0351.md) | Changed | Party |
| [Ace Trainer Melina](../trainers/trainer-0352.md) | Changed | Party |
| [Ace Trainer Enzio](../trainers/trainer-0353.md) | Changed | Party |
| [Ace Trainer Jeanne](../trainers/trainer-0354.md) | Changed | Party |
| [Ace Trainer Santino](../trainers/trainer-0355.md) | Changed | Party |
| [Team Plasma Sable](../trainers/trainer-0356.md) | Changed | AI flags, Party |
| [GAME FREAK Grunt](../trainers/trainer-0357.md) | Changed | Party |
| [⒆⒇ Trainer Nishino](../trainers/trainer-0358.md) | Changed | Class Id, AI battle items, Party |
| [Team Plasma Colress](../trainers/trainer-0359.md) | Changed | Party, Script references |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0360.md) | Changed | Party |
| [⒆⒇ Trainer Nate](../trainers/trainer-0361.md) | Changed | Party |
| [⒆⒇ Trainer Nate](../trainers/trainer-0362.md) | Changed | Party, Script references |
| [⒆⒇ Trainer Nate](../trainers/trainer-0363.md) | Changed | Party |
| [⒆⒇ Trainer Rosa](../trainers/trainer-0364.md) | Changed | Party |
| [⒆⒇ Trainer Rosa](../trainers/trainer-0365.md) | Changed | Party |
| [Motorcyclist Rosa](../trainers/trainer-0366.md) | Changed | AI flags, Party, Script references |
| [Motorcyclist Charles](../trainers/trainer-0367.md) | Changed | AI flags, Party, Script references |
| [⒆⒇ Trainer Charles](../trainers/trainer-0368.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0369.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0370.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0371.md) | Changed | Party |
| [Team Plasma Cheren](../trainers/trainer-0372.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0373.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0374.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0375.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0376.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0377.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0378.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0379.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0380.md) | Changed | AI flags, Party, Script references |
| [Veteran Rival](../trainers/trainer-0381.md) | Changed | Party |
| [Veteran Lucius](../trainers/trainer-0382.md) | Changed | Party |
| [Veteran Jerry](../trainers/trainer-0383.md) | Changed | Party |
| [Veteran Rhona](../trainers/trainer-0384.md) | Changed | AI flags, Party |
| [Veteran Ron](../trainers/trainer-0385.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Denae](../trainers/trainer-0386.md) | Changed | Party |
| [⒆⒇ Ranger Leaf](../trainers/trainer-0387.md) | Changed | Party |
| [⒆⒇ Ranger Naoko](../trainers/trainer-0388.md) | Changed | Party |
| [⒆⒇ Ranger Bret](../trainers/trainer-0389.md) | Changed | Party |
| [Backpacker Malory](../trainers/trainer-0390.md) | Changed | Party |
| [Psychic Boone](../trainers/trainer-0391.md) | Changed | Party |
| [Youngster Lynette](../trainers/trainer-0392.md) | Changed | Party |
| [School Kid Petey](../trainers/trainer-0393.md) | Changed | Party |
| [School Kid Edgar](../trainers/trainer-0394.md) | Changed | Party |
| [Nursery Aide Marsha](../trainers/trainer-0395.md) | Changed | Party |
| [Preschooler Autumn](../trainers/trainer-0396.md) | Changed | Party |
| [Preschooler Buster](../trainers/trainer-0397.md) | Changed | Party |
| [Preschooler Eva](../trainers/trainer-0398.md) | Changed | Party |
| [Fisherman Tyrone](../trainers/trainer-0399.md) | Changed | Party |
| [Fisherman Bruce](../trainers/trainer-0400.md) | Changed | Party |
| [Youngster Mack](../trainers/trainer-0401.md) | Changed | Party |
| [Lass Jimmy](../trainers/trainer-0402.md) | Changed | Party |
| [Veteran Mali](../trainers/trainer-0403.md) | Changed | Party |
| [Veteran Oriana](../trainers/trainer-0404.md) | Changed | Party |
| [Backpacker Rayne](../trainers/trainer-0405.md) | Changed | Party |
| [Backpacker Shane](../trainers/trainer-0406.md) | Changed | Party |
| [Youngster Jill](../trainers/trainer-0407.md) | Changed | Party |
| [Lass Mikey](../trainers/trainer-0408.md) | Changed | Party |
| [⒆⒇ Ranger Henrietta](../trainers/trainer-0409.md) | Changed | Party |
| [⒆⒇ Ranger Rick](../trainers/trainer-0410.md) | Changed | Party |
| [Ace Trainer Audra](../trainers/trainer-0411.md) | Changed | Party |
| [Ace Trainer Sean](../trainers/trainer-0412.md) | Changed | Party |
| [Fisherman Cheyenne](../trainers/trainer-0413.md) | Changed | Party |
| [Fisherman Lydon](../trainers/trainer-0414.md) | Changed | Party |
| [Swimmer ⑭ Bucky](../trainers/trainer-0415.md) | Changed | Party |
| [Swimmer ⑭ Wright](../trainers/trainer-0416.md) | Changed | Party |
| [Swimmer ⑮ Jeffery](../trainers/trainer-0417.md) | Changed | Party |
| [Swimmer ⑮ Ruth](../trainers/trainer-0418.md) | Changed | Party |
| [Hiker Dara](../trainers/trainer-0419.md) | Changed | Party |
| [Veteran Stephen](../trainers/trainer-0420.md) | Changed | Party |
| [Veteran Vincent](../trainers/trainer-0421.md) | Changed | Party |
| [Veteran Chester](../trainers/trainer-0422.md) | Changed | Party |
| [Veteran Maya](../trainers/trainer-0423.md) | Changed | Party |
| [Black Belt Gina](../trainers/trainer-0424.md) | Changed | Party |
| [Battle Girl Zachary](../trainers/trainer-0425.md) | Changed | Party |
| [Team Plasma Wendy](../trainers/trainer-0426.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0427.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0428.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0429.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0430.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0431.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0432.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0433.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0434.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0435.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0436.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0437.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0438.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0439.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0440.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0441.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0442.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0443.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0444.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0445.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0446.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0447.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0448.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0449.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0450.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0451.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0452.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0453.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0454.md) | Changed | AI flags, Party |
| [School Kid Grunt](../trainers/trainer-0455.md) | Changed | Party |
| [⒆⒇ Trainer Alberta](../trainers/trainer-0456.md) | Changed | AI battle items, Party |
| [Waitress Cynthia](../trainers/trainer-0457.md) | Changed | Party |
| [Nursery Aide Jan](../trainers/trainer-0458.md) | Changed | Party |
| [Clerk ⑮ Ilse](../trainers/trainer-0459.md) | Changed | Party |
| [Maid Lana](../trainers/trainer-0460.md) | Changed | Party |
| [Janitor Tammy](../trainers/trainer-0461.md) | Changed | Party |
| [Janitor Felix](../trainers/trainer-0462.md) | Changed | Party |
| [Scientist Brady](../trainers/trainer-0463.md) | Changed | Party |
| [Scientist Clarke](../trainers/trainer-0464.md) | Changed | AI flags, Party |
| [Worker Caroline](../trainers/trainer-0465.md) | Changed | Party |
| [Worker Zack](../trainers/trainer-0466.md) | Changed | Party |
| [Cyclist Scott](../trainers/trainer-0467.md) | Changed | AI flags, Party |
| [Cyclist Adelaide](../trainers/trainer-0468.md) | Changed | AI flags, Party |
| [Black Belt Jeremiah](../trainers/trainer-0469.md) | Changed | Party |
| [Battle Girl Drago](../trainers/trainer-0470.md) | Changed | Party |
| [Black Belt Tia](../trainers/trainer-0471.md) | Changed | Party |
| [Battle Girl Rich](../trainers/trainer-0472.md) | Changed | Party |
| [⒆⒇ Ranger Maki](../trainers/trainer-0473.md) | Changed | Party |
| [⒆⒇ Ranger Johan](../trainers/trainer-0474.md) | Changed | Party |
| [Hiker Mikiko](../trainers/trainer-0475.md) | Changed | AI flags, Party |
| [Hiker Don](../trainers/trainer-0476.md) | Changed | Double Battle, AI flags, Party |
| [Black Belt Doug](../trainers/trainer-0477.md) | Changed | AI flags, Party |
| [Battle Girl Luke](../trainers/trainer-0478.md) | Changed | AI flags, Party |
| [Ace Trainer Brenda](../trainers/trainer-0479.md) | Changed | Party |
| [Ace Trainer Juliet](../trainers/trainer-0480.md) | Changed | Party |
| [Black Belt Grant](../trainers/trainer-0481.md) | Changed | AI flags, Party |
| [Battle Girl Benjamin](../trainers/trainer-0482.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Tiffany](../trainers/trainer-0483.md) | Changed | Party |
| [⒆⒇ Ranger Lena](../trainers/trainer-0484.md) | Changed | Party |
| [Ace Trainer Steve](../trainers/trainer-0485.md) | Changed | Party |
| [Ace Trainer Tom](../trainers/trainer-0486.md) | Changed | Party |
| [Hiker Miki](../trainers/trainer-0487.md) | Changed | AI flags, Party |
| [Hiker Teppei](../trainers/trainer-0488.md) | Changed | AI flags, Party |
| [Worker Manuel](../trainers/trainer-0489.md) | Changed | AI flags, Party |
| [Worker Morgann](../trainers/trainer-0490.md) | Changed | AI flags, Party |
| [Worker Herman](../trainers/trainer-0491.md) | Changed | AI flags, Party |
| [Worker Paul](../trainers/trainer-0492.md) | Changed | Party |
| [Ace Trainer Cliff](../trainers/trainer-0493.md) | Changed | Party |
| [⒆⒇ Trainer Dusty](../trainers/trainer-0494.md) | Changed | Party |
| [⒆⒇ Trainer Chili](../trainers/trainer-0495.md) | Changed | Party |
| [⒆⒇ Trainer Cress](../trainers/trainer-0496.md) | Changed | Party |
| [Team Plasma Cilan](../trainers/trainer-0497.md) | Changed | Double Battle, AI flags, Party |
| [Team Plasma Zinzolin](../trainers/trainer-0498.md) | Changed | Double Battle, AI flags, Party |
| [Team Plasma Shadow](../trainers/trainer-0499.md) | Changed | Double Battle, AI flags, Party |
| [Team Plasma Shadow](../trainers/trainer-0500.md) | Changed | AI flags, Party |
| [Clerk ⑭ Grunt](../trainers/trainer-0501.md) | Changed | AI flags, Party |
| [Clerk ⑭ Clemens](../trainers/trainer-0502.md) | Changed | AI flags, Party |
| [School Kid Warren](../trainers/trainer-0503.md) | Changed | AI flags, Party |
| [Boss Trainer Neil](../trainers/trainer-0504.md) | Changed | Party |
| [Boss Trainer Jariel](../trainers/trainer-0505.md) | Changed | Party |
| [Worker Janna](../trainers/trainer-0506.md) | Changed | AI flags, Party |
| [Worker Leo](../trainers/trainer-0507.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Brand](../trainers/trainer-0508.md) | Changed | Party |
| [⒆⒇ Ranger Maxwell](../trainers/trainer-0509.md) | Changed | Party |
| [Psychic Katie](../trainers/trainer-0510.md) | Changed | AI flags, Party |
| [Psychic Dua](../trainers/trainer-0511.md) | Changed | AI flags, Party |
| [Psychic Perry](../trainers/trainer-0512.md) | Changed | AI flags, Party |
| [Backpacker Low](../trainers/trainer-0513.md) | Changed | AI flags, Party |
| [Backpacker Kiyo](../trainers/trainer-0514.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Kumiko](../trainers/trainer-0515.md) | Changed | Party |
| [⒆⒇ Ranger Lewis](../trainers/trainer-0516.md) | Changed | Party |
| [⒆⒇ Ranger Lewis](../trainers/trainer-0517.md) | Changed | Party |
| [⒆⒇ Ranger Eliza](../trainers/trainer-0518.md) | Changed | Party |
| [Ace Trainer Eliza](../trainers/trainer-0519.md) | Changed | AI flags, Party |
| [Ace Trainer Ray](../trainers/trainer-0520.md) | Changed | AI flags, Party |
| [Hiker Cora](../trainers/trainer-0521.md) | Changed | AI flags, Party |
| [Hiker Jared](../trainers/trainer-0522.md) | Changed | Party |
| [Black Belt Markus](../trainers/trainer-0523.md) | Changed | AI flags, Party |
| [Battle Girl Corey](../trainers/trainer-0524.md) | Changed | AI flags, Party |
| [Worker Chan](../trainers/trainer-0525.md) | Changed | Party |
| [Worker Cairn](../trainers/trainer-0526.md) | Changed | Party |
| [Worker Gus](../trainers/trainer-0527.md) | Changed | Party |
| [Worker Victor](../trainers/trainer-0528.md) | Changed | Party |
| [Worker Patton](../trainers/trainer-0529.md) | Changed | Party |
| [Hiker Ryan](../trainers/trainer-0530.md) | Changed | Party |
| [Hiker Hunter](../trainers/trainer-0531.md) | Changed | Party |
| [Veteran Wade](../trainers/trainer-0532.md) | Changed | Party |
| [Veteran Zach](../trainers/trainer-0533.md) | Changed | Party |
| [Veteran Julia](../trainers/trainer-0534.md) | Changed | Party |
| [Veteran Carter](../trainers/trainer-0535.md) | Changed | Party |
| [Champion Chloris](../trainers/trainer-0536.md) | Changed | Party |
| [Guitarist Iris](../trainers/trainer-0537.md) | Changed | AI flags, Party |
| [Guitarist Anna](../trainers/trainer-0538.md) | Changed | Party |
| [Hiker Beverly](../trainers/trainer-0539.md) | Changed | AI flags, Party |
| [Hiker Otto](../trainers/trainer-0540.md) | Changed | Party |
| [Scientist Jeremy](../trainers/trainer-0541.md) | Changed | AI flags, Party |
| [Scientist Ronald](../trainers/trainer-0542.md) | Changed | AI flags, AI battle items, Party |
| [⒆⒇ Ranger Lumi](../trainers/trainer-0543.md) | Changed | Party |
| [⒆⒇ Ranger Briana](../trainers/trainer-0544.md) | Changed | Party |
| [Ace Trainer Louis](../trainers/trainer-0545.md) | Changed | AI flags, Party |
| [Ace Trainer Vicki](../trainers/trainer-0546.md) | Changed | Party |
| [Ace Trainer Corky](../trainers/trainer-0547.md) | Changed | Party |
| [Ace Trainer Shaye](../trainers/trainer-0548.md) | Changed | Party |
| [Pokéfan Mary](../trainers/trainer-0549.md) | Changed | AI flags, Party |
| [Pokéfan Jude](../trainers/trainer-0550.md) | Changed | AI flags, Party |
| [Gentleman Georgia](../trainers/trainer-0551.md) | Changed | AI flags, Party |
| [Socialite Daniel](../trainers/trainer-0552.md) | Changed | AI flags, Party |
| [Psychic Grace](../trainers/trainer-0553.md) | Changed | AI flags, Party |
| [Psychic Micki](../trainers/trainer-0554.md) | Changed | AI flags, Party |
| [Psychic Joyce](../trainers/trainer-0555.md) | Changed | Party |
| [Psychic Bryce](../trainers/trainer-0556.md) | Changed | AI flags, Party |
| [Youngster Sarah](../trainers/trainer-0557.md) | Changed | AI flags, Party |
| [Lass Jaye](../trainers/trainer-0558.md) | Changed | AI flags, Party |
| [Youngster Lurleen](../trainers/trainer-0559.md) | Changed | AI flags, Party |
| [Twins Wes](../trainers/trainer-0560.md) | Changed | AI flags, Party |
| [Hiker Rae & Ula](../trainers/trainer-0561.md) | Changed | AI flags, Party |
| [Hiker Tobias](../trainers/trainer-0562.md) | Changed | Party |
| [Backpacker Keith](../trainers/trainer-0563.md) | Changed | AI flags, Party |
| [Backpacker Kendall](../trainers/trainer-0564.md) | Changed | AI flags, Party |
| [Backpacker Randall](../trainers/trainer-0565.md) | Changed | AI flags, Party |
| [Backpacker Annie](../trainers/trainer-0566.md) | Changed | AI flags, Party |
| [Scientist Eileen](../trainers/trainer-0567.md) | Changed | AI flags, Party |
| [Scientist Terrance](../trainers/trainer-0568.md) | Changed | AI flags, Party |
| [Psychic Lumina](../trainers/trainer-0569.md) | Changed | AI flags, Party |
| [Psychic Tully](../trainers/trainer-0570.md) | Changed | AI flags, Party |
| [Youngster Ena](../trainers/trainer-0571.md) | Changed | Party |
| [Lass Astor](../trainers/trainer-0572.md) | Changed | Party |
| [Parasol Lady Mai](../trainers/trainer-0573.md) | Changed | Party |
| [Parasol Lady Ingrid](../trainers/trainer-0574.md) | Changed | Party |
| [Fisherman Tyra](../trainers/trainer-0575.md) | Changed | Party |
| [Fisherman Ryder](../trainers/trainer-0576.md) | Changed | Party |
| [Fisherman Eustace](../trainers/trainer-0577.md) | Changed | Party |
| [⒆⒇ Ranger Arnold](../trainers/trainer-0578.md) | Changed | Party |
| [⒆⒇ Ranger Parker](../trainers/trainer-0579.md) | Changed | Party |
| [Black Belt Elaine](../trainers/trainer-0580.md) | Changed | Party |
| [Team Plasma Rocky](../trainers/trainer-0581.md) | Changed | Party |
| [⒆⒇ Trainer Colress](../trainers/trainer-0582.md) | Changed | Party |
| [Team Plasma Alder](../trainers/trainer-0583.md) | Changed | Party |
| [Team Plasma Shadow](../trainers/trainer-0584.md) | Changed | Party |
| [Team Plasma Zinzolin](../trainers/trainer-0585.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0586.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0587.md) | Changed | Party |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0588.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0589.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0590.md) | Changed | Party |
| [GAME FREAK Rival](../trainers/trainer-0591.md) | Changed | Party |
| [GAME FREAK Nishino](../trainers/trainer-0592.md) | Changed | Party |
| [Youngster Morimoto](../trainers/trainer-0593.md) | Changed | Party |
| [Ace Trainer Keita](../trainers/trainer-0594.md) | Changed | Party |
| [Psychic Billy](../trainers/trainer-0595.md) | Changed | AI flags, Party |
| [Ace Trainer Alia](../trainers/trainer-0596.md) | Changed | Party |
| [Psychic Jamie](../trainers/trainer-0597.md) | Changed | AI flags, Party |
| [Ace Trainer Al](../trainers/trainer-0598.md) | Changed | Party |
| [Ace Trainer Beckett](../trainers/trainer-0599.md) | Changed | Party |
| [Veteran Shelly](../trainers/trainer-0600.md) | Changed | Party |
| [Doctor Cathy](../trainers/trainer-0601.md) | Changed | Party |
| [Ace Trainer Logan](../trainers/trainer-0602.md) | Changed | AI flags, Party |
| [Ace Trainer Webster](../trainers/trainer-0603.md) | Changed | AI flags, Party |
| [Veteran Shanta](../trainers/trainer-0604.md) | Changed | AI flags, Party, Script references |
| [Veteran Sterling](../trainers/trainer-0605.md) | Changed | AI flags, Party, Script references |
| [Ace Trainer Portia](../trainers/trainer-0606.md) | Changed | AI flags, Party, Script references |
| [Black Belt Caroll](../trainers/trainer-0607.md) | Changed | AI flags, Party |
| [Ace Trainer Martell](../trainers/trainer-0608.md) | Changed | AI flags, Party, Script references |
| [Battle Girl Elmer](../trainers/trainer-0609.md) | Changed | AI flags, Party |
| [Ace Trainer Chalina](../trainers/trainer-0610.md) | Changed | Party |
| [Ace Trainer Pierce](../trainers/trainer-0611.md) | Changed | Party |
| [Veteran Chandra](../trainers/trainer-0612.md) | Changed | AI battle items, Party |
| [Backpacker Hugo](../trainers/trainer-0613.md) | Changed | AI flags, Party |
| [Veteran Mae](../trainers/trainer-0614.md) | Changed | Party |
| [Veteran Claude](../trainers/trainer-0615.md) | Changed | Party |
| [no data Cecile](../trainers/trainer-0616.md) | Changed | Party |
| [no data     ](../trainers/trainer-0617.md) | Changed | Party |
| [no data     ](../trainers/trainer-0618.md) | Changed | Party |
| [no data     ](../trainers/trainer-0619.md) | Changed | Party |
| [no data     ](../trainers/trainer-0620.md) | Changed | Party |
| [Rich Boy     ](../trainers/trainer-0621.md) | Changed | AI flags, Party |
| [Youngster Rolan](../trainers/trainer-0622.md) | Changed | Party |
| [Ace Trainer Chaz](../trainers/trainer-0624.md) | Changed | Party |
| [Ace Trainer Mariana](../trainers/trainer-0625.md) | Changed | Party |
| [Rich Boy Sibyl](../trainers/trainer-0627.md) | Changed | Party |
| [⒆⒇ Trainer Tanya](../trainers/trainer-0632.md) | Changed | Party |
| [School Kid Cheren](../trainers/trainer-0633.md) | Changed | Party |
| [School Kid Keston](../trainers/trainer-0634.md) | Changed | Party |
| [Ace Trainer Millie](../trainers/trainer-0635.md) | Changed | Party |
| [Ace Trainer Kelsey](../trainers/trainer-0636.md) | Changed | Party |
| [Black Belt Kathrine](../trainers/trainer-0637.md) | Changed | Party |
| [Battle Girl Kentaro](../trainers/trainer-0638.md) | Changed | Party |
| [⒆⒇ Ranger Lee](../trainers/trainer-0639.md) | Changed | Party |
| [⒆⒇ Ranger Ralph](../trainers/trainer-0640.md) | Changed | Party |
| [⒆⒇ Ranger Dwayne](../trainers/trainer-0641.md) | Changed | Party |
| [⒆⒇ Ranger Melita](../trainers/trainer-0642.md) | Changed | Party |
| [Veteran Hillary](../trainers/trainer-0643.md) | Changed | Party |
| [Veteran Sinan](../trainers/trainer-0644.md) | Changed | Party |
| [Youngster Rosaline](../trainers/trainer-0645.md) | Changed | Party |
| [Youngster Keita](../trainers/trainer-0646.md) | Changed | Party |
| [Nursery Aide Nicholas](../trainers/trainer-0647.md) | Changed | Party |
| [Preschooler Ethel](../trainers/trainer-0648.md) | Changed | Party |
| [Preschooler Jojo](../trainers/trainer-0649.md) | Changed | Party |
| [Preschooler José](../trainers/trainer-0650.md) | Changed | Party |
| [Twins Samantha](../trainers/trainer-0651.md) | Changed | Party |
| [Pokéfan Ally & Amy](../trainers/trainer-0652.md) | Changed | Party |
| [Pokéfan Elliot](../trainers/trainer-0653.md) | Changed | Party |
| [Scientist Lydia](../trainers/trainer-0654.md) | Changed | Party |
| [Backpacker Marie](../trainers/trainer-0655.md) | Changed | Party |
| [Backpacker Talon](../trainers/trainer-0656.md) | Changed | Party |
| [Veteran Corin](../trainers/trainer-0657.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Abraham](../trainers/trainer-0658.md) | Changed | Party |
| [⒆⒇ Ranger Eddie](../trainers/trainer-0659.md) | Changed | Party |
| [Nursery Aide Elle](../trainers/trainer-0660.md) | Changed | Party |
| [Gentleman Naoise](../trainers/trainer-0661.md) | Changed | Party |
| [Backpacker Rich](../trainers/trainer-0662.md) | Changed | AI flags, Party |
| [Backpacker Walt](../trainers/trainer-0663.md) | Changed | AI flags, Party |
| [Backpacker Sam](../trainers/trainer-0664.md) | Changed | AI flags, Party |
| [Backpacker Tami](../trainers/trainer-0665.md) | Changed | AI flags, Party |
| [⒆⒇ Ranger Clara](../trainers/trainer-0666.md) | Changed | Party |
| [⒆⒇ Ranger Jaden](../trainers/trainer-0667.md) | Changed | Party |
| [Psychic Anja](../trainers/trainer-0668.md) | Changed | AI flags, Party |
| [Psychic Tommy](../trainers/trainer-0669.md) | Changed | AI flags, Party |
| [Nurse Future](../trainers/trainer-0670.md) | Changed | Party |
| [Doctor Mariah](../trainers/trainer-0671.md) | Changed | Party |
| [Doctor Kit](../trainers/trainer-0672.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Nurse Derek](../trainers/trainer-0673.md) | Changed | AI flags, Party |
| [Hiker Dixie](../trainers/trainer-0674.md) | Changed | Party |
| [Battle Girl Zaiem](../trainers/trainer-0675.md) | Changed | Party |
| [Battle Girl Maggie](../trainers/trainer-0676.md) | Changed | Party |
| [Black Belt Xiao](../trainers/trainer-0677.md) | Changed | Party |
| [Black Belt Edward](../trainers/trainer-0678.md) | Changed | Party |
| [Doctor Thomas](../trainers/trainer-0679.md) | Changed | Party |
| [Hiker Heath](../trainers/trainer-0680.md) | Changed | AI flags, Party |
| [Hiker Jebediah](../trainers/trainer-0681.md) | Changed | Party |
| [Ace Trainer Shelby](../trainers/trainer-0682.md) | Changed | Party |
| [Ace Trainer Geoff](../trainers/trainer-0683.md) | Changed | Party |
| [⒆⒇ Trainer Belle](../trainers/trainer-0684.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0685.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0686.md) | Changed | AI flags, Party |
| [Team Plasma Rival](../trainers/trainer-0687.md) | Changed | Party |
| [Team Plasma Shadow](../trainers/trainer-0688.md) | Changed | Party |
| [Team Plasma Shadow](../trainers/trainer-0689.md) | Changed | Party |
| [Team Plasma Shadow](../trainers/trainer-0690.md) | Changed | Double Battle, AI flags, Party, Script references |
| [Clerk ⑮ Grunt](../trainers/trainer-0691.md) | Changed | AI flags, Party |
| [Clerk ⑭ Britney](../trainers/trainer-0692.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Gilligan](../trainers/trainer-0693.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0694.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0695.md) | Changed | AI flags, Party, Script references |
| [⒆⒇ Trainer Rival](../trainers/trainer-0696.md) | Changed | AI flags, Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0697.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0698.md) | Changed | Party |
| [Lass Diana](../trainers/trainer-0700.md) | Changed | Party |
| [⒆⒇ Trainer Diana](../trainers/trainer-0701.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0702.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0703.md) | Changed | Party |
| [Team Plasma Rival](../trainers/trainer-0704.md) | Changed | Party |
| [Team Plasma Zinzolin](../trainers/trainer-0705.md) | Changed | Party |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0706.md) | Changed | Party |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0707.md) | Changed | Party |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0708.md) | Changed | Party |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0709.md) | Changed | Party |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0710.md) | Changed | Party |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0711.md) | Changed | Party |
| [Ace Trainer Mathis](../trainers/trainer-0718.md) | Changed | Party |
| [Ace Trainer Natasha](../trainers/trainer-0719.md) | Changed | Party |
| [Ace Trainer Nina](../trainers/trainer-0720.md) | Changed | Party |
| [Ace Trainer Eve](../trainers/trainer-0721.md) | Changed | Party |
| [Ace Trainer Jacqueline](../trainers/trainer-0723.md) | Changed | Party |
| [Team Plasma Layla](../trainers/trainer-0724.md) | Changed | AI flags, Party |
| [Nurse Grunt](../trainers/trainer-0725.md) | Changed | Party |
| [Hoopster Carol](../trainers/trainer-0726.md) | Changed | Party |
| [Smasher Derrick](../trainers/trainer-0727.md) | Changed | Party |
| [Smasher Lizzy](../trainers/trainer-0728.md) | Changed | Party |
| [Hoopster Amy](../trainers/trainer-0729.md) | Changed | Party |
| [Black Belt Nicolas](../trainers/trainer-0730.md) | Changed | Party |
| [Battle Girl Wesley](../trainers/trainer-0731.md) | Changed | Party |
| [Subway Boss Alize](../trainers/trainer-0732.md) | Changed | Party, Script references |
| [Subway Boss Ingo](../trainers/trainer-0733.md) | Changed | Party, Script references |
| [Harlequin Emmet](../trainers/trainer-0734.md) | Changed | AI flags, Party |
| [Harlequin Clarence](../trainers/trainer-0735.md) | Changed | AI flags, Party |
| [Harlequin Jack](../trainers/trainer-0736.md) | Changed | AI flags, Party |
| [Harlequin Gary](../trainers/trainer-0737.md) | Changed | AI flags, Party |
| [Lass Anders](../trainers/trainer-0738.md) | Changed | AI flags, Party |
| [School Kid Daya](../trainers/trainer-0739.md) | Changed | Party |
| [School Kid William](../trainers/trainer-0740.md) | Changed | Party |
| [Psychic Rita](../trainers/trainer-0741.md) | Changed | Party |
| [Psychic Olesia](../trainers/trainer-0742.md) | Changed | Party |
| [Scientist Nandor](../trainers/trainer-0743.md) | Changed | Party |
| [Scientist Athena](../trainers/trainer-0744.md) | Changed | Party |
| [Youngster Franklin](../trainers/trainer-0745.md) | Changed | AI flags, Party |
| [Youngster Masahiro](../trainers/trainer-0746.md) | Changed | AI flags, Party |
| [School Kid Waylon](../trainers/trainer-0747.md) | Changed | AI flags, Party |
| [School Kid Seymour](../trainers/trainer-0748.md) | Changed | AI flags, Party |
| [School Kid Cassie](../trainers/trainer-0749.md) | Changed | AI flags, Party |
| [School Kid Seymour](../trainers/trainer-0750.md) | Changed | AI flags, Party |
| [Team Plasma Cassie](../trainers/trainer-0751.md) | Changed | Party, Script references |
| [⒆⒇ Breeder Grunt](../trainers/trainer-0752.md) | Changed | AI flags, Party |
| [Backers April](../trainers/trainer-0753.md) | Changed | Party |
| [Roughneck May & Mal](../trainers/trainer-0754.md) | Changed | AI flags, Party |
| [Dancer Ricky](../trainers/trainer-0755.md) | Changed | Double Battle, AI flags, Party |
| [Guitarist Jean-Paul](../trainers/trainer-0756.md) | Changed | Double Battle, AI flags, Party |
| [Veteran Ernest](../trainers/trainer-0758.md) | Changed | Party |
| [Veteran Eli](../trainers/trainer-0759.md) | Changed | Party |
| [Veteran Donnaven](../trainers/trainer-0760.md) | Changed | Party |
| [Veteran Crispin](../trainers/trainer-0761.md) | Changed | Party |
| [Veteran Joseph](../trainers/trainer-0762.md) | Changed | Party |
| [Team Plasma Wain](../trainers/trainer-0763.md) | Changed | Party |
| [Leader Grunt](../trainers/trainer-0764.md) | Changed | AI flags, AI battle items, Party |
| [Leader Cheren](../trainers/trainer-0765.md) | Changed | AI flags, AI battle items, Party |
| [Leader Roxie](../trainers/trainer-0766.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Leader Burgh](../trainers/trainer-0767.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Leader Elesa](../trainers/trainer-0768.md) | Changed | AI flags, AI battle items, Party |
| [Leader Clay](../trainers/trainer-0769.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Leader Skyla](../trainers/trainer-0770.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Leader Drayden](../trainers/trainer-0771.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Elite Four Marlon](../trainers/trainer-0772.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Elite Four Shauntal](../trainers/trainer-0773.md) | Changed | AI flags, AI battle items, Party |
| [Elite Four Grimsley](../trainers/trainer-0774.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Elite Four Marshal](../trainers/trainer-0775.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Champion Caitlin](../trainers/trainer-0776.md) | Changed | AI flags, AI battle items, Party |
| [Elite Four Iris](../trainers/trainer-0777.md) | Changed | AI flags, AI battle items, Party |
| [Elite Four Shauntal](../trainers/trainer-0778.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Elite Four Grimsley](../trainers/trainer-0779.md) | Changed | AI flags, AI battle items, Party |
| [Elite Four Marshal](../trainers/trainer-0780.md) | Changed | Double Battle, AI flags, AI battle items, Party |
| [Champion Caitlin](../trainers/trainer-0781.md) | Changed | AI flags, AI battle items, Party |
| [⒆⒇ Trainer Iris](../trainers/trainer-0782.md) | Changed | Party |
| [⒆⒇ Trainer N](../trainers/trainer-0783.md) | Changed | Party |
| [⒆⒇ Trainer N](../trainers/trainer-0784.md) | Changed | Party |
| [⒆⒇ Trainer N](../trainers/trainer-0785.md) | Changed | Party |
| [Ace Trainer N](../trainers/trainer-0786.md) | Changed | AI flags, Party |
| [Ace Trainer Ray](../trainers/trainer-0787.md) | Changed | AI flags, Party |
| [Backpacker Cora](../trainers/trainer-0788.md) | Changed | AI flags, Party |
| [Backpacker Kiyo](../trainers/trainer-0789.md) | Changed | AI flags, Party |
| [Nursery Aide Kumiko](../trainers/trainer-0790.md) | Changed | Party |
| [Preschooler Rosalyn](../trainers/trainer-0791.md) | Changed | Party |
| [Youngster Ike](../trainers/trainer-0792.md) | Changed | Party |
| [Lass Henley](../trainers/trainer-0793.md) | Changed | Party |
| [⒆⒇ Trainer Helia](../trainers/trainer-0794.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0795.md) | Changed | Party |
| [⒆⒇ Trainer Rival](../trainers/trainer-0796.md) | Changed | Party |
| [Team Plasma Rival](../trainers/trainer-0797.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0798.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0799.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0800.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0801.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0802.md) | Changed | AI flags, Party |
| [Nursery Aide Grunt](../trainers/trainer-0803.md) | Changed | Party |
| [Beauty June](../trainers/trainer-0804.md) | Changed | Party |
| [Clerk ⑭ December](../trainers/trainer-0805.md) | Changed | Party |
| [Guitarist Augustin](../trainers/trainer-0806.md) | Changed | Party |
| [Team Plasma January](../trainers/trainer-0807.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0808.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0809.md) | Changed | AI flags, Party |
| [Team Plasma Grunt](../trainers/trainer-0810.md) | Changed | AI flags, Party |
| [Doctor Grunt](../trainers/trainer-0811.md) | Changed | AI flags, AI battle items, Party |
| [Team Plasma Julius](../trainers/trainer-0812.md) | Changed | Party |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0813.md) | Changed | Party |
| [Leader Colress](../trainers/trainer-0814.md) | Added | — |
| [Leader Cheren](../trainers/trainer-0815.md) | Added | — |
| [Leader Roxie](../trainers/trainer-0816.md) | Added | — |
| [Leader Burgh](../trainers/trainer-0817.md) | Added | — |
| [Leader Elesa](../trainers/trainer-0818.md) | Added | — |
| [Leader Clay](../trainers/trainer-0819.md) | Added | — |
| [Leader Skyla](../trainers/trainer-0820.md) | Added | — |
| [Leader Drayden](../trainers/trainer-0821.md) | Added | — |
| [⒆⒇ Trainer Marlon](../trainers/trainer-0822.md) | Added | — |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0823.md) | Added | — |
| [⒆⒇ Trainer Hilda](../trainers/trainer-0824.md) | Added | — |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0825.md) | Added | — |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0826.md) | Added | — |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0827.md) | Added | — |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0828.md) | Added | — |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Added | — |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0830.md) | Added | — |
| [⒆⒇ Trainer Flannery](../trainers/trainer-0831.md) | Added | — |
| [⒆⒇ Trainer Flannery](../trainers/trainer-0832.md) | Added | — |
| [⒆⒇ Trainer Norman](../trainers/trainer-0833.md) | Added | — |
| [⒆⒇ Trainer Norman](../trainers/trainer-0834.md) | Added | — |
| [⒆⒇ Trainer Juan](../trainers/trainer-0835.md) | Added | — |
| [⒆⒇ Trainer Juan](../trainers/trainer-0836.md) | Added | — |
| [⒆⒇ Trainer Winona](../trainers/trainer-0837.md) | Added | — |
| [⒆⒇ Trainer Winona](../trainers/trainer-0838.md) | Added | — |
| [⒆⒇ Trainer Tate](../trainers/trainer-0839.md) | Added | — |
| [⒆⒇ Trainer Liza](../trainers/trainer-0840.md) | Added | — |
| [⒆⒇ Trainer Tate](../trainers/trainer-0841.md) | Added | — |
| [⒆⒇ Trainer Liza](../trainers/trainer-0842.md) | Added | — |
| [⒆⒇ Trainer Steven](../trainers/trainer-0843.md) | Added | — |
| [Veteran Wallace](../trainers/trainer-0844.md) | Added | — |
| [Boss Trainer ???](../trainers/trainer-0845.md) | Added | — |
| [⒆⒇ Trainer Benga](../trainers/trainer-0846.md) | Added | — |
| [⒆⒇ Trainer Lance](../trainers/trainer-0847.md) | Added | — |
| [⒆⒇ Trainer Brycen](../trainers/trainer-0848.md) | Added | — |
| [⒆⒇ Trainer Brycen](../trainers/trainer-0849.md) | Added | — |
| [⒆⒇ Trainer Lenora](../trainers/trainer-0850.md) | Added | — |
| [Scientist Lenora](../trainers/trainer-0851.md) | Added | — |
| [⒆⒇ Trainer Hawes](../trainers/trainer-0852.md) | Added | — |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0853.md) | Added | — |
| [⒆⒇ Trainer Hugh](../trainers/trainer-0854.md) | Added | — |
| [⒆⒇ Trainer Hugh](../trainers/trainer-0855.md) | Added | — |
| [⒆⒇ Trainer Hugh](../trainers/trainer-0856.md) | Added | — |
| [⒆⒇ Trainer Blue](../trainers/trainer-0857.md) | Added | — |
| [⒆⒇ Trainer Chili](../trainers/trainer-0858.md) | Added | — |
| [⒆⒇ Trainer Cilan](../trainers/trainer-0859.md) | Added | — |
| [⒆⒇ Trainer Cress](../trainers/trainer-0860.md) | Added | — |
| [⒆⒇ Trainer Clair](../trainers/trainer-0861.md) | Added | — |
| [⒆⒇ Trainer N?](../trainers/trainer-0862.md) | Added | — |
| [Team Plasma N?](../trainers/trainer-0863.md) | Added | — |
| [⒆⒇ Trainer Ghetsis?](../trainers/trainer-0864.md) | Added | — |
| [Ace Trainer Red](../trainers/trainer-0865.md) | Added | — |
| [Guy in Suit Drayano](../trainers/trainer-0866.md) | Added | — |
| [⒆⒇ Trainer AphexCubed](../trainers/trainer-0867.md) | Added | — |
| [⒆⒇ Trainer Colress](../trainers/trainer-0868.md) | Added | — |
| [Hoopster Colress](../trainers/trainer-0869.md) | Added | — |
| [Hoopster Jayden](../trainers/trainer-0870.md) | Added | — |
| [Hoopster Jayden](../trainers/trainer-0871.md) | Added | — |
| [Hoopster Jayden](../trainers/trainer-0872.md) | Added | — |
| [Hoopster Jayden](../trainers/trainer-0873.md) | Added | — |
| [Hoopster Jayden](../trainers/trainer-0874.md) | Added | — |
| [Striker Jayden](../trainers/trainer-0875.md) | Added | — |
| [Striker Justin](../trainers/trainer-0876.md) | Added | — |
| [Striker Justin](../trainers/trainer-0877.md) | Added | — |
| [Striker Justin](../trainers/trainer-0878.md) | Added | — |
| [Striker Justin](../trainers/trainer-0879.md) | Added | — |
| [Striker Justin](../trainers/trainer-0880.md) | Added | — |
| [Striker Justin](../trainers/trainer-0881.md) | Added | — |
| [Striker Justin](../trainers/trainer-0882.md) | Added | — |
| [Striker Justin](../trainers/trainer-0883.md) | Added | — |
| [Team Plasma Justin](../trainers/trainer-0884.md) | Added | — |
| [Boss Trainer Grunt](../trainers/trainer-0885.md) | Added | — |
| [Pokéfan Benga](../trainers/trainer-0886.md) | Added | — |
| [Boss Trainer Mabel](../trainers/trainer-0887.md) | Added | — |
| [Boss Trainer Melody](../trainers/trainer-0888.md) | Added | — |
| ⒆⒇ Trainer Nikola | Added | — |
| ⒆⒇ Trainer T4 | Added | — |

## Locations

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Striaton City](../locations/header-007.md) | Changed | Trainers |
| [Nacrene City](../locations/header-024.md) | Changed | Shops |
| [Castelia City](../locations/header-041.md) | Changed | Shops |
| [Castelia City](../locations/header-050.md) | Changed | Static Encounters |
| [Castelia City](../locations/header-053.md) | Changed | Trainers |
| [Nimbasa City](../locations/header-062.md) | Changed | Trainers |
| [Musical Theater](../locations/header-077.md) | Changed | Static Encounters |
| [Nimbasa City](../locations/header-080.md) | Changed | Trainers |
| [Driftveil City](../locations/header-096.md) | Changed | Trainers |
| [Driftveil City](../locations/header-099.md) | Changed | Shops |
| [Driftveil City](../locations/header-105.md) | Changed | Shops |
| [Mistralton City](../locations/header-108.md) | Changed | Static Encounters |
| [Mistralton City](../locations/header-109.md) | Changed | Shops, Static Encounters, Trainers |
| [Mistralton City](../locations/header-110.md) | Changed | Static Encounters |
| [Opelucid City](../locations/header-125.md) | Changed | Trainers |
| [Opelucid City](../locations/header-128.md) | Changed | Static Encounters |
| [Unity Tower](../locations/header-149.md) | Changed | Trainers |
| [Dreamyard](../locations/header-152.md) | Changed | Static Encounters |
| [Rumination Field](../locations/header-156.md) | Changed | Static Encounters |
| [Desert Resort](../locations/header-158.md) | Changed | Static Encounters |
| [Relic Castle](../locations/header-182.md) | Changed | Static Encounters |
| [Chargestone Cave](../locations/header-194.md) | Changed | Static Encounters, Trainers |
| [Chargestone Cave](../locations/header-195.md) | Changed | Static Encounters |
| [Chargestone Cave](../locations/header-197.md) | Changed | Static Encounters |
| [Twist Mountain](../locations/header-198.md) | Changed | Static Encounters, Trainers |
| [Twist Mountain](../locations/header-199.md) | Changed | Trainers |
| [Dragonspiral Tower](../locations/header-206.md) | Changed | Static Encounters |
| [Dragonspiral Tower](../locations/header-208.md) | Changed | Static Encounters |
| [Dragonspiral Tower](../locations/header-210.md) | Changed | Static Encounters |
| [Dragonspiral Tower](../locations/header-213.md) | Changed | Static Encounters |
| [Giant Chasm](../locations/header-230.md) | Changed | Static Encounters |
| [Giant Chasm](../locations/header-232.md) | Changed | Static Encounters |
| [Liberty Garden](../locations/header-235.md) | Changed | Trainers |
| [Liberty Garden](../locations/header-237.md) | Changed | Static Encounters |
| [P2 Laboratory](../locations/header-239.md) | Changed | Static Encounters |
| [Undella Bay](../locations/header-240.md) | Changed | Static Encounters |
| [Abyssal Ruins](../locations/header-244.md) | Changed | Items |
| [Abyssal Ruins](../locations/header-245.md) | Changed | Static Encounters |
| [Abyssal Ruins](../locations/header-248.md) | Changed | Static Encounters |
| [Village Bridge](../locations/header-255.md) | Changed | Static Encounters |
| [Village Bridge](../locations/header-256.md) | Changed | Items |
| [Entree Forest](../locations/header-281.md) | Changed | Static Encounters |
| [Entree Forest](../locations/header-286.md) | Changed | Warps |
| [White Forest](../locations/header-295.md) | Changed | Items |
| [Route 8](../locations/header-307.md) | Changed | Warps |
| [Route 11](../locations/header-309.md) | Changed | Items |
| [Wellspring Cave](../locations/header-324.md) | Changed | Trainers |
| [Wellspring Cave](../locations/header-325.md) | Changed | Static Encounters |
| [Route 4](../locations/header-326.md) | Changed | Static Encounters |
| [Route 6](../locations/header-332.md) | Changed | Static Encounters |
| [Mistralton Cave](../locations/header-335.md) | Changed | Name |
| [Celestial Tower](../locations/header-338.md) | Changed | Items |
| [Celestial Tower](../locations/header-342.md) | Changed | Static Encounters |
| [Route 7](../locations/header-343.md) | Changed | Npc Trades |
| [Moor of Icirrus](../locations/header-346.md) | Changed | Static Encounters |
| [Route 9](../locations/header-350.md) | Changed | Name, Shops |
| [Castelia Gardens](../locations/header-351.md) | Changed | Name, Static Encounters |
| [Route 11](../locations/header-365.md) | Changed | Static Encounters |
| [Route 12](../locations/header-368.md) | Changed | Trainers |
| [Route 13](../locations/header-370.md) | Changed | Static Encounters |
| [Route 14](../locations/header-374.md) | Changed | Static Encounters |
| [Abundant Shrine](../locations/header-376.md) | Changed | Static Encounters |
| [Route 15](../locations/header-378.md) | Changed | Static Encounters |
| [Route 16](../locations/header-383.md) | Changed | Static Encounters |
| [Lostlorn Forest](../locations/header-385.md) | Changed | Static Encounters |
| [Route 18](../locations/header-387.md) | Changed | Static Encounters, Trainers |
| [Nuvema Town](../locations/header-394.md) | Changed | Items |
| [Accumula Town](../locations/header-405.md) | Changed | Static Encounters |
| [Route 17](../locations/header-423.md) | Changed | Static Encounters |
| [Aspertia City](../locations/header-427.md) | Changed | Static Encounters |
| [Aspertia City](../locations/header-436.md) | Changed | Trainers |
| [Floccesy Town](../locations/header-439.md) | Changed | Static Encounters |
| [Floccesy Ranch](../locations/header-445.md) | Changed | Trainers |
| [Virbank City](../locations/header-448.md) | Changed | Trainers |
| [Virbank City](../locations/header-454.md) | Changed | Shops |
| [Inner Complex](../locations/header-457.md) | Changed | Name |
| [Lentimas Town](../locations/header-460.md) | Changed | Shops |
| [Reversal Mountain](../locations/header-461.md) | Changed | Static Encounters |
| [Marine Tube](../locations/header-464.md) | Changed | Warps, Items |
| [Humilau City](../locations/header-465.md) | Changed | Trainers |
| [Humilau City](../locations/header-467.md) | Changed | Npc Trades |
| [Humilau City](../locations/header-472.md) | Changed | Shops |
| [Route 22](../locations/header-474.md) | Changed | Static Encounters |
| [Route 23](../locations/header-475.md) | Changed | Static Encounters |
| [Black Tower](../locations/header-481.md) | Changed | Items |
| [Castelia City](../locations/header-494.md) | Changed | Static Encounters |
| [Castelia Gardens](../locations/header-500.md) | Changed | Name |
| [Relic Passage](../locations/header-503.md) | Changed | Warps, Trainers |
| [Seaside Cave](../locations/header-515.md) | Changed | Items, Static Encounters |
| [Cave of Being](../locations/header-517.md) | Changed | Warps |
| [Route 4](../locations/header-519.md) | Changed | Warps |
| [Route 4](../locations/header-520.md) | Changed | Warps, Npc Trades |
| [Reversal Mountain](../locations/header-531.md) | Changed | Trainers |
| [Reversal Mountain](../locations/header-534.md) | Changed | Static Encounters |
| [Reversal Mountain](../locations/header-537.md) | Changed | Trainers |
| [Driftveil City](../locations/header-550.md) | Changed | Static Encounters |
| [Route 4](../locations/header-551.md) | Changed | Static Encounters |
| [Nature Preserve](../locations/header-584.md) | Changed | Static Encounters, Trainers |
| [Victory Road](../locations/header-592.md) | Changed | Trainers |
| [Underground Ruins](../locations/header-610.md) | Changed | Items |
| [Pledge Grove](../locations/header-614.md) | Changed | Static Encounters |
| [Faraway Island](../locations/header-615.md) | Added | — |
| [Faraway Island](../locations/header-616.md) | Added | — |
