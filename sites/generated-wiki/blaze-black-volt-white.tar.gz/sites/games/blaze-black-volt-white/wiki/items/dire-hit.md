# Dire Hit

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dire-hit.png" alt="Dire Hit icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>56</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Stat Boosts</dd></div>
<div><dt>Base price</dt><dd>₽650</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Increases the chance of a critical hit in battle. Raises happiness.</strong></p>
<p>Used on a party Pokémon in battle : Increases the target’s critical hit chance by one stage until it leaves the field. Increases happiness by 1/1/0.</p>

<figure class="rw-pokedex-entry">
<blockquote>It raises the critical-hit ratio greatly. It can be used only once and wears off if the Pokémon is withdrawn.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x02</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>friendship (low +1, medium +1)</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Route 6](../locations/header-331.md) | Hidden | (150, 361) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Nacrene City](../locations/header-024.md) | Nacrene/Shopping Mall 9 X Items | ₽650 | Main game |
| [Shopping Mall](../locations/header-350.md) | Nacrene/Shopping Mall 9 X Items | ₽650 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Scientist Randall](../trainers/trainer-0114.md) | AI battle item |
| [Scientist Steve](../trainers/trainer-0115.md) | AI battle item |
| [Scientist Burgh](../trainers/trainer-0417.md) | AI battle item |
| [Scientist Ryder](../trainers/trainer-0468.md) | AI battle item |
| [Scientist Jacques](../trainers/trainer-0469.md) | AI battle item |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `56` |

Source: exact ROM record from `a/0/2/4` member `56`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/56/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../guard-spec/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/guard-spec.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Guard Spec.</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../x-attack/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/x-attack.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">X Attack →</span></a>
</nav>
