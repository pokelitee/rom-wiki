# Guard Spec.

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/guard-spec.png" alt="Guard Spec. icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>55</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Stat Boosts</dd></div>
<div><dt>Base price</dt><dd>₽700</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Prevents stat changes in battle for five turns in battle. Raises happiness.</strong></p>
<p>Used on a party Pokémon in battle : Protects the target’s stats from being lowered for the next five turns. Increases happiness by 1/1/0.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item that prevents stat reduction among the Trainer&#x27;s party Pokémon for five turns after use.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x02</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>friendship (low +1, medium +1)</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Nacrene City](../locations/header-024.md) | — | `header-024` | Nacrene/Shopping Mall 9 X Items | ₽700 | Main game |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Nacrene/Shopping Mall 9 X Items | ₽700 | Main game |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `55` |

Source: exact ROM record from `a/0/2/4` member `55`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/55/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../old-gateau/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/old-gateau.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Old Gateau</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../dire-hit/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dire-hit.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Dire Hit →</span></a>
</nav>
