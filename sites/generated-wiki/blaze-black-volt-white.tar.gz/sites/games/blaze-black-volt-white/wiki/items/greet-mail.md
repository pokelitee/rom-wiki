# Greet Mail

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/greet-mail.png" alt="Greet Mail icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>137</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>All Mail</dd></div>
<div><dt>Base price</dt><dd>₽50</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Lets a Trainer write a message and send it via Pokémon trade.</strong></p>
<p>Used to send short messages to other players via Pokémon trading. Trainer may compose a message from a finite list of words when giving this item to a Pokémon. Once taken and read, a message may be erased and this item can be reused, or the message may be stored in the trainer’s PC. Held : Holder cannot be placed in the PC. Any move attempting to remove this item from the holder will fail.</p>

<figure class="rw-pokedex-entry">
<blockquote>Stationery designed for introductory greetings. Let a Pokémon hold it for delivery.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Mail</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>7</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Victory Road](../locations/header-214.md) | Visible | (12, 3) |
| [Moor of Icirrus](../locations/header-346.md) | Hidden | (17, 51) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Black City](../locations/header-001.md) | Black City/White Forest Secondary | ₽50 | Post-game |
| [Striaton City](../locations/header-008.md) | Striaton Secondary | ₽50 | Main game |
| [Nacrene City](../locations/header-020.md) | Nacrene Secondary | ₽50 | Main game |
| [Castelia City](../locations/header-041.md) | Castelia Secondary | ₽50 | Main game |
| [Driftveil City](../locations/header-099.md) | Driftveil Secondary | ₽50 | Main game |
| [Opelucid City](../locations/header-122.md) | Opelucid Secondary | ₽50 | Main game |
| [Shopping Mall](../locations/header-350.md) | Shopping Mall 9 F2 | ₽50 | Main game |
| [Accumula Town](../locations/header-398.md) | Accumula Secondary | ₽50 | Main game |
| [Lacunosa Town](../locations/header-407.md) | Lacunosa Secondary | ₽50 | Post-game |
| [Undella Town](../locations/header-413.md) | Undella Secondary | ₽50 | Post-game |
| [White Forest](../locations/header-425.md) | Black City/White Forest Secondary | ₽50 | Post-game |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `137` |

Source: exact ROM record from `a/0/2/4` member `137`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/568/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../lustrous-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lustrous-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Lustrous Orb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../favored-mail/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/favored-mail.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Favored Mail →</span></a>
</nav>
