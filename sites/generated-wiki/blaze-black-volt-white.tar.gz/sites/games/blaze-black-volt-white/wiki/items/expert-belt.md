# Expert Belt

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/expert-belt.png" alt="Expert Belt icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>268</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s Super Effective moves do 20% extra damage.</strong></p>
<p>Held: When the holder hits with a super-effective move, its power is raised by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a well-worn belt that slightly boosts the power of supereffective moves.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>96</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/538.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Throh](../pokemon/throh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [⒆⒇ Trainer N](../trainers/trainer-0090.md) | Held by Simisage |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0091.md) | Held by Simisear |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0092.md) | Held by Simipour |
| [Leader Roberto](../trainers/trainer-0131.md) | Held by Abomasnow |
| [⒆⒇ Trainer Billy](../trainers/trainer-0403.md) | Held by Simisage |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0404.md) | Held by Simisear |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0405.md) | Held by Simipour |
| [Leader Skyla](../trainers/trainer-0411.md) | Held by Abomasnow |
| [GAME FREAK Cheren](../trainers/trainer-0542.md) | Held by Mew |
| [Elite Four](../trainers/trainer-0563.md) | Held by Golurk |
| [Elite Four Marshal](../trainers/trainer-0565.md) | Held by Weavile |
| [Elite Four Grimsley](../trainers/trainer-0566.md) | Held by Metagross |
| [Leader Blue](../trainers/trainer-0580.md) | Held by Kangaskhan |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Wild Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Throh</li><li>Sawk</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">13 entries added</p><ul class="rw-comparison-list"><li>Golurk</li><li>Metagross</li><li>Weavile</li><li>Mew</li><li>Kangaskhan</li><li>Abomasnow</li><li>Abomasnow</li><li>Simisage</li><li>Simisear</li><li>Simisear</li><li>Simipour</li><li>Simipour</li><li>Simisage</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `268` |

Source: exact ROM record from `a/0/2/4` member `268`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/245/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../wise-glasses/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wise-glasses.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Wise Glasses</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Light Clay →</span></a>
</nav>
