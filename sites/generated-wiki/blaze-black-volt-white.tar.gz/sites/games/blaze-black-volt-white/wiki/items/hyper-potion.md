# Hyper Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="Hyper Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>25</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 200 HP.</strong></p>
<p>Used on a party Pokémon : Restores 200 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>HP amount 200</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Nimbasa City](../locations/header-064.md) | map_64 | `header-064` | Visible | (49, 25) |
| [Undella Town](../locations/header-316.md) | map_316 | `header-316` | Hidden | (748, 300) |

## Shops

| Location | Section | Map header | Shop | Price | Availability |
| -------- | ------- | ---------- | ---- | ----: | ------------ |
| [Shopping Mall](../locations/header-350.md) | map_350 | `header-350` | Shopping Mall 9 F1 | ₽1,200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Lenora](../trainers/trainer-0022.md) | AI battle item |
| [Leader Burgh](../trainers/trainer-0023.md) | AI battle item |
| [Leader Elesa](../trainers/trainer-0024.md) | AI battle item |
| [Leader Clay](../trainers/trainer-0025.md) | AI battle item |
| [Leader Roberto](../trainers/trainer-0131.md) | AI battle item |
| [Leader Brycen](../trainers/trainer-0132.md) | AI battle item |
| [Leader Iris](../trainers/trainer-0133.md) | AI battle item |
| [Pokéfan Geoff](../trainers/trainer-0138.md) | AI battle item |
| [Pokéfan Jude](../trainers/trainer-0139.md) | AI battle item |
| [Doctor Devon](../trainers/trainer-0150.md) | AI battle item |
| [Doctor Wayne](../trainers/trainer-0151.md) | AI battle item |
| [Nurse Hank](../trainers/trainer-0152.md) | AI battle item |
| [Doctor Tyrone](../trainers/trainer-0249.md) | AI battle item |
| [Pokéfan Janie](../trainers/trainer-0373.md) | AI battle item |
| [Pokéfan Colin](../trainers/trainer-0374.md) | AI battle item |
| [Doctor Alexander](../trainers/trainer-0384.md) | AI battle item |
| [Pokéfan Yellow](../trainers/trainer-0429.md) | AI battle item |
| [⒆⒇ Trainer Shane](../trainers/trainer-0491.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0492.md) | AI battle item |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0493.md) | AI battle item |
| [Doctor Grunt](../trainers/trainer-0613.md) | AI battle item |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `25` |

Source: exact ROM record from `a/0/2/4` member `25`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/25/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Potion →</span></a>
</nav>
