# Full Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-heal.png" alt="Full Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>27</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It heals all the status problems of a single Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Twist Mountain](../locations/header-200.md) | — | `header-200` | Visible | (60, 8) |
| [Victory Road](../locations/header-227.md) | — | `header-227` | Hidden | (16, 12) |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Visible | (28, 48) |
| [Wellspring Cave](../locations/header-324.md) | — | `header-324` | Visible | (3, 11) |
| [Wellspring Cave](../locations/header-325.md) | — | `header-325` | Hidden | (25, 41) |
| [Route 8](../locations/header-345.md) | — | `header-345` | Visible | (206, 168) |
| [Route 10](../locations/header-355.md) | — | `header-355` | Visible | (492, 121) |
| [Route 12](../locations/header-368.md) | — | `header-368` | Visible | (610, 170) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F1 | ₽600 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Doctor Devon](../trainers/trainer-0150.md) | AI battle item |
| [Doctor Wayne](../trainers/trainer-0151.md) | AI battle item |
| [Nurse Hank](../trainers/trainer-0152.md) | AI battle item |
| [Doctor Tyrone](../trainers/trainer-0249.md) | AI battle item |
| [Doctor Alexander](../trainers/trainer-0384.md) | AI battle item |
| [Doctor Grunt](../trainers/trainer-0613.md) | AI battle item |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Route 3</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `27` |

Source: exact ROM record from `a/0/2/4` member `27`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/27/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Super Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../revive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/revive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Revive →</span></a>
</nav>
