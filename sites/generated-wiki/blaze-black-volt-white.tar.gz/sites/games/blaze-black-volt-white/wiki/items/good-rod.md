# Good Rod

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/good-rod.png" alt="Good Rod icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>446</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Gameplay</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Used to catch Pokémon in bodies of water.</strong></p>
<p>Used to find Pokémon on the Good Rod list for an area, which are generally mediocre.</p>

<figure class="rw-pokedex-entry">
<blockquote>A new, good-quality fishing rod. Use it by any body of water to fish for wild aquatic Pokémon.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `446` |

Source: exact ROM record from `a/0/2/4` member `446`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/423/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../old-rod/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/old-rod.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Old Rod</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../fishing-rod/"><span class="rw-record-nav__label">Fishing Rod →</span></a>
</nav>
