# Focus Sash

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-sash.png" alt="Focus Sash icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>275</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder survives any single-hit attack at 1 HP if at max HP, then the item is consumed.</strong></p>
<p>Held: If the holder has full HP and is attacked for regular damage that would faint it, this item is consumed and prevents the holder’s HP from lowering below 1. This effect works against multi-hit attacks, but does not work against the effects of Doom Desire or Future Sight.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. If it has full HP, the holder will endure one potential KO attack, leaving 1 HP.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>103</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 48 BP | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Roberto](../trainers/trainer-0131.md) | Held by Cryogonal |
| [Elite Four Shauntal](../trainers/trainer-0229.md) | Held by Breloom |
| [Elite Four Marshal](../trainers/trainer-0230.md) | Held by Houndoom |
| [Team Plasma Caitlin](../trainers/trainer-0232.md) | Held by Genesect |
| [Champion Ingo](../trainers/trainer-0407.md) | Held by Espeon |
| [Leader Krissa](../trainers/trainer-0410.md) | Held by Swoobat |
| [Leader Skyla](../trainers/trainer-0411.md) | Held by Cryogonal |
| [Leader Jay](../trainers/trainer-0416.md) | Held by Leavanny |
| [Elite Four](../trainers/trainer-0563.md) | Held by Gengar |
| [Elite Four Marshal](../trainers/trainer-0565.md) | Held by Sharpedo |

## Gifts and trades

=== "Blaze Black"

    No gift or trade references.

=== "Volt White"

    | Location | Section | Map ID | Kind | Pokémon | Type |
    | -------- | ------- | ------ | ---- | ------- | ---- |
    | [Driftveil City](../locations/header-101.md) | — | `header-101` | Trade | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/459.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snover](../pokemon/snover.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ice">Ice</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

=== "Blaze Black"

    Compared with **black-us**.

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Trainer Held By</p>
    <div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/serperior/">Serperior</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/samurott/">Samurott</a></li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/espeon/">Espeon</a></li><li><a href="../../pokemon/gengar/">Gengar</a></li><li><a href="../../pokemon/houndoom/">Houndoom</a></li><li><a href="../../pokemon/sharpedo/">Sharpedo</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/leavanny/">Leavanny</a></li><li><a href="../../pokemon/swoobat/">Swoobat</a></li><li><a href="../../pokemon/cryogonal/">Cryogonal</a></li><li><a href="../../pokemon/cryogonal/">Cryogonal</a></li><li><a href="../../pokemon/genesect/">Genesect</a></li></ul></div>
    </section>
    </div>

=== "Volt White"

    Compared with **white-us**.

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Trainer Held By</p>
    <div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/serperior/">Serperior</a></li><li><a href="../../pokemon/emboar/">Emboar</a></li><li><a href="../../pokemon/samurott/">Samurott</a></li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/espeon/">Espeon</a></li><li><a href="../../pokemon/gengar/">Gengar</a></li><li><a href="../../pokemon/houndoom/">Houndoom</a></li><li><a href="../../pokemon/sharpedo/">Sharpedo</a></li><li><a href="../../pokemon/breloom/">Breloom</a></li><li><a href="../../pokemon/leavanny/">Leavanny</a></li><li><a href="../../pokemon/swoobat/">Swoobat</a></li><li><a href="../../pokemon/cryogonal/">Cryogonal</a></li><li><a href="../../pokemon/cryogonal/">Cryogonal</a></li><li><a href="../../pokemon/genesect/">Genesect</a></li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Trades</p>
    <div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/snover/">Snover</a></li></ul></div>
    </section>
    </div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `275` |

Source: exact ROM record from `a/0/2/4` member `275`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/252/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../quick-powder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-powder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Quick Powder</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../zoom-lens/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/zoom-lens.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Zoom Lens →</span></a>
</nav>
