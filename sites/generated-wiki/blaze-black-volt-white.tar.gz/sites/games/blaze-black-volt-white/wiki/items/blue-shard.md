# Blue Shard

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="Blue Shard icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>73</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Collectibles</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>No effect. Can be traded for items or moves.</strong></p>
<p>No effect. In Diamond and Pearl, trade ten for a Rain Dance TM in the house midway along the southern section of Route 212. In Platinum, trade to move tutors on Route 212, in Snowpoint City, and in the Survival Area. Eight shards total are required per tutelage, but the particular combination of colors varies by move. In HeartGold and SoulSilver, trade one for a Chesto Berry, an Oran Berry, and a Wiki Berry with the Juggler near the Pokémon Center in Violet City. In HeartGold and SoulSilver, trade one for a Bluk Berry, a Cornn Berry, and a Kelpsy Berry with the Juggler near the Pal Park entrance in Fuchsia City.</p>

<figure class="rw-pokedex-entry">
<blockquote>A small blue shard. It appears to be from some sort of implement made long ago.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Black City](../locations/header-005.md) | — | `header-005` | Black City resident market | ₽3,000 | Current resident: Eliza |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-us / white-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `73` |

Source: exact ROM record from `a/0/2/4` member `73`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/73/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../red-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Red Shard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../yellow-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Yellow Shard →</span></a>
</nav>
