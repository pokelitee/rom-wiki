# Choice Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/choice-band.png" alt="Choice Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>220</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Choice</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Increases Attack by 50%, but restricts the holder to only one move.</strong></p>
<p>Held in battle : Holder has 1.5× its Attack. When the holder attempts to use a move, all its other moves are disabled until it leaves battle or loses this item. The restriction ends even if this item is swapped for another Choice item via Trick or Switcheroo.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. This headband ups Attack, but allows the use of only one of its moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>55</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Abyssal Ruins](../locations/header-245.md) | Visible | (117, 50) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-068.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-069.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-070.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-071.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-072.md) | Battle Point item exchange | 48 BP | Main game |
| [Gear Station](../locations/header-073.md) | Battle Point item exchange | 48 BP | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Champion Ingo](../trainers/trainer-0407.md) | Held by Bouffalant |
| [Leader Stephen](../trainers/trainer-0444.md) | Held by Haxorus |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Bouffalant</li><li>Haxorus</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `220` |

Source: exact ROM record from `a/0/2/4` member `220`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/197/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../mental-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/mental-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Mental Herb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../kings-rock/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/kings-rock.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">King&#x27;s Rock →</span></a>
</nav>
