# Gracidea

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gracidea.png" alt="Gracidea icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>466</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Event Items</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>Yes</dd></div>
<div><dt>Can be discarded</dt><dd>No</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Changes an unfrozen Shaymin to Sky Forme in the day.</strong></p>
<p>Used by trainer on a Shaymin : Changes the target Shaymin from Land Forme to Sky Forme. This item cannot be used on a frozen Shaymin or at night. Sky Forme Shaymin will revert to Land Forme overnight, when frozen, and upon entering a link battle. This item must be used again to change it back.</p>

<figure class="rw-pokedex-entry">
<blockquote>A flower sometimes bundled in bouquets to convey gratitude on special occasions like birthdays.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Gracidea</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>24</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `466` |

Source: exact ROM record from `a/0/2/4` member `466`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/444/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../vs-recorder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/vs-recorder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Vs. Recorder</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../secret-key/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/secret-key.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Secret Key →</span></a>
</nav>
