# Griseous Orb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/griseous-orb.png" alt="Griseous Orb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>112</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Species Specific</dd></div>
<div><dt>Base price</dt><dd>₽10,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">60</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Boosts the damage from Giratina’s Dragon-type and Ghost-type moves by 20%, and transforms it into Origin Forme.</strong></p>
<p>Held by Giratina : Holder’s Dragon and Ghost moves have 1.2× their base power. Holder is in Origin Forme. This item cannot be held by any Pokémon but Giratina. When you enter the Union Room or connect to Wi-Fi, this item returns to your bag.</p>

<figure class="rw-pokedex-entry">
<blockquote>A glowing orb to be held by Giratina. It boosts the power of Dragon- and Ghost-type moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>2</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [Twist Mountain](../locations/header-199.md) | map_199 | `header-199` | Visible | (50, 35) |
| [Undella Bay](../locations/header-240.md) | map_240 | `header-240` | Hidden | (792, 272) |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `112` |

Source: exact ROM record from `a/0/2/4` member `112`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/442/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../odd-keystone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/odd-keystone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Odd Keystone</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../douse-drive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/douse-drive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Douse Drive →</span></a>
</nav>
