# Coba Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/coba-berry.png" alt="Coba Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>192</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Type Protection</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when struck by a super-effective Flying-type attack to halve the damage.</strong></p>
<p>Held in battle : When the holder would take super-effective Flying-type damage, it consumes this item to halve the amount of damage taken.</p>

<figure class="rw-pokedex-entry">
<blockquote>Weakens a supereffective Flying-type attack against the holding Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>3</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>27</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--flying">Flying</span></span></dd></div>
</dl>

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/191.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sunkern](../pokemon/sunkern.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0494.md) | Held by Mienshao |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0495.md) | Held by Mienshao |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0496.md) | Held by Mienshao |
| [Leader Maki](../trainers/trainer-0575.md) | Held by Infernape |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Infernape</li><li>Mienshao</li><li>Mienshao</li><li>Mienshao</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `192` |

Source: exact ROM record from `a/0/2/4` member `192`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `53`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/169/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../shuca-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/shuca-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Shuca Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../payapa-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/payapa-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Payapa Berry →</span></a>
</nav>
