# Flying Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/flying-gem.png" alt="Flying Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>556</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an essence of air. When held, it strengthens the power of a Flying-type move only once.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Clay](../trainers/trainer-0025.md) | Held by Archeops |
| [Elite Four Shauntal](../trainers/trainer-0229.md) | Held by Mienshao |
| [Team Plasma Caitlin](../trainers/trainer-0232.md) | Held by Eelektross |
| [Champion Ingo](../trainers/trainer-0407.md) | Held by Braviary |
| [Leader Hillary](../trainers/trainer-0446.md) | Held by Eelektross |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0494.md) | Held by Simisear |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0495.md) | Held by Simipour |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0496.md) | Held by Simisage |
| [Elite Four Marshal](../trainers/trainer-0565.md) | Held by Honchkrow |
| [⒆⒇ Trainer N](../trainers/trainer-0588.md) | Held by Simisage |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0589.md) | Held by Simisear |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0590.md) | Held by Simipour |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0591.md) | Held by Simisage |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0592.md) | Held by Simisear |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0593.md) | Held by Simipour |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0594.md) | Held by Simisear |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0594.md) | Held by Mienshao |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0595.md) | Held by Simipour |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0595.md) | Held by Mienshao |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0596.md) | Held by Simisage |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0596.md) | Held by Mienshao |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">21 entries added</p><ul class="rw-comparison-list"><li>Braviary</li><li>Honchkrow</li><li>Mienshao</li><li>Archeops</li><li>Eelektross</li><li>Eelektross</li><li>Simisage</li><li>Simisage</li><li>Simisear</li><li>Simipour</li><li>Simipour</li><li>Mienshao</li><li>Mienshao</li><li>Simisage</li><li>Simisear</li><li>Simisear</li><li>Simisear</li><li>Simipour</li><li>Simipour</li><li>Mienshao</li><li>Simisage</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `556` |

Source: exact ROM record from `a/0/2/4` member `556`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/599/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ground-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ground-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ground Gem</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../psychic-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/psychic-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Psychic Gem →</span></a>
</nav>
