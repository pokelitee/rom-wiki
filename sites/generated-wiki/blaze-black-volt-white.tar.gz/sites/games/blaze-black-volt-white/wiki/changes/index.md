# Changes from base game

Every supported ROM dataset is compared with the configured clean base ROM. Unchanged records remain visible on their detail pages.

| Section | Unchanged | Changed | Added | Removed |
| ------- | --------: | ------: | ----: | ------: |
| [Pokémon](#pokemon) | 43 | 625 | 0 | 0 |
| [Abilities](#abilities) | 24 | 140 | 0 | 0 |
| [Moves](#moves) | 514 | 46 | 0 | 0 |
| [Items](#items) | 405 | 201 | 0 | 0 |
| [Wild encounters](#wild-encounters) | 0 | 148 | 0 | 0 |
| [Trainers](#trainers) | 0 | 615 | 0 | 0 |
| [Locations](#locations) | 362 | 65 | 0 | 0 |

## Pokémon

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Bulbasaur](../pokemon/bulbasaur.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Ivysaur](../pokemon/ivysaur.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Venusaur](../pokemon/venusaur.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Charmander](../pokemon/charmander.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Charmeleon](../pokemon/charmeleon.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Charizard](../pokemon/charizard.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Squirtle](../pokemon/squirtle.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Wartortle](../pokemon/wartortle.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Blastoise](../pokemon/blastoise.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Caterpie](../pokemon/caterpie.md) | Changed | Abilities, Level-up moves |
| [Metapod](../pokemon/metapod.md) | Changed | Abilities |
| [Butterfree](../pokemon/butterfree.md) | Changed | Base stats, Abilities, Level-up moves |
| [Weedle](../pokemon/weedle.md) | Changed | Abilities, Level-up moves |
| [Kakuna](../pokemon/kakuna.md) | Changed | Abilities |
| [Beedrill](../pokemon/beedrill.md) | Changed | Base stats, Abilities, Level-up moves |
| [Pidgey](../pokemon/pidgey.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Pidgeotto](../pokemon/pidgeotto.md) | Changed | Abilities, Wild held items, Machines, Level-up moves |
| [Pidgeot](../pokemon/pidgeot.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Rattata](../pokemon/rattata.md) | Changed | Abilities, Machines, Level-up moves |
| [Raticate](../pokemon/raticate.md) | Changed | Base stats, Abilities, Wild held items, Machines, Level-up moves |
| [Spearow](../pokemon/spearow.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Fearow](../pokemon/fearow.md) | Changed | Base stats, Abilities, Wild held items, Level-up moves |
| [Ekans](../pokemon/ekans.md) | Changed | Wild held items, Level-up moves |
| [Arbok](../pokemon/arbok.md) | Changed | Base stats, Wild held items, Level-up moves |
| [Pikachu](../pokemon/pikachu.md) | Changed | Base stats, Abilities, Wild held items, Machines, Level-up moves |
| [Raichu](../pokemon/raichu.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Sandshrew](../pokemon/sandshrew.md) | Changed | Abilities, Level-up moves |
| [Sandslash](../pokemon/sandslash.md) | Changed | Abilities, Level-up moves |
| [Nidoran](../pokemon/nidoran-f.md) | Changed | Wild held items, Level-up moves |
| [Nidorina](../pokemon/nidorina.md) | Changed | Abilities, Level-up moves |
| [Nidoqueen](../pokemon/nidoqueen.md) | Changed | Base stats, Abilities |
| [Nidoran](../pokemon/nidoran-m.md) | Changed | Wild held items, Level-up moves |
| [Nidorino](../pokemon/nidorino.md) | Changed | Abilities, Level-up moves |
| [Nidoking](../pokemon/nidoking.md) | Changed | Base stats, Abilities |
| [Clefairy](../pokemon/clefairy.md) | Changed | Level-up moves |
| [Clefable](../pokemon/clefable.md) | Changed | Base stats, Abilities, Level-up moves |
| [Vulpix](../pokemon/vulpix.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Ninetales](../pokemon/ninetales.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Jigglypuff](../pokemon/jigglypuff.md) | Changed | Base stats, Abilities, Level-up moves |
| [Wigglytuff](../pokemon/wigglytuff.md) | Changed | Base stats, Abilities, Level-up moves |
| [Zubat](../pokemon/zubat.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Golbat](../pokemon/golbat.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Oddish](../pokemon/oddish.md) | Changed | Abilities, Level-up moves |
| [Gloom](../pokemon/gloom.md) | Changed | Abilities, Level-up moves |
| [Vileplume](../pokemon/vileplume.md) | Changed | Base stats, Abilities, Level-up moves |
| [Paras](../pokemon/paras.md) | Changed | Level-up moves |
| [Parasect](../pokemon/parasect.md) | Changed | Base stats, Level-up moves |
| [Venonat](../pokemon/venonat.md) | Changed | Level-up moves |
| [Venomoth](../pokemon/venomoth.md) | Changed | Base stats, Abilities, Level-up moves |
| [Diglett](../pokemon/diglett.md) | Changed | Abilities |
| [Dugtrio](../pokemon/dugtrio.md) | Changed | Base stats, Abilities |
| [Meowth](../pokemon/meowth.md) | Changed | Level-up moves |
| [Persian](../pokemon/persian.md) | Changed | Base stats, Machines, Level-up moves |
| [Psyduck](../pokemon/psyduck.md) | Changed | Abilities, Level-up moves |
| [Golduck](../pokemon/golduck.md) | Changed | Abilities, Level-up moves |
| [Mankey](../pokemon/mankey.md) | Changed | Abilities |
| [Primeape](../pokemon/primeape.md) | Changed | Base stats, Abilities, Level-up moves |
| [Growlithe](../pokemon/growlithe.md) | Changed | Abilities, Level-up moves |
| [Arcanine](../pokemon/arcanine.md) | Changed | Abilities, Level-up moves |
| [Poliwag](../pokemon/poliwag.md) | Changed | Abilities, Level-up moves |
| [Poliwhirl](../pokemon/poliwhirl.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Poliwrath](../pokemon/poliwrath.md) | Changed | Base stats, Abilities, Level-up moves |
| [Abra](../pokemon/abra.md) | Changed | Abilities, Level-up moves |
| [Kadabra](../pokemon/kadabra.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Alakazam](../pokemon/alakazam.md) | Changed | Abilities, Level-up moves |
| [Machop](../pokemon/machop.md) | Changed | Level-up moves |
| [Machoke](../pokemon/machoke.md) | Changed | Evolutions, Level-up moves |
| [Machamp](../pokemon/machamp.md) | Changed | Level-up moves |
| [Bellsprout](../pokemon/bellsprout.md) | Changed | Abilities, Level-up moves |
| [Weepinbell](../pokemon/weepinbell.md) | Changed | Abilities, Level-up moves |
| [Victreebel](../pokemon/victreebel.md) | Changed | Base stats, Abilities, Level-up moves |
| [Tentacool](../pokemon/tentacool.md) | Changed | Level-up moves |
| [Tentacruel](../pokemon/tentacruel.md) | Changed | Level-up moves |
| [Geodude](../pokemon/geodude.md) | Changed | Level-up moves |
| [Graveler](../pokemon/graveler.md) | Changed | Evolutions, Level-up moves |
| [Golem](../pokemon/golem.md) | Changed | Base stats, Level-up moves |
| [Ponyta](../pokemon/ponyta.md) | Changed | Abilities, Level-up moves |
| [Rapidash](../pokemon/rapidash.md) | Changed | Abilities, Level-up moves |
| [Slowpoke](../pokemon/slowpoke.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Slowbro](../pokemon/slowbro.md) | Changed | Abilities, Level-up moves |
| [Magnemite](../pokemon/magnemite.md) | Changed | Abilities, Level-up moves |
| [Magneton](../pokemon/magneton.md) | Changed | Abilities, Level-up moves |
| [Farfetch'd](../pokemon/farfetchd.md) | Changed | Base stats, Types, Abilities, Base experience, Wild held items, Level-up moves |
| [Doduo](../pokemon/doduo.md) | Changed | Abilities, Level-up moves |
| [Dodrio](../pokemon/dodrio.md) | Changed | Abilities, Level-up moves |
| [Dewgong](../pokemon/dewgong.md) | Changed | Base stats |
| [Grimer](../pokemon/grimer.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Muk](../pokemon/muk.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Shellder](../pokemon/shellder.md) | Changed | Abilities, Level-up moves |
| [Cloyster](../pokemon/cloyster.md) | Changed | Abilities, Level-up moves |
| [Gastly](../pokemon/gastly.md) | Changed | Machines, Level-up moves |
| [Haunter](../pokemon/haunter.md) | Changed | Evolutions, Machines, Level-up moves |
| [Gengar](../pokemon/gengar.md) | Changed | Machines, Level-up moves |
| [Onix](../pokemon/onix.md) | Changed | Base stats, Abilities, Evolutions, Level-up moves |
| [Drowzee](../pokemon/drowzee.md) | Changed | Level-up moves |
| [Hypno](../pokemon/hypno.md) | Changed | Level-up moves |
| [Krabby](../pokemon/krabby.md) | Changed | Abilities, Machines, Level-up moves |
| [Kingler](../pokemon/kingler.md) | Changed | Abilities, Machines, Level-up moves |
| [Voltorb](../pokemon/voltorb.md) | Changed | Abilities, Level-up moves |
| [Electrode](../pokemon/electrode.md) | Changed | Abilities, Level-up moves |
| [Exeggcute](../pokemon/exeggcute.md) | Changed | Abilities, Level-up moves |
| [Exeggutor](../pokemon/exeggutor.md) | Changed | Abilities, Level-up moves |
| [Cubone](../pokemon/cubone.md) | Changed | Abilities, Level-up moves |
| [Marowak](../pokemon/marowak.md) | Changed | Base stats, Abilities, Level-up moves |
| [Hitmonlee](../pokemon/hitmonlee.md) | Changed | Abilities, Level-up moves |
| [Hitmonchan](../pokemon/hitmonchan.md) | Changed | Abilities, Level-up moves |
| [Lickitung](../pokemon/lickitung.md) | Changed | Abilities, Level-up moves |
| [Koffing](../pokemon/koffing.md) | Changed | Machines, Level-up moves |
| [Weezing](../pokemon/weezing.md) | Changed | Base stats, Machines, Level-up moves |
| [Rhyhorn](../pokemon/rhyhorn.md) | Changed | Abilities, Level-up moves |
| [Rhydon](../pokemon/rhydon.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Chansey](../pokemon/chansey.md) | Changed | Wild held items, Base friendship, Level-up moves |
| [Tangela](../pokemon/tangela.md) | Changed | Abilities, Level-up moves |
| [Kangaskhan](../pokemon/kangaskhan.md) | Changed | Level-up moves |
| [Horsea](../pokemon/horsea.md) | Changed | Machines, Level-up moves |
| [Seadra](../pokemon/seadra.md) | Changed | Abilities, Evolutions, Machines, Level-up moves |
| [Goldeen](../pokemon/goldeen.md) | Changed | Abilities, Level-up moves |
| [Seaking](../pokemon/seaking.md) | Changed | Base stats, Abilities, Level-up moves |
| [Staryu](../pokemon/staryu.md) | Changed | Abilities, Level-up moves |
| [Starmie](../pokemon/starmie.md) | Changed | Abilities, Level-up moves |
| [Mr. Mime](../pokemon/mr-mime.md) | Changed | Base stats |
| [Scyther](../pokemon/scyther.md) | Changed | Evolutions, Machines, Level-up moves |
| [Jynx](../pokemon/jynx.md) | Changed | Base stats, Abilities, Level-up moves |
| [Electabuzz](../pokemon/electabuzz.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Magmar](../pokemon/magmar.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Pinsir](../pokemon/pinsir.md) | Changed | Abilities, Level-up moves |
| [Tauros](../pokemon/tauros.md) | Changed | Base stats, Abilities, Level-up moves |
| [Magikarp](../pokemon/magikarp.md) | Changed | Abilities, Level-up moves |
| [Gyarados](../pokemon/gyarados.md) | Changed | Abilities, Level-up moves |
| [Lapras](../pokemon/lapras.md) | Changed | Level-up moves |
| [Ditto](../pokemon/ditto.md) | Changed | Abilities |
| [Eevee](../pokemon/eevee.md) | Changed | Abilities, Base friendship, Machines, Level-up moves |
| [Vaporeon](../pokemon/vaporeon.md) | Changed | Abilities, Base friendship, Machines, Level-up moves |
| [Jolteon](../pokemon/jolteon.md) | Changed | Abilities, Base friendship, Machines, Level-up moves |
| [Flareon](../pokemon/flareon.md) | Changed | Base stats, Abilities, Base friendship, Machines, Level-up moves |
| [Porygon](../pokemon/porygon.md) | Changed | Evolutions, Level-up moves |
| [Omanyte](../pokemon/omanyte.md) | Changed | Level-up moves |
| [Omastar](../pokemon/omastar.md) | Changed | Abilities, Level-up moves |
| [Kabutops](../pokemon/kabutops.md) | Changed | Abilities |
| [Aerodactyl](../pokemon/aerodactyl.md) | Changed | Level-up moves |
| [Snorlax](../pokemon/snorlax.md) | Changed | Abilities, Level-up moves |
| [Articuno](../pokemon/articuno.md) | Changed | Abilities, Wild held items |
| [Zapdos](../pokemon/zapdos.md) | Changed | Abilities, Wild held items |
| [Moltres](../pokemon/moltres.md) | Changed | Abilities, Wild held items |
| [Dratini](../pokemon/dratini.md) | Changed | Abilities, Level-up moves |
| [Dragonair](../pokemon/dragonair.md) | Changed | Abilities, Level-up moves |
| [Dragonite](../pokemon/dragonite.md) | Changed | Abilities, Level-up moves |
| [Mewtwo](../pokemon/mewtwo.md) | Changed | Abilities, Wild held items |
| [Mew](../pokemon/mew.md) | Changed | Abilities |
| [Chikorita](../pokemon/chikorita.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Bayleef](../pokemon/bayleef.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Meganium](../pokemon/meganium.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Cyndaquil](../pokemon/cyndaquil.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Quilava](../pokemon/quilava.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Typhlosion](../pokemon/typhlosion.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Totodile](../pokemon/totodile.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Croconaw](../pokemon/croconaw.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Feraligatr](../pokemon/feraligatr.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Sentret](../pokemon/sentret.md) | Changed | Abilities, Level-up moves |
| [Furret](../pokemon/furret.md) | Changed | Base stats, Abilities, Level-up moves |
| [Hoothoot](../pokemon/hoothoot.md) | Changed | Abilities, Level-up moves |
| [Noctowl](../pokemon/noctowl.md) | Changed | Base stats, Abilities, Level-up moves |
| [Ledyba](../pokemon/ledyba.md) | Changed | Base stats, Abilities |
| [Ledian](../pokemon/ledian.md) | Changed | Base stats, Abilities, Level-up moves |
| [Spinarak](../pokemon/spinarak.md) | Changed | Abilities, Level-up moves |
| [Ariados](../pokemon/ariados.md) | Changed | Base stats, Abilities, Level-up moves |
| [Crobat](../pokemon/crobat.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Chinchou](../pokemon/chinchou.md) | Changed | Abilities, Level-up moves |
| [Lanturn](../pokemon/lanturn.md) | Changed | Base stats, Abilities |
| [Pichu](../pokemon/pichu.md) | Changed | Abilities, Base friendship, Machines, Level-up moves |
| [Cleffa](../pokemon/cleffa.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Igglybuff](../pokemon/igglybuff.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Togepi](../pokemon/togepi.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Togetic](../pokemon/togetic.md) | Changed | Abilities, Level-up moves |
| [Natu](../pokemon/natu.md) | Changed | Abilities, Level-up moves |
| [Xatu](../pokemon/xatu.md) | Changed | Base stats, Abilities, Level-up moves |
| [Mareep](../pokemon/mareep.md) | Changed | Abilities, Level-up moves |
| [Flaaffy](../pokemon/flaaffy.md) | Changed | Abilities, Level-up moves |
| [Ampharos](../pokemon/ampharos.md) | Changed | Abilities, Machines, Level-up moves |
| [Bellossom](../pokemon/bellossom.md) | Changed | Base stats, Abilities, Level-up moves |
| [Marill](../pokemon/marill.md) | Changed | Base stats, Abilities, Level-up moves |
| [Azumarill](../pokemon/azumarill.md) | Changed | Base stats, Abilities, Level-up moves |
| [Sudowoodo](../pokemon/sudowoodo.md) | Changed | Base stats, Abilities, Level-up moves |
| [Politoed](../pokemon/politoed.md) | Changed | Abilities |
| [Hoppip](../pokemon/hoppip.md) | Changed | Abilities, Level-up moves |
| [Skiploom](../pokemon/skiploom.md) | Changed | Abilities, Level-up moves |
| [Jumpluff](../pokemon/jumpluff.md) | Changed | Abilities, Level-up moves |
| [Aipom](../pokemon/aipom.md) | Changed | Abilities, Level-up moves |
| [Sunkern](../pokemon/sunkern.md) | Changed | Abilities, Level-up moves |
| [Sunflora](../pokemon/sunflora.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Yanma](../pokemon/yanma.md) | Changed | Level-up moves |
| [Wooper](../pokemon/wooper.md) | Changed | Abilities, Level-up moves |
| [Quagsire](../pokemon/quagsire.md) | Changed | Base stats, Abilities, Level-up moves |
| [Espeon](../pokemon/espeon.md) | Changed | Abilities, Level-up moves |
| [Umbreon](../pokemon/umbreon.md) | Changed | Abilities, Machines, Level-up moves |
| [Murkrow](../pokemon/murkrow.md) | Changed | Abilities, Level-up moves |
| [Slowking](../pokemon/slowking.md) | Changed | Abilities, Level-up moves |
| [Misdreavus](../pokemon/misdreavus.md) | Changed | Level-up moves |
| [Unown](../pokemon/unown.md) | Changed | Base stats, Base experience, Level-up moves |
| [Wobbuffet](../pokemon/wobbuffet.md) | Changed | Abilities, Level-up moves |
| [Girafarig](../pokemon/girafarig.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Pineco](../pokemon/pineco.md) | Changed | Abilities, Level-up moves |
| [Forretress](../pokemon/forretress.md) | Changed | Abilities, Level-up moves |
| [Dunsparce](../pokemon/dunsparce.md) | Changed | Base stats, Abilities, Level-up moves |
| [Gligar](../pokemon/gligar.md) | Changed | Abilities |
| [Steelix](../pokemon/steelix.md) | Changed | Base stats, Abilities, Level-up moves |
| [Snubbull](../pokemon/snubbull.md) | Changed | Abilities, Level-up moves |
| [Granbull](../pokemon/granbull.md) | Changed | Base stats, Abilities, Level-up moves |
| [Qwilfish](../pokemon/qwilfish.md) | Changed | Base stats, Abilities, Level-up moves |
| [Scizor](../pokemon/scizor.md) | Changed | Level-up moves |
| [Shuckle](../pokemon/shuckle.md) | Changed | Abilities |
| [Heracross](../pokemon/heracross.md) | Changed | Abilities, Level-up moves |
| [Sneasel](../pokemon/sneasel.md) | Changed | Abilities, Machines, Level-up moves |
| [Teddiursa](../pokemon/teddiursa.md) | Changed | Abilities |
| [Ursaring](../pokemon/ursaring.md) | Changed | Abilities, Level-up moves |
| [Slugma](../pokemon/slugma.md) | Changed | Wild held items, Level-up moves |
| [Magcargo](../pokemon/magcargo.md) | Changed | Base stats, Abilities, Base experience, Wild held items, Level-up moves |
| [Swinub](../pokemon/swinub.md) | Changed | Abilities, Level-up moves |
| [Piloswine](../pokemon/piloswine.md) | Changed | Abilities, Level-up moves |
| [Corsola](../pokemon/corsola.md) | Changed | Base stats, Abilities, Base experience |
| [Remoraid](../pokemon/remoraid.md) | Changed | Abilities, Machines, Level-up moves |
| [Octillery](../pokemon/octillery.md) | Changed | Abilities, Machines, Level-up moves |
| [Delibird](../pokemon/delibird.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Mantine](../pokemon/mantine.md) | Changed | Machines, Level-up moves |
| [Skarmory](../pokemon/skarmory.md) | Changed | Abilities, Level-up moves |
| [Houndour](../pokemon/houndour.md) | Changed | Abilities, Level-up moves |
| [Houndoom](../pokemon/houndoom.md) | Changed | Abilities, Level-up moves |
| [Kingdra](../pokemon/kingdra.md) | Changed | Machines, Level-up moves |
| [Phanpy](../pokemon/phanpy.md) | Changed | Abilities, Level-up moves |
| [Donphan](../pokemon/donphan.md) | Changed | Abilities, Level-up moves |
| [Porygon2](../pokemon/porygon2.md) | Changed | Evolutions, Level-up moves |
| [Stantler](../pokemon/stantler.md) | Changed | Base stats, Abilities, Level-up moves |
| [Smeargle](../pokemon/smeargle.md) | Changed | Base stats, Abilities, Base experience |
| [Tyrogue](../pokemon/tyrogue.md) | Changed | Abilities |
| [Smoochum](../pokemon/smoochum.md) | Changed | Abilities, Level-up moves |
| [Elekid](../pokemon/elekid.md) | Changed | Abilities, Level-up moves |
| [Magby](../pokemon/magby.md) | Changed | Abilities, Level-up moves |
| [Miltank](../pokemon/miltank.md) | Changed | Base stats, Level-up moves |
| [Blissey](../pokemon/blissey.md) | Changed | Level-up moves |
| [Raikou](../pokemon/raikou.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Entei](../pokemon/entei.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Suicune](../pokemon/suicune.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Larvitar](../pokemon/larvitar.md) | Changed | Abilities, Level-up moves |
| [Pupitar](../pokemon/pupitar.md) | Changed | Abilities, Level-up moves |
| [Tyranitar](../pokemon/tyranitar.md) | Changed | Abilities, Level-up moves |
| [Lugia](../pokemon/lugia.md) | Changed | Abilities, Wild held items |
| [Ho-Oh](../pokemon/ho-oh.md) | Changed | Abilities |
| [Celebi](../pokemon/celebi.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Treecko](../pokemon/treecko.md) | Changed | Abilities, Wild held items |
| [Grovyle](../pokemon/grovyle.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Sceptile](../pokemon/sceptile.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Torchic](../pokemon/torchic.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Combusken](../pokemon/combusken.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Blaziken](../pokemon/blaziken.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Mudkip](../pokemon/mudkip.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Marshtomp](../pokemon/marshtomp.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Swampert](../pokemon/swampert.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Poochyena](../pokemon/poochyena.md) | Changed | Abilities |
| [Mightyena](../pokemon/mightyena.md) | Changed | Base stats, Abilities, Level-up moves |
| [Linoone](../pokemon/linoone.md) | Changed | Base stats, Abilities, Level-up moves |
| [Wurmple](../pokemon/wurmple.md) | Changed | Abilities, Level-up moves |
| [Silcoon](../pokemon/silcoon.md) | Changed | Abilities, Safari flee rate |
| [Beautifly](../pokemon/beautifly.md) | Changed | Base stats, Abilities, Level-up moves |
| [Cascoon](../pokemon/cascoon.md) | Changed | Abilities, Safari flee rate |
| [Dustox](../pokemon/dustox.md) | Changed | Base stats, Abilities, Level-up moves |
| [Lotad](../pokemon/lotad.md) | Changed | Level-up moves |
| [Lombre](../pokemon/lombre.md) | Changed | Level-up moves |
| [Ludicolo](../pokemon/ludicolo.md) | Changed | Level-up moves |
| [Seedot](../pokemon/seedot.md) | Changed | Abilities, Level-up moves |
| [Nuzleaf](../pokemon/nuzleaf.md) | Changed | Abilities, Level-up moves |
| [Shiftry](../pokemon/shiftry.md) | Changed | Abilities, Level-up moves |
| [Taillow](../pokemon/taillow.md) | Changed | Abilities, Machines, Level-up moves |
| [Swellow](../pokemon/swellow.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Wingull](../pokemon/wingull.md) | Changed | Abilities |
| [Pelipper](../pokemon/pelipper.md) | Changed | Base stats, Abilities, Level-up moves |
| [Ralts](../pokemon/ralts.md) | Changed | Base stats, Level-up moves |
| [Kirlia](../pokemon/kirlia.md) | Changed | Base stats, Level-up moves |
| [Gardevoir](../pokemon/gardevoir.md) | Changed | Level-up moves |
| [Surskit](../pokemon/surskit.md) | Changed | Abilities, Machines, Level-up moves |
| [Masquerain](../pokemon/masquerain.md) | Changed | Base stats, Types, Abilities, Base experience, Machines, Level-up moves |
| [Shroomish](../pokemon/shroomish.md) | Changed | Level-up moves |
| [Breloom](../pokemon/breloom.md) | Changed | Abilities, Level-up moves |
| [Slakoth](../pokemon/slakoth.md) | Changed | Abilities |
| [Vigoroth](../pokemon/vigoroth.md) | Changed | Base stats, Abilities, Level-up moves |
| [Slaking](../pokemon/slaking.md) | Changed | Abilities, Level-up moves |
| [Nincada](../pokemon/nincada.md) | Changed | Abilities, Level-up moves |
| [Ninjask](../pokemon/ninjask.md) | Changed | Abilities, Level-up moves |
| [Whismur](../pokemon/whismur.md) | Changed | Abilities, Level-up moves |
| [Loudred](../pokemon/loudred.md) | Changed | Abilities, Level-up moves |
| [Exploud](../pokemon/exploud.md) | Changed | Abilities, Level-up moves |
| [Makuhita](../pokemon/makuhita.md) | Changed | Abilities, Level-up moves |
| [Hariyama](../pokemon/hariyama.md) | Changed | Abilities, Level-up moves |
| [Azurill](../pokemon/azurill.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Nosepass](../pokemon/nosepass.md) | Changed | Level-up moves |
| [Skitty](../pokemon/skitty.md) | Changed | Abilities, Level-up moves |
| [Delcatty](../pokemon/delcatty.md) | Changed | Base stats, Abilities, Level-up moves |
| [Sableye](../pokemon/sableye.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Mawile](../pokemon/mawile.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Aggron](../pokemon/aggron.md) | Changed | Level-up moves |
| [Meditite](../pokemon/meditite.md) | Changed | Abilities, Level-up moves |
| [Medicham](../pokemon/medicham.md) | Changed | Abilities, Level-up moves |
| [Manectric](../pokemon/manectric.md) | Changed | Level-up moves |
| [Volbeat](../pokemon/volbeat.md) | Changed | Base stats, Types, Abilities, Base experience, Level-up moves |
| [Illumise](../pokemon/illumise.md) | Changed | Base stats, Types, Abilities, Base experience, Growth rate, Level-up moves |
| [Roselia](../pokemon/roselia.md) | Changed | Level-up moves |
| [Gulpin](../pokemon/gulpin.md) | Changed | Abilities |
| [Swalot](../pokemon/swalot.md) | Changed | Base stats, Abilities, Level-up moves |
| [Carvanha](../pokemon/carvanha.md) | Changed | Abilities, Level-up moves |
| [Sharpedo](../pokemon/sharpedo.md) | Changed | Abilities, Level-up moves |
| [Wailmer](../pokemon/wailmer.md) | Changed | Abilities, Level-up moves |
| [Wailord](../pokemon/wailord.md) | Changed | Abilities, Level-up moves |
| [Numel](../pokemon/numel.md) | Changed | Abilities |
| [Camerupt](../pokemon/camerupt.md) | Changed | Abilities, Level-up moves |
| [Torkoal](../pokemon/torkoal.md) | Changed | Base stats, Abilities, Level-up moves |
| [Spoink](../pokemon/spoink.md) | Changed | Level-up moves |
| [Grumpig](../pokemon/grumpig.md) | Changed | Level-up moves |
| [Spinda](../pokemon/spinda.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Trapinch](../pokemon/trapinch.md) | Changed | Abilities, Level-up moves |
| [Vibrava](../pokemon/vibrava.md) | Changed | Level-up moves |
| [Flygon](../pokemon/flygon.md) | Changed | Base stats, Base experience, Level-up moves |
| [Cacnea](../pokemon/cacnea.md) | Changed | Abilities, Level-up moves |
| [Cacturne](../pokemon/cacturne.md) | Changed | Abilities, Level-up moves |
| [Swablu](../pokemon/swablu.md) | Changed | Abilities, Machines, Level-up moves |
| [Altaria](../pokemon/altaria.md) | Changed | Base stats, Abilities, Base experience, Machines, Level-up moves |
| [Zangoose](../pokemon/zangoose.md) | Changed | Abilities, Level-up moves |
| [Seviper](../pokemon/seviper.md) | Changed | Abilities, Level-up moves |
| [Lunatone](../pokemon/lunatone.md) | Changed | Base stats, Level-up moves |
| [Solrock](../pokemon/solrock.md) | Changed | Base stats, Level-up moves |
| [Barboach](../pokemon/barboach.md) | Changed | Abilities, Level-up moves |
| [Whiscash](../pokemon/whiscash.md) | Changed | Base stats, Abilities, Level-up moves |
| [Corphish](../pokemon/corphish.md) | Changed | Abilities |
| [Crawdaunt](../pokemon/crawdaunt.md) | Changed | Abilities |
| [Claydol](../pokemon/claydol.md) | Changed | Wild held items, Machines, Level-up moves |
| [Lileep](../pokemon/lileep.md) | Changed | Abilities, Level-up moves |
| [Cradily](../pokemon/cradily.md) | Changed | Abilities, Level-up moves |
| [Anorith](../pokemon/anorith.md) | Changed | Abilities |
| [Armaldo](../pokemon/armaldo.md) | Changed | Abilities, Level-up moves |
| [Feebas](../pokemon/feebas.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Milotic](../pokemon/milotic.md) | Changed | Abilities, Level-up moves |
| [Castform](../pokemon/castform.md) | Changed | Base stats, Base experience |
| [Kecleon](../pokemon/kecleon.md) | Changed | Base stats, Level-up moves |
| [Shuppet](../pokemon/shuppet.md) | Changed | Abilities, Level-up moves |
| [Banette](../pokemon/banette.md) | Changed | Base stats, Abilities, Level-up moves |
| [Duskull](../pokemon/duskull.md) | Changed | Abilities, Level-up moves |
| [Dusclops](../pokemon/dusclops.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Tropius](../pokemon/tropius.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Chimecho](../pokemon/chimecho.md) | Changed | Base stats, Base experience, Level-up moves |
| [Absol](../pokemon/absol.md) | Changed | Abilities, Level-up moves |
| [Wynaut](../pokemon/wynaut.md) | Changed | Abilities |
| [Snorunt](../pokemon/snorunt.md) | Changed | Abilities |
| [Glalie](../pokemon/glalie.md) | Changed | Base stats, Types, Abilities, Base experience, Machines, Level-up moves |
| [Walrein](../pokemon/walrein.md) | Changed | Level-up moves |
| [Clamperl](../pokemon/clamperl.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Huntail](../pokemon/huntail.md) | Changed | Abilities |
| [Gorebyss](../pokemon/gorebyss.md) | Changed | Abilities |
| [Relicanth](../pokemon/relicanth.md) | Changed | Abilities, Level-up moves |
| [Luvdisc](../pokemon/luvdisc.md) | Changed | Base stats, Abilities, Base experience, Wild held items |
| [Bagon](../pokemon/bagon.md) | Changed | Abilities, Level-up moves |
| [Shelgon](../pokemon/shelgon.md) | Changed | Abilities, Level-up moves |
| [Salamence](../pokemon/salamence.md) | Changed | Abilities, Level-up moves |
| [Beldum](../pokemon/beldum.md) | Changed | Abilities, Level-up moves |
| [Metang](../pokemon/metang.md) | Changed | Abilities |
| [Metagross](../pokemon/metagross.md) | Changed | Abilities, Machines, Level-up moves |
| [Regirock](../pokemon/regirock.md) | Changed | Abilities |
| [Regice](../pokemon/regice.md) | Changed | Abilities |
| [Registeel](../pokemon/registeel.md) | Changed | Abilities |
| [Jirachi](../pokemon/jirachi.md) | Changed | Abilities |
| [Turtwig](../pokemon/turtwig.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Grotle](../pokemon/grotle.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Torterra](../pokemon/torterra.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Chimchar](../pokemon/chimchar.md) | Changed | Abilities, Wild held items |
| [Monferno](../pokemon/monferno.md) | Changed | Abilities, Wild held items |
| [Infernape](../pokemon/infernape.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Piplup](../pokemon/piplup.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Prinplup](../pokemon/prinplup.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Empoleon](../pokemon/empoleon.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Starly](../pokemon/starly.md) | Changed | Abilities, Machines, Level-up moves |
| [Staravia](../pokemon/staravia.md) | Changed | Abilities, Machines, Level-up moves |
| [Staraptor](../pokemon/staraptor.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Bidoof](../pokemon/bidoof.md) | Changed | Abilities, Level-up moves |
| [Bibarel](../pokemon/bibarel.md) | Changed | Base stats, Abilities, Level-up moves |
| [Kricketot](../pokemon/kricketot.md) | Changed | Abilities, Level-up moves |
| [Kricketune](../pokemon/kricketune.md) | Changed | Base stats, Abilities, Base experience |
| [Shinx](../pokemon/shinx.md) | Changed | Abilities, Level-up moves |
| [Luxio](../pokemon/luxio.md) | Changed | Types, Abilities, Level-up moves |
| [Luxray](../pokemon/luxray.md) | Changed | Base stats, Types, Abilities, Level-up moves |
| [Budew](../pokemon/budew.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Roserade](../pokemon/roserade.md) | Changed | Base stats, Abilities, Level-up moves |
| [Cranidos](../pokemon/cranidos.md) | Changed | Abilities, Level-up moves |
| [Rampardos](../pokemon/rampardos.md) | Changed | Abilities, Level-up moves |
| [Shieldon](../pokemon/shieldon.md) | Changed | Abilities |
| [Bastiodon](../pokemon/bastiodon.md) | Changed | Abilities, Level-up moves |
| [Burmy](../pokemon/burmy.md) | Changed | Abilities, Level-up moves |
| [Wormadam](../pokemon/wormadam-plant.md) | Changed | Base stats, Abilities |
| [Mothim](../pokemon/mothim.md) | Changed | Base stats, Abilities, Level-up moves |
| [Combee](../pokemon/combee.md) | Changed | Abilities, Level-up moves |
| [Vespiquen](../pokemon/vespiquen.md) | Changed | Abilities, Level-up moves |
| [Pachirisu](../pokemon/pachirisu.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Buizel](../pokemon/buizel.md) | Changed | Abilities, Level-up moves |
| [Floatzel](../pokemon/floatzel.md) | Changed | Abilities, Level-up moves |
| [Cherubi](../pokemon/cherubi.md) | Changed | Abilities |
| [Cherrim](../pokemon/cherrim.md) | Changed | Base stats, Abilities, Level-up moves |
| [Shellos](../pokemon/shellos.md) | Changed | Level-up moves |
| [Gastrodon](../pokemon/gastrodon.md) | Changed | Level-up moves |
| [Ambipom](../pokemon/ambipom.md) | Changed | Level-up moves |
| [Drifloon](../pokemon/drifloon.md) | Changed | Abilities, Level-up moves |
| [Drifblim](../pokemon/drifblim.md) | Changed | Abilities, Level-up moves |
| [Buneary](../pokemon/buneary.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Lopunny](../pokemon/lopunny.md) | Changed | Abilities, Level-up moves |
| [Mismagius](../pokemon/mismagius.md) | Changed | Base stats, Base experience, Level-up moves |
| [Honchkrow](../pokemon/honchkrow.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Glameow](../pokemon/glameow.md) | Changed | Level-up moves |
| [Purugly](../pokemon/purugly.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Chingling](../pokemon/chingling.md) | Changed | Base friendship, Level-up moves |
| [Stunky](../pokemon/stunky.md) | Changed | Level-up moves |
| [Skuntank](../pokemon/skuntank.md) | Changed | Level-up moves |
| [Bronzor](../pokemon/bronzor.md) | Changed | Level-up moves |
| [Bronzong](../pokemon/bronzong.md) | Changed | Machines, Level-up moves |
| [Bonsly](../pokemon/bonsly.md) | Changed | Abilities |
| [Mime Jr.](../pokemon/mime-jr.md) | Changed | Abilities, Level-up moves |
| [Happiny](../pokemon/happiny.md) | Changed | Abilities, Base friendship, Evolutions, Level-up moves |
| [Chatot](../pokemon/chatot.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Spiritomb](../pokemon/spiritomb.md) | Changed | Abilities, Level-up moves |
| [Gible](../pokemon/gible.md) | Changed | Abilities, Level-up moves |
| [Gabite](../pokemon/gabite.md) | Changed | Abilities, Level-up moves |
| [Garchomp](../pokemon/garchomp.md) | Changed | Abilities, Machines, Level-up moves |
| [Munchlax](../pokemon/munchlax.md) | Changed | Base friendship, Level-up moves |
| [Riolu](../pokemon/riolu.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Lucario](../pokemon/lucario.md) | Changed | Abilities, Level-up moves |
| [Hippopotas](../pokemon/hippopotas.md) | Changed | Abilities, Level-up moves |
| [Hippowdon](../pokemon/hippowdon.md) | Changed | Abilities, Level-up moves |
| [Drapion](../pokemon/drapion.md) | Changed | Level-up moves |
| [Croagunk](../pokemon/croagunk.md) | Changed | Abilities, Level-up moves |
| [Toxicroak](../pokemon/toxicroak.md) | Changed | Abilities, Level-up moves |
| [Carnivine](../pokemon/carnivine.md) | Changed | Base stats, Level-up moves |
| [Lumineon](../pokemon/lumineon.md) | Changed | Base stats, Level-up moves |
| [Mantyke](../pokemon/mantyke.md) | Changed | Level-up moves |
| [Snover](../pokemon/snover.md) | Changed | Abilities, Level-up moves |
| [Abomasnow](../pokemon/abomasnow.md) | Changed | Abilities, Level-up moves |
| [Weavile](../pokemon/weavile.md) | Changed | Abilities, Machines, Level-up moves |
| [Magnezone](../pokemon/magnezone.md) | Changed | Abilities, Level-up moves |
| [Lickilicky](../pokemon/lickilicky.md) | Changed | Abilities, Level-up moves |
| [Rhyperior](../pokemon/rhyperior.md) | Changed | Abilities, Level-up moves |
| [Tangrowth](../pokemon/tangrowth.md) | Changed | Abilities, Level-up moves |
| [Electivire](../pokemon/electivire.md) | Changed | Types, Abilities, Level-up moves |
| [Magmortar](../pokemon/magmortar.md) | Changed | Abilities, Level-up moves |
| [Togekiss](../pokemon/togekiss.md) | Changed | Abilities, Level-up moves |
| [Yanmega](../pokemon/yanmega.md) | Changed | Machines, Level-up moves |
| [Leafeon](../pokemon/leafeon.md) | Changed | Abilities, Level-up moves |
| [Glaceon](../pokemon/glaceon.md) | Changed | Abilities, Machines, Level-up moves |
| [Gliscor](../pokemon/gliscor.md) | Changed | Abilities, Machines |
| [Mamoswine](../pokemon/mamoswine.md) | Changed | Abilities, Level-up moves |
| [Porygon-Z](../pokemon/porygon-z.md) | Changed | Level-up moves |
| [Gallade](../pokemon/gallade.md) | Changed | Abilities, Level-up moves |
| [Probopass](../pokemon/probopass.md) | Changed | Level-up moves |
| [Dusknoir](../pokemon/dusknoir.md) | Changed | Abilities, Level-up moves |
| [Froslass](../pokemon/froslass.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Rotom](../pokemon/rotom.md) | Changed | Base stats, Abilities, Level-up moves |
| [Dialga](../pokemon/dialga.md) | Changed | Abilities |
| [Palkia](../pokemon/palkia.md) | Changed | Abilities |
| [Heatran](../pokemon/heatran.md) | Changed | Abilities |
| [Regigigas](../pokemon/regigigas.md) | Changed | Abilities |
| [Giratina](../pokemon/giratina-altered.md) | Changed | Abilities |
| [Phione](../pokemon/phione.md) | Changed | Base stats, Abilities, Base experience |
| [Manaphy](../pokemon/manaphy.md) | Changed | Abilities, Wild held items |
| [Shaymin](../pokemon/shaymin-land.md) | Changed | Wild held items |
| [Arceus](../pokemon/arceus.md) | Changed | Base experience, Wild held items |
| [Victini](../pokemon/victini.md) | Changed | Level-up moves |
| [Snivy](../pokemon/snivy.md) | Changed | Abilities, Base experience, Wild held items, Base friendship |
| [Servine](../pokemon/servine.md) | Changed | Abilities, Wild held items, Base friendship, Level-up moves |
| [Serperior](../pokemon/serperior.md) | Changed | Base stats, Types, Abilities, Wild held items, Base friendship, Machines, Level-up moves |
| [Tepig](../pokemon/tepig.md) | Changed | Abilities, Base experience, Wild held items |
| [Pignite](../pokemon/pignite.md) | Changed | Types, Abilities, Wild held items, Level-up moves |
| [Emboar](../pokemon/emboar.md) | Changed | Base stats, Types, Abilities, Wild held items, Level-up moves |
| [Oshawott](../pokemon/oshawott.md) | Changed | Abilities, Base experience, Wild held items |
| [Dewott](../pokemon/dewott.md) | Changed | Types, Abilities, Wild held items, Level-up moves |
| [Samurott](../pokemon/samurott.md) | Changed | Base stats, Types, Abilities, Wild held items, Machines, Level-up moves |
| [Patrat](../pokemon/patrat.md) | Changed | Abilities, Level-up moves |
| [Watchog](../pokemon/watchog.md) | Changed | Base stats, Abilities, Level-up moves |
| [Herdier](../pokemon/herdier.md) | Changed | Abilities |
| [Stoutland](../pokemon/stoutland.md) | Changed | Base stats, Abilities |
| [Purrloin](../pokemon/purrloin.md) | Changed | Abilities, Level-up moves |
| [Liepard](../pokemon/liepard.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Pansage](../pokemon/pansage.md) | Changed | Abilities, Level-up moves |
| [Simisage](../pokemon/simisage.md) | Changed | Abilities, Level-up moves |
| [Pansear](../pokemon/pansear.md) | Changed | Abilities, Level-up moves |
| [Simisear](../pokemon/simisear.md) | Changed | Abilities, Level-up moves |
| [Panpour](../pokemon/panpour.md) | Changed | Abilities, Level-up moves |
| [Simipour](../pokemon/simipour.md) | Changed | Abilities, Level-up moves |
| [Munna](../pokemon/munna.md) | Changed | Abilities, Level-up moves |
| [Musharna](../pokemon/musharna.md) | Changed | Abilities, Level-up moves |
| [Pidove](../pokemon/pidove.md) | Changed | Base stats, Abilities, Level-up moves |
| [Tranquill](../pokemon/tranquill.md) | Changed | Base stats, Abilities, Level-up moves |
| [Unfezant](../pokemon/unfezant.md) | Changed | Base stats, Abilities, Level-up moves |
| [Blitzle](../pokemon/blitzle.md) | Changed | Abilities, Level-up moves |
| [Zebstrika](../pokemon/zebstrika.md) | Changed | Abilities, Level-up moves |
| [Roggenrola](../pokemon/roggenrola.md) | Changed | Abilities, Level-up moves |
| [Boldore](../pokemon/boldore.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Gigalith](../pokemon/gigalith.md) | Changed | Abilities, Level-up moves |
| [Woobat](../pokemon/woobat.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Swoobat](../pokemon/swoobat.md) | Changed | Base stats, Abilities, Base experience, Base friendship, Level-up moves |
| [Drilbur](../pokemon/drilbur.md) | Changed | Abilities |
| [Excadrill](../pokemon/excadrill.md) | Changed | Abilities, Level-up moves |
| [Audino](../pokemon/audino.md) | Changed | Abilities, Base experience, Level-up moves |
| [Timburr](../pokemon/timburr.md) | Changed | Abilities, Level-up moves |
| [Gurdurr](../pokemon/gurdurr.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Conkeldurr](../pokemon/conkeldurr.md) | Changed | Abilities, Level-up moves |
| [Tympole](../pokemon/tympole.md) | Changed | Abilities, Machines, Level-up moves |
| [Palpitoad](../pokemon/palpitoad.md) | Changed | Abilities, Machines, Level-up moves |
| [Seismitoad](../pokemon/seismitoad.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Throh](../pokemon/throh.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Sawk](../pokemon/sawk.md) | Changed | Abilities, Wild held items, Level-up moves |
| [Sewaddle](../pokemon/sewaddle.md) | Changed | Base friendship |
| [Swadloon](../pokemon/swadloon.md) | Changed | Abilities, Base friendship, Level-up moves |
| [Leavanny](../pokemon/leavanny.md) | Changed | Base friendship, Level-up moves |
| [Venipede](../pokemon/venipede.md) | Changed | Level-up moves |
| [Whirlipede](../pokemon/whirlipede.md) | Changed | Abilities, Level-up moves |
| [Scolipede](../pokemon/scolipede.md) | Changed | Abilities, Level-up moves |
| [Whimsicott](../pokemon/whimsicott.md) | Changed | Level-up moves |
| [Petilil](../pokemon/petilil.md) | Changed | Abilities, Machines, Level-up moves |
| [Lilligant](../pokemon/lilligant.md) | Changed | Machines, Level-up moves |
| [Basculin](../pokemon/basculin-red-striped.md) | Changed | Base stats, Level-up moves |
| [Sandile](../pokemon/sandile.md) | Changed | Abilities, Level-up moves |
| [Krokorok](../pokemon/krokorok.md) | Changed | Abilities, Level-up moves |
| [Krookodile](../pokemon/krookodile.md) | Changed | Level-up moves |
| [Darumaka](../pokemon/darumaka.md) | Changed | Abilities, Level-up moves |
| [Darmanitan](../pokemon/darmanitan-standard.md) | Changed | Abilities, Level-up moves |
| [Maractus](../pokemon/maractus.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Dwebble](../pokemon/dwebble.md) | Changed | Level-up moves |
| [Crustle](../pokemon/crustle.md) | Changed | Level-up moves |
| [Scraggy](../pokemon/scraggy.md) | Changed | Evolutions, Level-up moves |
| [Scrafty](../pokemon/scrafty.md) | Changed | Level-up moves |
| [Sigilyph](../pokemon/sigilyph.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Yamask](../pokemon/yamask.md) | Changed | Level-up moves |
| [Cofagrigus](../pokemon/cofagrigus.md) | Changed | Types, Machines, Level-up moves |
| [Archen](../pokemon/archen.md) | Changed | Level-up moves |
| [Archeops](../pokemon/archeops.md) | Changed | Level-up moves |
| [Trubbish](../pokemon/trubbish.md) | Changed | Level-up moves |
| [Garbodor](../pokemon/garbodor.md) | Changed | Base stats, Abilities, Level-up moves |
| [Zoroark](../pokemon/zoroark.md) | Changed | Level-up moves |
| [Minccino](../pokemon/minccino.md) | Changed | Abilities, Level-up moves |
| [Cinccino](../pokemon/cinccino.md) | Changed | Base stats, Abilities, Level-up moves |
| [Gothita](../pokemon/gothita.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Gothorita](../pokemon/gothorita.md) | Changed | Types, Abilities, Machines, Level-up moves |
| [Gothitelle](../pokemon/gothitelle.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Solosis](../pokemon/solosis.md) | Changed | Abilities, Level-up moves |
| [Duosion](../pokemon/duosion.md) | Changed | Abilities, Level-up moves |
| [Reuniclus](../pokemon/reuniclus.md) | Changed | Base stats, Abilities, Level-up moves |
| [Ducklett](../pokemon/ducklett.md) | Changed | Abilities |
| [Swanna](../pokemon/swanna.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Vanillite](../pokemon/vanillite.md) | Changed | Abilities, Machines, Level-up moves |
| [Vanillish](../pokemon/vanillish.md) | Changed | Abilities, Machines, Level-up moves |
| [Vanilluxe](../pokemon/vanilluxe.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Deerling](../pokemon/deerling.md) | Changed | Abilities |
| [Sawsbuck](../pokemon/sawsbuck.md) | Changed | Base stats, Abilities, Level-up moves |
| [Emolga](../pokemon/emolga.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Karrablast](../pokemon/karrablast.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Escavalier](../pokemon/escavalier.md) | Changed | Abilities, Machines, Level-up moves |
| [Foongus](../pokemon/foongus.md) | Changed | Abilities, Level-up moves |
| [Amoonguss](../pokemon/amoonguss.md) | Changed | Abilities, Level-up moves |
| [Frillish](../pokemon/frillish-male.md) | Changed | Level-up moves |
| [Jellicent](../pokemon/jellicent-male.md) | Changed | Level-up moves |
| [Alomomola](../pokemon/alomomola.md) | Changed | Base stats, Abilities, Level-up moves |
| [Joltik](../pokemon/joltik.md) | Changed | Abilities |
| [Galvantula](../pokemon/galvantula.md) | Changed | Base stats, Abilities |
| [Ferroseed](../pokemon/ferroseed.md) | Changed | Level-up moves |
| [Ferrothorn](../pokemon/ferrothorn.md) | Changed | Level-up moves |
| [Klink](../pokemon/klink.md) | Changed | Abilities, Machines, Level-up moves |
| [Klang](../pokemon/klang.md) | Changed | Abilities, Machines, Level-up moves |
| [Klinklang](../pokemon/klinklang.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Eelektross](../pokemon/eelektross.md) | Changed | Level-up moves |
| [Elgyem](../pokemon/elgyem.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Beheeyem](../pokemon/beheeyem.md) | Changed | Base stats, Abilities, Level-up moves |
| [Litwick](../pokemon/litwick.md) | Changed | Evolutions |
| [Lampent](../pokemon/lampent.md) | Changed | Abilities, Level-up moves |
| [Chandelure](../pokemon/chandelure.md) | Changed | Abilities |
| [Haxorus](../pokemon/haxorus.md) | Changed | Level-up moves |
| [Cubchoo](../pokemon/cubchoo.md) | Changed | Abilities, Level-up moves |
| [Beartic](../pokemon/beartic.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Cryogonal](../pokemon/cryogonal.md) | Changed | Base stats |
| [Shelmet](../pokemon/shelmet.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Accelgor](../pokemon/accelgor.md) | Changed | Abilities, Level-up moves |
| [Stunfisk](../pokemon/stunfisk.md) | Changed | Base stats, Level-up moves |
| [Mienfoo](../pokemon/mienfoo.md) | Changed | Abilities, Evolutions |
| [Mienshao](../pokemon/mienshao.md) | Changed | Abilities, Level-up moves |
| [Druddigon](../pokemon/druddigon.md) | Changed | Machines, Level-up moves |
| [Golett](../pokemon/golett.md) | Changed | Evolutions |
| [Golurk](../pokemon/golurk.md) | Changed | Base stats, Abilities, Level-up moves |
| [Pawniard](../pokemon/pawniard.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Bisharp](../pokemon/bisharp.md) | Changed | Base stats, Abilities, Level-up moves |
| [Bouffalant](../pokemon/bouffalant.md) | Changed | Level-up moves |
| [Rufflet](../pokemon/rufflet.md) | Changed | Abilities, Evolutions |
| [Braviary](../pokemon/braviary.md) | Changed | Abilities, Level-up moves |
| [Vullaby](../pokemon/vullaby.md) | Changed | Evolutions |
| [Mandibuzz](../pokemon/mandibuzz.md) | Changed | Level-up moves |
| [Heatmor](../pokemon/heatmor.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Durant](../pokemon/durant.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Deino](../pokemon/deino.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Zweilous](../pokemon/zweilous.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Hydreigon](../pokemon/hydreigon.md) | Changed | Abilities, Level-up moves |
| [Larvesta](../pokemon/larvesta.md) | Changed | Abilities, Evolutions |
| [Volcarona](../pokemon/volcarona.md) | Changed | Abilities, Machines, Level-up moves |
| [Cobalion](../pokemon/cobalion.md) | Changed | Level-up moves |
| [Terrakion](../pokemon/terrakion.md) | Changed | Level-up moves |
| [Virizion](../pokemon/virizion.md) | Changed | Level-up moves |
| [Tornadus](../pokemon/tornadus-incarnate.md) | Changed | Abilities |
| [Thundurus](../pokemon/thundurus-incarnate.md) | Changed | Abilities |
| [Reshiram](../pokemon/reshiram.md) | Changed | Machines, Level-up moves |
| [Zekrom](../pokemon/zekrom.md) | Changed | Machines, Level-up moves |
| [Landorus](../pokemon/landorus-incarnate.md) | Changed | Abilities |
| [Kyurem](../pokemon/kyurem.md) | Changed | Abilities, Machines, Level-up moves |
| [Keldeo](../pokemon/keldeo-ordinary.md) | Changed | Machines, Level-up moves |
| [Meloetta](../pokemon/meloetta-aria.md) | Changed | Abilities, Level-up moves |
| [Wormadam Sandy](../pokemon/wormadam-sandy.md) | Changed | Base stats, Abilities |
| [Wormadam Trash](../pokemon/wormadam-trash.md) | Changed | Base stats, Abilities |
| [Giratina Origin](../pokemon/giratina-origin.md) | Changed | Abilities |
| [Rotom Heat](../pokemon/rotom-heat.md) | Changed | Abilities, Level-up moves |
| [Rotom Wash](../pokemon/rotom-wash.md) | Changed | Abilities, Level-up moves |
| [Rotom Frost](../pokemon/rotom-frost.md) | Changed | Abilities, Level-up moves |
| [Rotom Fan](../pokemon/rotom-fan.md) | Changed | Abilities, Level-up moves |
| [Rotom Mow](../pokemon/rotom-mow.md) | Changed | Abilities, Level-up moves |
| Castform Sunny Form | Changed | Base stats |
| Castform Rainy Form | Changed | Base stats |
| Castform Snowy Form | Changed | Base stats |
| [Basculin Blue Striped](../pokemon/basculin-blue-striped.md) | Changed | Base stats, Level-up moves |

## Abilities

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Stench](../abilities/stench.md) | Changed | Pokémon |
| [Drizzle](../abilities/drizzle.md) | Changed | Pokémon |
| [Speed Boost](../abilities/speed-boost.md) | Changed | Pokémon |
| [Battle Armor](../abilities/battle-armor.md) | Changed | Pokémon |
| [Sturdy](../abilities/sturdy.md) | Changed | Pokémon |
| [Damp](../abilities/damp.md) | Changed | Pokémon |
| [Limber](../abilities/limber.md) | Changed | Pokémon |
| [Sand Veil](../abilities/sand-veil.md) | Changed | Pokémon |
| [Volt Absorb](../abilities/volt-absorb.md) | Changed | Pokémon |
| [Water Absorb](../abilities/water-absorb.md) | Changed | Pokémon |
| [Oblivious](../abilities/oblivious.md) | Changed | Pokémon |
| [Cloud Nine](../abilities/cloud-nine.md) | Changed | Pokémon |
| [Compoundeyes](../abilities/compound-eyes.md) | Changed | Pokémon |
| [Insomnia](../abilities/insomnia.md) | Changed | Pokémon |
| [Immunity](../abilities/immunity.md) | Changed | Pokémon |
| [Flash Fire](../abilities/flash-fire.md) | Changed | Pokémon |
| [Shield Dust](../abilities/shield-dust.md) | Changed | Pokémon |
| [Own Tempo](../abilities/own-tempo.md) | Changed | Pokémon |
| [Suction Cups](../abilities/suction-cups.md) | Changed | Pokémon |
| [Intimidate](../abilities/intimidate.md) | Changed | Pokémon |
| [Shadow Tag](../abilities/shadow-tag.md) | Changed | Pokémon |
| [Rough Skin](../abilities/rough-skin.md) | Changed | Pokémon |
| [Levitate](../abilities/levitate.md) | Changed | Pokémon |
| [Effect Spore](../abilities/effect-spore.md) | Changed | Pokémon |
| [Synchronize](../abilities/synchronize.md) | Changed | Pokémon |
| [Clear Body](../abilities/clear-body.md) | Changed | Pokémon |
| [Natural Cure](../abilities/natural-cure.md) | Changed | Pokémon |
| [Lightningrod](../abilities/lightning-rod.md) | Changed | Pokémon |
| [Serene Grace](../abilities/serene-grace.md) | Changed | Pokémon |
| [Swift Swim](../abilities/swift-swim.md) | Changed | Pokémon |
| [Chlorophyll](../abilities/chlorophyll.md) | Changed | Pokémon |
| [Illuminate](../abilities/illuminate.md) | Changed | Pokémon |
| [Trace](../abilities/trace.md) | Changed | Pokémon |
| [Poison Point](../abilities/poison-point.md) | Changed | Pokémon |
| [Inner Focus](../abilities/inner-focus.md) | Changed | Pokémon |
| [Magma Armor](../abilities/magma-armor.md) | Changed | Pokémon |
| [Water Veil](../abilities/water-veil.md) | Changed | Pokémon |
| [Soundproof](../abilities/soundproof.md) | Changed | Pokémon |
| [Rain Dish](../abilities/rain-dish.md) | Changed | Pokémon |
| [Pressure](../abilities/pressure.md) | Changed | Pokémon |
| [Thick Fat](../abilities/thick-fat.md) | Changed | Pokémon |
| [Early Bird](../abilities/early-bird.md) | Changed | Pokémon |
| [Flame Body](../abilities/flame-body.md) | Changed | Pokémon |
| [Run Away](../abilities/run-away.md) | Changed | Pokémon |
| [Keen Eye](../abilities/keen-eye.md) | Changed | Pokémon |
| [Hyper Cutter](../abilities/hyper-cutter.md) | Changed | Pokémon |
| [Hustle](../abilities/hustle.md) | Changed | Pokémon |
| [Cute Charm](../abilities/cute-charm.md) | Changed | Pokémon |
| [Plus](../abilities/plus.md) | Changed | Pokémon |
| [Minus](../abilities/minus.md) | Changed | Pokémon |
| [Sticky Hold](../abilities/sticky-hold.md) | Changed | Pokémon |
| [Shed Skin](../abilities/shed-skin.md) | Changed | Pokémon |
| [Guts](../abilities/guts.md) | Changed | Pokémon |
| [Marvel Scale](../abilities/marvel-scale.md) | Changed | Pokémon |
| [Overgrow](../abilities/overgrow.md) | Changed | Pokémon |
| [Blaze](../abilities/blaze.md) | Changed | Pokémon |
| [Torrent](../abilities/torrent.md) | Changed | Pokémon |
| [Swarm](../abilities/swarm.md) | Changed | Pokémon |
| [Rock Head](../abilities/rock-head.md) | Changed | Pokémon |
| [Drought](../abilities/drought.md) | Changed | Pokémon |
| [Arena Trap](../abilities/arena-trap.md) | Changed | Pokémon |
| [Vital Spirit](../abilities/vital-spirit.md) | Changed | Pokémon |
| [White Smoke](../abilities/white-smoke.md) | Changed | Pokémon |
| [Shell Armor](../abilities/shell-armor.md) | Changed | Pokémon |
| [Tangled Feet](../abilities/tangled-feet.md) | Changed | Pokémon |
| [Motor Drive](../abilities/motor-drive.md) | Changed | Pokémon |
| [Rivalry](../abilities/rivalry.md) | Changed | Pokémon |
| [Steadfast](../abilities/steadfast.md) | Changed | Pokémon |
| [Snow Cloak](../abilities/snow-cloak.md) | Changed | Pokémon |
| [Gluttony](../abilities/gluttony.md) | Changed | Pokémon |
| [Anger Point](../abilities/anger-point.md) | Changed | Pokémon |
| [Unburden](../abilities/unburden.md) | Changed | Pokémon |
| [Heatproof](../abilities/heatproof.md) | Changed | Pokémon |
| [Simple](../abilities/simple.md) | Changed | Pokémon |
| [Dry Skin](../abilities/dry-skin.md) | Changed | Pokémon |
| [Iron Fist](../abilities/iron-fist.md) | Changed | Pokémon |
| [Poison Heal](../abilities/poison-heal.md) | Changed | Pokémon |
| [Adaptability](../abilities/adaptability.md) | Changed | Pokémon |
| [Skill Link](../abilities/skill-link.md) | Changed | Pokémon |
| [Hydration](../abilities/hydration.md) | Changed | Pokémon |
| [Solar Power](../abilities/solar-power.md) | Changed | Pokémon |
| [Quick Feet](../abilities/quick-feet.md) | Changed | Pokémon |
| [Normalize](../abilities/normalize.md) | Changed | Pokémon |
| [Sniper](../abilities/sniper.md) | Changed | Pokémon |
| [Magic Guard](../abilities/magic-guard.md) | Changed | Pokémon |
| [No Guard](../abilities/no-guard.md) | Changed | Pokémon |
| [Stall](../abilities/stall.md) | Changed | Pokémon |
| [Technician](../abilities/technician.md) | Changed | Pokémon |
| [Leaf Guard](../abilities/leaf-guard.md) | Changed | Pokémon |
| [Klutz](../abilities/klutz.md) | Changed | Pokémon |
| [Mold Breaker](../abilities/mold-breaker.md) | Changed | Pokémon |
| [Super Luck](../abilities/super-luck.md) | Changed | Pokémon |
| [Aftermath](../abilities/aftermath.md) | Changed | Pokémon |
| [Anticipation](../abilities/anticipation.md) | Changed | Pokémon |
| [Forewarn](../abilities/forewarn.md) | Changed | Pokémon |
| [Unaware](../abilities/unaware.md) | Changed | Pokémon |
| [Tinted Lens](../abilities/tinted-lens.md) | Changed | Pokémon |
| [Slow Start](../abilities/slow-start.md) | Changed | Pokémon |
| [Scrappy](../abilities/scrappy.md) | Changed | Pokémon |
| [Storm Drain](../abilities/storm-drain.md) | Changed | Pokémon |
| [Ice Body](../abilities/ice-body.md) | Changed | Pokémon |
| [Solid Rock](../abilities/solid-rock.md) | Changed | Pokémon |
| [Snow Warning](../abilities/snow-warning.md) | Changed | Pokémon |
| [Honey Gather](../abilities/honey-gather.md) | Changed | Pokémon |
| [Frisk](../abilities/frisk.md) | Changed | Pokémon |
| [Reckless](../abilities/reckless.md) | Changed | Pokémon |
| [Flower Gift](../abilities/flower-gift.md) | Changed | Pokémon |
| [Pickpocket](../abilities/pickpocket.md) | Changed | Pokémon |
| [Sheer Force](../abilities/sheer-force.md) | Changed | Pokémon |
| [Contrary](../abilities/contrary.md) | Changed | Pokémon |
| [Unnerve](../abilities/unnerve.md) | Changed | Pokémon |
| [Defiant](../abilities/defiant.md) | Changed | Pokémon |
| [Cursed Body](../abilities/cursed-body.md) | Changed | Pokémon |
| [Healer](../abilities/healer.md) | Changed | Pokémon |
| [Friend Guard](../abilities/friend-guard.md) | Changed | Pokémon |
| [Weak Armor](../abilities/weak-armor.md) | Changed | Pokémon |
| [Light Metal](../abilities/light-metal.md) | Changed | Pokémon |
| [Multiscale](../abilities/multiscale.md) | Changed | Pokémon |
| [Toxic Boost](../abilities/toxic-boost.md) | Changed | Pokémon |
| [Flare Boost](../abilities/flare-boost.md) | Changed | Pokémon |
| [Harvest](../abilities/harvest.md) | Changed | Pokémon |
| [Telepathy](../abilities/telepathy.md) | Changed | Pokémon |
| [Moody](../abilities/moody.md) | Changed | Pokémon |
| [Overcoat](../abilities/overcoat.md) | Changed | Pokémon |
| [Poison Touch](../abilities/poison-touch.md) | Changed | Pokémon |
| [Regenerator](../abilities/regenerator.md) | Changed | Pokémon |
| [Big Pecks](../abilities/big-pecks.md) | Changed | Pokémon |
| [Sand Rush](../abilities/sand-rush.md) | Changed | Pokémon |
| [Wonder Skin](../abilities/wonder-skin.md) | Changed | Pokémon |
| [Analytic](../abilities/analytic.md) | Changed | Pokémon |
| [Imposter](../abilities/imposter.md) | Changed | Pokémon |
| [Infiltrator](../abilities/infiltrator.md) | Changed | Pokémon |
| [Moxie](../abilities/moxie.md) | Changed | Pokémon |
| [Justified](../abilities/justified.md) | Changed | Pokémon |
| [Rattled](../abilities/rattled.md) | Changed | Pokémon |
| [Magic Bounce](../abilities/magic-bounce.md) | Changed | Pokémon |
| [Sap Sipper](../abilities/sap-sipper.md) | Changed | Pokémon |
| [Prankster](../abilities/prankster.md) | Changed | Pokémon |
| [Sand Force](../abilities/sand-force.md) | Changed | Pokémon |
| [Iron Barbs](../abilities/iron-barbs.md) | Changed | Pokémon |

## Moves

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Comet Punch](../moves/comet-punch.md) | Changed | Power |
| [Fire Punch](../moves/fire-punch.md) | Changed | Power |
| [Ice Punch](../moves/ice-punch.md) | Changed | Power |
| [ThunderPunch](../moves/thunderpunch.md) | Changed | Power |
| [Cut](../moves/cut.md) | Changed | Type, Power, Accuracy, Pp |
| [Wing Attack](../moves/wing-attack.md) | Changed | Power |
| [Fly](../moves/fly.md) | Changed | Power, Accuracy, Pp |
| [Pin Missile](../moves/pin-missile.md) | Changed | Power |
| [Strength](../moves/strength.md) | Changed | Type, Power |
| [Absorb](../moves/absorb.md) | Changed | Power |
| [Mega Drain](../moves/mega-drain.md) | Changed | Power |
| [Dig](../moves/dig.md) | Changed | Power |
| [Waterfall](../moves/waterfall.md) | Changed | Power |
| [Spike Cannon](../moves/spike-cannon.md) | Changed | Power |
| [Rock Slide](../moves/rock-slide.md) | Changed | Power, Accuracy |
| [Flame Wheel](../moves/flame-wheel.md) | Changed | Power |
| [Twister](../moves/twister.md) | Changed | Power |
| [Shadow Ball](../moves/shadow-ball.md) | Changed | Power |
| [Dive](../moves/dive.md) | Changed | Power |
| [Arm Thrust](../moves/arm-thrust.md) | Changed | Power |
| [Needle Arm](../moves/needle-arm.md) | Changed | Power |
| [Shadow Punch](../moves/shadow-punch.md) | Changed | Power |
| [Shock Wave](../moves/shock-wave.md) | Changed | Power |
| [Dark Pulse](../moves/dark-pulse.md) | Changed | Power |
| [Power Gem](../moves/power-gem.md) | Changed | Power |
| [Energy Ball](../moves/energy-ball.md) | Changed | Power |
| [Shadow Claw](../moves/shadow-claw.md) | Changed | Power |
| [Thunder Fang](../moves/thunder-fang.md) | Changed | Power |
| [Ice Fang](../moves/ice-fang.md) | Changed | Power |
| [Fire Fang](../moves/fire-fang.md) | Changed | Power |
| [Magnet Bomb](../moves/magnet-bomb.md) | Changed | Power |
| [Sky Drop](../moves/sky-drop.md) | Changed | Power |
| [Incinerate](../moves/incinerate.md) | Changed | Power |
| [Water Pledge](../moves/water-pledge.md) | Changed | Power |
| [Fire Pledge](../moves/fire-pledge.md) | Changed | Power |
| [Grass Pledge](../moves/grass-pledge.md) | Changed | Power |
| [Struggle Bug](../moves/struggle-bug.md) | Changed | Power |
| [Bulldoze](../moves/bulldoze.md) | Changed | Power |
| [Horn Leech](../moves/horn-leech.md) | Changed | Power |
| [Steamroller](../moves/steamroller.md) | Changed | Power |
| [Night Daze](../moves/night-daze.md) | Changed | Power, Accuracy |
| [Glaciate](../moves/glaciate.md) | Changed | Power, Accuracy |
| [Freeze Shock](../moves/freeze-shock.md) | Changed | Power |
| [Ice Burn](../moves/ice-burn.md) | Changed | Power |
| [Snarl](../moves/snarl.md) | Changed | Power |
| [Icicle Crash](../moves/icicle-crash.md) | Changed | Power, Accuracy |

## Items

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Master Ball](../items/master-ball.md) | Changed | Locations, Trades |
| [Ultra Ball](../items/ultra-ball.md) | Changed | Locations |
| [Great Ball](../items/great-ball.md) | Changed | Locations |
| [Poké Ball](../items/poke-ball.md) | Changed | Locations |
| [Net Ball](../items/net-ball.md) | Changed | Locations |
| [Timer Ball](../items/timer-ball.md) | Changed | Locations |
| [Heal Ball](../items/heal-ball.md) | Changed | Locations |
| [Quick Ball](../items/quick-ball.md) | Changed | Locations |
| [Cherish Ball](../items/cherish-ball.md) | Changed | Locations |
| [Potion](../items/potion.md) | Changed | Locations |
| [Burn Heal](../items/burn-heal.md) | Changed | Locations |
| [Ice Heal](../items/ice-heal.md) | Changed | Locations |
| [Parlyz Heal](../items/parlyz-heal.md) | Changed | Locations |
| [Full Restore](../items/full-restore.md) | Changed | Trainer battle items |
| [Max Potion](../items/max-potion.md) | Changed | Locations |
| [Hyper Potion](../items/hyper-potion.md) | Changed | Locations |
| [Super Potion](../items/super-potion.md) | Changed | Locations |
| [Full Heal](../items/full-heal.md) | Changed | Locations |
| [Revive](../items/revive.md) | Changed | Locations |
| [Fresh Water](../items/fresh-water.md) | Changed | Locations |
| [Max Elixir](../items/max-elixir.md) | Changed | Trades |
| [HP Up](../items/hp-up.md) | Changed | Locations |
| [Protein](../items/protein.md) | Changed | Locations |
| [Carbos](../items/carbos.md) | Changed | Locations |
| [Rare Candy](../items/rare-candy.md) | Changed | Locations |
| [PP Up](../items/pp-up.md) | Changed | Locations |
| [Zinc](../items/zinc.md) | Changed | Locations |
| [PP Max](../items/pp-max.md) | Changed | Locations |
| [X Attack](../items/x-attack.md) | Changed | Locations, Trainer battle items |
| [X Accuracy](../items/x-accuracy.md) | Changed | Locations |
| [X Special](../items/x-special.md) | Changed | Trainer battle items |
| [X Sp. Def](../items/x-sp-def.md) | Changed | Trainer battle items |
| [Max Repel](../items/max-repel.md) | Changed | Locations |
| [Repel](../items/repel.md) | Changed | Locations |
| [Sun Stone](../items/sun-stone.md) | Changed | Locations |
| [Moon Stone](../items/moon-stone.md) | Changed | Locations |
| [Fire Stone](../items/fire-stone.md) | Changed | Locations |
| [Thunderstone](../items/thunder-stone.md) | Changed | Locations |
| [Water Stone](../items/water-stone.md) | Changed | Locations |
| [Leaf Stone](../items/leaf-stone.md) | Changed | Locations |
| [Stardust](../items/stardust.md) | Changed | Locations |
| [Nugget](../items/nugget.md) | Changed | Locations |
| [Heart Scale](../items/heart-scale.md) | Changed | Wild Held By |
| [Root Fossil](../items/root-fossil.md) | Changed | Locations |
| [Claw Fossil](../items/claw-fossil.md) | Changed | Locations |
| [Helix Fossil](../items/helix-fossil.md) | Changed | Locations |
| [Dome Fossil](../items/dome-fossil.md) | Changed | Locations |
| [Old Amber](../items/old-amber.md) | Changed | Locations |
| [Armor Fossil](../items/armor-fossil.md) | Changed | Locations |
| [Skull Fossil](../items/skull-fossil.md) | Changed | Locations |
| [Rare Bone](../items/rare-bone.md) | Changed | Locations |
| [Shiny Stone](../items/shiny-stone.md) | Changed | Locations |
| [Dusk Stone](../items/dusk-stone.md) | Changed | Locations |
| [Dawn Stone](../items/dawn-stone.md) | Changed | Locations |
| [Oval Stone](../items/oval-stone.md) | Changed | Fling power, Locations, Evolutions |
| [Cheri Berry](../items/cheri-berry.md) | Changed | Trades (blaze-black), Trades (volt-white) |
| [Chesto Berry](../items/chesto-berry.md) | Changed | Locations, Trainer Held By |
| [Pecha Berry](../items/pecha-berry.md) | Changed | Wild Held By |
| [Rawst Berry](../items/rawst-berry.md) | Changed | Wild Held By |
| [Oran Berry](../items/oran-berry.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [Persim Berry](../items/persim-berry.md) | Changed | Trainer Held By |
| [Lum Berry](../items/lum-berry.md) | Changed | Wild Held By, Trainer Held By, Trades (blaze-black), Trades (volt-white) |
| [Sitrus Berry](../items/sitrus-berry.md) | Changed | Wild Held By, Trainer Held By, Trades (blaze-black), Trades (volt-white) |
| [Occa Berry](../items/occa-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Passho Berry](../items/passho-berry.md) | Changed | Trainer Held By |
| [Wacan Berry](../items/wacan-berry.md) | Changed | Trainer Held By |
| [Rindo Berry](../items/rindo-berry.md) | Changed | Trainer Held By |
| [Yache Berry](../items/yache-berry.md) | Changed | Trainer Held By |
| [Chople Berry](../items/chople-berry.md) | Changed | Trainer Held By |
| [Kebia Berry](../items/kebia-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Shuca Berry](../items/shuca-berry.md) | Changed | Trainer Held By |
| [Coba Berry](../items/coba-berry.md) | Changed | Trainer Held By |
| [Payapa Berry](../items/payapa-berry.md) | Changed | Trainer Held By |
| [Tanga Berry](../items/tanga-berry.md) | Changed | Trainer Held By |
| [Charti Berry](../items/charti-berry.md) | Changed | Trainer Held By |
| [Kasib Berry](../items/kasib-berry.md) | Changed | Trainer Held By |
| [Chilan Berry](../items/chilan-berry.md) | Changed | Wild Held By |
| [Liechi Berry](../items/liechi-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Ganlon Berry](../items/ganlon-berry.md) | Changed | Wild Held By |
| [Salac Berry](../items/salac-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Petaya Berry](../items/petaya-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Apicot Berry](../items/apicot-berry.md) | Changed | Wild Held By |
| [Lansat Berry](../items/lansat-berry.md) | Changed | Wild Held By |
| [Starf Berry](../items/starf-berry.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [Enigma Berry](../items/enigma-berry.md) | Changed | Locations, Wild Held By |
| [Micle Berry](../items/micle-berry.md) | Changed | Wild Held By |
| [Custap Berry](../items/custap-berry.md) | Changed | Wild Held By, Trainer Held By |
| [Jaboca Berry](../items/jaboca-berry.md) | Changed | Wild Held By |
| [Rowap Berry](../items/rowap-berry.md) | Changed | Wild Held By |
| [White Herb](../items/white-herb.md) | Changed | Trainer Held By, Trades |
| [Exp. Share](../items/exp-share.md) | Changed | Locations |
| [Choice Band](../items/choice-band.md) | Changed | Locations, Trainer Held By |
| [King's Rock](../items/kings-rock.md) | Changed | Locations, Evolutions |
| [Soul Dew](../items/soul-dew.md) | Changed | Locations |
| [DeepSeaTooth](../items/deep-sea-tooth.md) | Changed | Locations, Evolutions |
| [DeepSeaScale](../items/deep-sea-scale.md) | Changed | Locations, Evolutions |
| [Everstone](../items/everstone.md) | Changed | Locations |
| [Lucky Egg](../items/lucky-egg.md) | Changed | Locations, Wild Held By |
| [Scope Lens](../items/scope-lens.md) | Changed | Trainer Held By |
| [Metal Coat](../items/metal-coat.md) | Changed | Locations, Evolutions |
| [Leftovers](../items/leftovers.md) | Changed | Trainer Held By, Trades |
| [Dragon Scale](../items/dragon-scale.md) | Changed | Field use, Field-use function, Held effect, Party use, Party effects, Evolutions |
| [Light Ball](../items/light-ball.md) | Changed | Locations, Wild Held By |
| [Soft Sand](../items/soft-sand.md) | Changed | Trainer Held By |
| [Hard Stone](../items/hard-stone.md) | Changed | Trainer Held By |
| [Miracle Seed](../items/miracle-seed.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [BlackGlasses](../items/black-glasses.md) | Changed | Locations, Trainer Held By |
| [Black Belt](../items/black-belt.md) | Changed | Wild Held By |
| [Mystic Water](../items/mystic-water.md) | Changed | Wild Held By, Trainer Held By |
| [Sharp Beak](../items/sharp-beak.md) | Changed | Wild Held By, Trainer Held By |
| [NeverMeltIce](../items/never-melt-ice.md) | Changed | Trainer Held By |
| [Spell Tag](../items/spell-tag.md) | Changed | Trainer Held By |
| [TwistedSpoon](../items/twisted-spoon.md) | Changed | Trainer Held By |
| [Charcoal](../items/charcoal.md) | Changed | Wild Held By, Trainer Held By |
| [Up-Grade](../items/up-grade.md) | Changed | Field use, Field-use function, Held effect, Party use, Party effects, Locations, Evolutions |
| [Sea Incense](../items/sea-incense.md) | Changed | Trainer Held By |
| [Lax Incense](../items/lax-incense.md) | Changed | Trainer Held By |
| [Lucky Punch](../items/lucky-punch.md) | Changed | Wild Held By |
| [Thick Club](../items/thick-club.md) | Changed | Locations, Trainer Held By |
| [Stick](../items/stick.md) | Changed | Wild Held By |
| [Wide Lens](../items/wide-lens.md) | Changed | Locations, Trainer Held By |
| [Wise Glasses](../items/wise-glasses.md) | Changed | Trainer Held By |
| [Expert Belt](../items/expert-belt.md) | Changed | Wild Held By, Trainer Held By |
| [Light Clay](../items/light-clay.md) | Changed | Locations, Trainer Held By |
| [Life Orb](../items/life-orb.md) | Changed | Locations, Wild Held By, Trainer Held By |
| [Power Herb](../items/power-herb.md) | Changed | Locations, Trainer Held By |
| [Toxic Orb](../items/toxic-orb.md) | Changed | Wild Held By, Trainer Held By |
| [Flame Orb](../items/flame-orb.md) | Changed | Wild Held By, Trainer Held By |
| [Focus Sash](../items/focus-sash.md) | Changed | Trainer Held By, Trades |
| [Zoom Lens](../items/zoom-lens.md) | Changed | Locations |
| [Metronome](../items/metronome.md) | Changed | Locations |
| [Iron Ball](../items/iron-ball.md) | Changed | Trainer Held By |
| [Black Sludge](../items/black-sludge.md) | Changed | Locations |
| [Damp Rock](../items/damp-rock.md) | Changed | Trainer Held By |
| [Grip Claw](../items/grip-claw.md) | Changed | Locations |
| [Choice Scarf](../items/choice-scarf.md) | Changed | Locations, Trainer Held By |
| [Shed Shell](../items/shed-shell.md) | Changed | Locations |
| [Choice Specs](../items/choice-specs.md) | Changed | Locations |
| [Rose Incense](../items/rose-incense.md) | Changed | Trainer Held By |
| [Protector](../items/protector.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Electirizer](../items/electirizer.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Magmarizer](../items/magmarizer.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Dubious Disc](../items/dubious-disc.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Evolutions |
| [Reaper Cloth](../items/reaper-cloth.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Razor Claw](../items/razor-claw.md) | Changed | Locations |
| [Razor Fang](../items/razor-fang.md) | Changed | Locations |
| [TM01](../items/tm01.md) | Changed | Locations |
| [TM03](../items/tm03.md) | Changed | Locations |
| [TM04](../items/tm04.md) | Changed | Locations |
| [TM08](../items/tm08.md) | Changed | Locations |
| [TM09](../items/tm09.md) | Changed | Locations |
| [TM10](../items/tm10.md) | Changed | Locations |
| [TM13](../items/tm13.md) | Changed | Locations |
| [TM19](../items/tm19.md) | Changed | Locations |
| [TM23](../items/tm23.md) | Changed | Locations |
| [TM26](../items/tm26.md) | Changed | Locations |
| [TM29](../items/tm29.md) | Changed | Locations |
| [TM32](../items/tm32.md) | Changed | Locations |
| [TM34](../items/tm34.md) | Changed | Locations |
| [TM35](../items/tm35.md) | Changed | Locations |
| [TM43](../items/tm43.md) | Changed | Locations |
| [TM53](../items/tm53.md) | Changed | Locations |
| [TM59](../items/tm59.md) | Changed | Locations |
| [TM69](../items/tm69.md) | Changed | Locations |
| [TM71](../items/tm71.md) | Changed | Locations |
| [TM72](../items/tm72.md) | Changed | Locations |
| [TM75](../items/tm75.md) | Changed | Locations |
| [TM76](../items/tm76.md) | Changed | Locations |
| [TM77](../items/tm77.md) | Changed | Locations |
| [TM79](../items/tm79.md) | Changed | Locations |
| [TM87](../items/tm87.md) | Changed | Locations |
| [TM88](../items/tm88.md) | Changed | Locations |
| [TM89](../items/tm89.md) | Changed | Locations |
| [HM01](../items/hm01.md) | Changed | Locations |
| [HM02](../items/hm02.md) | Changed | Locations |
| [Fishing Rod](../items/fishing-rod.md) | Changed | Name, Locations |
| [Bicycle](../items/bicycle.md) | Changed | Locations |
| [Gracidea](../items/gracidea.md) | Changed | Locations |
| [RageCandyBar](../items/rage-candy-bar.md) | Changed | Locations |
| [Prism Scale](../items/prism-scale.md) | Changed | Price, Field use, Field-use function, Party use, Party effects, Locations, Evolutions |
| [Eviolite](../items/eviolite.md) | Changed | Trainer Held By |
| [Rocky Helmet](../items/rocky-helmet.md) | Changed | Trainer Held By |
| [Air Balloon](../items/air-balloon.md) | Changed | Locations, Trainer Held By |
| [Red Card](../items/red-card.md) | Changed | Trainer Held By |
| [Binding Band](../items/binding-band.md) | Changed | Locations |
| [Eject Button](../items/eject-button.md) | Changed | Trainer Held By |
| [Fire Gem](../items/fire-gem.md) | Changed | Trainer Held By |
| [Water Gem](../items/water-gem.md) | Changed | Trainer Held By |
| [Electric Gem](../items/electric-gem.md) | Changed | Trainer Held By |
| [Grass Gem](../items/grass-gem.md) | Changed | Trainer Held By |
| [Flying Gem](../items/flying-gem.md) | Changed | Trainer Held By |
| [Psychic Gem](../items/psychic-gem.md) | Changed | Trainer Held By |
| [Rock Gem](../items/rock-gem.md) | Changed | Trainer Held By |
| [Dragon Gem](../items/dragon-gem.md) | Changed | Trainer Held By |
| [Dark Gem](../items/dark-gem.md) | Changed | Trainer Held By |
| [Normal Gem](../items/normal-gem.md) | Changed | Trainer Held By |
| [Cover Fossil](../items/cover-fossil.md) | Changed | Locations |
| [Plume Fossil](../items/plume-fossil.md) | Changed | Locations |
| [TM93](../items/tm93.md) | Changed | Locations |
| [Xtransceiver](../items/xtransceiver-621.md) | Changed | Locations |
| [Xtransceiver](../items/xtransceiver-626.md) | Changed | Locations |

## Wild encounters

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Striaton City](../encounters/map-000.md) | Changed | Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Driftveil City](../encounters/map-001.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Icirrus City](../encounters/map-002.md) | Changed | Fishing, Fishing Spots |
| [Dreamyard](../encounters/map-003.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Dreamyard](../encounters/map-004.md) | Changed | Doubles Grass |
| [Pinwheel Forest](../encounters/map-005.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Pinwheel Forest](../encounters/map-006.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white), Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Desert Resort](../encounters/map-007.md) | Changed | Grass/Cave |
| [Desert Resort](../encounters/map-008.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-009.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-010.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-011.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-012.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-013.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-014.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-015.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-016.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-017.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-018.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-019.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-020.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-021.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-022.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-023.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-024.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-025.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-026.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-027.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-028.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-029.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-030.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-031.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-032.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-033.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-034.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-035.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-036.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-037.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-038.md) | Changed | Grass/Cave |
| [Relic Castle](../encounters/map-039.md) | Changed | Grass/Cave |
| [Cold Storage](../encounters/map-040.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Chargestone Cave](../encounters/map-041.md) | Changed | Grass/Cave, Shaking Spots |
| [Chargestone Cave](../encounters/map-042.md) | Changed | Grass/Cave, Shaking Spots |
| [Chargestone Cave](../encounters/map-043.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-044.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-044.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-044.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-044.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-045.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-045.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-045.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-045.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-046.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-046.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-046.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-046.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-047.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-047.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-047.md) | Changed | Grass/Cave, Shaking Spots |
| [Twist Mountain](../encounters/map-047.md) | Changed | Grass/Cave, Shaking Spots |
| [Dragonspiral Tower](../encounters/map-048.md) | Changed | Grass/Cave, Shaking Spots |
| [Dragonspiral Tower](../encounters/map-048.md) | Changed | Grass/Cave, Shaking Spots |
| [Dragonspiral Tower](../encounters/map-048.md) | Changed | Grass/Cave, Shaking Spots |
| [Dragonspiral Tower](../encounters/map-048.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Dragonspiral Tower](../encounters/map-049.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Dragonspiral Tower](../encounters/map-049.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Dragonspiral Tower](../encounters/map-049.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Dragonspiral Tower](../encounters/map-049.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Dragonspiral Tower](../encounters/map-050.md) | Changed | Grass/Cave |
| [Dragonspiral Tower](../encounters/map-051.md) | Changed | Grass/Cave |
| [Victory Road](../encounters/map-052.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white) |
| [Victory Road](../encounters/map-053.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Victory Road](../encounters/map-054.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-055.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-056.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-057.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-058.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Victory Road](../encounters/map-059.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-060.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-061.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-062.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-063.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-064.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-065.md) | Changed | Grass/Cave, Shaking Spots |
| [Victory Road](../encounters/map-066.md) | Changed | Grass/Cave, Shaking Spots |
| [Trial Chamber](../encounters/map-067.md) | Changed | Grass/Cave, Shaking Spots |
| [Giant Chasm](../encounters/map-068.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Giant Chasm](../encounters/map-069.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Giant Chasm](../encounters/map-070.md) | Changed | Grass/Cave, Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots |
| [Giant Chasm](../encounters/map-071.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [P2 Laboratory](../encounters/map-072.md) | Changed | Grass/Cave, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Bay](../encounters/map-073.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Bay](../encounters/map-073.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Bay](../encounters/map-073.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Bay](../encounters/map-073.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Driftveil Drawbridge](../encounters/map-074.md) | Changed | Shaking Spots |
| [Village Bridge](../encounters/map-075.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Marvelous Bridge](../encounters/map-076.md) | Changed | Shaking Spots |
| [Route 1](../encounters/map-077.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 2](../encounters/map-078.md) | Changed | Grass/Cave, Shaking Spots |
| [Route 3](../encounters/map-079.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Wellspring Cave](../encounters/map-080.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Wellspring Cave](../encounters/map-081.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 4](../encounters/map-082.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 5](../encounters/map-083.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots |
| [Route 6](../encounters/map-084.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 6](../encounters/map-084.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 6](../encounters/map-084.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 6](../encounters/map-084.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Mistralton Cave](../encounters/map-085.md) | Changed | Grass/Cave, Shaking Spots |
| [Mistralton Cave](../encounters/map-086.md) | Changed | Grass/Cave, Shaking Spots |
| [Guidance Chamber](../encounters/map-087.md) | Changed | Grass/Cave, Shaking Spots |
| [Route 7](../encounters/map-088.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Route 7](../encounters/map-088.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Route 7](../encounters/map-088.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Route 7](../encounters/map-088.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots |
| [Celestial Tower](../encounters/map-089.md) | Changed | Grass/Cave |
| [Celestial Tower](../encounters/map-090.md) | Changed | Grass/Cave |
| [Celestial Tower](../encounters/map-091.md) | Changed | Grass/Cave |
| [Celestial Tower](../encounters/map-092.md) | Changed | Grass/Cave |
| [Route 8](../encounters/map-093.md) | Changed | Grass/Cave, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Route 8](../encounters/map-093.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Route 8](../encounters/map-093.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Route 8](../encounters/map-093.md) | Changed | Fishing, Fishing Spots |
| [Moor of Icirrus](../encounters/map-094.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Moor of Icirrus](../encounters/map-094.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Moor of Icirrus](../encounters/map-094.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Moor of Icirrus](../encounters/map-094.md) | Changed | Fishing, Fishing Spots |
| [Route 9](../encounters/map-095.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Challenger's Cave](../encounters/map-096.md) | Changed | Grass/Cave, Shaking Spots |
| [Challenger's Cave](../encounters/map-097.md) | Changed | Grass/Cave, Shaking Spots |
| [Challenger's Cave](../encounters/map-098.md) | Changed | Grass/Cave, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 10](../encounters/map-099.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Route 10](../encounters/map-100.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Route 11](../encounters/map-101.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 12](../encounters/map-102.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Route 13](../encounters/map-103.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Route 14](../encounters/map-104.md) | Changed | Grass/Cave, Doubles Grass, Shaking Spots, Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Abundant Shrine](../encounters/map-105.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white), Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 15](../encounters/map-106.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white) |
| [Route 16](../encounters/map-107.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots |
| [Lostlorn Forest](../encounters/map-108.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white), Surfing (blaze-black), Surfing (volt-white), Surfing Spots (blaze-black), Surfing Spots (volt-white), Fishing (blaze-black), Fishing (volt-white), Fishing Spots (blaze-black), Fishing Spots (volt-white) |
| [Route 18](../encounters/map-109.md) | Changed | Grass/Cave (blaze-black), Grass/Cave (volt-white), Doubles Grass (blaze-black), Doubles Grass (volt-white), Shaking Spots (blaze-black), Shaking Spots (volt-white), Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Undella Town](../encounters/map-110.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |
| [Route 17](../encounters/map-111.md) | Changed | Surfing, Surfing Spots, Fishing, Fishing Spots |

## Trainers

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Youngster](../trainers/trainer-0001.md) | Changed | Name, Party |
| [Lass Jimmy](../trainers/trainer-0002.md) | Changed | Party |
| [School Kid Mali](../trainers/trainer-0003.md) | Changed | Party |
| [School Kid Al](../trainers/trainer-0004.md) | Changed | Party |
| [Smasher Marsha](../trainers/trainer-0005.md) | Changed | Party |
| [Linebacker Elena](../trainers/trainer-0006.md) | Changed | Party |
| [Youngster Dan](../trainers/trainer-0007.md) | Changed | Party |
| [Lass Joey](../trainers/trainer-0008.md) | Changed | Party |
| [Waiter Eri](../trainers/trainer-0009.md) | Changed | Party |
| [Waitress Maxwell](../trainers/trainer-0010.md) | Changed | Party |
| [Leader Tia](../trainers/trainer-0011.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Chili](../trainers/trainer-0012.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Cilan](../trainers/trainer-0013.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Nursery Aide Cress](../trainers/trainer-0014.md) | Changed | Party |
| [Preschooler Autumn](../trainers/trainer-0015.md) | Changed | Party |
| [Preschooler Wendy](../trainers/trainer-0016.md) | Changed | Party |
| [Preschooler Doyle](../trainers/trainer-0017.md) | Changed | Party |
| [Twins Tully](../trainers/trainer-0018.md) | Changed | Party |
| [ Breeder Kumi &amp; Amy](../trainers/trainer-0019.md) | Changed | Party |
| [ Breeder Galen](../trainers/trainer-0020.md) | Changed | Party |
| [Leader Adelaide](../trainers/trainer-0021.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Lenora](../trainers/trainer-0022.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Burgh](../trainers/trainer-0023.md) | Changed | AI flags, Party |
| [Leader Elesa](../trainers/trainer-0024.md) | Changed | AI flags, Party |
| [Leader Clay](../trainers/trainer-0025.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Ranger Skyla](../trainers/trainer-0026.md) | Changed | Party |
| [ Ranger Forrest](../trainers/trainer-0027.md) | Changed | Party |
| [ Ranger Irene](../trainers/trainer-0028.md) | Changed | Party |
| [ Ranger Miguel](../trainers/trainer-0029.md) | Changed | Party |
| [School Kid Audra](../trainers/trainer-0030.md) | Changed | Party |
| [School Kid Sammy](../trainers/trainer-0031.md) | Changed | Party |
| [Twins Millie](../trainers/trainer-0032.md) | Changed | Party |
| [Youngster Mayo &amp; May](../trainers/trainer-0033.md) | Changed | Party |
| [Lass Nicholas](../trainers/trainer-0034.md) | Changed | Party |
| [Worker Eva](../trainers/trainer-0035.md) | Changed | Party |
| [Worker Scott](../trainers/trainer-0036.md) | Changed | Party |
| [Worker Shelby](../trainers/trainer-0037.md) | Changed | Party |
| [Worker Zack](../trainers/trainer-0038.md) | Changed | Party |
| [Backpacker Cairn](../trainers/trainer-0039.md) | Changed | Party |
| [Backpacker Waylon](../trainers/trainer-0040.md) | Changed | Party |
| [Fisherman Jill](../trainers/trainer-0041.md) | Changed | Party |
| [Fisherman Hubert](../trainers/trainer-0042.md) | Changed | Party |
| [Smasher Andrew](../trainers/trainer-0043.md) | Changed | Party |
| [Backpacker Aspen](../trainers/trainer-0044.md) | Changed | Party |
| [Backpacker Michael](../trainers/trainer-0045.md) | Changed | Party |
| [Musician Lois](../trainers/trainer-0046.md) | Changed | Party |
| [Dancer Preston](../trainers/trainer-0047.md) | Changed | Party |
| [Harlequin Brian](../trainers/trainer-0048.md) | Changed | Party |
| [Artist Paul](../trainers/trainer-0049.md) | Changed | Party |
| [Baker Horton](../trainers/trainer-0050.md) | Changed | Party |
| [Psychic Jenn](../trainers/trainer-0051.md) | Changed | Party |
| [Psychic Perry](../trainers/trainer-0052.md) | Changed | Party |
| [ Trainer Dua](../trainers/trainer-0053.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0054.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0055.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0056.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0057.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0058.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0059.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0060.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0061.md) | Changed | AI flags, Party |
| [Team Plasma Bianca](../trainers/trainer-0062.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0063.md) | Changed | Party |
| [ Trainer Grunt](../trainers/trainer-0064.md) | Changed | AI flags, Party |
| [ Trainer N](../trainers/trainer-0065.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Rich Boy N](../trainers/trainer-0066.md) | Changed | Party |
| [Rich Boy Cody](../trainers/trainer-0067.md) | Changed | Party |
| [Lady Rolan](../trainers/trainer-0068.md) | Changed | Party |
| [Lady Magnolia](../trainers/trainer-0069.md) | Changed | Party |
| [Pilot Colette](../trainers/trainer-0070.md) | Changed | Party |
| [Pilot Ted](../trainers/trainer-0071.md) | Changed | Party |
| [Worker Chase](../trainers/trainer-0072.md) | Changed | Party |
| [Worker Victor](../trainers/trainer-0073.md) | Changed | Party |
| [Worker Felipe](../trainers/trainer-0074.md) | Changed | Name, Party |
| [Worker Glenn](../trainers/trainer-0075.md) | Changed | Party |
| [Worker Ryan](../trainers/trainer-0076.md) | Changed | Party |
| [Worker Patton](../trainers/trainer-0077.md) | Changed | Party |
| [Worker Eddie](../trainers/trainer-0078.md) | Changed | Party |
| [Worker Matthew](../trainers/trainer-0079.md) | Changed | Party |
| [Team Plasma](../trainers/trainer-0080.md) | Changed | Party |
| [Team Plasma](../trainers/trainer-0081.md) | Changed | Party |
| [Hoopster Grunt](../trainers/trainer-0082.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0083.md) | Changed | Party |
| [School Kid John](../trainers/trainer-0084.md) | Changed | Party |
| [Youngster Edgar](../trainers/trainer-0085.md) | Changed | Party |
| [School Kid Roland](../trainers/trainer-0086.md) | Changed | Party |
| [School Kid Carter](../trainers/trainer-0087.md) | Changed | Party |
| [Scientist Lydia](../trainers/trainer-0088.md) | Changed | Party |
| [Team Plasma Satomi](../trainers/trainer-0089.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer N](../trainers/trainer-0090.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0091.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0092.md) | Changed | AI flags, Party |
| [Clerk  Cheren](../trainers/trainer-0093.md) | Changed | Party |
| [Clerk  Ingrid](../trainers/trainer-0094.md) | Changed | Party |
| [Clerk  Alberta](../trainers/trainer-0095.md) | Changed | Party |
| [Clerk  Katie](../trainers/trainer-0096.md) | Changed | Party |
| [Waiter Trisha](../trainers/trainer-0097.md) | Changed | Party |
| [Waitress Bert](../trainers/trainer-0098.md) | Changed | Party |
| [Ace Trainer Flo](../trainers/trainer-0099.md) | Changed | Party |
| [Ace Trainer Cheyenne](../trainers/trainer-0100.md) | Changed | Party |
| [Ace Trainer Stella](../trainers/trainer-0101.md) | Changed | Party |
| [Ace Trainer Allison](../trainers/trainer-0102.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0103.md) | Changed | Party |
| [Ace Trainer Johan](../trainers/trainer-0104.md) | Changed | Party |
| [Ace Trainer Corky](../trainers/trainer-0105.md) | Changed | Party |
| [Ace Trainer Jared](../trainers/trainer-0106.md) | Changed | Party |
| [Lady Jesse](../trainers/trainer-0107.md) | Changed | Party |
| [Rich Boy Isabel](../trainers/trainer-0108.md) | Changed | Party |
| [Black Belt Manuel](../trainers/trainer-0109.md) | Changed | Party |
| [Black Belt Corey](../trainers/trainer-0110.md) | Changed | Party |
| [Black Belt Teppei](../trainers/trainer-0111.md) | Changed | Party |
| [Scientist Kentaro](../trainers/trainer-0112.md) | Changed | Party |
| [Scientist William](../trainers/trainer-0113.md) | Changed | Party |
| [Scientist Randall](../trainers/trainer-0114.md) | Changed | Party |
| [Scientist Steve](../trainers/trainer-0115.md) | Changed | Party |
| [Scientist Orville](../trainers/trainer-0116.md) | Changed | Party |
| [Scientist Samantha](../trainers/trainer-0117.md) | Changed | Party |
| [Psychic Naoko](../trainers/trainer-0118.md) | Changed | Party |
| [Psychic Micki](../trainers/trainer-0119.md) | Changed | Party |
| [Psychic Bryce](../trainers/trainer-0120.md) | Changed | Party |
| [Psychic Doreen](../trainers/trainer-0121.md) | Changed | Party |
| [Worker Lin](../trainers/trainer-0122.md) | Changed | Party |
| [Worker Rob](../trainers/trainer-0123.md) | Changed | Party |
| [Worker Rich](../trainers/trainer-0124.md) | Changed | Party |
| [Worker Heath](../trainers/trainer-0125.md) | Changed | Party |
| [Worker Cliff](../trainers/trainer-0126.md) | Changed | Party |
| [Worker](../trainers/trainer-0127.md) | Changed | Party |
| [Worker Brady](../trainers/trainer-0128.md) | Changed | Party |
| [Striker Arnold](../trainers/trainer-0129.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0130.md) | Changed | Party |
| [Leader Roberto](../trainers/trainer-0131.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Brycen](../trainers/trainer-0132.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Leader Iris](../trainers/trainer-0133.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Roughneck Drayden](../trainers/trainer-0134.md) | Changed | Party |
| [Roughneck Chance](../trainers/trainer-0135.md) | Changed | Party |
| [Roughneck Reese](../trainers/trainer-0136.md) | Changed | Party |
| [Janitor Fletcher](../trainers/trainer-0137.md) | Changed | Party |
| [Pokéfan Geoff](../trainers/trainer-0138.md) | Changed | Party |
| [Pokéfan Jude](../trainers/trainer-0139.md) | Changed | Party |
| [Youngster Georgia](../trainers/trainer-0140.md) | Changed | Party |
| [Youngster Albert](../trainers/trainer-0141.md) | Changed | Party |
| [Youngster Kenneth](../trainers/trainer-0142.md) | Changed | Party |
| [Youngster Mikey](../trainers/trainer-0143.md) | Changed | Party |
| [Youngster Parker](../trainers/trainer-0144.md) | Changed | Party |
| [Youngster Zachary](../trainers/trainer-0145.md) | Changed | Party |
| [Youngster Keita](../trainers/trainer-0146.md) | Changed | Party |
| [Youngster Abe](../trainers/trainer-0147.md) | Changed | Party |
| [Fisherman Kevin](../trainers/trainer-0148.md) | Changed | Party |
| [Fisherman Bruce](../trainers/trainer-0149.md) | Changed | Party |
| [Doctor Devon](../trainers/trainer-0150.md) | Changed | Party |
| [Doctor Wayne](../trainers/trainer-0151.md) | Changed | Party |
| [Nurse Hank](../trainers/trainer-0152.md) | Changed | Party |
| [Backpacker Sachiko](../trainers/trainer-0153.md) | Changed | Party |
| [Backpacker Jerome](../trainers/trainer-0154.md) | Changed | Party |
| [Backpacker Terrance](../trainers/trainer-0155.md) | Changed | Party |
| [Backpacker Ruth](../trainers/trainer-0156.md) | Changed | Party |
| [Hooligans Anna](../trainers/trainer-0157.md) | Changed | Party |
| [Battle Girl Jim &amp; Cas](../trainers/trainer-0158.md) | Changed | Party |
| [Battle Girl Amy](../trainers/trainer-0159.md) | Changed | Party |
| [Battle Girl Sharon](../trainers/trainer-0160.md) | Changed | Party |
| [Parasol Lady Lee](../trainers/trainer-0161.md) | Changed | Party |
| [Parasol Lady Nicole](../trainers/trainer-0162.md) | Changed | Party |
| [Parasol Lady Tihana](../trainers/trainer-0163.md) | Changed | Party |
| [Parasol Lady Melita](../trainers/trainer-0164.md) | Changed | Party |
| [Clerk  Lumi](../trainers/trainer-0165.md) | Changed | Party |
| [Clerk  Clemens](../trainers/trainer-0166.md) | Changed | Party |
| [Clerk  Warren](../trainers/trainer-0167.md) | Changed | Party |
| [Clerk  Ivan](../trainers/trainer-0168.md) | Changed | Party |
| [Clerk  Isaac](../trainers/trainer-0169.md) | Changed | Party |
| [Clerk  Ryouta](../trainers/trainer-0170.md) | Changed | Name, Party |
| [Clerk  Wade](../trainers/trainer-0171.md) | Changed | Party |
| [Backers Fredric](../trainers/trainer-0172.md) | Changed | Party |
| [Backers Hawk &amp; Dar](../trainers/trainer-0173.md) | Changed | Party |
| [Backers Joe &amp; Ross](../trainers/trainer-0174.md) | Changed | Party |
| [Backers Masa &amp; Yas](../trainers/trainer-0175.md) | Changed | Party |
| [Backers Kay &amp; Ali](../trainers/trainer-0176.md) | Changed | Party |
| [Linebacker Ami &amp; Eira](../trainers/trainer-0177.md) | Changed | Party |
| [Veteran Bob](../trainers/trainer-0178.md) | Changed | Party |
| [Veteran Chester](../trainers/trainer-0179.md) | Changed | Party |
| [Biker Karla](../trainers/trainer-0180.md) | Changed | Party |
| [Biker Phillip](../trainers/trainer-0181.md) | Changed | Party |
| [ Ranger Zeke](../trainers/trainer-0182.md) | Changed | Party |
| [ Ranger Richard](../trainers/trainer-0183.md) | Changed | Party |
| [ Ranger Pedro](../trainers/trainer-0184.md) | Changed | Party |
| [ Ranger Lewis](../trainers/trainer-0185.md) | Changed | Party |
| [ Ranger Alain](../trainers/trainer-0186.md) | Changed | Party |
| [ Ranger Shanti](../trainers/trainer-0187.md) | Changed | Party |
| [ Ranger Mary](../trainers/trainer-0188.md) | Changed | Party |
| [ Ranger Annie](../trainers/trainer-0189.md) | Changed | Party |
| [Lass Heidi](../trainers/trainer-0190.md) | Changed | Party |
| [Infielder Kara](../trainers/trainer-0191.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0192.md) | Changed | Party |
| [Hiker Connor](../trainers/trainer-0193.md) | Changed | Party |
| [Hiker Bret](../trainers/trainer-0194.md) | Changed | Party |
| [Hiker Hardy](../trainers/trainer-0195.md) | Changed | Party |
| [Harlequin Neil](../trainers/trainer-0196.md) | Changed | Party |
| [Harlequin Jack](../trainers/trainer-0197.md) | Changed | Party |
| [Harlequin](../trainers/trainer-0198.md) | Changed | Party |
| [Harlequin Louis](../trainers/trainer-0199.md) | Changed | Party |
| [Harlequin Kerry](../trainers/trainer-0200.md) | Changed | Party |
| [Worker Rick](../trainers/trainer-0201.md) | Changed | Party |
| [Worker Felix](../trainers/trainer-0202.md) | Changed | Party |
| [Worker Sterling](../trainers/trainer-0203.md) | Changed | Party |
| [Twins Don](../trainers/trainer-0204.md) | Changed | Party |
| [Ace Trainer](../trainers/trainer-0205.md) | Changed | Party |
| [Ace Trainer Mariana](../trainers/trainer-0206.md) | Changed | Party |
| [Lass Henry](../trainers/trainer-0207.md) | Changed | Party |
| [Rich Boy Sibyl](../trainers/trainer-0208.md) | Changed | Party |
| [Lady Brad](../trainers/trainer-0209.md) | Changed | Party |
| [Socialite Elizandra](../trainers/trainer-0210.md) | Changed | Party |
| [Gentleman Cassandra](../trainers/trainer-0211.md) | Changed | Party |
| [Battle Girl Robert](../trainers/trainer-0212.md) | Changed | Party |
| [Battle Girl Miriam](../trainers/trainer-0213.md) | Changed | Party |
| [Battle Girl Mikiko](../trainers/trainer-0214.md) | Changed | Party |
| [Black Belt Chandra](../trainers/trainer-0215.md) | Changed | Party |
| [Black Belt Grant](../trainers/trainer-0216.md) | Changed | Party |
| [Black Belt Kendrew](../trainers/trainer-0217.md) | Changed | Party |
| [Team Plasma Thomas](../trainers/trainer-0218.md) | Changed | AI flags, Party |
| [ Trainer N](../trainers/trainer-0219.md) | Changed | Party |
| [Team Plasma](../trainers/trainer-0220.md) | Changed | Party |
| [Team Plasma](../trainers/trainer-0221.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0222.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0223.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0224.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0225.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0226.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0227.md) | Changed | Party |
| [Elite Four Grunt](../trainers/trainer-0228.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Elite Four Shauntal](../trainers/trainer-0229.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Elite Four Marshal](../trainers/trainer-0230.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Elite Four Grimsley](../trainers/trainer-0231.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Team Plasma Caitlin](../trainers/trainer-0232.md) | Changed | AI flags, Party |
| [Psychic Ghetsis](../trainers/trainer-0233.md) | Changed | Party |
| [Psychic Low](../trainers/trainer-0234.md) | Changed | Party |
| [Psychic Gaven](../trainers/trainer-0235.md) | Changed | Party |
| [Backpacker Cybil](../trainers/trainer-0236.md) | Changed | Party |
| [Backpacker Kelsey](../trainers/trainer-0237.md) | Changed | Party |
| [Backpacker Nate](../trainers/trainer-0238.md) | Changed | Party |
| [Backpacker Liz](../trainers/trainer-0239.md) | Changed | Party |
| [Scientist Elaine](../trainers/trainer-0240.md) | Changed | Party |
| [Worker Ronald](../trainers/trainer-0241.md) | Changed | Party |
| [Hiker Brand](../trainers/trainer-0242.md) | Changed | Party |
| [Hiker Darrell](../trainers/trainer-0243.md) | Changed | Party |
| [Ace Trainer Terrell](../trainers/trainer-0244.md) | Changed | Party |
| [Ace Trainer Shanta](../trainers/trainer-0245.md) | Changed | Party |
| [Ace Trainer Cathy](../trainers/trainer-0246.md) | Changed | Party |
| [Ace Trainer Dwayne](../trainers/trainer-0247.md) | Changed | Party |
| [Black Belt David](../trainers/trainer-0248.md) | Changed | Party |
| [Doctor Tyrone](../trainers/trainer-0249.md) | Changed | Party |
| [Veteran Logan](../trainers/trainer-0250.md) | Changed | Party |
| [Veteran Martell](../trainers/trainer-0251.md) | Changed | Party |
| [Black Belt Tiffany](../trainers/trainer-0252.md) | Changed | Party |
| [Battle Girl Edward](../trainers/trainer-0253.md) | Changed | Party |
| [Battle Girl Maggie](../trainers/trainer-0254.md) | Changed | Party |
| [Hiker Xiao](../trainers/trainer-0255.md) | Changed | Party |
| [Hiker Hugh](../trainers/trainer-0256.md) | Changed | Party |
| [Scientist Clarke](../trainers/trainer-0257.md) | Changed | Party |
| [Scientist Ron](../trainers/trainer-0258.md) | Changed | Party |
| [Leader Maria](../trainers/trainer-0259.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Veteran Drayden](../trainers/trainer-0260.md) | Changed | Name, Party |
| [Ace Trainer Julia](../trainers/trainer-0261.md) | Changed | Party |
| [Ace Trainer Beverly](../trainers/trainer-0262.md) | Changed | Party |
| [Psychic Green](../trainers/trainer-0263.md) | Changed | Name, Party |
| [Ace Trainer Belle](../trainers/trainer-0264.md) | Changed | Party |
| [Ace Trainer Kassandra](../trainers/trainer-0265.md) | Changed | Party |
| [Ace Trainer Olwen](../trainers/trainer-0266.md) | Changed | Party |
| [Ace Trainer Clara](../trainers/trainer-0267.md) | Changed | Party |
| [Ace Trainer Dara](../trainers/trainer-0268.md) | Changed | Party |
| [Ace Trainer](../trainers/trainer-0269.md) | Changed | Party |
| [Ace Trainer Beckett](../trainers/trainer-0270.md) | Changed | Party |
| [Ace Trainer Webster](../trainers/trainer-0271.md) | Changed | Party |
| [Ace Trainer Jose](../trainers/trainer-0272.md) | Changed | Party |
| [Ace Trainer Tom](../trainers/trainer-0273.md) | Changed | Party |
| [Veteran](../trainers/trainer-0274.md) | Changed | Party |
| [Veteran Hugo](../trainers/trainer-0275.md) | Changed | Party |
| [Team Plasma Kim](../trainers/trainer-0276.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0277.md) | Changed | Party |
| [Team Plasma](../trainers/trainer-0278.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0279.md) | Changed | Party |
| [Ace Trainer Grunt](../trainers/trainer-0280.md) | Changed | Party |
| [Ace Trainer](../trainers/trainer-0281.md) | Changed | Party |
| [Clerk  Austin](../trainers/trainer-0282.md) | Changed | Party |
| [Waiter](../trainers/trainer-0283.md) | Changed | Party |
| [Rich Boy](../trainers/trainer-0284.md) | Changed | Party |
| [Lass Martin](../trainers/trainer-0285.md) | Changed | Party |
| [Lady Maya](../trainers/trainer-0286.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0287.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0288.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0289.md) | Changed | AI flags, Party |
| [Backpacker Cheren](../trainers/trainer-0290.md) | Changed | Party |
| [Worker Keane](../trainers/trainer-0291.md) | Changed | Party |
| [School Kid Gus](../trainers/trainer-0292.md) | Changed | Party |
| [Team Plasma Gina](../trainers/trainer-0293.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0294.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0295.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0296.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0297.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0298.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0299.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0300.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0301.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0302.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0303.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0304.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0305.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0306.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0307.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0308.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0309.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0310.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0311.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0312.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0313.md) | Changed | Party |
| [Smasher Grunt](../trainers/trainer-0314.md) | Changed | Party |
| [Smasher Mari](../trainers/trainer-0315.md) | Changed | Party |
| [Smasher Elena](../trainers/trainer-0316.md) | Changed | Party |
| [Smasher Elena](../trainers/trainer-0317.md) | Changed | Party |
| [Smasher Elena](../trainers/trainer-0318.md) | Changed | Party |
| [Infielder Aspen](../trainers/trainer-0319.md) | Changed | Party |
| [Infielder Todd](../trainers/trainer-0320.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0321.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0322.md) | Changed | Party |
| [Infielder Alex](../trainers/trainer-0323.md) | Changed | Party |
| [Striker Connor](../trainers/trainer-0324.md) | Changed | Party |
| [Striker Marco](../trainers/trainer-0325.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0326.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0327.md) | Changed | Party |
| [Striker Tony](../trainers/trainer-0328.md) | Changed | Party |
| [Linebacker Roberto](../trainers/trainer-0329.md) | Changed | Party |
| [Linebacker Jonah](../trainers/trainer-0330.md) | Changed | Party |
| [Linebacker Dan](../trainers/trainer-0331.md) | Changed | Party |
| [Linebacker Dan](../trainers/trainer-0332.md) | Changed | Party |
| [Linebacker Dan](../trainers/trainer-0333.md) | Changed | Party |
| [Hoopster Bob](../trainers/trainer-0334.md) | Changed | Party |
| [Hoopster Lamacrus](../trainers/trainer-0335.md) | Changed | Name, Party |
| [Hoopster Bobby](../trainers/trainer-0336.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0337.md) | Changed | Party |
| [Hoopster Bobby](../trainers/trainer-0338.md) | Changed | Party |
| [Backers John](../trainers/trainer-0339.md) | Changed | Party |
| [Backers Hawk &amp; Dar](../trainers/trainer-0340.md) | Changed | Party |
| [Backers Hawk &amp; Dar](../trainers/trainer-0341.md) | Changed | Party |
| [Backers Joe &amp; Ross](../trainers/trainer-0342.md) | Changed | Party |
| [Backers Joe &amp; Ross](../trainers/trainer-0343.md) | Changed | Party |
| [Backers Masa &amp; Yas](../trainers/trainer-0344.md) | Changed | Party |
| [Backers Masa &amp; Yas](../trainers/trainer-0345.md) | Changed | Party |
| [Backers Les &amp; Web](../trainers/trainer-0346.md) | Changed | Party |
| [Backers Alf &amp; Fred](../trainers/trainer-0347.md) | Changed | Party |
| [Backers Kay &amp; Ali](../trainers/trainer-0348.md) | Changed | Party |
| [Backers Kay &amp; Ali](../trainers/trainer-0349.md) | Changed | Party |
| [Backers Ami &amp; Eira](../trainers/trainer-0350.md) | Changed | Party |
| [Backers Ami &amp; Eira](../trainers/trainer-0351.md) | Changed | Party |
| [Backers Cam &amp; Abby](../trainers/trainer-0352.md) | Changed | Party |
| [Backers Ai &amp; Ciel](../trainers/trainer-0353.md) | Changed | Party |
| [Lass Kat &amp; Phae](../trainers/trainer-0354.md) | Changed | Party |
| [School Kid Dana](../trainers/trainer-0355.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0356.md) | Changed | Party |
| [Ace Trainer Sally](../trainers/trainer-0357.md) | Changed | Party |
| [Ace Trainer Lucille](../trainers/trainer-0358.md) | Changed | Party |
| [Veteran Charlie](../trainers/trainer-0359.md) | Changed | Party |
| [Veteran Arlen](../trainers/trainer-0360.md) | Changed | Party |
| [ Breeder Sayuri](../trainers/trainer-0361.md) | Changed | Party |
| [ Breeder Owen](../trainers/trainer-0362.md) | Changed | Party |
| [Waiter Brooke](../trainers/trainer-0363.md) | Changed | Party |
| [Waitress Clint](../trainers/trainer-0364.md) | Changed | Party |
| [Scientist Bonita](../trainers/trainer-0365.md) | Changed | Party |
| [Scientist Simon](../trainers/trainer-0366.md) | Changed | Party |
| [Lady Blythe](../trainers/trainer-0367.md) | Changed | Party |
| [Rich Boy Sophie](../trainers/trainer-0368.md) | Changed | Party |
| [Socialite Anthony](../trainers/trainer-0369.md) | Changed | Party |
| [Gentleman Emilia](../trainers/trainer-0370.md) | Changed | Party |
| [Black Belt Renaud](../trainers/trainer-0371.md) | Changed | Party |
| [Battle Girl Lao](../trainers/trainer-0372.md) | Changed | Party |
| [Pokéfan Janie](../trainers/trainer-0373.md) | Changed | Party |
| [Pokéfan Colin](../trainers/trainer-0374.md) | Changed | Party |
| [Pilot Darcy](../trainers/trainer-0375.md) | Changed | Party |
| [Worker Leonard](../trainers/trainer-0376.md) | Changed | Party |
| [Baker Tyler](../trainers/trainer-0377.md) | Changed | Party |
| [Nursery Aide Lilly](../trainers/trainer-0378.md) | Changed | Party |
| [Clerk  Leah](../trainers/trainer-0379.md) | Changed | Party |
| [Clerk  Nelson](../trainers/trainer-0380.md) | Changed | Party |
| [Janitor Wren](../trainers/trainer-0381.md) | Changed | Party |
| [Backpacker Caleb](../trainers/trainer-0382.md) | Changed | Party |
| [Backpacker Patty](../trainers/trainer-0383.md) | Changed | Party |
| [Doctor Alexander](../trainers/trainer-0384.md) | Changed | Party |
| [Nurse Jules](../trainers/trainer-0385.md) | Changed | Party |
| [Psychic Kirsten](../trainers/trainer-0386.md) | Changed | Party |
| [Psychic Gerard](../trainers/trainer-0387.md) | Changed | Party |
| [Depot Agent Madhu](../trainers/trainer-0388.md) | Changed | Party |
| [Swimmer  Josh](../trainers/trainer-0389.md) | Changed | Party |
| [Swimmer  Wright](../trainers/trainer-0390.md) | Changed | Party |
| [Dancer Joyce](../trainers/trainer-0391.md) | Changed | Party |
| [Musician Davey](../trainers/trainer-0392.md) | Changed | Party |
| [Harlequin Boris](../trainers/trainer-0393.md) | Changed | Party |
| [Artist Charley](../trainers/trainer-0394.md) | Changed | Party |
| [Policeman Pierre](../trainers/trainer-0395.md) | Changed | Party |
| [Maid Jeff](../trainers/trainer-0396.md) | Changed | Party |
| [Parasol Lady Alica](../trainers/trainer-0397.md) | Changed | Party |
| [Hiker Gwyneth](../trainers/trainer-0398.md) | Changed | Party |
| [Preschooler Russel](../trainers/trainer-0399.md) | Changed | Party |
| [Preschooler Mia](../trainers/trainer-0400.md) | Changed | Party |
| [Preschooler Evan](../trainers/trainer-0401.md) | Changed | Party |
| [Preschooler Sarah](../trainers/trainer-0402.md) | Changed | Party |
| [ Trainer Billy](../trainers/trainer-0403.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0404.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0405.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Subway Boss Cheren](../trainers/trainer-0406.md) | Changed | Party |
| [Champion Ingo](../trainers/trainer-0407.md) | Changed | AI flags, Party |
| [Cyclist Alder](../trainers/trainer-0408.md) | Changed | Party |
| [Cyclist Hector](../trainers/trainer-0409.md) | Changed | Party |
| [Leader Krissa](../trainers/trainer-0410.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Leader Skyla](../trainers/trainer-0411.md) | Changed | Name, Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Policeman Brycen](../trainers/trainer-0412.md) | Changed | Name, Party |
| [Swimmer  Daniel](../trainers/trainer-0413.md) | Changed | Party |
| [Black Belt Berke](../trainers/trainer-0414.md) | Changed | Party |
| [Black Belt Benjamin](../trainers/trainer-0415.md) | Changed | Party |
| [Leader Jay](../trainers/trainer-0416.md) | Changed | Class Id, Class Name, AI flags, AI battle items, Party |
| [Scientist Burgh](../trainers/trainer-0417.md) | Changed | Name, Party |
| [Scientist Kathrine](../trainers/trainer-0418.md) | Changed | Party |
| [Scientist Chan](../trainers/trainer-0419.md) | Changed | Party |
| [Scientist Markus](../trainers/trainer-0420.md) | Changed | Party |
| [Scientist Luke](../trainers/trainer-0421.md) | Changed | AI battle items, Party |
| [Psychic Nathan](../trainers/trainer-0422.md) | Changed | Party |
| [Psychic Future](../trainers/trainer-0423.md) | Changed | Party |
| [Psychic Rudolf](../trainers/trainer-0424.md) | Changed | Party |
| [Gentleman Tommy](../trainers/trainer-0425.md) | Changed | Party |
| [Socialite Yan](../trainers/trainer-0426.md) | Changed | Party |
| [School Kid Marian](../trainers/trainer-0427.md) | Changed | Party |
| [School Kid Gold](../trainers/trainer-0428.md) | Changed | Name, Party |
| [Pokéfan Yellow](../trainers/trainer-0429.md) | Changed | Name, Party |
| [Youngster Pearl](../trainers/trainer-0430.md) | Changed | Name, Party |
| [Fisherman Silver](../trainers/trainer-0431.md) | Changed | Name, Party |
| [Fisherman Sid](../trainers/trainer-0432.md) | Changed | Party |
| [Fisherman Lydon](../trainers/trainer-0433.md) | Changed | Party |
| [Fisherman Jones](../trainers/trainer-0434.md) | Changed | Party |
| [Fisherman Mick](../trainers/trainer-0435.md) | Changed | Party |
| [Fisherman Pete](../trainers/trainer-0436.md) | Changed | Party |
| [Leader Vince](../trainers/trainer-0437.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Backpacker Cress](../trainers/trainer-0438.md) | Changed | Name, Party |
| [Backpacker Lora](../trainers/trainer-0439.md) | Changed | Party |
| [Leader Kumiko](../trainers/trainer-0440.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Backpacker Cilan](../trainers/trainer-0441.md) | Changed | Name, Party |
| [Backpacker Sam](../trainers/trainer-0442.md) | Changed | Party |
| [Backpacker Peter](../trainers/trainer-0443.md) | Changed | Party |
| [Leader Stephen](../trainers/trainer-0444.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Battle Girl Iris](../trainers/trainer-0445.md) | Changed | Name, Party |
| [Leader Hillary](../trainers/trainer-0446.md) | Changed | Class Id, Class Name, AI flags, AI battle items, Party |
| [Swimmer  Elesa](../trainers/trainer-0447.md) | Changed | Name, Party |
| [Backers Caroline](../trainers/trainer-0448.md) | Changed | Party |
| [Twins Fey &amp; Sue](../trainers/trainer-0449.md) | Changed | Party |
| [Veteran Emy &amp; Lin](../trainers/trainer-0450.md) | Changed | Party |
| [ Breeder Ray](../trainers/trainer-0451.md) | Changed | Party |
| [ Breeder Eustace](../trainers/trainer-0452.md) | Changed | Party |
| [ Ranger Crystal](../trainers/trainer-0453.md) | Changed | Name, Party |
| [ Ranger Red](../trainers/trainer-0454.md) | Changed | Name, Party |
| [ Ranger Shelly](../trainers/trainer-0455.md) | Changed | Party |
| [ Ranger Ruby](../trainers/trainer-0456.md) | Changed | Name, Party |
| [Lass Diamond](../trainers/trainer-0457.md) | Changed | Name, Party |
| [Leader Platinum](../trainers/trainer-0458.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party |
| [Hiker Clay](../trainers/trainer-0459.md) | Changed | Name, Party |
| [Hiker Kit](../trainers/trainer-0460.md) | Changed | Party |
| [Clerk  Jeremiah](../trainers/trainer-0461.md) | Changed | Party |
| [Clerk  Britney](../trainers/trainer-0462.md) | Changed | Party |
| [Ace Trainer Piper](../trainers/trainer-0463.md) | Changed | Party |
| [Ace Trainer Lena](../trainers/trainer-0464.md) | Changed | Party |
| [Lady Vincent](../trainers/trainer-0465.md) | Changed | Party |
| [Rich Boy Lynette](../trainers/trainer-0466.md) | Changed | Party |
| [Black Belt Pierce](../trainers/trainer-0467.md) | Changed | Party |
| [Scientist Ryder](../trainers/trainer-0468.md) | Changed | Party |
| [Scientist Jacques](../trainers/trainer-0469.md) | Changed | Party |
| [Clerk  Marie](../trainers/trainer-0470.md) | Changed | Party |
| [Clerk  Doug](../trainers/trainer-0471.md) | Changed | Party |
| [Gentleman Collin](../trainers/trainer-0472.md) | Changed | Party |
| [School Kid Federic](../trainers/trainer-0473.md) | Changed | Name, Party |
| [School Kid Leo](../trainers/trainer-0474.md) | Changed | Party |
| [Roughneck Silvia](../trainers/trainer-0475.md) | Changed | Party |
| [Youngster Dave](../trainers/trainer-0476.md) | Changed | Party |
| [Backpacker Robbie](../trainers/trainer-0477.md) | Changed | Party |
| [Backpacker Molly](../trainers/trainer-0478.md) | Changed | Party |
| [Backpacker Emi](../trainers/trainer-0479.md) | Changed | Party |
| [Backpacker Carlos](../trainers/trainer-0480.md) | Changed | Party |
| [Battle Girl Herman](../trainers/trainer-0481.md) | Changed | Party |
| [Veteran Karenna](../trainers/trainer-0482.md) | Changed | Party |
| [Veteran Rosa](../trainers/trainer-0483.md) | Changed | Party |
| [Lass Ken](../trainers/trainer-0484.md) | Changed | Party |
| [Hiker Miki](../trainers/trainer-0485.md) | Changed | Party |
| [ Ranger Gene](../trainers/trainer-0486.md) | Changed | Party |
| [ Ranger Eliza](../trainers/trainer-0487.md) | Changed | Party |
| [Socialite Ralph](../trainers/trainer-0488.md) | Changed | Party |
| [Nursery Aide Grace](../trainers/trainer-0489.md) | Changed | Party |
| [School Kid Mihko](../trainers/trainer-0490.md) | Changed | Name, Party |
| [ Trainer Shane](../trainers/trainer-0491.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0492.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0493.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0494.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0495.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0496.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Team Plasma Bianca](../trainers/trainer-0497.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0498.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0499.md) | Changed | AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0500.md) | Changed | AI flags, Party |
| [Preschooler Bianca](../trainers/trainer-0501.md) | Changed | Party |
| [Preschooler Juliet](../trainers/trainer-0502.md) | Changed | Party |
| [Harlequin Homer](../trainers/trainer-0503.md) | Changed | Party |
| [Harlequin Pat](../trainers/trainer-0504.md) | Changed | Party |
| [Parasol Lady Ian](../trainers/trainer-0505.md) | Changed | Party |
| [Motorcyclist April](../trainers/trainer-0506.md) | Changed | Party |
| [ Trainer Charles](../trainers/trainer-0507.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0508.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0509.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0510.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0511.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0512.md) | Changed | Party |
| [Ace Trainer](../trainers/trainer-0513.md) | Changed | Party |
| [Ace Trainer Eileen](../trainers/trainer-0514.md) | Changed | Party |
| [Youngster Lou](../trainers/trainer-0515.md) | Changed | Party |
| [Lass Kyle](../trainers/trainer-0516.md) | Changed | Party |
| [Lass Dye](../trainers/trainer-0517.md) | Changed | Party |
| [Ace Trainer Dye](../trainers/trainer-0518.md) | Changed | Party |
| [Ace Trainer Caroll](../trainers/trainer-0519.md) | Changed | Party |
| [The Riches Jordan](../trainers/trainer-0520.md) | Changed | Party |
| [Ace Trainer Draco](../trainers/trainer-0521.md) | Changed | Party |
| [Ace Trainer](../trainers/trainer-0522.md) | Changed | Party |
| [The Riches](../trainers/trainer-0523.md) | Changed | Party |
| [The Riches Trish](../trainers/trainer-0524.md) | Changed | Party |
| [The Riches Clairdonna](../trainers/trainer-0525.md) | Changed | Party |
| [Scientist Zillion](../trainers/trainer-0526.md) | Changed | Party |
| [Biker Dudley](../trainers/trainer-0527.md) | Changed | Party |
| [Backpacker](../trainers/trainer-0528.md) | Changed | Party |
| [School Kid Kiyo](../trainers/trainer-0529.md) | Changed | Party |
| [Nursery Aide Shaye](../trainers/trainer-0530.md) | Changed | Party |
| [ Ranger Briana](../trainers/trainer-0531.md) | Changed | Party |
| [ Ranger Brenda](../trainers/trainer-0532.md) | Changed | Party |
| [Fisherman Claude](../trainers/trainer-0533.md) | Changed | Party |
| [Ace Trainer Sean](../trainers/trainer-0534.md) | Changed | Party |
| [Hiker](../trainers/trainer-0535.md) | Changed | Party |
| [Preschooler Andy](../trainers/trainer-0536.md) | Changed | Party |
| [Dancer Winter](../trainers/trainer-0537.md) | Changed | Party |
| [Waitress Dirk](../trainers/trainer-0538.md) | Changed | Party |
| [ Trainer Aurora](../trainers/trainer-0539.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0540.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0541.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [GAME FREAK Cheren](../trainers/trainer-0542.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [Maid Morimoto](../trainers/trainer-0543.md) | Changed | Party |
| [Biker Tanya](../trainers/trainer-0544.md) | Changed | Party |
| [Biker Morgann](../trainers/trainer-0545.md) | Changed | Party |
| [Nurse Jeremy](../trainers/trainer-0546.md) | Changed | Party |
| [The Riches Shery](../trainers/trainer-0547.md) | Changed | Party |
| [The Riches Susan](../trainers/trainer-0548.md) | Changed | Party |
| [ Ranger Miles](../trainers/trainer-0549.md) | Changed | Party |
| [ Ranger Mylene](../trainers/trainer-0550.md) | Changed | Party |
| [Baker Jaden](../trainers/trainer-0551.md) | Changed | Party |
| [Team Plasma Chris](../trainers/trainer-0552.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0553.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0554.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0555.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0556.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0557.md) | Changed | Party |
| [ Trainer Grunt](../trainers/trainer-0558.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0559.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0560.md) | Changed | Party |
| [ Trainer](../trainers/trainer-0561.md) | Changed | Party |
| [Veteran](../trainers/trainer-0562.md) | Changed | Party |
| [Elite Four](../trainers/trainer-0563.md) | Changed | AI flags, Party |
| [Elite Four Shauntal](../trainers/trainer-0564.md) | Changed | AI flags, Party |
| [Elite Four Marshal](../trainers/trainer-0565.md) | Changed | AI flags, Party |
| [Elite Four Grimsley](../trainers/trainer-0566.md) | Changed | AI flags, Party |
| [ Trainer Caitlin](../trainers/trainer-0567.md) | Changed | AI flags, Party |
| [Swimmer  Cynthia](../trainers/trainer-0568.md) | Changed | Party |
| [Swimmer  Matt](../trainers/trainer-0569.md) | Changed | Party |
| [Swimmer  Bart](../trainers/trainer-0570.md) | Changed | Party |
| [Swimmer  Tim](../trainers/trainer-0571.md) | Changed | Party |
| [Swimmer  Rebecca](../trainers/trainer-0572.md) | Changed | Party |
| [Swimmer  Tyra](../trainers/trainer-0573.md) | Changed | Party |
| [Lass Larissa](../trainers/trainer-0574.md) | Changed | Party |
| [Leader Maki](../trainers/trainer-0575.md) | Changed | Class Id, Class Name, Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Youngster Chili](../trainers/trainer-0576.md) | Changed | Name, Party |
| [Backpacker Emerald](../trainers/trainer-0577.md) | Changed | Name, Party |
| [Backpacker Sapphire](../trainers/trainer-0578.md) | Changed | Name, Party |
| [School Kid Toru](../trainers/trainer-0579.md) | Changed | AI flags, Party |
| [Leader Blue](../trainers/trainer-0580.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party |
| [Lass Lenora](../trainers/trainer-0581.md) | Changed | Name, Party |
| [ Ranger Lurleen](../trainers/trainer-0582.md) | Changed | Party |
| [ Ranger Chloris](../trainers/trainer-0583.md) | Changed | Party |
| [Fisherman Harry](../trainers/trainer-0584.md) | Changed | Party |
| [Parasol Lady Damon](../trainers/trainer-0585.md) | Changed | Party |
| [Team Plasma Mariah](../trainers/trainer-0586.md) | Changed | Party |
| [Team Plasma N](../trainers/trainer-0587.md) | Changed | Party |
| [ Trainer N](../trainers/trainer-0588.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0589.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0590.md) | Changed | AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0591.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0592.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0593.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Cheren](../trainers/trainer-0594.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0595.md) | Changed | Battle Mode, Double Battle, AI flags, Party |
| [ Trainer Bianca](../trainers/trainer-0596.md) | Changed | Battle Mode, Double Battle, AI flags, AI battle items, Party |
| [Team Plasma Bianca](../trainers/trainer-0597.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0598.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0599.md) | Changed | Party |
| [Dancer Grunt](../trainers/trainer-0600.md) | Changed | Party |
| [Dancer Mickey](../trainers/trainer-0601.md) | Changed | Party |
| [Dancer Raymond](../trainers/trainer-0602.md) | Changed | Party |
| [Motorcyclist Edmond](../trainers/trainer-0603.md) | Changed | Party |
| [Ace Trainer Charles](../trainers/trainer-0604.md) | Changed | Party |
| [Ace Trainer Eileen](../trainers/trainer-0605.md) | Changed | Party |
| [Ace Trainer Lou](../trainers/trainer-0606.md) | Changed | Party |
| [Ace Trainer Elmer](../trainers/trainer-0607.md) | Changed | Party |
| [Ace Trainer Elmer](../trainers/trainer-0608.md) | Changed | Party |
| [Ace Trainer Glinda](../trainers/trainer-0609.md) | Changed | Party |
| [Team Plasma Glinda](../trainers/trainer-0610.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0611.md) | Changed | Party |
| [Team Plasma Grunt](../trainers/trainer-0612.md) | Changed | Party |
| [Doctor Grunt](../trainers/trainer-0613.md) | Changed | Party |
| [Subway Boss Jerry](../trainers/trainer-0614.md) | Changed | Party |
| [Roughneck Emmet](../trainers/trainer-0615.md) | Changed | Party |

## Locations

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Striaton City](../locations/header-010.md) | Changed | Script Awarded Items |
| [Striaton City](../locations/header-015.md) | Changed | Script Awarded Items |
| [Nacrene City](../locations/header-016.md) | Changed | Script Awarded Items |
| [Nacrene City](../locations/header-023.md) | Changed | Npc Trades (blaze-black), Npc Trades (volt-white) |
| [Castelia City](../locations/header-029.md) | Changed | Script Awarded Items |
| [Castelia City](../locations/header-040.md) | Changed | Script Awarded Items |
| [Castelia City](../locations/header-045.md) | Changed | Script Awarded Items |
| [Castelia City](../locations/header-046.md) | Changed | Script Awarded Items |
| [Nimbasa City](../locations/header-062.md) | Changed | Script Awarded Items |
| [Nimbasa City](../locations/header-063.md) | Changed | Script Awarded Items |
| [Gear Station](../locations/header-066.md) | Changed | Static Encounters |
| [Nimbasa Gate](../locations/header-090.md) | Changed | Script Awarded Items |
| [Nimbasa City](../locations/header-095.md) | Changed | Script Awarded Items |
| [Driftveil City](../locations/header-096.md) | Changed | Script Awarded Items |
| [Driftveil City](../locations/header-101.md) | Changed | Npc Trades (blaze-black), Npc Trades (volt-white) |
| [Icirrus City](../locations/header-113.md) | Changed | Items |
| [Icirrus City](../locations/header-114.md) | Changed | Script Awarded Items |
| [Dreamyard](../locations/header-152.md) | Changed | Items, Script Awarded Items |
| [Dreamyard](../locations/header-153.md) | Changed | Static Encounters |
| [Pinwheel Forest](../locations/header-155.md) | Changed | Items, Script Awarded Items |
| [Rumination Field](../locations/header-156.md) | Changed | Static Encounters |
| [Desert Resort](../locations/header-158.md) | Changed | Items |
| [Relic Castle](../locations/header-160.md) | Changed | Script Awarded Items |
| [Relic Castle](../locations/header-162.md) | Changed | Items |
| [Relic Castle](../locations/header-181.md) | Changed | Script Awarded Items |
| [Relic Castle](../locations/header-182.md) | Changed | Static Encounters |
| [Cold Storage](../locations/header-192.md) | Changed | Items |
| [Cold Storage](../locations/header-193.md) | Changed | Items, Script Awarded Items |
| [Chargestone Cave](../locations/header-195.md) | Changed | Script Awarded Items |
| [Chargestone Cave](../locations/header-197.md) | Changed | Items, Script Awarded Items |
| [Dragonspiral Tower](../locations/header-211.md) | Changed | Items |
| [Dragonspiral Tower](../locations/header-213.md) | Changed | Static Encounters |
| [Victory Road](../locations/header-214.md) | Changed | Items |
| [Trial Chamber](../locations/header-229.md) | Changed | Static Encounters |
| [Giant Chasm](../locations/header-232.md) | Changed | Items |
| [Liberty Garden](../locations/header-237.md) | Changed | Static Encounters |
| [Abyssal Ruins](../locations/header-248.md) | Changed | Items |
| [Tubeline Bridge](../locations/header-254.md) | Changed | Script Awarded Items |
| [N's Castle](../locations/header-278.md) | Changed | Static Encounters |
| [Route 1](../locations/header-317.md) | Changed | Items |
| [Route 3](../locations/header-321.md) | Changed | Items, Script Awarded Items |
| [Route 4](../locations/header-326.md) | Changed | Items |
| [Route 5](../locations/header-329.md) | Changed | Items |
| [Route 6](../locations/header-331.md) | Changed | Items |
| [Route 6](../locations/header-332.md) | Changed | Script Awarded Items |
| [Mistralton Cave](../locations/header-333.md) | Changed | Items |
| [Guidance Chamber](../locations/header-335.md) | Changed | Items, Static Encounters |
| [Route 6](../locations/header-336.md) | Changed | Script Awarded Items |
| [Route 7](../locations/header-337.md) | Changed | Items |
| [Celestial Tower](../locations/header-340.md) | Changed | Items |
| [Route 7](../locations/header-343.md) | Changed | Npc Trades |
| [Moor of Icirrus](../locations/header-346.md) | Changed | Items |
| [Challenger's Cave](../locations/header-353.md) | Changed | Items |
| [Challenger's Cave](../locations/header-354.md) | Changed | Items |
| [Route 10](../locations/header-355.md) | Changed | Items |
| [Route 12](../locations/header-368.md) | Changed | Items |
| [Route 13](../locations/header-370.md) | Changed | Items, Script Awarded Items |
| [Route 14](../locations/header-374.md) | Changed | Items, Script Awarded Items |
| [Abundant Shrine](../locations/header-376.md) | Changed | Items, Static Encounters |
| [Route 15](../locations/header-378.md) | Changed | Items |
| [Route 15](../locations/header-382.md) | Changed | Npc Trades |
| [Route 16](../locations/header-383.md) | Changed | Items |
| [Route 18](../locations/header-387.md) | Changed | Items, Script Awarded Items |
| [Nuvema Town](../locations/header-390.md) | Changed | Script Awarded Items |
| [Undella Town](../locations/header-415.md) | Changed | Npc Trades |
