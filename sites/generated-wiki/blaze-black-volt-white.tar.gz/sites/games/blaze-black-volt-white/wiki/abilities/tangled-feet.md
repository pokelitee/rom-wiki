# Tangled Feet

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>77</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Doubles evasion when confused.</strong></p>
<p>When this Pokémon is confused, it has twice its evasion.</p>

<figure class="rw-pokedex-entry">
<blockquote>Raises evasion if the Pokémon is confused.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/18.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeot](../pokemon/pidgeot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/441.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chatot](../pokemon/chatot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 ability slot change</p><ul class="rw-comparison-list"><li><a href="../../pokemon/doduo/">Doduo</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul><p class="rw-comparison-count">1 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/spinda/">Spinda</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/77/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../air-lock/"><span class="rw-record-nav__label">← Air Lock</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../motor-drive/"><span class="rw-record-nav__label">Motor Drive →</span></a>
</nav>
