# Stall

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>100</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">0</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Makes the Pokémon move last within its move&#x27;s priority bracket.</strong></p>
<p>This Pokémon moves last within its priority bracket. Multiple Pokémon with this ability move in order of Speed amongst themselves. The Full Incense and Lagging Tail take precedence over this ability; that is, Pokémon with these items move after Pokémon with this ability. Pokémon with both this ability and one of these items are delayed as much as if they had only the item. This ability works as usual during Trick Room: Pokémon with this ability will move in reverse order of Speed after Pokémon without it.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon moves after all other Pokémon do.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

No Pokémon are assigned this ability.

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-us / white-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sableye/">Sableye</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/100/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../no-guard/"><span class="rw-record-nav__label">← No Guard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../technician/"><span class="rw-record-nav__label">Technician →</span></a>
</nav>
