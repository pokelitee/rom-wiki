# Damp

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>6</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">10</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents Self-Destruct, Explosion, and Aftermath from working while the Pokémon is in battle.</strong></p>
<p>While this Pokémon is in battle, Self-Destruct and Explosion will fail and Aftermath will not take effect.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents the use of self-destructing moves.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/46.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Paras](../pokemon/paras.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/230.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingdra](../pokemon/kingdra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/258.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mudkip](../pokemon/mudkip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/259.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marshtomp](../pokemon/marshtomp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/260.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swampert](../pokemon/swampert.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/592.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Frillish](../pokemon/frillish-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/593.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jellicent](../pokemon/jellicent-male.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">8 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a></li><li><a href="../../pokemon/golduck/">Golduck</a></li><li><a href="../../pokemon/poliwag/">Poliwag</a></li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a></li><li><a href="../../pokemon/poliwrath/">Poliwrath</a></li><li><a href="../../pokemon/politoed/">Politoed</a></li><li><a href="../../pokemon/wooper/">Wooper</a></li><li><a href="../../pokemon/quagsire/">Quagsire</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/6/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sturdy/"><span class="rw-record-nav__label">← Sturdy</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../limber/"><span class="rw-record-nav__label">Limber →</span></a>
</nav>
