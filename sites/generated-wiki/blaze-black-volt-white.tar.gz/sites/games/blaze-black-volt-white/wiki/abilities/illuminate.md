# Illuminate

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>35</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">0</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Doubles the wild encounter rate.</strong></p>
<p>Overworld: If the lead Pokémon has this ability, the wild encounter rate is doubled. This ability has no effect in battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>Raises the likelihood of meeting wild Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

No Pokémon are assigned this ability.

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-us / white-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">6 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staryu/">Staryu</a></li><li><a href="../../pokemon/starmie/">Starmie</a></li><li><a href="../../pokemon/chinchou/">Chinchou</a></li><li><a href="../../pokemon/lanturn/">Lanturn</a></li><li><a href="../../pokemon/volbeat/">Volbeat</a></li><li><a href="../../pokemon/watchog/">Watchog</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/35/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../chlorophyll/"><span class="rw-record-nav__label">← Chlorophyll</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../trace/"><span class="rw-record-nav__label">Trace →</span></a>
</nav>
