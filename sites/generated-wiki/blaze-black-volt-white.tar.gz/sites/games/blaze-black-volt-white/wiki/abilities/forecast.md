# Forecast

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>59</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Changes Castform&#x27;s type and form to match the weather.</strong></p>
<p>During rain, strong sunlight, or hail, this Pokémon&#x27;s type changes to Water, Fire, or Ice, respectively, and its form changes to match. This ability has no effect for any Pokémon other than Castform. If the weather ends or becomes anything that does not trigger this ability, or a Pokémon with Air Lock or Cloud Nine enters battle, this Pokémon&#x27;s type and form revert to their default. If this ability is lost or disabled, this Pokémon cannot change its current type and form until it regains its ability.</p>

<figure class="rw-pokedex-entry">
<blockquote>Castform transforms with the weather.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/351.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Castform](../pokemon/castform.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |

## Hack changes

Verified unchanged from **black-us / white-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/59/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../minus/"><span class="rw-record-nav__label">← Minus</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sticky-hold/"><span class="rw-record-nav__label">Sticky Hold →</span></a>
</nav>
