# Sturdy

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>5</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">38</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents being KOed from full HP, leaving 1 HP instead. Protects against the one-hit KO moves regardless of HP.</strong></p>
<p>When this Pokémon is at full HP, any hit that would knock it out will instead leave it with 1 HP. Regardless of its current HP, it is also immune to the one-hit KO moves: Fissure, Guillotine, Horn Drill, and Sheer Cold. If this Pokémon is holding a Focus Sash, this ability takes precedence and the item will not be consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>It cannot be knocked out with one hit.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/7.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Squirtle](../pokemon/squirtle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/8.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wartortle](../pokemon/wartortle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/9.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blastoise](../pokemon/blastoise.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/95.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Onix](../pokemon/onix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/185.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sudowoodo](../pokemon/sudowoodo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/205.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Forretress](../pokemon/forretress.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/213.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuckle](../pokemon/shuckle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/304.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/306.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aggron](../pokemon/aggron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/369.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Relicanth](../pokemon/relicanth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/377.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Regirock](../pokemon/regirock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/379.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Registeel](../pokemon/registeel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/387.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Turtwig](../pokemon/turtwig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/388.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grotle](../pokemon/grotle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/389.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torterra](../pokemon/torterra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/410.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shieldon](../pokemon/shieldon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/411.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bastiodon](../pokemon/bastiodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/438.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bonsly](../pokemon/bonsly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/476.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Probopass](../pokemon/probopass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--steel">Steel</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/524.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Roggenrola](../pokemon/roggenrola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/526.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gigalith](../pokemon/gigalith.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/539.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawk](../pokemon/sawk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/557.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dwebble](../pokemon/dwebble.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/558.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crustle](../pokemon/crustle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/564.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tirtouga](../pokemon/tirtouga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/565.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carracosta](../pokemon/carracosta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10005.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wormadam Trash](../pokemon/wormadam-trash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-us / white-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 ability slot change</p><ul class="rw-comparison-list"><li><a href="../../pokemon/relicanth/">Relicanth</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul><p class="rw-comparison-count">3 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magnemite/">Magnemite</a></li><li><a href="../../pokemon/magneton/">Magneton</a></li><li><a href="../../pokemon/magnezone/">Magnezone</a></li></ul><p class="rw-comparison-count">9 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/squirtle/">Squirtle</a></li><li><a href="../../pokemon/wartortle/">Wartortle</a></li><li><a href="../../pokemon/blastoise/">Blastoise</a></li><li><a href="../../pokemon/torkoal/">Torkoal</a></li><li><a href="../../pokemon/registeel/">Registeel</a></li><li><a href="../../pokemon/turtwig/">Turtwig</a></li><li><a href="../../pokemon/grotle/">Grotle</a></li><li><a href="../../pokemon/torterra/">Torterra</a></li><li><a href="../../pokemon/wormadam-trash/">Wormadam Trash</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/5/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../battle-armor/"><span class="rw-record-nav__label">← Battle Armor</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../damp/"><span class="rw-record-nav__label">Damp →</span></a>
</nav>
