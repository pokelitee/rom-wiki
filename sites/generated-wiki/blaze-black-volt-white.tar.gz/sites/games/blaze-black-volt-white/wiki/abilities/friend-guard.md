# Friend Guard

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>132</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">5</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Decreases all direct damage taken by friendly Pokémon to 0.75×.</strong></p>
<p>All friendly Pokémon take 0.75× as much direct damage from moves while this Pokémon is in battle. This effect stacks if multiple allied Pokémon have it.</p>

<figure class="rw-pokedex-entry">
<blockquote>Reduces damage done to allies.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/173.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cleffa](../pokemon/cleffa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/174.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Igglybuff](../pokemon/igglybuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/cleffa/">Cleffa</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/igglybuff/">Igglybuff</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/happiny/">Happiny</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/132/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../healer/"><span class="rw-record-nav__label">← Healer</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../weak-armor/"><span class="rw-record-nav__label">Weak Armor →</span></a>
</nav>
