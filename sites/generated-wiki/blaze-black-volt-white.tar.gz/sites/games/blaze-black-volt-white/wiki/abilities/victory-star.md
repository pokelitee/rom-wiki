# Victory Star

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>162</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases moves&#x27; accuracy to 1.1× for friendly Pokémon.</strong></p>
<p>All friendly Pokémon&#x27;s moves, including this Pokémon&#x27;s own moves, have 1.1× their usual accuracy while this Pokémon is in battle.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the accuracy of its allies and itself.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/494.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Victini](../pokemon/victini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--fire">Fire</span></span> | 1 |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-us / white-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/162/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../zen-mode/"><span class="rw-record-nav__label">← Zen Mode</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../turboblaze/"><span class="rw-record-nav__label">Turboblaze →</span></a>
</nav>
