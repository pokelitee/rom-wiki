# Slow Start

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>112</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Halves Attack and Speed for five turns upon entering battle.</strong></p>
<p>This Pokémon&#x27;s Attack and Speed are halved for five turns upon entering battle. This ability also takes effect when acquired during battle. If this Pokémon loses its ability before the five turns are up, its Attack and Speed return to normal; if it then regains this ability without leaving battle, its Attack and Speed are halved again, but the counter keeps counting from where it was.</p>

<figure class="rw-pokedex-entry">
<blockquote>Temporarily halves Attack and Speed.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/287.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slakoth](../pokemon/slakoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/289.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slaking](../pokemon/slaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/regigigas/">Regigigas</a></li></ul><p class="rw-comparison-count">2 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slakoth/">Slakoth</a></li><li><a href="../../pokemon/slaking/">Slaking</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/112/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../filter/"><span class="rw-record-nav__label">← Filter</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../scrappy/"><span class="rw-record-nav__label">Scrappy →</span></a>
</nav>
