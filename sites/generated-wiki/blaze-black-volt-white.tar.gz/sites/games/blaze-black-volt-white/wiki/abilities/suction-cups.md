# Suction Cups

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>21</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">3</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents being forced out of battle by other Pokémon&#x27;s moves.</strong></p>
<p>This Pokémon cannot be forced out of battle by moves such as Whirlwind. Dragon Tail and Circle Throw still inflict damage against this Pokémon. Overworld: If the lead Pokémon has this ability, the success rate while fishing is increased.</p>

<figure class="rw-pokedex-entry">
<blockquote>Negates all moves that force switching out.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/345.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lileep](../pokemon/lileep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/346.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cradily](../pokemon/cradily.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--grass">Grass</span></span> | 1 |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/octillery/">Octillery</a></li></ul><p class="rw-comparison-count">1 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/0/2` member `182`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/21/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../own-tempo/"><span class="rw-record-nav__label">← Own Tempo</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../intimidate/"><span class="rw-record-nav__label">Intimidate →</span></a>
</nav>
