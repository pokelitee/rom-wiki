# White Smoke

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>73</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">2</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents stats from being lowered by other Pokémon.</strong></p>
<p>This Pokémon cannot have its stats lowered by other Pokémon. This ability does not prevent any stat losses other than stat modifiers, such as the Speed cut from paralysis; nor self-inflicted stat drops, such as the Special Attack drop from Overheat; nor opponent-triggered stat boosts, such as the Attack boost from Swagger. This Pokémon can still be passed negative stat modifiers through Guard Swap, Heart Swap, or Power Swap. This ability functions identically to Clear Body in battle. Overworld: If the lead Pokémon has this ability, the wild encounter rate is halved.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents other Pokémon from lowering its stats.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/631.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heatmor](../pokemon/heatmor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-us / white-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 ability slot change</p><ul class="rw-comparison-list"><li><a href="../../pokemon/heatmor/">Heatmor</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `182`.
Ability description source: ROM message table `a/0/0/2` member `183`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/73/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../vital-spirit/"><span class="rw-record-nav__label">← Vital Spirit</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../pure-power/"><span class="rw-record-nav__label">Pure Power →</span></a>
</nav>
