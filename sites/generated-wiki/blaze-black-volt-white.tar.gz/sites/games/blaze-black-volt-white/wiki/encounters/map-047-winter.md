# Twist Mountain

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>62</dd></div>
<div><dt>Map index</dt><dd>47</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Twist Mountain](../locations/header-203.md) | 203 | Blaze Black / Volt White |

## Grass/Cave

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 44–52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 44–52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 44–52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/225.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 44–52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 44–52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/303.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 44–52 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/302.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 44–52 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/615.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cryogonal](../pokemon/cryogonal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 44–52 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/632.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Durant](../pokemon/durant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 44–52 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/378.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Regice](../pokemon/regice.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 50 | 1% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/530.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Excadrill](../pokemon/excadrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--steel">Steel</span></span> | 44–52 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–52 | 50% |

## Same-name encounter areas

These encounter tables resolve to the same map-header display name. A shared map index identifies seasonal variants; a shared name alone does not establish that two maps are the same area.

| Map index | Season | Relationship | Encounter table |
| --------: | ------ | ------------ | --------------- |
| 44 | Spring | Same display name | [Map 044 (Spring)](map-044-spring.md) |
| 44 | Summer | Same display name | [Map 044 (Summer)](map-044-summer.md) |
| 44 | Autumn | Same display name | [Map 044 (Autumn)](map-044-autumn.md) |
| 44 | Winter | Same display name | [Map 044 (Winter)](map-044-winter.md) |
| 45 | Spring | Same display name | [Map 045 (Spring)](map-045-spring.md) |
| 45 | Summer | Same display name | [Map 045 (Summer)](map-045-summer.md) |
| 45 | Autumn | Same display name | [Map 045 (Autumn)](map-045-autumn.md) |
| 45 | Winter | Same display name | [Map 045 (Winter)](map-045-winter.md) |
| 46 | Spring | Same display name | [Map 046 (Spring)](map-046-spring.md) |
| 46 | Summer | Same display name | [Map 046 (Summer)](map-046-summer.md) |
| 46 | Autumn | Same display name | [Map 046 (Autumn)](map-046-autumn.md) |
| 46 | Winter | Same display name | [Map 046 (Winter)](map-046-winter.md) |
| 47 | Spring | Seasonal variant | [Map 047 (Spring)](map-047-spring.md) |
| 47 | Summer | Seasonal variant | [Map 047 (Summer)](map-047-summer.md) |
| 47 | Autumn | Seasonal variant | [Map 047 (Autumn)](map-047-autumn.md) |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Woobat — Lv. 30</li><li>Cryogonal — Lv. 31</li><li>Gurdurr — Lv. 29</li><li>Cubchoo — Lv. 29</li><li>Boldore — Lv. 30</li><li>Cubchoo — Lv. 30</li><li>Cubchoo — Lv. 28</li><li>Boldore — Lv. 29</li><li>Woobat — Lv. 29</li><li>Cryogonal — Lv. 31</li><li>Woobat — Lv. 28</li><li>Cubchoo — Lv. 31</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Regice — Lv. 50</li><li>Cryogonal — Lv. 44–52</li><li>Sneasel — Lv. 44–52</li><li>Piloswine — Lv. 44–52</li><li>Delibird — Lv. 44–52</li><li>Beartic — Lv. 44–52</li><li>Ursaring — Lv. 44–52</li><li>Donphan — Lv. 44–52</li><li>Cryogonal — Lv. 44–52</li><li>Durant — Lv. 44–52</li><li>Sableye — Lv. 44–52</li><li>Mawile — Lv. 44–52</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">6 entries removed</p><ul class="rw-comparison-list"><li>Drilbur — Lv. 31</li><li>Drilbur — Lv. 29</li><li>Drilbur — Lv. 30</li><li>Drilbur — Lv. 28</li><li>Drilbur — Lv. 31</li><li>Drilbur — Lv. 31</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li>Dugtrio — Lv. 44–52</li><li>Excadrill — Lv. 44–52</li><li>Dugtrio — Lv. 44–52</li><li>Excadrill — Lv. 44–52</li><li>Dugtrio — Lv. 44–52</li><li>Excadrill — Lv. 44–52</li><li>Dugtrio — Lv. 44–52</li><li>Excadrill — Lv. 44–52</li><li>Dugtrio — Lv. 44–52</li><li>Excadrill — Lv. 44–52</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `47`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-047-autumn/"><span class="rw-record-nav__label">← Twist Mountain</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-048-spring/"><span class="rw-record-nav__label">Dragonspiral Tower →</span></a>
</nav>
