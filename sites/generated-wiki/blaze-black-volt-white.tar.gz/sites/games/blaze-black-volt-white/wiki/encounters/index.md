# Wild encounters

Exact encounter tables decoded from the ROM's own wild-encounter archive.

<div class="rw-catalog" data-rw-catalog="catalog.json" data-rw-kind="encounters" aria-busy="true">
<p class="rw-catalog__status" data-rw-catalog-status role="status" aria-live="polite"><span class="rw-visually-hidden">Loading catalog&hellip;</span></p>
<div class="rw-catalog__skeleton" data-rw-catalog-skeleton aria-hidden="true">
<div class="rw-skeleton__controls">
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
<span class="rw-skeleton__field"></span>
</div>
<span class="rw-skeleton__bar"></span>
<div class="rw-skeleton__table">
<div class="rw-skeleton__table-row rw-skeleton__table-row--head"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
<div class="rw-skeleton__table-row"><span class="rw-skeleton__cell"></span></div>
</div>
</div>
</div>

<div class="rw-catalog-fallback" data-rw-catalog-fallback>

## All records

- [Striaton City — map_6](map-000.md)
- [Driftveil City — map_96](map-001.md)
- [Icirrus City — map_113](map-002.md)
- [Dreamyard — map_152](map-003.md)
- [Dreamyard — map_153](map-004.md)
- [Pinwheel Forest — map_154](map-005.md)
- [Pinwheel Forest — map_155](map-006.md)
- [Desert Resort — map_157](map-007.md)
- [Desert Resort — map_158](map-008.md)
- [Relic Castle — map_160](map-009.md)
- [Relic Castle — map_161](map-010.md)
- [Relic Castle — map_162](map-011.md)
- [Relic Castle — map_163](map-012.md)
- [Relic Castle — map_164](map-013.md)
- [Relic Castle — map_165](map-014.md)
- [Relic Castle — map_166](map-015.md)
- [Relic Castle — map_167](map-016.md)
- [Relic Castle — map_168](map-017.md)
- [Relic Castle — map_169](map-018.md)
- [Relic Castle — map_170](map-019.md)
- [Relic Castle — map_171](map-020.md)
- [Relic Castle — map_172](map-021.md)
- [Relic Castle — map_173](map-022.md)
- [Relic Castle — map_174](map-023.md)
- [Relic Castle — map_175](map-024.md)
- [Relic Castle — map_176](map-025.md)
- [Relic Castle — map_177](map-026.md)
- [Relic Castle — map_178](map-027.md)
- [Relic Castle — map_179](map-028.md)
- [Relic Castle — map_180](map-029.md)
- [Relic Castle — map_181](map-030.md)
- [Relic Castle — map_182](map-031.md)
- [Relic Castle — map_183](map-032.md)
- [Relic Castle — map_184](map-033.md)
- [Relic Castle — map_185](map-034.md)
- [Relic Castle — map_186](map-035.md)
- [Relic Castle — map_187](map-036.md)
- [Relic Castle — map_188](map-037.md)
- [Relic Castle — map_189](map-038.md)
- [Relic Castle — map_190](map-039.md)
- [Cold Storage — map_191](map-040.md)
- [Chargestone Cave — map_195](map-041.md)
- [Chargestone Cave — map_196](map-042.md)
- [Chargestone Cave — map_197](map-043.md)
- [Twist Mountain — map_200](map-044.md)
- [Twist Mountain — map_201](map-045.md)
- [Twist Mountain — map_202](map-046.md)
- [Twist Mountain — map_203](map-047.md)
- [Dragonspiral Tower — map_205](map-048.md)
- [Dragonspiral Tower — map_206](map-049.md)
- [Dragonspiral Tower — map_207](map-050.md)
- [Dragonspiral Tower — map_208](map-051.md)
- [Victory Road — map_214](map-052.md)
- [Victory Road — map_215](map-053.md)
- [Victory Road — map_216](map-054.md)
- [Victory Road — map_217](map-055.md)
- [Victory Road — map_218](map-056.md)
- [Victory Road — map_219](map-057.md)
- [Victory Road — map_220](map-058.md)
- [Victory Road — map_221](map-059.md)
- [Victory Road — map_222](map-060.md)
- [Victory Road — map_223](map-061.md)
- [Victory Road — map_224](map-062.md)
- [Victory Road — map_225](map-063.md)
- [Victory Road — map_226](map-064.md)
- [Victory Road — map_227](map-065.md)
- [Victory Road — map_228](map-066.md)
- [Trial Chamber — map_229](map-067.md)
- [Giant Chasm — map_230](map-068.md)
- [Giant Chasm — map_231](map-069.md)
- [Giant Chasm — map_232](map-070.md)
- [Giant Chasm — map_234](map-071.md)
- [P2 Laboratory — map_238](map-072.md)
- [Undella Bay — map_240](map-073.md)
- [Driftveil Drawbridge — map_253](map-074.md)
- [Village Bridge — map_255](map-075.md)
- [Marvelous Bridge — map_263](map-076.md)
- [Route 1 — map_317](map-077.md)
- [Route 2 — map_319](map-078.md)
- [Route 3 — map_321](map-079.md)
- [Wellspring Cave — map_324](map-080.md)
- [Wellspring Cave — map_325](map-081.md)
- [Route 4 — map_326](map-082.md)
- [Route 5 — map_329](map-083.md)
- [Route 6 — map_331](map-084.md)
- [Mistralton Cave — map_333](map-085.md)
- [Mistralton Cave — map_334](map-086.md)
- [Guidance Chamber — map_335](map-087.md)
- [Route 7 — map_337](map-088.md)
- [Celestial Tower — map_339](map-089.md)
- [Celestial Tower — map_340](map-090.md)
- [Celestial Tower — map_341](map-091.md)
- [Celestial Tower — map_342](map-092.md)
- [Route 8 — map_345](map-093.md)
- [Moor of Icirrus — map_346](map-094.md)
- [Route 9 — map_348](map-095.md)
- [Challenger's Cave — map_352](map-096.md)
- [Challenger's Cave — map_353](map-097.md)
- [Challenger's Cave — map_354](map-098.md)
- [Route 10 — map_355](map-099.md)
- [Route 10 — map_358](map-100.md)
- [Route 11 — map_365](map-101.md)
- [Route 12 — map_368](map-102.md)
- [Route 13 — map_370](map-103.md)
- [Route 14 — map_374](map-104.md)
- [Abundant Shrine — map_376](map-105.md)
- [Route 15 — map_378](map-106.md)
- [Route 16 — map_383](map-107.md)
- [Lostlorn Forest — map_385](map-108.md)
- [Route 18 — map_387](map-109.md)
- [Undella Town — map_412](map-110.md)
- [Route 17 — map_423](map-111.md)

</div>
