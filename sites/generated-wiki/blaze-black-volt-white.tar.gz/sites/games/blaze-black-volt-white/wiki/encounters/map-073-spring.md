# Undella Bay

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>94</dd></div>
<div><dt>Map index</dt><dd>73</dd></div>
<div><dt>Season</dt><dd>Spring</dd></div>
<div><dt>Methods</dt><dd>Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Undella Bay](../locations/header-240.md) | 240 | Blaze Black / Volt White |

## Surfing

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/458.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mantyke](../pokemon/mantyke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 58–60 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/320.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailmer](../pokemon/wailmer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 58–60 | 40% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/226.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mantine](../pokemon/mantine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 63–65 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/321.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailord](../pokemon/wailord.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 63–65 | 40% |

## Fishing

Encounter rate: 80

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 58–60 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 58–60 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 58–60 | 5% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 63–65 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 63–65 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/224.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 63–65 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/91.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cloyster](../pokemon/cloyster.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 63–65 | 5% |

## Hack changes

Compared with **black-us / white-us**.

<details markdown="1">
<summary>4 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Pelipper — Lv. 25–55</li><li>Mantyke — Lv. 25–55</li><li>Pelipper — Lv. 25–55</li><li>Pelipper — Lv. 25–55</li><li>Wingull — Lv. 25–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Wailmer — Lv. 58–60</li><li>Wailmer — Lv. 58–60</li><li>Wailmer — Lv. 58–60</li><li>Wailmer — Lv. 58–60</li><li>Mantyke — Lv. 58–60</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Wailord — Lv. 35–70</li><li>Wailmer — Lv. 25–60</li><li>Wailord — Lv. 35–70</li><li>Mantine — Lv. 35–70</li><li>Wailmer — Lv. 25–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Wailord — Lv. 63–65</li><li>Wailord — Lv. 63–65</li><li>Wailord — Lv. 63–65</li><li>Wailord — Lv. 63–65</li><li>Mantine — Lv. 63–65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Luvdisc — Lv. 35–55</li><li>Shellder — Lv. 35–55</li><li>Luvdisc — Lv. 35–55</li><li>Remoraid — Lv. 35–55</li><li>Remoraid — Lv. 35–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Luvdisc — Lv. 58–60</li><li>Shellder — Lv. 58–60</li><li>Luvdisc — Lv. 58–60</li><li>Remoraid — Lv. 58–60</li><li>Remoraid — Lv. 58–60</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Cloyster — Lv. 45–70</li><li>Luvdisc — Lv. 35–60</li><li>Cloyster — Lv. 45–70</li><li>Octillery — Lv. 35–70</li><li>Shellder — Lv. 35–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Cloyster — Lv. 63–65</li><li>Luvdisc — Lv. 63–65</li><li>Cloyster — Lv. 63–65</li><li>Octillery — Lv. 63–65</li><li>Shellder — Lv. 63–65</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `73`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-072/"><span class="rw-record-nav__label">← P2 Laboratory</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-073-summer/"><span class="rw-record-nav__label">Undella Bay →</span></a>
</nav>
