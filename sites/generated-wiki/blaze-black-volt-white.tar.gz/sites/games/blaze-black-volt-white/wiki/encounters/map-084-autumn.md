# Route 6

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>110</dd></div>
<div><dt>Map index</dt><dd>84</dd></div>
<div><dt>Season</dt><dd>Autumn</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Route 6](../locations/header-331.md) | 331 | Blaze Black / Volt White |

## Grass/Cave

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 29–32 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 29–32 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29–32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 29–32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 29–32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 29–32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/439.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 29–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/438.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bonsly](../pokemon/bonsly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 29–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 29–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 29–32 | 5% |

## Doubles Grass

Encounter rate: 8

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 34–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 34–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 34–36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/590.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Foongus](../pokemon/foongus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 34–36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 34–36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 34–36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/122.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mr. Mime](../pokemon/mr-mime.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 34–36 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/185.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sudowoodo](../pokemon/sudowoodo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 34–36 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 34–36 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 34–36 | 5% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 29–32 | 70% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/587.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emolga](../pokemon/emolga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 29–32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/542.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leavanny](../pokemon/leavanny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/521.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unfezant](../pokemon/unfezant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 32 | 10% |

## Surfing

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–45 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–45 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/170.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chinchou](../pokemon/chinchou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 35–45 | 10% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/457.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lumineon](../pokemon/lumineon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–50 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/171.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 40–50 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–50 | 10% |

## Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 29–32 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/170.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chinchou](../pokemon/chinchou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 29–32 | 40% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/457.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lumineon](../pokemon/lumineon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 34–36 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/171.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 34–36 | 40% |

## Same-name encounter areas

These encounter tables resolve to the same map-header display name. A shared map index identifies seasonal variants; a shared name alone does not establish that two maps are the same area.

| Map index | Season | Relationship | Encounter table |
| --------: | ------ | ------------ | --------------- |
| 84 | Spring | Seasonal variant | [Map 084 (Spring)](map-084-spring.md) |
| 84 | Summer | Seasonal variant | [Map 084 (Summer)](map-084-summer.md) |
| 84 | Winter | Seasonal variant | [Map 084 (Winter)](map-084-winter.md) |

## Hack changes

### Blaze Black

Compared with **black-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Tranquill — Lv. 25</li><li>Foongus — Lv. 25</li><li>Tranquill — Lv. 23</li><li>Swadloon — Lv. 23</li><li>Foongus — Lv. 23</li><li>Deerling — Lv. 23</li><li>Karrablast — Lv. 22</li><li>Deerling — Lv. 22</li><li>Tranquill — Lv. 25</li><li>Foongus — Lv. 25</li><li>Karrablast — Lv. 24</li><li>Deerling — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Plusle — Lv. 29–32</li><li>Minun — Lv. 29–32</li><li>Pidgeotto — Lv. 29–32</li><li>Natu — Lv. 29–32</li><li>Stantler — Lv. 29–32</li><li>Foongus — Lv. 29–32</li><li>Cherubi — Lv. 29–32</li><li>Deerling — Lv. 29–32</li><li>Plusle — Lv. 29–32</li><li>Minun — Lv. 29–32</li><li>Bonsly — Lv. 29–32</li><li>Mime Jr. — Lv. 29–32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Tranquill — Lv. 29</li><li>Foongus — Lv. 29</li><li>Tranquill — Lv. 27</li><li>Swadloon — Lv. 27</li><li>Foongus — Lv. 27</li><li>Deerling — Lv. 27</li><li>Karrablast — Lv. 26</li><li>Deerling — Lv. 26</li><li>Tranquill — Lv. 29</li><li>Foongus — Lv. 29</li><li>Karrablast — Lv. 28</li><li>Deerling — Lv. 28</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Plusle — Lv. 34–36</li><li>Minun — Lv. 34–36</li><li>Pidgeotto — Lv. 34–36</li><li>Xatu — Lv. 34–36</li><li>Stantler — Lv. 34–36</li><li>Foongus — Lv. 34–36</li><li>Cherrim — Lv. 34–36</li><li>Sawsbuck — Lv. 34–36</li><li>Plusle — Lv. 34–36</li><li>Minun — Lv. 34–36</li><li>Mr. Mime — Lv. 34–36</li><li>Sudowoodo — Lv. 34–36</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Unfezant — Lv. 25</li><li>Leavanny — Lv. 25</li><li>Emolga — Lv. 23</li><li>Audino — Lv. 24</li><li>Audino — Lv. 25</li><li>Emolga — Lv. 25</li><li>Audino — Lv. 22</li><li>Audino — Lv. 23</li><li>Unfezant — Lv. 25</li><li>Leavanny — Lv. 25</li><li>Audino — Lv. 25</li></ul><p class="rw-comparison-count">7 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 32</li><li>Chansey — Lv. 29–32</li><li>Emolga — Lv. 29–32</li><li>Chansey — Lv. 29–32</li><li>Chansey — Lv. 32</li><li>Unfezant — Lv. 32</li><li>Leavanny — Lv. 32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 35–45</li><li>Goldeen — Lv. 35–45</li><li>Chinchou — Lv. 35–45</li><li>Chinchou — Lv. 35–45</li><li>Finneon — Lv. 35–45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40–50</li><li>Lanturn — Lv. 40–50</li><li>Seaking — Lv. 40–50</li><li>Seaking — Lv. 40–50</li><li>Lumineon — Lv. 40–50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 35–55</li><li>Basculin — Lv. 35–55</li><li>Poliwag — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwag — Lv. 35–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Finneon — Lv. 29–32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Politoed — Lv. 45–70</li><li>Basculin — Lv. 35–60</li><li>Politoed — Lv. 45–70</li><li>Poliwhirl — Lv. 35–70</li><li>Poliwhirl — Lv. 35–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lumineon — Lv. 34–36</li></ul></li></ul></div>
</section>
</div>

</details>

### Volt White

Compared with **white-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Tranquill — Lv. 25</li><li>Foongus — Lv. 25</li><li>Tranquill — Lv. 23</li><li>Swadloon — Lv. 23</li><li>Foongus — Lv. 23</li><li>Deerling — Lv. 23</li><li>Karrablast — Lv. 22</li><li>Deerling — Lv. 22</li><li>Tranquill — Lv. 25</li><li>Foongus — Lv. 25</li><li>Karrablast — Lv. 24</li><li>Deerling — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Plusle — Lv. 29–32</li><li>Minun — Lv. 29–32</li><li>Pidgeotto — Lv. 29–32</li><li>Natu — Lv. 29–32</li><li>Stantler — Lv. 29–32</li><li>Foongus — Lv. 29–32</li><li>Cherubi — Lv. 29–32</li><li>Deerling — Lv. 29–32</li><li>Plusle — Lv. 29–32</li><li>Minun — Lv. 29–32</li><li>Bonsly — Lv. 29–32</li><li>Mime Jr. — Lv. 29–32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Tranquill — Lv. 29</li><li>Foongus — Lv. 29</li><li>Tranquill — Lv. 27</li><li>Swadloon — Lv. 27</li><li>Foongus — Lv. 27</li><li>Deerling — Lv. 27</li><li>Karrablast — Lv. 26</li><li>Deerling — Lv. 26</li><li>Tranquill — Lv. 29</li><li>Foongus — Lv. 29</li><li>Karrablast — Lv. 28</li><li>Deerling — Lv. 28</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Plusle — Lv. 34–36</li><li>Minun — Lv. 34–36</li><li>Pidgeotto — Lv. 34–36</li><li>Xatu — Lv. 34–36</li><li>Stantler — Lv. 34–36</li><li>Foongus — Lv. 34–36</li><li>Cherrim — Lv. 34–36</li><li>Sawsbuck — Lv. 34–36</li><li>Plusle — Lv. 34–36</li><li>Minun — Lv. 34–36</li><li>Mr. Mime — Lv. 34–36</li><li>Sudowoodo — Lv. 34–36</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Unfezant — Lv. 25</li><li>Leavanny — Lv. 25</li><li>Emolga — Lv. 23</li><li>Audino — Lv. 24</li><li>Audino — Lv. 25</li><li>Emolga — Lv. 25</li><li>Audino — Lv. 22</li><li>Audino — Lv. 23</li><li>Unfezant — Lv. 25</li><li>Leavanny — Lv. 25</li><li>Audino — Lv. 25</li></ul><p class="rw-comparison-count">7 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 32</li><li>Chansey — Lv. 29–32</li><li>Emolga — Lv. 29–32</li><li>Chansey — Lv. 29–32</li><li>Chansey — Lv. 32</li><li>Unfezant — Lv. 32</li><li>Leavanny — Lv. 32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li><li>Basculin — Lv. 10–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 35–45</li><li>Goldeen — Lv. 35–45</li><li>Chinchou — Lv. 35–45</li><li>Chinchou — Lv. 35–45</li><li>Finneon — Lv. 35–45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li><li>Basculin — Lv. 10–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40–50</li><li>Lanturn — Lv. 40–50</li><li>Seaking — Lv. 40–50</li><li>Seaking — Lv. 40–50</li><li>Lumineon — Lv. 40–50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 35–55</li><li>Basculin — Lv. 35–55</li><li>Poliwag — Lv. 35–55</li><li>Poliwhirl — Lv. 35–55</li><li>Poliwag — Lv. 35–55</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Chinchou — Lv. 29–32</li><li>Finneon — Lv. 29–32</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Politoed — Lv. 45–70</li><li>Basculin — Lv. 35–60</li><li>Politoed — Lv. 45–70</li><li>Poliwhirl — Lv. 35–70</li><li>Poliwhirl — Lv. 35–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lanturn — Lv. 34–36</li><li>Lumineon — Lv. 34–36</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/6` member `84`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-084-summer/"><span class="rw-record-nav__label">← Route 6</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-084-winter/"><span class="rw-record-nav__label">Route 6 →</span></a>
</nav>
