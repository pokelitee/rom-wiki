# Full Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-heal.png" alt="Full Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>27</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It heals all the status problems of a single Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Twist Mountain](../locations/header-203.md) | — | `header-203` | Visible | (587, 618) |
| [Abyssal Ruins](../locations/header-244.md) | — | `header-244` | Visible | (28, 10) |
| [Village Bridge](../locations/header-256.md) | — | `header-256` | Visible | (43, 31) |
| [Route 11](../locations/header-309.md) | — | `header-309` | Visible | (664, 308) |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden | (11, 42) |
| [Relic Passage](../locations/header-504.md) | — | `header-504` | Hidden | (6, 11) |
| [Cave of Being](../locations/header-517.md) | — | `header-517` | Visible | (342, 170) |
| [Plasma Frigate](../locations/header-563.md) | — | `header-563` | Visible | (552, 74) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Doctor Jules](../trainers/trainer-0118.md) | AI battle item |
| [Nurse Kirsten](../trainers/trainer-0119.md) | AI battle item |
| [Doctor Braid](../trainers/trainer-0327.md) | AI battle item |
| [Doctor Logan](../trainers/trainer-0601.md) | AI battle item |
| [Nurse Mariah](../trainers/trainer-0670.md) | AI battle item |
| [Doctor Kit](../trainers/trainer-0671.md) | AI battle item |
| [Doctor Derek](../trainers/trainer-0672.md) | AI battle item |
| [Nurse Dixie](../trainers/trainer-0673.md) | AI battle item |
| [Doctor Heath](../trainers/trainer-0679.md) | AI battle item |
| [Nurse Carol](../trainers/trainer-0725.md) | AI battle item |
| [Doctor Julius](../trainers/trainer-0811.md) | AI battle item |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Entree Forest</li><li>Route 11</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `27` |

Source: exact ROM record from `a/0/2/4` member `27`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/27/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Super Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../revive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/revive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Revive →</span></a>
</nav>
