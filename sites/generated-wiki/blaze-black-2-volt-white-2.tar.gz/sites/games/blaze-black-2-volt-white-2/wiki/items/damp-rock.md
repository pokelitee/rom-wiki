# Damp Rock

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-rock.png" alt="Damp Rock icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>285</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">60</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Rain Dance by the holder lasts 8 rounds instead of 5.</strong></p>
<p>Held: The holder’s Rain Dance will create rain lasting for eight turns rather than five. As this item affects the move rather than the weather itself, the effect is not lost if the holder leaves battle or drops this item.</p>

<figure class="rw-pokedex-entry">
<blockquote>A Pokémon held item that extends the duration of the move Rain Dance used by the holder.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>113</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [White Treehollow](../locations/header-480.md) | Visible | (27, 10) |

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Lentimas Town](../locations/header-460.md) | Lentimas Secondary | ₽200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Roxie](../trainers/trainer-0766.md) | Held by Accelgor |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0828.md) | Held by Voltorb |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Held by Electrode |
| [⒆⒇ Trainer Norman](../trainers/trainer-0834.md) | Held by Luvdisc |
| [⒆⒇ Trainer Steven](../trainers/trainer-0843.md) | Held by Milotic |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Lentimas Town</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Omastar</li><li>Tentacruel</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Accelgor</li><li>Voltorb</li><li>Luvdisc</li><li>Milotic</li><li>Electrode</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `285` |

Source: exact ROM record from `a/0/2/4` member `285`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/262/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../heat-rock/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/heat-rock.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Heat Rock</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../grip-claw/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/grip-claw.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Grip Claw →</span></a>
</nav>
