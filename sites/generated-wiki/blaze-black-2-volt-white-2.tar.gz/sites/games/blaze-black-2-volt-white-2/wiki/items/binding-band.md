# Binding Band

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/binding-band.png" alt="Binding Band icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>544</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Doubles the per-turn damage of multi-turn trapping moves.</strong></p>
<p>Held : Moves used by the holder that trap and damage a target for multiple turns (e.g. Bind, Fire Spin) inflict twice their usual per-turn damage.</p>

<figure class="rw-pokedex-entry">
<blockquote>A band that increases the power of binding moves when held.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Gear Station — map_67](../locations/header-067.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_68](../locations/header-068.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_69](../locations/header-069.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_70](../locations/header-070.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_71](../locations/header-071.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_72](../locations/header-072.md) | Battle Point item exchange | 8 BP | Main game |
| [Gear Station — map_73](../locations/header-073.md) | Battle Point item exchange | 8 BP | Main game |
| [PWT — map_192](../locations/header-192.md) | Battle Point item exchange | 8 BP | Main game |

## Hack changes

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `544` |

Source: exact ROM record from `a/0/2/4` member `544`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/587/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ring-target/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ring-target.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ring Target</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../absorb-bulb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/absorb-bulb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Absorb Bulb →</span></a>
</nav>
