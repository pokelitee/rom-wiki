# Flying Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/flying-gem.png" alt="Flying Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>556</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Flying-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an essence of air. When held, it strengthens the power of a Flying-type move only once.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Marshal](../trainers/trainer-0039.md) | Held by Mienshao |
| [Pilot Winslow](../trainers/trainer-0150.md) | Held by Drifblim |
| [Leader Elesa](../trainers/trainer-0153.md) | Held by Emolga |
| [Leader Burgh](../trainers/trainer-0154.md) | Held by Scyther |
| [Leader Skyla](../trainers/trainer-0155.md) | Held by Archeops |
| [Leader Skyla](../trainers/trainer-0155.md) | Held by Gliscor |
| [Boss Trainer Abigail](../trainers/trainer-0183.md) | Held by Archeops |
| [Boss Trainer Frederick](../trainers/trainer-0193.md) | Held by Tornadus Therian |
| [Champion Iris](../trainers/trainer-0341.md) | Held by Archeops |
| [Team Plasma Ghetsis](../trainers/trainer-0345.md) | Held by Eelektross |
| [Team Plasma Zinzolin](../trainers/trainer-0347.md) | Held by Drifblim |
| [Team Plasma Shadow](../trainers/trainer-0348.md) | Held by Crobat |
| [Team Plasma Zinzolin](../trainers/trainer-0497.md) | Held by Drifblim |
| [Team Plasma Shadow](../trainers/trainer-0583.md) | Held by Crobat |
| [GAME FREAK Morimoto](../trainers/trainer-0592.md) | Held by Swoobat |
| [Team Plasma Shadow](../trainers/trainer-0687.md) | Held by Crobat |
| [Leader Burgh](../trainers/trainer-0766.md) | Held by Vespiquen |
| [Leader Elesa](../trainers/trainer-0767.md) | Held by Emolga |
| [Leader Skyla](../trainers/trainer-0769.md) | Held by Archeops |
| [Leader Skyla](../trainers/trainer-0769.md) | Held by Gliscor |
| [Elite Four Shauntal](../trainers/trainer-0777.md) | Held by Drifblim |
| [Champion Iris](../trainers/trainer-0781.md) | Held by Archeops |
| [Leader Roxie](../trainers/trainer-0815.md) | Held by Crobat |
| [Leader Elesa](../trainers/trainer-0817.md) | Held by Emolga |
| [Leader Skyla](../trainers/trainer-0819.md) | Held by Archeops |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0822.md) | Held by Archeops |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0827.md) | Held by Mienshao |
| [⒆⒇ Trainer Tate](../trainers/trainer-0838.md) | Held by Solrock |
| [⒆⒇ Trainer Tate](../trainers/trainer-0840.md) | Held by Solrock |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Archeops</li><li>Drifblim</li><li>Drifblim</li></ul><p class="rw-comparison-count">27 entries added</p><ul class="rw-comparison-list"><li>Archeops</li><li>Tornadus Therian</li><li>Archeops</li><li>Mienshao</li><li>Swoobat</li><li>Scyther</li><li>Vespiquen</li><li>Emolga</li><li>Emolga</li><li>Emolga</li><li>Crobat</li><li>Gliscor</li><li>Gliscor</li><li>Archeops</li><li>Archeops</li><li>Archeops</li><li>Drifblim</li><li>Eelektross</li><li>Crobat</li><li>Crobat</li><li>Crobat</li><li>Drifblim</li><li>Drifblim</li><li>Mienshao</li><li>Archeops</li><li>Solrock</li><li>Solrock</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `556` |

Source: exact ROM record from `a/0/2/4` member `556`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/599/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ground-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ground-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ground Gem</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../psychic-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/psychic-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Psychic Gem →</span></a>
</nav>
