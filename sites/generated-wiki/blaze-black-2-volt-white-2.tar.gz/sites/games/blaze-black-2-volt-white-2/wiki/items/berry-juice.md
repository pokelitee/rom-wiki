# Berry Juice

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/berry-juice.png" alt="Berry Juice icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>43</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 20 HP.</strong></p>
<p>Used on a party Pokémon : Restores 20 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A 100% pure juice made of Berries. It restores the HP of one Pokémon by just 20 points.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>1</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>HP amount 20</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Twist Mountain — map_203](../locations/header-203.md) | Hidden | (597, 635) |
| [Route 11 — map_367](../locations/header-367.md) | Visible | (90, 38) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/213.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuckle](../pokemon/shuckle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | Common |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/213.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuckle](../pokemon/shuckle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Cheren](../trainers/trainer-0764.md) | Held by Pidove |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0824.md) | Held by Anorith |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0824.md) | Held by Lileep |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0824.md) | Held by Nosepass |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0826.md) | Held by Makuhita |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Pidove</li><li>Makuhita</li><li>Nosepass</li><li>Lileep</li><li>Anorith</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `43` |

Source: exact ROM record from `a/0/2/4` member `43`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/43/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../lava-cookie/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lava-cookie.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Lava Cookie</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../sacred-ash/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/sacred-ash.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Sacred Ash →</span></a>
</nav>
