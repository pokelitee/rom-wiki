# Big Nugget

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-nugget.png" alt="Big Nugget icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>581</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Loot</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Sell to Ore Collector for 30000 Pokédollars.</strong></p>
<p>Cult vendor trash.</p>

<figure class="rw-pokedex-entry">
<blockquote>A big nugget of pure gold that gives off a lustrous gleam. A maniac will buy it for a high price.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Chargestone Cave](../locations/header-196.md) | — | `header-196` | Script Awarded | — |
| [Twist Mountain](../locations/header-203.md) | — | `header-203` | Visible | (20, 11) |
| [Clay Tunnel](../locations/header-508.md) | — | `header-508` | Hidden | (26, 60) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/569.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Garbodor](../pokemon/garbodor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | Dark_Grass |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `581` |

Source: exact ROM record from `a/0/2/4` member `581`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/622/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../balm-mushroom/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/balm-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← BalmMushroom</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../pearl-string/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pearl-string.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Pearl String →</span></a>
</nav>
