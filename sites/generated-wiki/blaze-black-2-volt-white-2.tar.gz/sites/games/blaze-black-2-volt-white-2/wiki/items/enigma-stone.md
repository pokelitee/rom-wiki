# Enigma Stone

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/enigma-stone.png" alt="Enigma Stone icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>536</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Event Items</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>S: Summons Latias H: Summons Latios.</strong></p>
<p>When taken to the Pewter City museum, causes Latias or Latios to attack the trainer. The Pokémon to appear will be whicher can’t be encountered roaming in the wild.</p>

<figure class="rw-pokedex-entry">
<blockquote>A crystal ball that was excavated from the ground. A very beautiful stone that is covered with bits of rock and earth.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>4</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Hack changes

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `536` |

Source: exact ROM record from `a/0/2/4` member `536`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/470/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../blue-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Blue Orb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../prism-scale/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/prism-scale.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Prism Scale →</span></a>
</nav>
