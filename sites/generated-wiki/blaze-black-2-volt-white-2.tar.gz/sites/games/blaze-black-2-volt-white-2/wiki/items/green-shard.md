# Green Shard

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="Green Shard icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>75</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Collectibles</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>No effect. Can be traded for items or moves.</strong></p>
<p>No effect. In Diamond and Pearl, trade ten for a Hail TM in the house midway along the southern section of Route 212. In Platinum, trade to move tutors on Route 212, in Snowpoint City, and in the Survival Area. Eight shards total are required per tutelage, but the particular combination of colors varies by move. In HeartGold and SoulSilver, trade one for an Aguav Berry, a Lum Berry, and a Rawst Berry with the Juggler near the Pokémon Center in Violet City. In HeartGold and SoulSilver, trade one for a Durin Berry, a Hondew Berry, and a Wepear Berry with the Juggler near the Pal Park entrance in Fuchsia City.</p>

<figure class="rw-pokedex-entry">
<blockquote>A small green shard. It appears to be from some sort of implement made long ago.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden | (19, 73) |
| [Desert Resort](../locations/header-158.md) | — | `header-158` | Visible | (57, 77) |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden | (356, 435) |
| [Mistralton Cave](../locations/header-334.md) | — | `header-334` | Visible | (4, 3) |
| [Mistralton Cave](../locations/header-334.md) | — | `header-334` | Hidden | (5, 9) |
| [Moor of Icirrus](../locations/header-346.md) | — | `header-346` | Visible | (38, 13) |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden | (664, 116) |
| [Relic Passage](../locations/header-504.md) | — | `header-504` | Hidden | (82, 12) |
| [Reversal Mountain](../locations/header-533.md) | — | `header-533` | Hidden | (84, 36) |
| [Route 4](../locations/header-551.md) | — | `header-551` | Hidden | (398, 564) |
| [Floccesy Ranch](../locations/header-445.md) | — | `header-445` | Hidden Grotto Hidden | — |
| [Route 5](../locations/header-329.md) | — | `header-329` | Hidden Grotto Hidden | — |
| [Lostlorn Forest](../locations/header-385.md) | — | `header-385` | Hidden Grotto Hidden | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Hidden | — |
| [Route 6](../locations/header-331.md) | — | `header-331` | Hidden Grotto Hidden | — |
| [Route 7](../locations/header-337.md) | — | `header-337` | Hidden Grotto Hidden | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Hidden | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Hidden Grotto Hidden | — |
| [Route 9](../locations/header-348.md) | — | `header-348` | Hidden Grotto Hidden | — |
| [Giant Chasm](../locations/header-232.md) | — | `header-232` | Hidden Grotto Hidden | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Hidden Grotto Hidden | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Hidden Grotto Hidden | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Hidden | — |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden Grotto Hidden | — |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Hidden Grotto Hidden | — |
| [Pinwheel Forest](../locations/header-154.md) | — | `header-154` | Hidden Grotto Hidden | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Hidden | — |
| [Route 3](../locations/header-321.md) | — | `header-321` | Hidden Grotto Hidden | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Hidden Grotto Hidden | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Hidden Grotto Hidden | — |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Driftveil City](../locations/header-099.md) | — | `header-099` | Driftveil Secondary | ₽200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Janitor Caleb](../trainers/trainer-0115.md) | Victory reward |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Driftveil City</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `75` |

Source: exact ROM record from `a/0/2/4` member `75`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/75/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../yellow-shard/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Yellow Shard</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-repel/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Repel →</span></a>
</nav>
