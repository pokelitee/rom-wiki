# Black Flute

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/black-flute.png" alt="Black Flute icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>68</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Spelunking</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Halves the wild Pokémon encounter rate.</strong></p>
<p>Used outside of battle : Decreases the wild Pokémon encounter rate by 50%.</p>

<figure class="rw-pokedex-entry">
<blockquote>A toy flute made from black glass. A maniac will buy it for a high price.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 13](../locations/header-370.md) | — | `header-370` | Script Awarded | — |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Route 13</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Route 13</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `68` |

Source: exact ROM record from `a/0/2/4` member `68`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/68/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../red-flute/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-flute.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Red Flute</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../white-flute/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/white-flute.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">White Flute →</span></a>
</nav>
