# Fire Gem

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-gem.png" alt="Fire Gem icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>548</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Jewels</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: When the holder uses a damaging Fire-type move, the move has 1.5× power and this item is consumed.</strong></p>
<p>Held : When the holder uses a damaging Fire-type move, the move has 1.5× power and this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>A gem with an essence of fire. When held, it strengthens the power of a Fire-type move only once.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Dreamyard](../locations/header-152.md) | — | `header-152` | Script Awarded | — |
| [Dragonspiral Tower](../locations/header-208.md) | — | `header-208` | Script Awarded | — |
| [Victory Road](../locations/header-216.md) | — | `header-216` | Script Awarded | — |
| [Victory Road](../locations/header-224.md) | — | `header-224` | Script Awarded | — |
| [Victory Road](../locations/header-226.md) | — | `header-226` | Script Awarded | — |
| [Giant Chasm](../locations/header-231.md) | — | `header-231` | Script Awarded | — |
| [Route 2](../locations/header-319.md) | — | `header-319` | Script Awarded | — |
| [Mistralton Cave](../locations/header-333.md) | — | `header-333` | Script Awarded | — |
| [Mistralton Cave](../locations/header-334.md) | — | `header-334` | Script Awarded | — |
| [Guidance Chamber](../locations/header-335.md) | — | `header-335` | Script Awarded | — |
| [Moor of Icirrus](../locations/header-346.md) | — | `header-346` | Script Awarded | — |
| [Route 13](../locations/header-370.md) | — | `header-370` | Script Awarded | — |
| [Route 15](../locations/header-378.md) | — | `header-378` | Script Awarded | — |
| [Route 16](../locations/header-383.md) | — | `header-383` | Script Awarded | — |
| [Route 18](../locations/header-387.md) | — | `header-387` | Script Awarded | — |
| [Accumula Town](../locations/header-404.md) | — | `header-404` | Script Awarded | — |
| [Route 22](../locations/header-474.md) | — | `header-474` | Script Awarded | — |
| [Route 23](../locations/header-475.md) | — | `header-475` | Script Awarded | — |
| [White Treehollow](../locations/header-485.md) | — | `header-485` | Script Awarded | — |
| [Relic Passage](../locations/header-503.md) | — | `header-503` | Script Awarded | — |
| [Relic Passage](../locations/header-504.md) | — | `header-504` | Script Awarded | — |
| [Relic Passage](../locations/header-505.md) | — | `header-505` | Script Awarded | — |
| [Clay Tunnel](../locations/header-506.md) | — | `header-506` | Script Awarded | — |
| [Clay Tunnel](../locations/header-507.md) | — | `header-507` | Script Awarded | — |
| [Clay Tunnel](../locations/header-508.md) | — | `header-508` | Script Awarded | — |
| [Twist Mountain](../locations/header-509.md) | — | `header-509` | Script Awarded | — |
| [Seaside Cave](../locations/header-516.md) | — | `header-516` | Script Awarded | — |
| [Reversal Mountain](../locations/header-539.md) | — | `header-539` | Hidden | (27, 18) |
| [Victory Road](../locations/header-587.md) | — | `header-587` | Script Awarded | — |
| [Victory Road](../locations/header-590.md) | — | `header-590` | Script Awarded | — |
| [Victory Road](../locations/header-594.md) | — | `header-594` | Script Awarded | — |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Roxie](../trainers/trainer-0157.md) | Held by Koffing |
| [Veteran Zach](../trainers/trainer-0532.md) | Held by Charizard |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/koffing/">Koffing</a></li><li><a href="../../pokemon/charizard/">Charizard</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `548` |

Source: exact ROM record from `a/0/2/4` member `548`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/591/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../eject-button/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/eject-button.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Eject Button</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../water-gem/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-gem.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Water Gem →</span></a>
</nav>
