# Calcium

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/calcium.png" alt="Calcium icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>49</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Special Attack effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Special Attack effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Sp. Atk (Special Attack) stat of a single Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Sp. Atk EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 2](../locations/header-319.md) | — | `header-319` | Visible | (764, 627) |
| [Abundant Shrine](../locations/header-376.md) | — | `header-376` | Hidden | (50, 35) |
| [Route 22](../locations/header-474.md) | — | `header-474` | Visible | (726, 143) |
| [Route 23](../locations/header-475.md) | — | `header-475` | Visible | (583, 82) |
| [Seaside Cave](../locations/header-515.md) | — | `header-515` | Hidden | (6, 30) |
| [Reversal Mountain](../locations/header-533.md) | — | `header-533` | Hidden | (30, 49) |
| [Reversal Mountain](../locations/header-539.md) | — | `header-539` | Hidden | (57, 32) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 1 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 1 BP | Main game |
| [PWT](../locations/header-192.md) | — | `header-192` | Battle Point item exchange | 1 BP | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Hoopster Lamarcus](../trainers/trainer-0068.md) | Victory reward |
| [Hoopster Bobby](../trainers/trainer-0071.md) | Victory reward |
| [Hoopster John](../trainers/trainer-0072.md) | Victory reward |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>PWT</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `49` |

Source: exact ROM record from `a/0/2/4` member `49`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/49/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../carbos/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Carbos</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rare-candy/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Rare Candy →</span></a>
</nav>
