# Focus Sash

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/focus-sash.png" alt="Focus Sash icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>275</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder survives any single-hit attack at 1 HP if at max HP, then the item is consumed.</strong></p>
<p>Held: If the holder has full HP and is attacked for regular damage that would faint it, this item is consumed and prevents the holder’s HP from lowering below 1. This effect works against multi-hit attacks, but does not work against the effects of Doom Desire or Future Sight.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. If it has full HP, the holder will endure one potential KO attack, leaving 1 HP.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>103</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Gear Station — map_67](../locations/header-067.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_68](../locations/header-068.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_69](../locations/header-069.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_70](../locations/header-070.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_71](../locations/header-071.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_72](../locations/header-072.md) | Battle Point item exchange | 24 BP | Main game |
| [Gear Station — map_73](../locations/header-073.md) | Battle Point item exchange | 24 BP | Main game |
| [PWT — map_192](../locations/header-192.md) | Battle Point item exchange | 24 BP | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Marshal](../trainers/trainer-0039.md) | Held by Medicham |
| [Elite Four Grimsley](../trainers/trainer-0040.md) | Held by Houndoom |
| [Elite Four Caitlin](../trainers/trainer-0041.md) | Held by Beheeyem |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | Held by Froslass |
| [Elite Four Marshal](../trainers/trainer-0144.md) | Held by Mienshao |
| [Elite Four Grimsley](../trainers/trainer-0145.md) | Held by Bisharp |
| [Elite Four Caitlin](../trainers/trainer-0146.md) | Held by Gallade |
| [Leader Burgh](../trainers/trainer-0154.md) | Held by Parasect |
| [Leader Skyla](../trainers/trainer-0155.md) | Held by Swanna |
| [Leader Marlon](../trainers/trainer-0160.md) | Held by Politoed |
| [Boss Trainer Iria](../trainers/trainer-0199.md) | Held by Kabutops |
| [Champion Iris](../trainers/trainer-0341.md) | Held by Haxorus |
| [Team Plasma Colress](../trainers/trainer-0344.md) | Held by Klinklang |
| [Team Plasma Ghetsis](../trainers/trainer-0345.md) | Held by Genesect |
| [Veteran Oriana](../trainers/trainer-0403.md) | Held by Feraligatr |
| [Veteran Rayne](../trainers/trainer-0404.md) | Held by Sunflora |
| [Veteran Chester](../trainers/trainer-0421.md) | Held by Dugtrio |
| [Veteran Maya](../trainers/trainer-0422.md) | Held by Empoleon |
| [⒆⒇ Trainer Cynthia](../trainers/trainer-0456.md) | Held by Roserade |
| [Team Plasma Zinzolin](../trainers/trainer-0497.md) | Held by Abomasnow |
| [Team Plasma Shadow](../trainers/trainer-0498.md) | Held by Banette |
| [Team Plasma Shadow](../trainers/trainer-0499.md) | Held by Venomoth |
| [Veteran Chloris](../trainers/trainer-0535.md) | Held by Omastar |
| [Champion Iris](../trainers/trainer-0536.md) | Held by Serperior |
| [⒆⒇ Trainer Alder](../trainers/trainer-0582.md) | Held by Escavalier |
| [Team Plasma Shadow](../trainers/trainer-0583.md) | Held by Scyther |
| [Team Plasma Zinzolin](../trainers/trainer-0584.md) | Held by Weavile |
| [⒆⒇ Trainer Rival](../trainers/trainer-0684.md) | Held by Flygon |
| [⒆⒇ Trainer Rival](../trainers/trainer-0685.md) | Held by Flygon |
| [⒆⒇ Trainer Rival](../trainers/trainer-0686.md) | Held by Flygon |
| [Team Plasma Shadow](../trainers/trainer-0688.md) | Held by Accelgor |
| [Team Plasma Shadow](../trainers/trainer-0689.md) | Held by Venomoth |
| [⒆⒇ Trainer Rival](../trainers/trainer-0697.md) | Held by Samurott |
| [Team Plasma Zinzolin](../trainers/trainer-0704.md) | Held by Cryogonal |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0706.md) | Held by Emboar |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0707.md) | Held by Samurott |
| [⒆⒇ Trainer Bianca](../trainers/trainer-0708.md) | Held by Serperior |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0709.md) | Held by Emboar |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0710.md) | Held by Samurott |
| [⒆⒇ Trainer Cheren](../trainers/trainer-0711.md) | Held by Serperior |
| [Leader Roxie](../trainers/trainer-0765.md) | Held by Trubbish |
| [Leader Burgh](../trainers/trainer-0766.md) | Held by Leavanny |
| [Leader Elesa](../trainers/trainer-0767.md) | Held by Galvantula |
| [Leader Drayden](../trainers/trainer-0770.md) | Held by Haxorus |
| [Leader Marlon](../trainers/trainer-0771.md) | Held by Carracosta |
| [Elite Four Grimsley](../trainers/trainer-0773.md) | Held by Bisharp |
| [Elite Four Marshal](../trainers/trainer-0774.md) | Held by Blaziken |
| [Champion Iris](../trainers/trainer-0776.md) | Held by Haxorus |
| [Elite Four Grimsley](../trainers/trainer-0778.md) | Held by Bisharp |
| [Elite Four Marshal](../trainers/trainer-0779.md) | Held by Blaziken |
| [Champion Iris](../trainers/trainer-0781.md) | Held by Serperior |
| [⒆⒇ Trainer N](../trainers/trainer-0782.md) | Held by Politoed |
| [⒆⒇ Trainer N](../trainers/trainer-0783.md) | Held by Ninetales |
| [⒆⒇ Trainer N](../trainers/trainer-0784.md) | Held by Hippowdon |
| [⒆⒇ Trainer N](../trainers/trainer-0785.md) | Held by Abomasnow |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | Held by Porygon-Z |
| [Leader Cheren](../trainers/trainer-0814.md) | Held by Zangoose |
| [Leader Roxie](../trainers/trainer-0815.md) | Held by Scolipede |
| [Leader Burgh](../trainers/trainer-0816.md) | Held by Leavanny |
| [Leader Drayden](../trainers/trainer-0820.md) | Held by Haxorus |
| [Leader Marlon](../trainers/trainer-0821.md) | Held by Cloyster |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0822.md) | Held by Samurott |
| [⒆⒇ Trainer Hilda](../trainers/trainer-0823.md) | Held by Serperior |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0825.md) | Held by Aerodactyl |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0827.md) | Held by Breloom |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Held by Manectric |
| [⒆⒇ Trainer Steven](../trainers/trainer-0842.md) | Held by Empoleon |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Volcarona</li><li>Volcarona</li><li>Lucario</li><li>Weavile</li><li>Haxorus</li><li>Haxorus</li><li>Serperior</li><li>Samurott</li><li>Serperior</li><li>Emboar</li><li>Samurott</li></ul><p class="rw-comparison-count">64 entries added</p><ul class="rw-comparison-list"><li>Kabutops</li><li>Serperior</li><li>Serperior</li><li>Gallade</li><li>Beheeyem</li><li>Houndoom</li><li>Bisharp</li><li>Bisharp</li><li>Bisharp</li><li>Blaziken</li><li>Blaziken</li><li>Medicham</li><li>Mienshao</li><li>Froslass</li><li>Parasect</li><li>Leavanny</li><li>Leavanny</li><li>Zangoose</li><li>Haxorus</li><li>Haxorus</li><li>Galvantula</li><li>Politoed</li><li>Carracosta</li><li>Cloyster</li><li>Scolipede</li><li>Trubbish</li><li>Swanna</li><li>Klinklang</li><li>Genesect</li><li>Scyther</li><li>Banette</li><li>Venomoth</li><li>Venomoth</li><li>Accelgor</li><li>Abomasnow</li><li>Weavile</li><li>Cryogonal</li><li>Dugtrio</li><li>Omastar</li><li>Empoleon</li><li>Feraligatr</li><li>Sunflora</li><li>Escavalier</li><li>Serperior</li><li>Emboar</li><li>Samurott</li><li>Breloom</li><li>Serperior</li><li>Samurott</li><li>Porygon-Z</li><li>Roserade</li><li>Samurott</li><li>Serperior</li><li>Politoed</li><li>Ninetales</li><li>Hippowdon</li><li>Abomasnow</li><li>Flygon</li><li>Flygon</li><li>Flygon</li><li>Samurott</li><li>Aerodactyl</li><li>Empoleon</li><li>Manectric</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `275` |

Source: exact ROM record from `a/0/2/4` member `275`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/252/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../quick-powder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-powder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Quick Powder</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../zoom-lens/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/zoom-lens.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Zoom Lens →</span></a>
</nav>
