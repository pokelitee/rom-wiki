# Chople Berry

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chople-berry.png" alt="Chople Berry icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>189</dd></div>
<div><dt>Pocket</dt><dd>Berries</dd></div>
<div><dt>Category</dt><dd>Type Protection</dd></div>
<div><dt>Base price</dt><dd>₽20</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Consumed when struck by a super-effective Fighting-type attack to halve the damage.</strong></p>
<p>Held in battle : When the holder would take super-effective Fighting-type damage, it consumes this item to halve the amount of damage taken.</p>

<figure class="rw-pokedex-entry">
<blockquote>Weakens a supereffective Fighting-type attack against the holding Pokémon.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Berry</dd></div>
<div><dt>Field pocket ID</dt><dd>3</dd></div>
<div><dt>Field use function ID</dt><dd>8</dd></div>
<div><dt>Held effect ID</dt><dd>24</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Natural Gift</dt><dd>60 power, <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span></dd></div>
</dl>

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Grimsley](../trainers/trainer-0145.md) | Held by Tyranitar |
| [Champion Iris](../trainers/trainer-0536.md) | Held by Lapras |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | Held by Clefable |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | Held by Audino |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | Held by Wigglytuff |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | Held by Blissey |
| [Ace Trainer Kelsey](../trainers/trainer-0635.md) | Held by Mightyena |
| [Leader Cheren](../trainers/trainer-0764.md) | Held by Minccino |
| [Leader Cheren](../trainers/trainer-0764.md) | Held by Buneary |
| [Elite Four Grimsley](../trainers/trainer-0773.md) | Held by Tyranitar |
| [Leader Cheren](../trainers/trainer-0814.md) | Held by Stoutland |
| [Leader Clay](../trainers/trainer-0818.md) | Held by Krookodile |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hydreigon/">Hydreigon</a></li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/mightyena/">Mightyena</a></li><li><a href="../../pokemon/lapras/">Lapras</a></li><li><a href="../../pokemon/tyranitar/">Tyranitar</a></li><li><a href="../../pokemon/tyranitar/">Tyranitar</a></li><li><a href="../../pokemon/blissey/">Blissey</a></li><li><a href="../../pokemon/clefable/">Clefable</a></li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a></li><li><a href="../../pokemon/audino/">Audino</a></li><li><a href="../../pokemon/buneary/">Buneary</a></li><li><a href="../../pokemon/stoutland/">Stoutland</a></li><li><a href="../../pokemon/minccino/">Minccino</a></li><li><a href="../../pokemon/krookodile/">Krookodile</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `189` |

Source: exact ROM record from `a/0/2/4` member `189`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/166/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../yache-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yache-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Yache Berry</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../kebia-berry/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/kebia-berry.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Kebia Berry →</span></a>
</nav>
