# Air Balloon

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/air-balloon.png" alt="Air Balloon icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>541</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Grants immunity to Ground-type moves, Spikes, and Toxic Spikes. Consumed when the holder takes damage from a move.</strong></p>
<p>Held : Holder is immune to Ground-type moves, Spikes, Toxic Spikes, and Arena Trap. This effect does not apply during Gravity or Ingrain. When the holder takes damage from a move, this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>When held by a Pokémon, the Pokémon will float into the air. When the holder is attacked, this item will burst.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-068.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-069.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-070.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-071.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-072.md) | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-073.md) | Battle Point item exchange | 12 BP | Main game |
| [PWT](../locations/header-192.md) | Battle Point item exchange | 12 BP | Main game |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/426.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifblim](../pokemon/drifblim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Marshal](../trainers/trainer-0040.md) | Held by Bisharp |
| [Elite Four Grimsley](../trainers/trainer-0041.md) | Held by Metagross |
| [Elite Four Murphy](../trainers/trainer-0143.md) | Held by Chandelure |
| [Elite Four Shauntal](../trainers/trainer-0144.md) | Held by Lucario |
| [Elite Four Grimsley](../trainers/trainer-0146.md) | Held by Metagross |
| [Leader Chase](../trainers/trainer-0153.md) | Held by Lanturn |
| [Leader Roxie](../trainers/trainer-0158.md) | Held by Excadrill |
| [Team Plasma Grunt](../trainers/trainer-0344.md) | Held by Metagross |
| [Team Plasma Grunt](../trainers/trainer-0344.md) | Held by Magnezone |
| [Team Plasma Zinzolin](../trainers/trainer-0348.md) | Held by Bisharp |
| [⒆⒇ Trainer Nishino](../trainers/trainer-0358.md) | Held by Magnemite |
| [Veteran Vincent](../trainers/trainer-0421.md) | Held by Luxray |
| [Veteran Chester](../trainers/trainer-0422.md) | Held by Pachirisu |
| [Team Plasma Zinzolin](../trainers/trainer-0498.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0499.md) | Held by Bisharp |
| [Champion Chloris](../trainers/trainer-0536.md) | Held by Excadrill |
| [Team Plasma Alder](../trainers/trainer-0583.md) | Held by Bisharp |
| [Ace Trainer Millie](../trainers/trainer-0635.md) | Held by Plusle |
| [Ace Trainer Kelsey](../trainers/trainer-0636.md) | Held by Aggron |
| [Team Plasma Rival](../trainers/trainer-0687.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0688.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0689.md) | Held by Bisharp |
| [Leader Burgh](../trainers/trainer-0767.md) | Held by Lanturn |
| [Leader Elesa](../trainers/trainer-0768.md) | Held by Excadrill |
| [Elite Four Marlon](../trainers/trainer-0772.md) | Held by Chandelure |
| [Elite Four Iris](../trainers/trainer-0777.md) | Held by Chandelure |
| [Elite Four Shauntal](../trainers/trainer-0778.md) | Held by Drapion |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0813.md) | Held by Metagross |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0813.md) | Held by Magnezone |
| [⒆⒇ Trainer Grunt](../trainers/trainer-0813.md) | Held by Klinklang |
| [Leader Burgh](../trainers/trainer-0817.md) | Held by Ampharos |
| [⒆⒇ Trainer Hilbert](../trainers/trainer-0823.md) | Held by Zekrom |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0825.md) | Held by Probopass |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0828.md) | Held by Plusle |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0828.md) | Held by Minun |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Held by Magnezone |
| [⒆⒇ Trainer Flannery](../trainers/trainer-0831.md) | Held by Chandelure |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Raikou</li><li>Heatran</li><li>Klinklang</li></ul><p class="rw-comparison-count">36 entries added</p><ul class="rw-comparison-list"><li>Aggron</li><li>Plusle</li><li>Excadrill</li><li>Metagross</li><li>Metagross</li><li>Chandelure</li><li>Chandelure</li><li>Bisharp</li><li>Chandelure</li><li>Lucario</li><li>Drapion</li><li>Lanturn</li><li>Ampharos</li><li>Lanturn</li><li>Excadrill</li><li>Excadrill</li><li>Bisharp</li><li>Metagross</li><li>Magnezone</li><li>Bisharp</li><li>Bisharp</li><li>Bisharp</li><li>Bisharp</li><li>Bisharp</li><li>Bisharp</li><li>Pachirisu</li><li>Luxray</li><li>Plusle</li><li>Minun</li><li>Chandelure</li><li>Metagross</li><li>Magnezone</li><li>Zekrom</li><li>Magnemite</li><li>Probopass</li><li>Magnezone</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `541` |

Source: exact ROM record from `a/0/2/4` member `541`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/584/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rocky-helmet/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rocky-helmet.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Rocky Helmet</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../red-card/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-card.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Red Card →</span></a>
</nav>
