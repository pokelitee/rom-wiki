# Air Balloon

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/air-balloon.png" alt="Air Balloon icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>541</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">10</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Grants immunity to Ground-type moves, Spikes, and Toxic Spikes. Consumed when the holder takes damage from a move.</strong></p>
<p>Held : Holder is immune to Ground-type moves, Spikes, Toxic Spikes, and Arena Trap. This effect does not apply during Gravity or Ingrain. When the holder takes damage from a move, this item is consumed.</p>

<figure class="rw-pokedex-entry">
<blockquote>When held by a Pokémon, the Pokémon will float into the air. When the holder is attacked, this item will burst.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | — | `header-067` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-068.md) | — | `header-068` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-069.md) | — | `header-069` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-070.md) | — | `header-070` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-071.md) | — | `header-071` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-072.md) | — | `header-072` | Battle Point item exchange | 12 BP | Main game |
| [Gear Station](../locations/header-073.md) | — | `header-073` | Battle Point item exchange | 12 BP | Main game |
| [PWT](../locations/header-192.md) | — | `header-192` | Battle Point item exchange | 12 BP | Main game |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/426.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifblim](../pokemon/drifblim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Grimsley](../trainers/trainer-0040.md) | Held by Bisharp |
| [Elite Four Caitlin](../trainers/trainer-0041.md) | Held by Metagross |
| [Elite Four Shauntal](../trainers/trainer-0143.md) | Held by Chandelure |
| [Elite Four Marshal](../trainers/trainer-0144.md) | Held by Lucario |
| [Elite Four Caitlin](../trainers/trainer-0146.md) | Held by Metagross |
| [Leader Elesa](../trainers/trainer-0153.md) | Held by Lanturn |
| [Leader Clay](../trainers/trainer-0158.md) | Held by Excadrill |
| [Team Plasma Colress](../trainers/trainer-0344.md) | Held by Metagross |
| [Team Plasma Colress](../trainers/trainer-0344.md) | Held by Magnezone |
| [Team Plasma Shadow](../trainers/trainer-0348.md) | Held by Bisharp |
| [⒆⒇ Trainer Colress](../trainers/trainer-0358.md) | Held by Magnemite |
| [Veteran Chester](../trainers/trainer-0421.md) | Held by Luxray |
| [Veteran Maya](../trainers/trainer-0422.md) | Held by Pachirisu |
| [Team Plasma Shadow](../trainers/trainer-0498.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0499.md) | Held by Bisharp |
| [Champion Iris](../trainers/trainer-0536.md) | Held by Excadrill |
| [Team Plasma Shadow](../trainers/trainer-0583.md) | Held by Bisharp |
| [Ace Trainer Kelsey](../trainers/trainer-0635.md) | Held by Plusle |
| [Ace Trainer Kathrine](../trainers/trainer-0636.md) | Held by Aggron |
| [Team Plasma Shadow](../trainers/trainer-0687.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0688.md) | Held by Bisharp |
| [Team Plasma Shadow](../trainers/trainer-0689.md) | Held by Bisharp |
| [Leader Elesa](../trainers/trainer-0767.md) | Held by Lanturn |
| [Leader Clay](../trainers/trainer-0768.md) | Held by Excadrill |
| [Elite Four Shauntal](../trainers/trainer-0772.md) | Held by Chandelure |
| [Elite Four Shauntal](../trainers/trainer-0777.md) | Held by Chandelure |
| [Elite Four Grimsley](../trainers/trainer-0778.md) | Held by Drapion |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | Held by Metagross |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | Held by Magnezone |
| [⒆⒇ Trainer Colress](../trainers/trainer-0813.md) | Held by Klinklang |
| [Leader Elesa](../trainers/trainer-0817.md) | Held by Ampharos |
| [⒆⒇ Trainer Hilda](../trainers/trainer-0823.md) | Held by Zekrom |
| [⒆⒇ Trainer Roxanne](../trainers/trainer-0825.md) | Held by Probopass |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0828.md) | Held by Plusle |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0828.md) | Held by Minun |
| [⒆⒇ Trainer Wattson](../trainers/trainer-0829.md) | Held by Magnezone |
| [⒆⒇ Trainer Flannery](../trainers/trainer-0831.md) | Held by Chandelure |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raikou/">Raikou</a></li><li><a href="../../pokemon/heatran/">Heatran</a></li><li><a href="../../pokemon/klinklang/">Klinklang</a></li></ul><p class="rw-comparison-count">36 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/aggron/">Aggron</a></li><li><a href="../../pokemon/plusle/">Plusle</a></li><li><a href="../../pokemon/excadrill/">Excadrill</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/drapion/">Drapion</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/lucario/">Lucario</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/excadrill/">Excadrill</a></li><li><a href="../../pokemon/excadrill/">Excadrill</a></li><li><a href="../../pokemon/lanturn/">Lanturn</a></li><li><a href="../../pokemon/lanturn/">Lanturn</a></li><li><a href="../../pokemon/ampharos/">Ampharos</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/magnezone/">Magnezone</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/bisharp/">Bisharp</a></li><li><a href="../../pokemon/luxray/">Luxray</a></li><li><a href="../../pokemon/pachirisu/">Pachirisu</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/magnezone/">Magnezone</a></li><li><a href="../../pokemon/magnemite/">Magnemite</a></li><li><a href="../../pokemon/chandelure/">Chandelure</a></li><li><a href="../../pokemon/zekrom/">Zekrom</a></li><li><a href="../../pokemon/probopass/">Probopass</a></li><li><a href="../../pokemon/plusle/">Plusle</a></li><li><a href="../../pokemon/minun/">Minun</a></li><li><a href="../../pokemon/magnezone/">Magnezone</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `541` |

Source: exact ROM record from `a/0/2/4` member `541`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/584/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rocky-helmet/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rocky-helmet.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Rocky Helmet</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../red-card/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-card.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Red Card →</span></a>
</nav>
