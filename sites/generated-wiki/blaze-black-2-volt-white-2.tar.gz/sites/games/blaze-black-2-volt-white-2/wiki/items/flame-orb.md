# Flame Orb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/flame-orb.png" alt="Flame Orb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>273</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Bad Held Items</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Inflicts Burn on the holder at the end of the turn. Activates after Burn damage would occur.</strong></p>
<p>Held: Burns the holder at the end of each turn.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is a bizarre orb that inflicts a burn on the holder in battle.</blockquote>
<figcaption>Black White Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>101</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>30</dd></div>
</dl>

## Shops

| Location | Shop | Price | Availability |
| -------- | ---- | ----: | ------------ |
| [Gear Station](../locations/header-067.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-068.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-069.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-070.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-071.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-072.md) | Battle Point item exchange | 16 BP | Main game |
| [Gear Station](../locations/header-073.md) | Battle Point item exchange | 16 BP | Main game |
| [PWT](../locations/header-192.md) | Battle Point item exchange | 16 BP | Main game |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/631.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heatmor](../pokemon/heatmor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | Dark_Grass |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Elite Four Shauntal](../trainers/trainer-0038.md) | Held by Drifblim |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Heracross</li><li>Conkeldurr</li><li>Conkeldurr</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Drifblim</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `273` |

Source: exact ROM record from `a/0/2/4` member `273`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/250/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../toxic-orb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/toxic-orb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Toxic Orb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../quick-powder/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-powder.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Quick Powder →</span></a>
</nav>
