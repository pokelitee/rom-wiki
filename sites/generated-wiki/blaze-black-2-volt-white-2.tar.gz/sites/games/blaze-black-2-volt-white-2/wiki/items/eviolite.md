# Eviolite

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/eviolite.png" alt="Eviolite icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>538</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">40</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder has 1.5× Defense and Special Defense, as long as it’s not fully evolved.</strong></p>
<p>Held by a Pokémon that is not fully evolved : Holder has 1.5× Defense and Special Defense.</p>

<figure class="rw-pokedex-entry">
<blockquote>A mysterious evolutionary lump. When held, it raises the Defense and Sp. Def of a Pokémon that can still evolve.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>147</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F1 | ₽200 | Main game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Drayden](../trainers/trainer-0159.md) | Held by Zweilous |
| [⒆⒇ Trainer Colress](../trainers/trainer-0358.md) | Held by Porygon2 |
| [⒆⒇ Trainer Rival](../trainers/trainer-0378.md) | Held by Eelektrik |
| [⒆⒇ Trainer Rival](../trainers/trainer-0379.md) | Held by Eelektrik |
| [⒆⒇ Trainer Rival](../trainers/trainer-0380.md) | Held by Eelektrik |
| [Veteran Lucius](../trainers/trainer-0381.md) | Held by Deino |
| [Veteran Lucius](../trainers/trainer-0381.md) | Held by Fraxure |
| [Veteran Lucius](../trainers/trainer-0381.md) | Held by Zweilous |
| [Veteran Jerry](../trainers/trainer-0382.md) | Held by Vibrava |
| [Veteran Rhona](../trainers/trainer-0383.md) | Held by Dragonair |
| [Veteran Ron](../trainers/trainer-0384.md) | Held by Gible |
| [Veteran Ron](../trainers/trainer-0384.md) | Held by Gabite |
| [Veteran Denae](../trainers/trainer-0385.md) | Held by Bagon |
| [Veteran Denae](../trainers/trainer-0385.md) | Held by Shelgon |
| [Ace Trainer Dusty](../trainers/trainer-0493.md) | Held by Dusclops |
| [Veteran Carter](../trainers/trainer-0534.md) | Held by Porygon2 |
| [Veteran Carter](../trainers/trainer-0534.md) | Held by Rhydon |
| [GAME FREAK Nishino](../trainers/trainer-0591.md) | Held by Porygon2 |
| [Leader Roxie](../trainers/trainer-0765.md) | Held by Koffing |
| [Leader Roxie](../trainers/trainer-0765.md) | Held by Whirlipede |
| [Leader Burgh](../trainers/trainer-0766.md) | Held by Scyther |
| [Elite Four Shauntal](../trainers/trainer-0772.md) | Held by Dusclops |
| [⒆⒇ Trainer Brawly](../trainers/trainer-0826.md) | Held by Scraggy |
| [⒆⒇ Trainer Norman](../trainers/trainer-0832.md) | Held by Vigoroth |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Shops</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Magneton</li><li>Magneton</li></ul><p class="rw-comparison-count">24 entries added</p><ul class="rw-comparison-list"><li>Dusclops</li><li>Dusclops</li><li>Porygon2</li><li>Scyther</li><li>Zweilous</li><li>Koffing</li><li>Whirlipede</li><li>Rhydon</li><li>Porygon2</li><li>Bagon</li><li>Shelgon</li><li>Vibrava</li><li>Fraxure</li><li>Deino</li><li>Zweilous</li><li>Dragonair</li><li>Gible</li><li>Gabite</li><li>Scraggy</li><li>Porygon2</li><li>Vigoroth</li><li>Eelektrik</li><li>Eelektrik</li><li>Eelektrik</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `538` |

Source: exact ROM record from `a/0/2/4` member `538`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/581/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../prism-scale/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/prism-scale.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Prism Scale</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../float-stone/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/float-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Float Stone →</span></a>
</nav>
