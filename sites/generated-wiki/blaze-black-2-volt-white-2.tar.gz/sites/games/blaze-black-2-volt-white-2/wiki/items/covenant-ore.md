# Covenant Ore

<section class="rw-summary">
<div class="rw-summary__media"><span class="rw-summary__placeholder">Icon unavailable</span></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>262</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

<figure class="rw-pokedex-entry">
<blockquote>A vibrant chunk of rock said to contain the energy of a true bond. Some Pokémon react with it.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Striaton City](../locations/header-006.md) | — | `header-006` | Visible | (759, 603) |
| [Pinwheel Forest](../locations/header-155.md) | — | `header-155` | Visible | (49, 55) |
| [PWT](../locations/header-191.md) | — | `header-191` | Visible | (178, 490) |
| [Mistralton Cave](../locations/header-333.md) | — | `header-333` | Visible | (26, 7) |
| [Celestial Tower](../locations/header-341.md) | — | `header-341` | Visible | (8, 16) |

## Shops

| Location | Section | Map ID | Shop | Price | Availability |
| -------- | ------- | ------ | ---- | ----: | ------------ |
| [Shopping Mall](../locations/header-350.md) | — | `header-350` | Shopping Mall 9 F1 | ₽2,100 | Main game |

## Gifts and trades

=== "Blaze Black 2"

    | Location | Section | Map ID | Kind | Pokémon | Type |
    | -------- | ------- | ------ | ---- | ------- | ---- |
    | [Route 7](../locations/header-343.md) | — | `header-343` | Trade | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/94.png" alt="" loading="lazy" referrerpolicy="no-referrer">Gengar</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> |
    | [Humilau City](../locations/header-467.md) | — | `header-467` | Trade | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/103.png" alt="" loading="lazy" referrerpolicy="no-referrer">Exeggutor</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
    | [Route 4](../locations/header-520.md) | — | `header-520` | Trade | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/175.png" alt="" loading="lazy" referrerpolicy="no-referrer">Togepi</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

=== "Volt White 2"

    No gift or trade references.

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/67.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machoke](../pokemon/machoke.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/68.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machamp](../pokemon/machamp.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/94.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gengar](../pokemon/gengar.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/525.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Boldore](../pokemon/boldore.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/526.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gigalith](../pokemon/gigalith.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/533.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gurdurr](../pokemon/gurdurr.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/534.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Conkeldurr](../pokemon/conkeldurr.md)</span> | Use Item |

## Hack changes

=== "Blaze Black 2"

    Compared with **black-2-us**.

    <details markdown="1">
    <summary>11 fields changed</summary>

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Name</p>
    <div class="rw-change__value">Pink Scarf<span class="rw-diff-arrow">→</span>Covenant Ore</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Price</p>
    <div class="rw-change__value">100<span class="rw-diff-arrow">→</span>2100</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Field use</p>
    <div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Field-use function</p>
    <div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Fling power</p>
    <div class="rw-change__value">10<span class="rw-diff-arrow">→</span>30</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Party use</p>
    <div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Party effects</p>
    <div class="rw-change__value">—<span class="rw-diff-arrow">→</span>Structured value<details><summary>Exact data</summary><code>{&quot;attack_ev_amount&quot;:0,&quot;defense_ev_amount&quot;:0,&quot;friendship_high_amount&quot;:0,&quot;friendship_low_amount&quot;:0,&quot;friendship_medium_amount&quot;:0,&quot;heal_burn&quot;:false,&quot;heal_confusion&quot;:false,&quot;heal_freeze&quot;:false,&quot;heal_paralysis&quot;:false,&quot;heal_poison&quot;:false,&quot;heal_sleep&quot;:false,&quot;hp_ev_amount&quot;:0,&quot;hp_restored&quot;:0,&quot;level_up&quot;:false,&quot;pp_restored&quot;:0,&quot;revive&quot;:false,&quot;revive_all&quot;:false,&quot;special_attack_ev_amount&quot;:0,&quot;special_defense_ev_amount&quot;:0,&quot;speed_ev_amount&quot;:0}</code></details></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Locations</p>
    <div class="rw-change__value"><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Pinwheel Forest</li><li>PWT</li><li>Mistralton Cave</li><li>Celestial Tower</li><li>Striaton City</li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Shops</p>
    <div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Trades</p>
    <div class="rw-change__value"><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gengar/">Gengar</a></li><li><a href="../../pokemon/exeggutor/">Exeggutor</a></li><li><a href="../../pokemon/togepi/">Togepi</a></li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Evolutions</p>
    <div class="rw-change__value"><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gigalith/">Gigalith</a> — use-item</li><li><a href="../../pokemon/conkeldurr/">Conkeldurr</a> — use-item</li><li><a href="../../pokemon/alakazam/">Alakazam</a> — use-item</li><li><a href="../../pokemon/machamp/">Machamp</a> — use-item</li><li><a href="../../pokemon/golem/">Golem</a> — use-item</li><li><a href="../../pokemon/gengar/">Gengar</a> — use-item</li></ul></div>
    </section>
    </div>

    </details>

=== "Volt White 2"

    Compared with **white-2-us**.

    <details markdown="1">
    <summary>10 fields changed</summary>

    <div class="rw-changes">
    <section class="rw-change">
    <p class="rw-change__field">Name</p>
    <div class="rw-change__value">Pink Scarf<span class="rw-diff-arrow">→</span>Covenant Ore</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Price</p>
    <div class="rw-change__value">100<span class="rw-diff-arrow">→</span>2100</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Field use</p>
    <div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Field-use function</p>
    <div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Fling power</p>
    <div class="rw-change__value">10<span class="rw-diff-arrow">→</span>30</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Party use</p>
    <div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Party effects</p>
    <div class="rw-change__value">—<span class="rw-diff-arrow">→</span>Structured value<details><summary>Exact data</summary><code>{&quot;attack_ev_amount&quot;:0,&quot;defense_ev_amount&quot;:0,&quot;friendship_high_amount&quot;:0,&quot;friendship_low_amount&quot;:0,&quot;friendship_medium_amount&quot;:0,&quot;heal_burn&quot;:false,&quot;heal_confusion&quot;:false,&quot;heal_freeze&quot;:false,&quot;heal_paralysis&quot;:false,&quot;heal_poison&quot;:false,&quot;heal_sleep&quot;:false,&quot;hp_ev_amount&quot;:0,&quot;hp_restored&quot;:0,&quot;level_up&quot;:false,&quot;pp_restored&quot;:0,&quot;revive&quot;:false,&quot;revive_all&quot;:false,&quot;special_attack_ev_amount&quot;:0,&quot;special_defense_ev_amount&quot;:0,&quot;speed_ev_amount&quot;:0}</code></details></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Locations</p>
    <div class="rw-change__value"><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Pinwheel Forest</li><li>PWT</li><li>Mistralton Cave</li><li>Celestial Tower</li><li>Striaton City</li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Shops</p>
    <div class="rw-change__value"><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Shopping Mall</li></ul></div>
    </section>
    <section class="rw-change">
    <p class="rw-change__field">Evolutions</p>
    <div class="rw-change__value"><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gigalith/">Gigalith</a> — use-item</li><li><a href="../../pokemon/conkeldurr/">Conkeldurr</a> — use-item</li><li><a href="../../pokemon/alakazam/">Alakazam</a> — use-item</li><li><a href="../../pokemon/machamp/">Machamp</a> — use-item</li><li><a href="../../pokemon/golem/">Golem</a> — use-item</li><li><a href="../../pokemon/gengar/">Gengar</a> — use-item</li></ul></div>
    </section>
    </div>

    </details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `262` |

Source: exact ROM record from `a/0/2/4` member `262`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Item description source: ROM message table `a/0/0/2` member `63`.

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../frozen-ore/"><span class="rw-record-nav__label">← Frozen Ore</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../green-scarf/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-scarf.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Green Scarf →</span></a>
</nav>
