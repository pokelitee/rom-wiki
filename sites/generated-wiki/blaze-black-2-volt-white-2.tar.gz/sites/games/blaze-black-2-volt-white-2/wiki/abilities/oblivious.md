# Oblivious

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>12</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">5</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Prevents infatuation and protects against Captivate.</strong></p>
<p>This Pokémon cannot be infatuated and is immune to Captivate. If a Pokémon is infatuated and acquires this ability, its infatuation is cleared.</p>

<figure class="rw-pokedex-entry">
<blockquote>Prevents it from becoming infatuated.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/365.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Walrein](../pokemon/walrein.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">14 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slowpoke/">Slowpoke</a></li><li><a href="../../pokemon/slowbro/">Slowbro</a></li><li><a href="../../pokemon/lickitung/">Lickitung</a></li><li><a href="../../pokemon/jynx/">Jynx</a></li><li><a href="../../pokemon/slowking/">Slowking</a></li><li><a href="../../pokemon/swinub/">Swinub</a></li><li><a href="../../pokemon/piloswine/">Piloswine</a></li><li><a href="../../pokemon/smoochum/">Smoochum</a></li><li><a href="../../pokemon/illumise/">Illumise</a></li><li><a href="../../pokemon/wailmer/">Wailmer</a></li><li><a href="../../pokemon/wailord/">Wailord</a></li><li><a href="../../pokemon/numel/">Numel</a></li><li><a href="../../pokemon/lickilicky/">Lickilicky</a></li><li><a href="../../pokemon/mamoswine/">Mamoswine</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/12/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../water-absorb/"><span class="rw-record-nav__label">← Water Absorb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../cloud-nine/"><span class="rw-record-nav__label">Cloud Nine →</span></a>
</nav>
