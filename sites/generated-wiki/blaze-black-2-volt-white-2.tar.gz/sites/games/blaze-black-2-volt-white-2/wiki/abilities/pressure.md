# Pressure

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>46</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">24</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases the PP cost of moves targetting the Pokémon by one.</strong></p>
<p>Moves targetting this Pokémon use one extra PP. This ability stacks if multiple targets have it. This ability still affects moves that fail or miss. This ability does not affect ally moves that target either the entire field or just its side, nor this Pokémon&#x27;s self-targetted moves; it does, however, affect single-targetted ally moves aimed at this Pokémon, ally moves that target all other Pokémon, and opponents&#x27; moves that target the entire field. If this ability raises a move&#x27;s PP cost above its remaining PP, it will use all remaining PP. When this Pokémon enters battle, all participating trainers are notified that it has this ability. Overworld: If the lead Pokémon has this ability, higher-levelled Pokémon have their encounter rate increased.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon raises the foe&#x27;s PP usage.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/144.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Articuno](../pokemon/articuno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/145.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zapdos](../pokemon/zapdos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/146.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Moltres](../pokemon/moltres.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/150.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mewtwo](../pokemon/mewtwo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/243.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raikou](../pokemon/raikou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/244.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Entei](../pokemon/entei.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/245.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Suicune](../pokemon/suicune.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/249.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lugia](../pokemon/lugia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/250.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ho-Oh](../pokemon/ho-oh.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/320.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailmer](../pokemon/wailmer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/321.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wailord](../pokemon/wailord.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/356.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/386.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deoxys](../pokemon/deoxys-normal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/416.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vespiquen](../pokemon/vespiquen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/442.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spiritomb](../pokemon/spiritomb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--dark">Dark</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/477.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dusknoir](../pokemon/dusknoir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/483.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dialga](../pokemon/dialga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/484.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Palkia](../pokemon/palkia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/487.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Giratina](../pokemon/giratina-altered.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/624.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pawniard](../pokemon/pawniard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/625.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bisharp](../pokemon/bisharp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10001.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deoxys Attack](../pokemon/deoxys-attack.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10002.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deoxys Defense](../pokemon/deoxys-defense.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/10003.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deoxys Speed](../pokemon/deoxys-speed.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/wailmer/">Wailmer</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/wailord/">Wailord</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/dusclops/">Dusclops</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/dusknoir/">Dusknoir</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 3</li></ul><p class="rw-comparison-count">4 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/aerodactyl/">Aerodactyl</a></li><li><a href="../../pokemon/absol/">Absol</a></li><li><a href="../../pokemon/weavile/">Weavile</a></li><li><a href="../../pokemon/kyurem/">Kyurem</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/46/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sand-stream/"><span class="rw-record-nav__label">← Sand Stream</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../thick-fat/"><span class="rw-record-nav__label">Thick Fat →</span></a>
</nav>
