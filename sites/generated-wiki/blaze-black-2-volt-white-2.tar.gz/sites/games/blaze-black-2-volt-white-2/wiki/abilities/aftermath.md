# Aftermath

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>106</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Damages the attacker for 1/4 its max HP when knocked out by a contact move.</strong></p>
<p>When this Pokémon is knocked out by a move that makes contact, the move&#x27;s user takes 1/4 its maximum HP in damage.</p>

<figure class="rw-pokedex-entry">
<blockquote>Damages the attacker landing the finishing hit.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/101.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/434.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stunky](../pokemon/stunky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/435.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skuntank](../pokemon/skuntank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/568.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Trubbish](../pokemon/trubbish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/569.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Garbodor](../pokemon/garbodor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/voltorb/">Voltorb</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/electrode/">Electrode</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 1, 3</li><li><a href="../../pokemon/trubbish/">Trubbish</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/garbodor/">Garbodor</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul><p class="rw-comparison-count">2 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/drifloon/">Drifloon</a></li><li><a href="../../pokemon/drifblim/">Drifblim</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/106/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-luck/"><span class="rw-record-nav__label">← Super Luck</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../anticipation/"><span class="rw-record-nav__label">Anticipation →</span></a>
</nav>
