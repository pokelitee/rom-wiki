# Light Metal

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>135</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">5</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Halves the Pokémon&#x27;s weight.</strong></p>
<p>This Pokémon has half the usual weight for its species.</p>

<figure class="rw-pokedex-entry">
<blockquote>Halves the Pokémon&#x27;s weight.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/212.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scizor](../pokemon/scizor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/374.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beldum](../pokemon/beldum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/376.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metagross](../pokemon/metagross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/379.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Registeel](../pokemon/registeel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/135/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../heavy-metal/"><span class="rw-record-nav__label">← Heavy Metal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../multiscale/"><span class="rw-record-nav__label">Multiscale →</span></a>
</nav>
