# Wonder Guard

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>25</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">1</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Protects against damaging moves that are not super effective.</strong></p>
<p>This Pokémon is immune to damaging moves that are not super effective against it. Moves that inflict fixed damage, such as Night Shade or Seismic Toss, are considered super effective if their types are. Damage not directly dealt by moves, such as damage from weather, a status ailment, or Spikes, is not prevented. This ability cannot be copied with Role Play or traded away with Skill Swap, but it can be copied with Trace, disabled with Gastro Acid, or changed with Worry Seed. This Pokémon can still use Role Play itself to lose this ability, but not Skill Swap. If this Pokémon has a Substitute, this ability will block moves as usual and any moves not blocked will react to the Substitute as usual.</p>

<figure class="rw-pokedex-entry">
<blockquote>Only supereffective moves will hit.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/292.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shedinja](../pokemon/shedinja.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 1, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/25/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../rough-skin/"><span class="rw-record-nav__label">← Rough Skin</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../levitate/"><span class="rw-record-nav__label">Levitate →</span></a>
</nav>
