# Lightningrod

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>31</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Redirects single-target Electric moves to this Pokémon where possible. Absorbs Electric moves, raising Special Attack one stage.</strong></p>
<p>All other Pokémon&#x27;s single-target Electric-type moves are redirected to this Pokémon if it is an eligible target. Other Pokémon&#x27;s Electric moves raise this Pokémon&#x27;s Special Attack one stage, negating any other effect on it, and cannot miss it. If the move&#x27;s intended target also has this ability, the move is not redirected. When multiple Pokémon with this ability are possible targets for redirection, the move is redirected to the one with the highest Speed stat, or, in the case of a tie, to a random tied Pokémon. Follow Me takes precedence over this ability. If the Pokémon is a Ground-type and thus immune to Electric moves, its immunity prevents the Special Attack boost.</p>

<figure class="rw-pokedex-entry">
<blockquote>Draws in all Electric-type moves to up Sp. Attack.</blockquote>
<figcaption>ROM description</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/26.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raichu](../pokemon/raichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/135.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jolteon](../pokemon/jolteon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/145.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zapdos](../pokemon/zapdos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/172.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2, 3<abbr class="rw-hidden-ability" title="Hidden Ability">*</abbr> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/309.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electrike](../pokemon/electrike.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/310.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/522.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blitzle](../pokemon/blitzle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">6 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pikachu/">Pikachu</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/raichu/">Raichu</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/goldeen/">Goldeen</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/seaking/">Seaking</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/zapdos/">Zapdos</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li><li><a href="../../pokemon/pichu/">Pichu</a>: Slot 3<span class="rw-diff-arrow">→</span>Slots 2, 3</li></ul><p class="rw-comparison-count">5 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a></li><li><a href="../../pokemon/marowak/">Marowak</a></li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a></li><li><a href="../../pokemon/rhydon/">Rhydon</a></li><li><a href="../../pokemon/rhyperior/">Rhyperior</a></li></ul><p class="rw-comparison-count">1 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jolteon/">Jolteon</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. The displayed description comes from the ROM message table.
Ability name source: ROM message table `a/0/0/2` member `374`.
Ability description source: ROM message table `a/0/0/2` member `375`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/31/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../natural-cure/"><span class="rw-record-nav__label">← Natural Cure</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../serene-grace/"><span class="rw-record-nav__label">Serene Grace →</span></a>
</nav>
