# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 15](../locations/header-378.md) | `header-378` | `map_378` |

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 40–55 |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C64`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-376/"><span class="rw-record-nav__label">← Daily Swarm — Abundant Shrine</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-383/"><span class="rw-record-nav__label">Daily Swarm — Route 16 →</span></a>
</nav>
