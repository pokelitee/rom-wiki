# Map 111 (Spring)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>138</dd></div>
<div><dt>Map index</dt><dd>111</dd></div>
<div><dt>Season</dt><dd>Spring</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Route 7](../locations/header-337.md) | 337 | Blaze Black 2 / Volt White 2 |

## Grass/Cave

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/520.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tranquill](../pokemon/tranquill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 35 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/585.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Deerling](../pokemon/deerling.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 36 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/231.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/162.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/335.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zangoose](../pokemon/zangoose.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/336.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seviper](../pokemon/seviper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 36 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/327.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinda](../pokemon/spinda.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 2% |

## Doubles Grass

Encounter rate: 6

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/520.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tranquill](../pokemon/tranquill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/523.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zebstrika](../pokemon/zebstrika.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 39 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/505.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Watchog](../pokemon/watchog.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 39 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 37 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/162.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 37 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/335.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zangoose](../pokemon/zangoose.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/336.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seviper](../pokemon/seviper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 38 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/327.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinda](../pokemon/spinda.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 37 | 2% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 34 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/587.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emolga](../pokemon/emolga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 34 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/521.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unfezant](../pokemon/unfezant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/424.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ambipom](../pokemon/ambipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 36 | 10% |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Watchog — Lv. 33</li><li>Foongus — Lv. 33</li><li>Watchog — Lv. 31</li><li>Zebstrika — Lv. 31</li><li>Tranquill — Lv. 32</li><li>Zebstrika — Lv. 33</li><li>Tranquill — Lv. 30</li><li>Deerling — Lv. 30</li><li>Watchog — Lv. 33</li><li>Foongus — Lv. 33</li><li>Zangoose — Lv. 32</li><li>Seviper — Lv. 32</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Spinda — Lv. 35</li><li>Aipom — Lv. 34</li><li>Phanpy — Lv. 34</li><li>Deerling — Lv. 34</li><li>Watchog — Lv. 36</li><li>Tranquill — Lv. 35</li><li>Zebstrika — Lv. 36</li><li>Zangoose — Lv. 36</li><li>Seviper — Lv. 36</li><li>Furret — Lv. 35</li><li>Kecleon — Lv. 35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Watchog — Lv. 36</li><li>Foongus — Lv. 36</li><li>Watchog — Lv. 34</li><li>Zebstrika — Lv. 34</li><li>Tranquill — Lv. 35</li><li>Zebstrika — Lv. 36</li><li>Tranquill — Lv. 33</li><li>Deerling — Lv. 33</li><li>Watchog — Lv. 36</li><li>Foongus — Lv. 36</li><li>Zangoose — Lv. 35</li><li>Seviper — Lv. 35</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Spinda — Lv. 37</li><li>Aipom — Lv. 37</li><li>Watchog — Lv. 38</li><li>Sawsbuck — Lv. 38</li><li>Donphan — Lv. 39</li><li>Tranquill — Lv. 38</li><li>Zebstrika — Lv. 39</li><li>Zangoose — Lv. 38</li><li>Seviper — Lv. 38</li><li>Kecleon — Lv. 37</li><li>Furret — Lv. 38</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Unfezant — Lv. 33</li><li>Audino — Lv. 33</li><li>Audino — Lv. 31</li><li>Emolga — Lv. 31</li><li>Audino — Lv. 32</li><li>Audino — Lv. 30</li><li>Unfezant — Lv. 33</li><li>Audino — Lv. 33</li><li>Audino — Lv. 33</li></ul><p class="rw-comparison-count">8 entries added</p><ul class="rw-comparison-list"><li>Audino — Lv. 36</li><li>Audino — Lv. 34</li><li>Emolga — Lv. 34</li><li>Audino — Lv. 35</li><li>Audino — Lv. 34</li><li>Audino — Lv. 36</li><li>Ambipom — Lv. 35</li><li>Unfezant — Lv. 35</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `111`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-110/"><span class="rw-record-nav__label">← Map 110</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-111-summer/"><span class="rw-record-nav__label">Map 111 (Summer) →</span></a>
</nav>
