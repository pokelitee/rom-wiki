# Daily Swarm { #daily-swarm }

This encounter is available only when this route is selected as the daily swarm.

| Pokémon | Type | Levels |
| ------- | ---- | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/284.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Masquerain](../pokemon/masquerain.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 40–55 |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 11](../locations/header-365.md) | `header-365` | `map_365` |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **black-2-us / white-2-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Daily Swarm source: exact ROM table record in `overlay36` at offset `0x50C4C`.
The swarm-to-location relationship uses the stored map-header ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../daily-swarm-345/"><span class="rw-record-nav__label">← Daily Swarm — Route 8</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../daily-swarm-370/"><span class="rw-record-nav__label">Daily Swarm — Route 13 →</span></a>
</nav>
