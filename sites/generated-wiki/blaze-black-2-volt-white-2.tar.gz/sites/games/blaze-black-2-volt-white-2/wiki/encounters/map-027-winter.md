# Map 027 (Winter)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>45</dd></div>
<div><dt>Map index</dt><dd>27</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Dragonspiral Tower](../locations/header-205.md) | 205 | Blaze Black 2 / Volt White 2 |

## Grass/Cave

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 63 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 64 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/620.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienshao](../pokemon/mienshao.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/620.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienshao](../pokemon/mienshao.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 66 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 64 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 65 | 1% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 66 | 1% |

## Doubles Grass

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 67 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/583.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanillish](../pokemon/vanillish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 68 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/620.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienshao](../pokemon/mienshao.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/586.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sawsbuck](../pokemon/sawsbuck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--grass">Grass</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/614.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beartic](../pokemon/beartic.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/620.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mienshao](../pokemon/mienshao.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 69 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 67 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 68 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 68 | 1% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 69 | 1% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 65 | 51% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/587.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Emolga](../pokemon/emolga.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 65 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 66 | 29% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 68 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/584.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vanilluxe](../pokemon/vanilluxe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 68 | 5% |

## Hack changes

Compared with **black-2-us / white-2-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Beartic — Lv. 58</li><li>Mienshao — Lv. 58</li><li>Mienshao — Lv. 56</li><li>Beartic — Lv. 57</li><li>Mienshao — Lv. 57</li><li>Sawsbuck — Lv. 57</li><li>Vanillish — Lv. 55</li><li>Sawsbuck — Lv. 55</li><li>Beartic — Lv. 58</li><li>Mienshao — Lv. 58</li><li>Vanillish — Lv. 57</li><li>Mienshao — Lv. 58</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 65</li><li>Altaria — Lv. 66</li><li>Beartic — Lv. 65</li><li>Mienshao — Lv. 65</li><li>Sawsbuck — Lv. 65</li><li>Sawsbuck — Lv. 66</li><li>Vanillish — Lv. 63</li><li>Vanillish — Lv. 64</li><li>Kadabra — Lv. 64</li><li>Altaria — Lv. 65</li><li>Mienshao — Lv. 66</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Beartic — Lv. 66</li><li>Mienfoo — Lv. 66</li><li>Mienshao — Lv. 64</li><li>Beartic — Lv. 65</li><li>Mienshao — Lv. 65</li><li>Sawsbuck — Lv. 65</li><li>Vanillish — Lv. 63</li><li>Sawsbuck — Lv. 63</li><li>Beartic — Lv. 66</li><li>Mienshao — Lv. 66</li><li>Vanillish — Lv. 65</li><li>Mienshao — Lv. 66</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 68</li><li>Altaria — Lv. 69</li><li>Mienshao — Lv. 68</li><li>Beartic — Lv. 69</li><li>Sawsbuck — Lv. 68</li><li>Sawsbuck — Lv. 69</li><li>Vanillish — Lv. 67</li><li>Vanillish — Lv. 68</li><li>Kadabra — Lv. 67</li><li>Altaria — Lv. 68</li><li>Mienshao — Lv. 69</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Audino — Lv. 58</li><li>Vanilluxe — Lv. 58</li><li>Audino — Lv. 56</li><li>Emolga — Lv. 56</li><li>Audino — Lv. 57</li><li>Audino — Lv. 55</li><li>Audino — Lv. 58</li><li>Vanilluxe — Lv. 58</li><li>Audino — Lv. 58</li></ul><p class="rw-comparison-count">9 entries added</p><ul class="rw-comparison-list"><li>Audino — Lv. 65</li><li>Audino — Lv. 66</li><li>Audino — Lv. 65</li><li>Emolga — Lv. 65</li><li>Audino — Lv. 66</li><li>Audino — Lv. 65</li><li>Audino — Lv. 66</li><li>Vanilluxe — Lv. 68</li><li>Alakazam — Lv. 68</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `27`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-027-autumn/"><span class="rw-record-nav__label">← Map 027 (Autumn)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-028-spring/"><span class="rw-record-nav__label">Map 028 (Spring) →</span></a>
</nav>
