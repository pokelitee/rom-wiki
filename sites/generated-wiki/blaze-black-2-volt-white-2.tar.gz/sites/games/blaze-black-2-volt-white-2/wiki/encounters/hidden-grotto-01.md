# Hidden Grotto 01 — Route 5 { #hidden-grotto-01 }

The ROM chooses one of four groups independently from the listed pool. Pool chance and group chance are kept separate.

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 5](../locations/header-329.md) | `header-329` | `map_329` |

## Pokémon

| Pokémon | Type | Levels | Female | Pool | Group |
| ------- | ---- | -----: | -----: | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/446.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24–29 | 50% | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/510.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Liepard](../pokemon/liepard.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 24–29 | 50% | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/572.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minccino](../pokemon/minccino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24–29 | 50% | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/561.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sigilyph](../pokemon/sigilyph.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 24–29 | 50% | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 24–29 | 100% | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 24–29 | 0% | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/575.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gothorita](../pokemon/gothorita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--dark">Dark</span></span> | 24–29 | 50% | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/578.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duosion](../pokemon/duosion.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 24–29 | 50% | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/8.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wartortle](../pokemon/wartortle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 15% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/159.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Croconaw](../pokemon/croconaw.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 15% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/8.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wartortle](../pokemon/wartortle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 15% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/159.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Croconaw](../pokemon/croconaw.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 24–29 | 50% | 15% | D |

## Visible items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fire-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fire Stone](../items/fire-stone.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/water-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Water Stone](../items/water-stone.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/thunder-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Thunderstone](../items/thunder-stone.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leaf-stone.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Leaf Stone](../items/leaf-stone.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ultra Ball](../items/ultra-ball.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Max Repel](../items/max-repel.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hyper Potion](../items/hyper-potion.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Great Ball](../items/great-ball.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Repel](../items/super-repel.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Super Potion](../items/super-potion.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poké Ball](../items/poke-ball.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/repel.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Repel](../items/repel.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/potion.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Potion](../items/potion.md)</span> | 25% | D |

## Hidden items

| Item | Pool | Group |
| ---- | ---: | ----- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rare Candy](../items/rare-candy.md)</span> | 1% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-up.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Up](../items/pp-up.md)</span> | 1% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pp-max.png" alt="" loading="lazy" referrerpolicy="no-referrer">[PP Max](../items/pp-max.md)</span> | 1% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/red-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Red Shard](../items/red-shard.md)</span> | 4% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/blue-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Blue Shard](../items/blue-shard.md)</span> | 4% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/yellow-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yellow Shard](../items/yellow-shard.md)</span> | 4% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/green-shard.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Green Shard](../items/green-shard.md)</span> | 4% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/big-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Big Mushroom](../items/big-mushroom.md)</span> | 10% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/tiny-mushroom.png" alt="" loading="lazy" referrerpolicy="no-referrer">[TinyMushroom](../items/tiny-mushroom.md)</span> | 10% | D |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/growth-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growth Mulch](../items/growth-mulch.md)</span> | 25% | A |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/damp-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Damp Mulch](../items/damp-mulch.md)</span> | 25% | B |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/stable-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stable Mulch](../items/stable-mulch.md)</span> | 25% | C |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gooey-mulch.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gooey Mulch](../items/gooey-mulch.md)</span> | 25% | D |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **black-2-us / white-2-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/liepard/">Liepard</a> — Lv. 20–25</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 20–25</li><li><a href="../../pokemon/liepard/">Liepard</a> — Lv. 20–25</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 20–25</li><li><a href="../../pokemon/liepard/">Liepard</a> — Lv. 20–25</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 20–25</li><li><a href="../../pokemon/liepard/">Liepard</a> — Lv. 20–25</li><li><a href="../../pokemon/foongus/">Foongus</a> — Lv. 20–25</li><li><a href="../../pokemon/minccino/">Minccino</a> — Lv. 20–25</li><li><a href="../../pokemon/minccino/">Minccino</a> — Lv. 20–25</li><li><a href="../../pokemon/minccino/">Minccino</a> — Lv. 20–25</li><li><a href="../../pokemon/minccino/">Minccino</a> — Lv. 20–25</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/nidorino/">Nidorino</a> — Lv. 24–29</li><li><a href="../../pokemon/nidorina/">Nidorina</a> — Lv. 24–29</li><li><a href="../../pokemon/munchlax/">Munchlax</a> — Lv. 24–29</li><li><a href="../../pokemon/wartortle/">Wartortle</a> — Lv. 24–29</li><li><a href="../../pokemon/croconaw/">Croconaw</a> — Lv. 24–29</li><li><a href="../../pokemon/liepard/">Liepard</a> — Lv. 24–29</li><li><a href="../../pokemon/minccino/">Minccino</a> — Lv. 24–29</li><li><a href="../../pokemon/gothorita/">Gothorita</a> — Lv. 24–29</li><li><a href="../../pokemon/wartortle/">Wartortle</a> — Lv. 24–29</li><li><a href="../../pokemon/croconaw/">Croconaw</a> — Lv. 24–29</li><li><a href="../../pokemon/sigilyph/">Sigilyph</a> — Lv. 24–29</li><li><a href="../../pokemon/duosion/">Duosion</a> — Lv. 24–29</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/7/3` member `1`.
Hidden Grotto Pokémon, levels, gender percentages, forms, and item IDs come from the Grotto record.
The exterior-map relationship comes from its ROM furniture dispatch ID.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../hidden-grotto-00/"><span class="rw-record-nav__label">← Hidden Grotto 00 — Floccesy Ranch</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../hidden-grotto-02/"><span class="rw-record-nav__label">Hidden Grotto 02 — Lostlorn Forest →</span></a>
</nav>
