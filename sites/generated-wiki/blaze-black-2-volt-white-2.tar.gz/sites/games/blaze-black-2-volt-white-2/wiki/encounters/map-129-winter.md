# Map 129 (Winter)

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>168</dd></div>
<div><dt>Map index</dt><dd>129</dd></div>
<div><dt>Season</dt><dd>Winter</dd></div>
<div><dt>Methods</dt><dd>Grass/Cave, Doubles Grass, Shaking Spots, Surfing, Surfing Spots, Fishing, Fishing Spots</dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Version |
| -------- | -----: | ------- |
| [Route 20](../locations/header-446.md) | 446 | Blaze Black 2 / Volt White 2 |

## Grass/Cave

Encounter rate: 2

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/504.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Patrat](../pokemon/patrat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2–7 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/540.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sewaddle](../pokemon/sewaddle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 2–7 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2–7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 3–7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 3–7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 2–7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 4–5 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2–7 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2–7 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/52.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meowth](../pokemon/meowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2–7 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/371.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 2–7 | 2% |

## Doubles Grass

Encounter rate: 3

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/540.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sewaddle](../pokemon/sewaddle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 11–14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/543.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venipede](../pokemon/venipede.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 11–14 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/519.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidove](../pokemon/pidove.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 10–13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 11–14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 11–14 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–13 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/438.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bonsly](../pokemon/bonsly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 11–13 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/439.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 11–13 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 11–14 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/48.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venonat](../pokemon/venonat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 11–14 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/371.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 10–13 | 2% |

## Shaking Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/206.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dunsparce](../pokemon/dunsparce.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/531.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Audino](../pokemon/audino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 6 | 10% |

## Surfing

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/298.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Azurill](../pokemon/azurill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5–35 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 5–35 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–35 | 5% |

## Surfing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 30–40 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–40 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 35–45 | 5% |

## Fishing

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5 | 5% |

## Fishing Spots

Encounter rate: 1

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–15 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/550.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Basculin](../pokemon/basculin-red-striped.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–15 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 5–15 | 10% |

## Hack changes

### Blaze Black 2

Compared with **black-2-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Sunkern — Lv. 4</li><li>Purrloin — Lv. 4</li><li>Patrat — Lv. 3</li><li>Purrloin — Lv. 3</li><li>Sewaddle — Lv. 3</li><li>Pidove — Lv. 2</li><li>Sewaddle — Lv. 2</li><li>Sunkern — Lv. 4</li><li>Purrloin — Lv. 4</li><li>Pidove — Lv. 4</li><li>Sewaddle — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 2–7</li><li>Swinub — Lv. 2–7</li><li>Pidove — Lv. 2–7</li><li>Lotad — Lv. 3–7</li><li>Seedot — Lv. 3–7</li><li>Patrat — Lv. 2–7</li><li>Sewaddle — Lv. 2–7</li><li>Meowth — Lv. 2–7</li><li>Mankey — Lv. 2–7</li><li>Ralts — Lv. 4–5</li><li>Smoochum — Lv. 2–7</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Sunkern — Lv. 11</li><li>Purrloin — Lv. 11</li><li>Patrat — Lv. 10</li><li>Purrloin — Lv. 10</li><li>Sewaddle — Lv. 11</li><li>Venipede — Lv. 10</li><li>Pidove — Lv. 9</li><li>Sunkern — Lv. 11</li><li>Purrloin — Lv. 11</li><li>Pidove — Lv. 10</li><li>Sewaddle — Lv. 10</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 10–13</li><li>Swinub — Lv. 10–13</li><li>Pidove — Lv. 10–13</li><li>Lotad — Lv. 11–14</li><li>Seedot — Lv. 11–14</li><li>Sewaddle — Lv. 11–14</li><li>Venipede — Lv. 11–14</li><li>Smoochum — Lv. 11–14</li><li>Venonat — Lv. 11–14</li><li>Bonsly — Lv. 11–13</li><li>Mime Jr. — Lv. 11–13</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">6 entries removed</p><ul class="rw-comparison-list"><li>Audino — Lv. 4</li><li>Dunsparce — Lv. 3</li><li>Audino — Lv. 3</li><li>Audino — Lv. 2</li><li>Audino — Lv. 4</li><li>Audino — Lv. 4</li></ul><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li>Audino — Lv. 6</li><li>Dunsparce — Lv. 4</li><li>Audino — Lv. 5</li><li>Audino — Lv. 4</li><li>Audino — Lv. 6</li><li>Audino — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 5–15</li><li>Azurill — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Azurill — Lv. 5–35</li><li>Surskit — Lv. 5–35</li><li>Azurill — Lv. 5–35</li><li>Seel — Lv. 5–35</li><li>Azurill — Lv. 5–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Azumarill — Lv. 5–15</li><li>Marill — Lv. 5–15</li><li>Azumarill — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dewgong — Lv. 35–45</li><li>Marill — Lv. 30–40</li><li>Dewgong — Lv. 35–45</li><li>Seel — Lv. 30–40</li><li>Surskit — Lv. 30–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 50–70</li><li>Basculin — Lv. 40–60</li><li>Poliwag — Lv. 50–70</li><li>Poliwag — Lv. 50–70</li><li>Poliwag — Lv. 40–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Basculin — Lv. 5</li><li>Shellder — Lv. 5</li><li>Basculin — Lv. 5</li><li>Shellder — Lv. 5</li><li>Shellder — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Politoed — Lv. 50–70</li><li>Basculin — Lv. 40–60</li><li>Politoed — Lv. 50–70</li><li>Poliwhirl — Lv. 50–70</li><li>Poliwhirl — Lv. 40–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Dratini — Lv. 5–15</li><li>Dratini — Lv. 5–15</li><li>Shellder — Lv. 5–15</li></ul></li></ul></div>
</section>
</div>

</details>

### Volt White 2

Compared with **white-2-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Grass/Cave</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Sunkern — Lv. 4</li><li>Purrloin — Lv. 4</li><li>Patrat — Lv. 3</li><li>Purrloin — Lv. 3</li><li>Sewaddle — Lv. 3</li><li>Pidove — Lv. 2</li><li>Sewaddle — Lv. 2</li><li>Sunkern — Lv. 4</li><li>Purrloin — Lv. 4</li><li>Pidove — Lv. 4</li><li>Sewaddle — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 2–7</li><li>Swinub — Lv. 2–7</li><li>Pidove — Lv. 2–7</li><li>Lotad — Lv. 3–7</li><li>Seedot — Lv. 3–7</li><li>Patrat — Lv. 2–7</li><li>Sewaddle — Lv. 2–7</li><li>Meowth — Lv. 2–7</li><li>Mankey — Lv. 2–7</li><li>Ralts — Lv. 4–5</li><li>Smoochum — Lv. 2–7</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Doubles Grass</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Sunkern — Lv. 11</li><li>Purrloin — Lv. 11</li><li>Patrat — Lv. 10</li><li>Purrloin — Lv. 10</li><li>Sewaddle — Lv. 11</li><li>Venipede — Lv. 10</li><li>Pidove — Lv. 9</li><li>Sunkern — Lv. 11</li><li>Purrloin — Lv. 11</li><li>Pidove — Lv. 10</li><li>Sewaddle — Lv. 10</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 10–13</li><li>Swinub — Lv. 10–13</li><li>Pidove — Lv. 10–13</li><li>Lotad — Lv. 11–14</li><li>Seedot — Lv. 11–14</li><li>Sewaddle — Lv. 11–14</li><li>Venipede — Lv. 11–14</li><li>Smoochum — Lv. 11–14</li><li>Venonat — Lv. 11–14</li><li>Bonsly — Lv. 11–13</li><li>Mime Jr. — Lv. 11–13</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Shaking Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">6 entries removed</p><ul class="rw-comparison-list"><li>Audino — Lv. 4</li><li>Dunsparce — Lv. 3</li><li>Audino — Lv. 3</li><li>Audino — Lv. 2</li><li>Audino — Lv. 4</li><li>Audino — Lv. 4</li></ul><p class="rw-comparison-count">6 entries added</p><ul class="rw-comparison-list"><li>Audino — Lv. 6</li><li>Dunsparce — Lv. 4</li><li>Audino — Lv. 5</li><li>Audino — Lv. 4</li><li>Audino — Lv. 6</li><li>Audino — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Basculin — Lv. 5–15</li><li>Azurill — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Azurill — Lv. 5–35</li><li>Surskit — Lv. 5–35</li><li>Azurill — Lv. 5–35</li><li>Seel — Lv. 5–35</li><li>Azurill — Lv. 5–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surfing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Azumarill — Lv. 5–15</li><li>Marill — Lv. 5–15</li><li>Azumarill — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Basculin — Lv. 5–15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dewgong — Lv. 35–45</li><li>Marill — Lv. 30–40</li><li>Dewgong — Lv. 35–45</li><li>Seel — Lv. 30–40</li><li>Surskit — Lv. 30–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 50–70</li><li>Basculin — Lv. 40–60</li><li>Poliwag — Lv. 50–70</li><li>Poliwag — Lv. 50–70</li><li>Poliwag — Lv. 40–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Basculin — Lv. 5</li><li>Shellder — Lv. 5</li><li>Basculin — Lv. 5</li><li>Shellder — Lv. 5</li><li>Shellder — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fishing Spots</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Politoed — Lv. 50–70</li><li>Basculin — Lv. 40–60</li><li>Politoed — Lv. 50–70</li><li>Poliwhirl — Lv. 50–70</li><li>Poliwhirl — Lv. 40–60</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 5–15</li><li>Basculin — Lv. 5–15</li><li>Dratini — Lv. 5–15</li><li>Dratini — Lv. 5–15</li><li>Shellder — Lv. 5–15</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/1/2/7` member `129`.
Chance percentages are not stored in the ROM's encounter tables — only each slot's species and level(s) are ROM data — they are fixed, publicly documented Generation III+ engine weights applied by slot position.
Location names and links come from the ROM's own map header table, cross-referenced through the shared wild-encounter table index.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../map-129-autumn/"><span class="rw-record-nav__label">← Map 129 (Autumn)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../map-130/"><span class="rw-record-nav__label">Map 130 →</span></a>
</nav>
