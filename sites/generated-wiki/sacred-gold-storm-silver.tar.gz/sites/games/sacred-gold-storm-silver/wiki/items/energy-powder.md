# EnergyPowder

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/energy-powder.png" alt="EnergyPowder icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>34</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 50 HP, but lowers happiness.</strong></p>
<p>Used on a party Pokémon : Restores 50 HP. Decreases happiness by 5/5/10.</p>

<figure class="rw-pokedex-entry">
<blockquote>A very bitter medicine powder. It restores the HP of one Pokémon by 50 points.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 50, friendship (low -5, medium -5, high -10)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map header | Kind | Coordinates |
| -------- | ------- | ---------- | ---- | ----------- |
| [National Park](../locations/header-096.md) | D22R0101 | `header-096` | Hidden | (41, 62) |
| [Union Cave](../locations/header-099.md) | D25R0101 | `header-099` | Visible | (29, 72) |
| [National Park](../locations/header-487.md) | D22R0102 | `header-487` | Hidden | (41, 62) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Herb Shop | ₽500 | Post-game |

## Hack changes

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `34` |

Source: exact ROM record from `a/0/1/7` member `34`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/34/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../moomoo-milk/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moomoo-milk.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Moomoo Milk</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../energy-root/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/energy-root.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Energy Root →</span></a>
</nav>
