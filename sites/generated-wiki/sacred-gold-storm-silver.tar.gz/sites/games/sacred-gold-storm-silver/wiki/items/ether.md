# Ether

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ether.png" alt="Ether icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>38</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Pp Recovery</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 10 PP for one move.</strong></p>
<p>Used on a party Pokémon : Restores 10 PP for a selected move.</p>

<figure class="rw-pokedex-entry">
<blockquote>It restores the PP of a Pokémon’s selected move by a maximum of 10 points.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>10</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x10</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores PP, PP amount 10</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Burned Tower](../locations/header-007.md) | D18R0101 | `header-007` | Hidden | (11, 6) |
| [Route 9](../locations/header-017.md) | R09 | `header-017` | Hidden | (1422, 140) |
| [Ecruteak City](../locations/header-078.md) | T27 | `header-078` | Hidden | (379, 146) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Visible | (47, 16) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Hidden | (33, 14) |
| [Mt. Mortar](../locations/header-119.md) | D38R0101 | `header-119` | Visible | (34, 20) |
| [Goldenrod City](../locations/header-200.md) | D37R0103 | `header-200` | Visible | (17, 23) |
| [Lighthouse](../locations/header-222.md) | D27R0104 | `header-222` | Visible | (14, 13) |
| [Mt. Mortar](../locations/header-250.md) | D38R0102 | `header-250` | Hidden | (43, 20) |
| [Lake of Rage](../locations/header-295.md) | T29R0201 | `header-295` | Script Awarded | — |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `38` |

Source: exact ROM record from `a/0/1/7` member `38`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/38/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../revival-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/revival-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Revival Herb</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-ether/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-ether.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Ether →</span></a>
</nav>
