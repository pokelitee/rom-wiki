# Full Heal

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-heal.png" alt="Full Heal icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>27</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽600</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It heals all the status problems of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 39](../locations/header-043.md) | R39 | `header-043` | Hidden | (285, 231) |
| [Route 45](../locations/header-047.md) | R45 | `header-047` | Visible | (653, 269) |
| [Vermilion City](../locations/header-054.md) | T06 | `header-054` | Hidden | (1324, 306) |
| [Azalea Town](../locations/header-074.md) | T23 | `header-074` | Hidden | (421, 469) |
| [Olivine City](../locations/header-077.md) | T26 | `header-077` | Hidden | (285, 231) |
| [National Park](../locations/header-096.md) | D22R0101 | `header-096` | Hidden | (41, 62) |
| [National Park](../locations/header-096.md) | D22R0101 | `header-096` | Hidden | (53, 78) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Hidden | (39, 12) |
| [Victory Road](../locations/header-124.md) | D43R0101 | `header-124` | Hidden | (26, 35) |
| [Dark Cave](../locations/header-176.md) | D42R0102 | `header-176` | Visible | (56, 43) |
| [Slowpoke Well](../locations/header-177.md) | D26R0102 | `header-177` | Hidden | (36, 19) |
| [Goldenrod City](../locations/header-201.md) | D37R0104 | `header-201` | Visible | (7, 4) |
| [Ice Path](../locations/header-238.md) | D39R0103 | `header-238` | Visible | (15, 15) |
| [Team Rocket HQ](../locations/header-248.md) | D35R0103 | `header-248` | Hidden | (20, 29) |
| [Team Rocket HQ](../locations/header-249.md) | D35R0104 | `header-249` | Visible | (49, 15) |
| [Mt. Mortar](../locations/header-251.md) | D38R0103 | `header-251` | Hidden | (16, 18) |
| [Bell Tower](../locations/header-333.md) | D17R0103 | `header-333` | Visible | (6, 25) |
| [Bell Tower](../locations/header-336.md) | D17R0106 | `header-336` | Visible | (6, 7) |
| [Cerulean Cave](../locations/header-450.md) | D03R0102 | `header-450` | Hidden | (56, 24) |
| [National Park](../locations/header-487.md) | D22R0102 | `header-487` | Hidden | (41, 62) |
| [National Park](../locations/header-487.md) | D22R0102 | `header-487` | Hidden | (53, 78) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Cianwood Pharmacy | ₽600 | Main game |
| Goldenrod Department Store Healing | ₽600 | Main game |
| Celadon Department Store Healing | ₽600 | Post-game |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Victory Road</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `27` |

Source: exact ROM record from `a/0/1/7` member `27`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/27/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Super Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../revive/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/revive.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Revive →</span></a>
</nav>
