# Life Orb

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/life-orb.png" alt="Life Orb icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>270</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Held Items</dd></div>
<div><dt>Base price</dt><dd>₽200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Holder’s moves inflict 30% extra damage, but cost 10% max HP.</strong></p>
<p>Held: Damage from the holder’s moves is increased by 30%. On each turn the holder uses a damage-inflicting move, it takes 10% its max HP in damage.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It boosts the power of moves, but at the cost of some HP on each hit.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>98</dd></div>
<div><dt>Held effect parameter</dt><dd>30</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Ruins of Alph](../locations/header-326.md) | D24R0214 | `header-326` | Visible | (4, 12) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Rival ………](../trainers/trainer-0511.md) | Held by Lugia |
| [Rival ………](../trainers/trainer-0511.md) | Held by Ho-oh |
| [Rival ………](../trainers/trainer-0511.md) | Held by Mewtwo |
| [Champion Lance](../trainers/trainer-0701.md) | Held by Gyarados |
| [Leader Whitney](../trainers/trainer-0714.md) | Held by Clefable |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gyarados/">Gyarados</a></li><li><a href="../../pokemon/clefable/">Clefable</a></li><li><a href="../../pokemon/mewtwo/">Mewtwo</a></li><li><a href="../../pokemon/lugia/">Lugia</a></li><li><a href="../../pokemon/ho-oh/">Ho-oh</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `248` |

Source: exact ROM record from `a/0/1/7` member `248`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/247/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../light-clay/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-clay.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Light Clay</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../power-herb/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/power-herb.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Power Herb →</span></a>
</nav>
