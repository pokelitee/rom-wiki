# Carbos

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="Carbos icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>48</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Speed effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Speed effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Speed stat of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Speed EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 10](../locations/header-018.md) | R10 | `header-018` | Hidden | (1418, 183) |
| [Radio Tower](../locations/header-186.md) | D23R0102 | `header-186` | Script Awarded | — |
| [Ice Path](../locations/header-238.md) | D39R0103 | `header-238` | Hidden | (26, 26) |
| [Whirl Islands](../locations/header-242.md) | D40R0102 | `header-242` | Visible | (19, 36) |
| [Mt. Mortar](../locations/header-252.md) | D38R0104 | `header-252` | Visible | (11, 58) |
| [Bell Tower](../locations/header-338.md) | D17R0108 | `header-338` | Hidden | (21, 6) |
| [Route 2](../locations/header-414.md) | R02R0101 | `header-414` | Visible | (1053, 129) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store Vitamins | ₽9,800 | Main game |
| Celadon Department Store Vitamins | ₽9,800 | Post-game |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `48` |

Source: exact ROM record from `a/0/1/7` member `48`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/48/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../iron/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iron.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Iron</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../calcium/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/calcium.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Calcium →</span></a>
</nav>
