# Awakening

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/awakening.png" alt="Awakening icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>21</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Status Cures</dd></div>
<div><dt>Base price</dt><dd>₽250</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Cures sleep.</strong></p>
<p>Used on a party Pokémon : Cures sleep.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine. It awakens a Pokémon from the clutches of sleep.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x08</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Burned Tower](../locations/header-217.md) | D18R0102 | `header-217` | Hidden | (15, 24) |
| [Ruins of Alph](../locations/header-327.md) | D24R0215 | `header-327` | Visible | (4, 8) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store Healing | ₽250 | Main game |
| Celadon Department Store Healing | ₽250 | Post-game |

## Hack changes

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `21` |

Source: exact ROM record from `a/0/1/7` member `21`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/21/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ice-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ice-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ice Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../parlyz-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/paralyze-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Parlyz Heal →</span></a>
</nav>
