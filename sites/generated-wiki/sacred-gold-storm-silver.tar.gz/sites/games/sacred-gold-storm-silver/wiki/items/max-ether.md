# Max Ether

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-ether.png" alt="Max Ether icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>39</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Pp Recovery</dd></div>
<div><dt>Base price</dt><dd>₽2,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores PP to full for one move.</strong></p>
<p>Used on a party Pokémon : Restores PP to full for a selected move.</p>

<figure class="rw-pokedex-entry">
<blockquote>It fully restores the PP of a single selected move that has been learned by the target Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x10</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores PP, PP amount 127</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 17](../locations/header-025.md) | R17 | `header-025` | Hidden | (1133, 355) |
| [Route 43](../locations/header-045.md) | R43 | `header-045` | Visible | (532, 138) |
| [Route 41](../locations/header-095.md) | W41 | `header-095` | Hidden | (237, 370) |
| [Viridian Forest](../locations/header-147.md) | D46R0101 | `header-147` | Hidden | (11, 71) |
| [Dark Cave](../locations/header-176.md) | D42R0102 | `header-176` | Hidden | (59, 26) |
| [Goldenrod City](../locations/header-202.md) | D37R0105 | `header-202` | Visible | (28, 23) |
| [Mt. Mortar](../locations/header-252.md) | D38R0104 | `header-252` | Visible | (46, 45) |
| [Mt. Silver Cave](../locations/header-459.md) | D41R0102 | `header-459` | Hidden | (23, 12) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `39` |

Source: exact ROM record from `a/0/1/7` member `39`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/39/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ether/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ether.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Ether</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../elixir/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/elixir.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Elixir →</span></a>
</nav>
