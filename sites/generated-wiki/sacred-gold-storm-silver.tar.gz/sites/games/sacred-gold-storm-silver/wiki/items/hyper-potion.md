# Hyper Potion

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hyper-potion.png" alt="Hyper Potion icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>25</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽1,200</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 200 HP.</strong></p>
<p>Used on a party Pokémon : Restores 200 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>200</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 200</dd></div>
</dl>

## Overworld locations

| Location | Kind | Coordinates |
| -------- | ---- | ----------- |
| [Cianwood City — T24](../locations/header-075.md) | Hidden | (170, 332) |
| [Ruins of Alph — D24R0214](../locations/header-326.md) | Visible | (4, 8) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Cianwood Pharmacy | ₽1,200 | Main game |
| Mahogany After Hideout | ₽1,200 | Main game |
| Goldenrod Department Store Healing | ₽1,200 | Main game |
| Celadon Department Store Healing | ₽1,200 | Post-game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Morty](../trainers/trainer-0031.md) | AI battle item |
| [Leader Pryce](../trainers/trainer-0032.md) | AI battle item |
| [Leader Jasmine](../trainers/trainer-0033.md) | AI battle item |
| [Leader Chuck](../trainers/trainer-0034.md) | AI battle item |
| [Leader Clair](../trainers/trainer-0035.md) | AI battle item |
| [Executive Ariana](../trainers/trainer-0478.md) | AI battle item |
| [Executive Archer](../trainers/trainer-0485.md) | AI battle item |
| [Executive Petrel](../trainers/trainer-0487.md) | AI battle item |
| [School Kid Jack](../trainers/trainer-0503.md) | AI battle item |
| [Executive Proton](../trainers/trainer-0706.md) | AI battle item |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Archer</li><li>Ariana</li><li>Petrel</li><li>Proton</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `25` |

Source: exact ROM record from `a/0/1/7` member `25`.
The name, item-data member mapping, mechanics, and references are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Effect description, flavor text, and icon come from PokéDB / PokéAPI reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/25/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Max Potion</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../super-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/super-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Super Potion →</span></a>
</nav>
