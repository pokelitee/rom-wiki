# Iron

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iron.png" alt="Iron icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>47</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Defense effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Defense effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Defense stat of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Defense EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 34](../locations/header-038.md) | R34 | `header-038` | Visible | (364, 438) |
| [Mt. Mortar](../locations/header-251.md) | D38R0103 | `header-251` | Hidden | (53, 29) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store Vitamins | ₽9,800 | Main game |
| Celadon Department Store Vitamins | ₽9,800 | Post-game |

## Hack changes

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `47` |

Source: exact ROM record from `a/0/1/7` member `47`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/47/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../protein/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/protein.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Protein</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../carbos/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Carbos →</span></a>
</nav>
