# Calcium

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/calcium.png" alt="Calcium icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>49</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Vitamins</dd></div>
<div><dt>Base price</dt><dd>₽9,800</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Raises Special Attack effort and happiness.</strong></p>
<p>Used on a party Pokémon : Increases Special Attack effort by 10, but won’t increase it beyond 100. Increases happiness by 5/3/2.</p>

<figure class="rw-pokedex-entry">
<blockquote>A nutritious drink for Pokémon. It raises the base Sp. Atk (Special Attack) stat of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>Sp. Atk EVs +10, friendship (low +5, medium +3, high +2)</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Route 12](../locations/header-020.md) | R12 | `header-020` | Visible | (1410, 332) |
| [Route 13](../locations/header-021.md) | R13 | `header-021` | Hidden | (1386, 377) |
| [Diglett's Cave](../locations/header-106.md) | D01R0101 | `header-106` | Hidden | (17, 44) |
| [Union Cave](../locations/header-154.md) | D25R0103 | `header-154` | Hidden | (4, 59) |
| [Whirl Islands](../locations/header-242.md) | D40R0102 | `header-242` | Visible | (70, 39) |
| [Dragon's Den](../locations/header-253.md) | D44R0102 | `header-253` | Visible | (42, 16) |
| [Mt. Silver Cave](../locations/header-463.md) | D41R0106 | `header-463` | Visible | (17, 37) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Goldenrod Department Store Vitamins | ₽9,800 | Main game |
| Celadon Department Store Vitamins | ₽9,800 | Post-game |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>DIGLETT&#x27;s Cave</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Diglett&#x27;s Cave</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `49` |

Source: exact ROM record from `a/0/1/7` member `49`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/49/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../carbos/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/carbos.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Carbos</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../rare-candy/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Rare Candy →</span></a>
</nav>
