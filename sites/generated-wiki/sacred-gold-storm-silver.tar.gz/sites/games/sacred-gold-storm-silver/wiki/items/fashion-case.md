# Fashion Case

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fashion-case.png" alt="Fashion Case icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>435</dd></div>
<div><dt>Pocket</dt><dd>Key Items</dd></div>
<div><dt>Category</dt><dd>Gameplay</dd></div>
<div><dt>Base price</dt><dd>₽0</dd></div>
<div><dt>Selectable</dt><dd>Yes</dd></div>
<div><dt>Can be discarded</dt><dd>No</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Holds Pokémon Accessories for use in Contests.</strong></p>
<p>Contains Pokémon Accessories.</p>

<figure class="rw-pokedex-entry">
<blockquote>A fancy case for the tidy and organized storage of colorful Pokémon Accessories.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Bag Message</dd></div>
<div><dt>Field pocket ID</dt><dd>7</dd></div>
<div><dt>Field use function ID</dt><dd>19</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Goldenrod Tunnel](../locations/header-118.md) | D37R0101 | `header-118` | Script Awarded | — |
| [Goldenrod Tunnel](../locations/header-118.md) | D37R0101 | `header-118` | Script Awarded | — |
| [Goldenrod Tunnel](../locations/header-118.md) | D37R0101 | `header-118` | Script Awarded | — |
| [Goldenrod Tunnel](../locations/header-118.md) | D37R0101 | `header-118` | Script Awarded | — |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Goldenrod Tunnel</li><li>Goldenrod Tunnel</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Goldenrod Tunnel</li><li>Goldenrod Tunnel</li><li>Goldenrod Tunnel</li><li>Goldenrod Tunnel</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `412` |

Source: exact ROM record from `a/0/1/7` member `412`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/412/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../seal-case/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/seal-case.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Seal Case</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../serenade-orb/"><span class="rw-record-nav__label">Serenade Orb →</span></a>
</nav>
