# Dragon Scale

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dragon-scale.png" alt="Dragon Scale icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>235</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Evolution</dd></div>
<div><dt>Base price</dt><dd>₽2,100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Traded on a Seadra: Holder evolves into Kingdra.</strong></p>
<p>Held by Seadra: Evolves the holder into Kingdra when traded.</p>

<figure class="rw-pokedex-entry">
<blockquote>A thick and tough scale. Dragon-type Pokémon may be holding this item when caught.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>triggers evolution</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Mt. Silver Cave](../locations/header-460.md) | D41R0103 | `header-460` | Visible | (27, 46) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/116.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/148.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/149.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonite](../pokemon/dragonite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/230.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingdra](../pokemon/kingdra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dragon">Dragon</span></span> | Rare |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/117.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seadra](../pokemon/seadra.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/230.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingdra](../pokemon/kingdra.md)</span> | Use Item |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Field use</p>
<div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field-use function</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Held effect</p>
<div class="rw-change__value">70<span class="rw-diff-arrow">→</span>0</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Held-effect parameter</p>
<div class="rw-change__value">10<span class="rw-diff-arrow">→</span>0</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party use</p>
<div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party effects</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Evolve: No<span class="rw-diff-arrow">→</span>Yes</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Evolutions</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kingdra/">Kingdra</a> — trade-held-item</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kingdra/">Kingdra</a> — use-item</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `213` |

Source: exact ROM record from `a/0/1/7` member `213`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/212/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../leftovers/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leftovers.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Leftovers</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../light-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/light-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Light Ball →</span></a>
</nav>
