# Covenant Orb

<section class="rw-summary">
<div class="rw-summary__media"><span class="rw-summary__placeholder">Icon unavailable</span></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>467</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Base price</dt><dd>₽3,500</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

No PokéDB reference data is available for this item.

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Evolution Stone</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>20</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>triggers evolution</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Ecruteak City](../locations/header-085.md) | T27R0401 | `header-085` | Script Awarded | — |
| [Diglett's Cave](../locations/header-106.md) | D01R0101 | `header-106` | Script Awarded | — |
| [Diglett's Cave](../locations/header-106.md) | D01R0101 | `header-106` | Script Awarded | — |
| [Olivine City](../locations/header-138.md) | T26GYM0101 | `header-138` | Script Awarded | — |
| [Violet City](../locations/header-162.md) | T22R0601 | `header-162` | Script Awarded | — |
| [Azalea Town](../locations/header-166.md) | T23PC0101 | `header-166` | Script Awarded | — |
| [Goldenrod City](../locations/header-195.md) | T25R1005 | `header-195` | Script Awarded | — |
| [Goldenrod City](../locations/header-205.md) | T25R0801 | `header-205` | Script Awarded | — |
| [Olivine City](../locations/header-228.md) | T26R0301 | `header-228` | Script Awarded | — |
| [Saffron City](../locations/header-400.md) | T11R0601 | `header-400` | Script Awarded | — |
| [Power Plant](../locations/header-467.md) | R10R0201 | `header-467` | Script Awarded | — |
| [Pewter City](../locations/header-475.md) | T03PC0101 | `header-475` | Script Awarded | — |
| [Power Plant](../locations/header-489.md) | R10R0202 | `header-489` | Script Awarded | — |

## Evolutions

| From | To | Method |
| ---- | -- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/67.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machoke](../pokemon/machoke.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/68.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Machamp](../pokemon/machamp.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | Use Item |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/94.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gengar](../pokemon/gengar.md)</span> | Use Item |

## Hack changes

<details markdown="1">
<summary>12 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Name</p>
<div class="rw-change__value">Secret Key<span class="rw-diff-arrow">→</span>Covenant Orb</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Price</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>3500</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Pocket</p>
<div class="rw-change__value">Key Items<span class="rw-diff-arrow">→</span>Items</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field pocket</p>
<div class="rw-change__value">7<span class="rw-diff-arrow">→</span>0</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field use</p>
<div class="rw-change__value">None<span class="rw-diff-arrow">→</span>Evolution Stone</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Field-use function</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>20</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Fling power</p>
<div class="rw-change__value">0<span class="rw-diff-arrow">→</span>30</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party use</p>
<div class="rw-change__value">No<span class="rw-diff-arrow">→</span>Yes</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Party effects</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Evolve: No<span class="rw-diff-arrow">→</span>Yes</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Prevents tossing</p>
<div class="rw-change__value">Yes<span class="rw-diff-arrow">→</span>No</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">13 entries added</p><ul class="rw-comparison-list"><li>Diglett&#x27;s Cave</li><li>Olivine City</li><li>Pewter City</li><li>Violet City</li><li>Ecruteak City</li><li>Olivine City</li><li>Goldenrod City</li><li>Power Plant</li><li>Saffron City</li><li>Power Plant</li><li>Azalea Town</li><li>Goldenrod City</li><li>Diglett&#x27;s Cave</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Evolutions</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/alakazam/">Alakazam</a> — use-item</li><li><a href="../../pokemon/machamp/">Machamp</a> — use-item</li><li><a href="../../pokemon/golem/">Golem</a> — use-item</li><li><a href="../../pokemon/gengar/">Gengar</a> — use-item</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `444` |

Source: exact ROM record from `a/0/1/7` member `444`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../gracidea/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/gracidea.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Gracidea</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../apricorn-box/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/apricorn-box.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Apricorn Box →</span></a>
</nav>
