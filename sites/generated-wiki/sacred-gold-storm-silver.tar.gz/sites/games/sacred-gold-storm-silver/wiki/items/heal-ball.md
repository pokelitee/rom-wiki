# Heal Ball

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/heal-ball.png" alt="Heal Ball icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>14</dd></div>
<div><dt>Pocket</dt><dd>Poké Balls</dd></div>
<div><dt>Category</dt><dd>Special Balls</dd></div>
<div><dt>Base price</dt><dd>₽300</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Tries to catch a wild Pokémon. Caught Pokémon are immediately healed.</strong></p>
<p>Used in battle : Attempts to catch a wild Pokémon, using a catch rate of 1×. The caught Pokémon’s HP is immediately restored, PP for all its moves is restored, and any status ailment is cured. If used in a trainer battle, nothing happens and the ball is lost.</p>

<figure class="rw-pokedex-entry">
<blockquote>A remedial Poké Ball that restores the caught Pokémon’s HP and eliminates any status problem.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>2</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>0</dd></div>
<div><dt>Battle use function ID</dt><dd>1</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x01</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Dark Cave](../locations/header-176.md) | D42R0102 | `header-176` | Hidden | (12, 11) |
| [Ruins of Alph](../locations/header-324.md) | D24R0212 | `header-324` | Visible | (8, 8) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Cherrygrove Secondary | ₽300 | Main game |
| Ecruteak Secondary | ₽300 | Main game |
| Violet Secondary | ₽300 | Main game |
| Olivine Secondary | ₽300 | Main game |
| Viridian Secondary | ₽300 | Post-game |
| Azalea Secondary | ₽300 | Main game |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `14` |

Source: exact ROM record from `a/0/1/7` member `14`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/14/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../dusk-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/dusk-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Dusk Ball</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../quick-ball/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/quick-ball.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Quick Ball →</span></a>
</nav>
