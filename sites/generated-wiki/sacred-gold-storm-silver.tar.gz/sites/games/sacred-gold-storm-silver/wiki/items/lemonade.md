# Lemonade

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lemonade.png" alt="Lemonade icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>32</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽350</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores 80 HP.</strong></p>
<p>Used on a party Pokémon : Restores 80 HP.</p>

<figure class="rw-pokedex-entry">
<blockquote>A very sweet drink. It restores the HP of one Pokémon by 80 points.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>80</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x04</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>restores HP, HP amount 80</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [National Park](../locations/header-096.md) | D22R0101 | `header-096` | Visible | (77, 33) |
| [Ilex Forest](../locations/header-117.md) | D36R0101 | `header-117` | Hidden | (39, 12) |

## Shops

| Shop | Price | Availability |
| ---- | ----: | ------------ |
| Mt. Moon Square | ₽350 | Post-game |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Pokémon Trainer Lyra](../trainers/trainer-0011.md) | AI battle item |
| [Pokémon Trainer Ethan](../trainers/trainer-0019.md) | AI battle item |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>2 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Locations</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Route 32</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>National Park</li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Ethan</li><li>Lyra</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `32` |

Source: exact ROM record from `a/0/1/7` member `32`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/32/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../soda-pop/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/soda-pop.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Soda Pop</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../moomoo-milk/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/moomoo-milk.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Moomoo Milk →</span></a>
</nav>
