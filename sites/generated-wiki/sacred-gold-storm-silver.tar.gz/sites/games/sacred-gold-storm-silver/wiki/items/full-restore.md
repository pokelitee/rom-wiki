# Full Restore

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/full-restore.png" alt="Full Restore icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>23</dd></div>
<div><dt>Pocket</dt><dd>Medicine</dd></div>
<div><dt>Category</dt><dd>Healing</dd></div>
<div><dt>Base price</dt><dd>₽3,000</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">30</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Restores HP to full and cures any status ailment and confusion.</strong></p>
<p>Used on a party Pokémon : Restores HP to full and cures any status ailment and confusion.</p>

<figure class="rw-pokedex-entry">
<blockquote>A medicine that fully restores the HP and heals any status problems of a single Pokémon.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>Healing</dd></div>
<div><dt>Field pocket ID</dt><dd>1</dd></div>
<div><dt>Field use function ID</dt><dd>1</dd></div>
<div><dt>Held effect ID</dt><dd>0</dd></div>
<div><dt>Held effect parameter</dt><dd>255</dd></div>
<div><dt>Battle use function ID</dt><dd>2</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x0c</dd></div>
<div><dt>Usable on party</dt><dd>Yes</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
<div><dt>Party-use effects</dt><dd>cures sleep, cures poison, cures burn, cures freeze, cures paralysis, cures confusion, restores HP, HP amount 255</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Olivine City](../locations/header-077.md) | T26 | `header-077` | Hidden | (309, 256) |
| [Ruins of Alph](../locations/header-327.md) | D24R0215 | `header-327` | Visible | (4, 12) |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [Leader Pryce](../trainers/trainer-0032.md) | AI battle item |
| [Leader Clair](../trainers/trainer-0035.md) | AI battle item |
| [Gentleman Preston](../trainers/trainer-0037.md) | AI battle item |
| [Gentleman Edward](../trainers/trainer-0231.md) | AI battle item |
| [Champion Lance](../trainers/trainer-0244.md) | AI battle item |
| [Elite Four Will](../trainers/trainer-0245.md) | AI battle item |
| [Elite Four Karen](../trainers/trainer-0246.md) | AI battle item |
| [Elite Four Koga](../trainers/trainer-0247.md) | AI battle item |
| [Leader Brock](../trainers/trainer-0253.md) | AI battle item |
| [Leader Misty](../trainers/trainer-0254.md) | AI battle item |
| [Leader Lt. Surge](../trainers/trainer-0255.md) | AI battle item |
| [Leader Erika](../trainers/trainer-0256.md) | AI battle item |
| [Leader Janine](../trainers/trainer-0257.md) | AI battle item |
| [Leader Sabrina](../trainers/trainer-0258.md) | AI battle item |
| [Leader Blaine](../trainers/trainer-0259.md) | AI battle item |
| [Pokémon Trainer Red](../trainers/trainer-0260.md) | AI battle item |
| [Leader Blue](../trainers/trainer-0261.md) | AI battle item |
| [Gentleman Gregory](../trainers/trainer-0337.md) | AI battle item |
| [Gentleman Mickey](../trainers/trainer-0338.md) | AI battle item |
| [Gentleman Alfred](../trainers/trainer-0401.md) | AI battle item |
| [Elite Four Bruno](../trainers/trainer-0418.md) | AI battle item |
| [Executive Proton](../trainers/trainer-0473.md) | AI battle item |
| [Executive Petrel](../trainers/trainer-0474.md) | AI battle item |
| [Executive Ariana](../trainers/trainer-0475.md) | AI battle item |
| [Executive Archer](../trainers/trainer-0476.md) | AI battle item |
| [Rocket Boss Giovanni](../trainers/trainer-0477.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0489.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0490.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0491.md) | AI battle item |
| [Champion Steven](../trainers/trainer-0521.md) | AI battle item |
| [Champion Cynthia](../trainers/trainer-0526.md) | AI battle item |
| [Mystery Man Eusine](../trainers/trainer-0529.md) | AI battle item |
| [Pokémon Trainer Ethan](../trainers/trainer-0531.md) | AI battle item |
| [Pokémon Trainer Lyra](../trainers/trainer-0532.md) | AI battle item |
| [Gentleman Milton](../trainers/trainer-0554.md) | AI battle item |
| [Pokémon Trainer Cheryl](../trainers/trainer-0667.md) | AI battle item |
| [Pokémon Trainer Marley](../trainers/trainer-0668.md) | AI battle item |
| [Pokémon Trainer Mira](../trainers/trainer-0669.md) | AI battle item |
| [Pokémon Trainer Riley](../trainers/trainer-0670.md) | AI battle item |
| [Pokémon Trainer Buck](../trainers/trainer-0671.md) | AI battle item |
| [Gentleman Alfred](../trainers/trainer-0672.md) | AI battle item |
| [Gentleman Alfred](../trainers/trainer-0673.md) | AI battle item |
| [Gentleman Alfred](../trainers/trainer-0674.md) | AI battle item |
| [Rocket Boss Giovanni](../trainers/trainer-0700.md) | AI battle item |
| [Champion Lance](../trainers/trainer-0701.md) | AI battle item |
| [Elite Four Will](../trainers/trainer-0702.md) | AI battle item |
| [Elite Four Koga](../trainers/trainer-0703.md) | AI battle item |
| [Elite Four Bruno](../trainers/trainer-0704.md) | AI battle item |
| [Elite Four Karen](../trainers/trainer-0705.md) | AI battle item |
| [Leader Falkner](../trainers/trainer-0712.md) | AI battle item |
| [Leader Bugsy](../trainers/trainer-0713.md) | AI battle item |
| [Leader Whitney](../trainers/trainer-0714.md) | AI battle item |
| [Leader Morty](../trainers/trainer-0715.md) | AI battle item |
| [Leader Pryce](../trainers/trainer-0716.md) | AI battle item |
| [Leader Jasmine](../trainers/trainer-0717.md) | AI battle item |
| [Leader Chuck](../trainers/trainer-0718.md) | AI battle item |
| [Leader Clair](../trainers/trainer-0719.md) | AI battle item |
| [Leader Brock](../trainers/trainer-0720.md) | AI battle item |
| [Leader Misty](../trainers/trainer-0721.md) | AI battle item |
| [Leader Lt. Surge](../trainers/trainer-0722.md) | AI battle item |
| [Leader Erika](../trainers/trainer-0723.md) | AI battle item |
| [Leader Janine](../trainers/trainer-0724.md) | AI battle item |
| [Leader Sabrina](../trainers/trainer-0725.md) | AI battle item |
| [Leader Blaine](../trainers/trainer-0726.md) | AI battle item |
| [Leader Blue](../trainers/trainer-0727.md) | AI battle item |
| [Champion Lance](../trainers/trainer-0733.md) | AI battle item |
| [Leader Clair](../trainers/trainer-0734.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0735.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0736.md) | AI battle item |
| [Rival Silver](../trainers/trainer-0737.md) | AI battle item |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer battle items</p>
<div class="rw-change__value"><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li>Cynthia</li><li>Steven</li><li>Archer</li><li>Ariana</li><li>Petrel</li><li>Proton</li><li>Eusine</li><li>Ethan</li><li>Lyra</li><li>Giovanni</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `23` |

Source: exact ROM record from `a/0/1/7` member `23`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/23/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../parlyz-heal/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/paralyze-heal.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Parlyz Heal</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../max-potion/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/max-potion.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Max Potion →</span></a>
</nav>
