# Hard Stone

<section class="rw-summary">
<div class="rw-summary__media"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/hard-stone.png" alt="Hard Stone icon" loading="lazy" referrerpolicy="no-referrer"></div>
<div class="rw-summary__body">
<dl class="rw-summary__facts">
<div><dt>Item ID</dt><dd>238</dd></div>
<div><dt>Pocket</dt><dd>Items</dd></div>
<div><dt>Category</dt><dd>Type Enhancement</dd></div>
<div><dt>Base price</dt><dd>₽100</dd></div>
<div><dt>Selectable</dt><dd>No</dd></div>
<div><dt>Can be discarded</dt><dd>Yes</dd></div>
<div><dt>Fling power</dt><dd><a href="#mechanics">100</a></dd></div>
</dl>
</div>
</section>

## Effect

<p><strong>Held: Rock-Type moves from holder do 20% more damage.</strong></p>
<p>Held: Increases the power of the holder’s Rock moves by 20%.</p>

<figure class="rw-pokedex-entry">
<blockquote>An item to be held by a Pokémon. It is an unbreakable stone that ups the power of Rock-type moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Mechanics

<dl class="rw-data-grid">
<div><dt>Field use</dt><dd>None</dd></div>
<div><dt>Field pocket ID</dt><dd>0</dd></div>
<div><dt>Field use function ID</dt><dd>0</dd></div>
<div><dt>Held effect ID</dt><dd>73</dd></div>
<div><dt>Held effect parameter</dt><dd>20</dd></div>
<div><dt>Battle use function ID</dt><dd>0</dd></div>
<div><dt>Battle pocket mask</dt><dd>0x00</dd></div>
<div><dt>Usable on party</dt><dd>No</dd></div>
<div><dt>Fling effect ID</dt><dd>0</dd></div>
</dl>

## Overworld locations

| Location | Section | Map ID | Kind | Position |
| -------- | ------- | ------ | ---- | -------- |
| [Mt. Silver Cave](../locations/header-463.md) | D41R0106 | `header-463` | Visible | (17, 11) |

## Wild held by

| Pokémon | Type | Rarity |
| ------- | ---- | ------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/222.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corsola](../pokemon/corsola.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/304.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/306.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aggron](../pokemon/aggron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | Rare |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/476.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Probopass](../pokemon/probopass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--steel">Steel</span></span> | Rare |

## Trainer references

| Trainer | Reference |
| ------- | --------- |
| [School Kid Ricky](../trainers/trainer-0429.md) | Held by Ambipom |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Trainer Held By</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/aipom/">Aipom</a></li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ambipom/">Ambipom</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

| Native field | Value |
| ------------ | ----- |
| Data archive member | `216` |

Source: exact ROM record from `a/0/1/7` member `216`.
The name, item-data member mapping, mechanics, and relationships are exact ROM facts. Numeric effect IDs are retained when their behavior is implemented by game code rather than the item record. Structured effect text and the icon come from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/item/215/).

</details>

<nav class="rw-record-nav" aria-label="Item navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../soft-sand/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/soft-sand.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">← Soft Sand</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../miracle-seed/"><img class="rw-record-nav__sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/miracle-seed.png" alt="" loading="lazy" referrerpolicy="no-referrer"><span class="rw-record-nav__label">Miracle Seed →</span></a>
</nav>
