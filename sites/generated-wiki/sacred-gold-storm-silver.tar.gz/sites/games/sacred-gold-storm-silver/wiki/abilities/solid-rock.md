# Solid Rock

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>116</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">4</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Decreases damage taken from super-effective moves by 1/4.</strong></p>
<p>This Pokémon takes 0.75× as much damage from moves that are super effective against it. This ability functions identically to Filter.</p>

<figure class="rw-pokedex-entry">
<blockquote>Powers down super­ effective moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shuckle](../pokemon/shuckle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magcargo](../pokemon/magcargo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--rock">Rock</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyperior](../pokemon/rhyperior.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuckle/">Shuckle</a></li><li><a href="../../pokemon/magcargo/">Magcargo</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/116/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../ice-body/"><span class="rw-record-nav__label">← Ice Body</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../snow-warning/"><span class="rw-record-nav__label">Snow Warning →</span></a>
</nav>
