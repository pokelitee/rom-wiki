# Shed Skin

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>61</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">14</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 33% chance of curing any major status ailment after each turn.</strong></p>
<p>Chance of taking effect is 30%.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon may heal its own status problems.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1, 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kakuna](../pokemon/kakuna.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 1, 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pupitar](../pokemon/pupitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Silcoon](../pokemon/silcoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1, 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cascoon](../pokemon/cascoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1, 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seviper](../pokemon/seviper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 1, 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 ability slot changes</p><ul class="rw-comparison-list"><li><a href="../../pokemon/metapod/">Metapod</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 2</li><li><a href="../../pokemon/kakuna/">Kakuna</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 2</li><li><a href="../../pokemon/silcoon/">Silcoon</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 2</li><li><a href="../../pokemon/cascoon/">Cascoon</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 2</li><li><a href="../../pokemon/burmy/">Burmy</a>: Slot 1<span class="rw-diff-arrow">→</span>Slots 1, 2</li></ul><p class="rw-comparison-count">2 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/krabby/">Krabby</a></li><li><a href="../../pokemon/kingler/">Kingler</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/61/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sticky-hold/"><span class="rw-record-nav__label">← Sticky Hold</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../guts/"><span class="rw-record-nav__label">Guts →</span></a>
</nav>
