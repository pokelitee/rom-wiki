# Static

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>9</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">14</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Has a 30% chance of paralyzing attacking Pokémon on contact.</strong></p>
<p>Whenever a move makes contact with this Pokémon, the move&#x27;s user has a 30% chance of being paralyzed. Pokémon that are immune to Electric-type moves can still be paralyzed by this ability. Overworld: If the lead Pokémon has this ability, there is a 50% chance that encounters will be with an Electric Pokémon, if applicable.</p>

<figure class="rw-pokedex-entry">
<blockquote>Contact with the Pokémon may cause paralysis.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raichu](../pokemon/raichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mareep](../pokemon/mareep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ampharos](../pokemon/ampharos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrike](../pokemon/electrike.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/plusle/">Plusle</a></li><li><a href="../../pokemon/minun/">Minun</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/9/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../sand-veil/"><span class="rw-record-nav__label">← Sand Veil</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../volt-absorb/"><span class="rw-record-nav__label">Volt Absorb →</span></a>
</nav>
