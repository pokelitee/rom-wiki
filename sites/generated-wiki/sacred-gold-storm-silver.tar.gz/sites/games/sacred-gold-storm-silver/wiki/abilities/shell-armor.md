# Shell Armor

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>75</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">11</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Protects against critical hits.</strong></p>
<p>Moves cannot score critical hits against this Pokémon. This ability functions identically to Battle Armor.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon is protected against critical hits.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/91.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cloyster](../pokemon/cloyster.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/131.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lapras](../pokemon/lapras.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/138.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Omanyte](../pokemon/omanyte.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/139.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Omastar](../pokemon/omastar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/341.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Corphish](../pokemon/corphish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/342.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crawdaunt](../pokemon/crawdaunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/366.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clamperl](../pokemon/clamperl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/387.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Turtwig](../pokemon/turtwig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/388.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grotle](../pokemon/grotle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/389.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torterra](../pokemon/torterra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/krabby/">Krabby</a></li><li><a href="../../pokemon/kingler/">Kingler</a></li></ul><p class="rw-comparison-count">3 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/turtwig/">Turtwig</a></li><li><a href="../../pokemon/grotle/">Grotle</a></li><li><a href="../../pokemon/torterra/">Torterra</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/75/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../pure-power/"><span class="rw-record-nav__label">← Pure Power</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../air-lock/"><span class="rw-record-nav__label">Air Lock →</span></a>
</nav>
