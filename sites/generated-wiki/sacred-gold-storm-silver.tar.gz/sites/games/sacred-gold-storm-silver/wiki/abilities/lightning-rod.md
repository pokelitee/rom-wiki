# Lightningrod

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>31</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Redirects single-target Electric moves to this Pokémon where possible. Absorbs Electric moves, raising Special Attack one stage.</strong></p>
<p>Redirects Electric moves without negating them or granting any Special Attack boost. Does not redirect Hidden Power.</p>

<figure class="rw-pokedex-entry">
<blockquote>The Pokémon draws in all Electric-type moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/25.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/26.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raichu](../pokemon/raichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/145.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zapdos](../pokemon/zapdos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/172.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/309.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electrike](../pokemon/electrike.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/310.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a></li><li><a href="../../pokemon/marowak/">Marowak</a></li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a></li><li><a href="../../pokemon/rhydon/">Rhydon</a></li><li><a href="../../pokemon/rhyperior/">Rhyperior</a></li></ul><p class="rw-comparison-count">4 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pikachu/">Pikachu</a></li><li><a href="../../pokemon/raichu/">Raichu</a></li><li><a href="../../pokemon/zapdos/">Zapdos</a></li><li><a href="../../pokemon/pichu/">Pichu</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/31/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../natural-cure/"><span class="rw-record-nav__label">← Natural Cure</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../serene-grace/"><span class="rw-record-nav__label">Serene Grace →</span></a>
</nav>
