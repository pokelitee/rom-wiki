# Quick Feet

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>95</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">5</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases Speed to 1.5× with a major status ailment.</strong></p>
<p>Whenever this Pokémon has a major status ailment, it has 1.5× its Speed. This Pokémon is not affected by the usual Speed cut from paralysis. Overworld: If the lead Pokémon has this ability, the wild encounter rate is halved.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts Speed if there is a status problem.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Jolteon](../pokemon/jolteon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Granbull](../pokemon/granbull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poochyena](../pokemon/poochyena.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mightyena](../pokemon/mightyena.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/teddiursa/">Teddiursa</a></li></ul><p class="rw-comparison-count">1 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jolteon/">Jolteon</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/95/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../solar-power/"><span class="rw-record-nav__label">← Solar Power</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../normalize/"><span class="rw-record-nav__label">Normalize →</span></a>
</nav>
