# Scrappy

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>113</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">7</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Lets the Pokémon&#x27;s Normal and Fighting moves hit Ghost Pokémon.</strong></p>
<p>This Pokémon ignores Ghost-type Pokémon&#x27;s immunity to Normal- and Fighting-type moves. Ghost Pokémon&#x27;s other types affect damage as usual.</p>

<figure class="rw-pokedex-entry">
<blockquote>Enables moves to hit Ghost-type foes.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Taillow](../pokemon/taillow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swellow](../pokemon/swellow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Exploud](../pokemon/exploud.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/furret/">Furret</a></li><li><a href="../../pokemon/taillow/">Taillow</a></li><li><a href="../../pokemon/swellow/">Swellow</a></li><li><a href="../../pokemon/loudred/">Loudred</a></li><li><a href="../../pokemon/exploud/">Exploud</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/113/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../slow-start/"><span class="rw-record-nav__label">← Slow Start</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../storm-drain/"><span class="rw-record-nav__label">Storm Drain →</span></a>
</nav>
