# Hydration

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>93</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">7</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Cures any major status ailment after each turn during rain.</strong></p>
<p>This Pokémon is cured of any major status ailment after each turn during rain.</p>

<figure class="rw-pokedex-entry">
<blockquote>Heals status problems if it is raining.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Vaporeon](../pokemon/vaporeon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Phione](../pokemon/phione.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manaphy](../pokemon/manaphy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vaporeon/">Vaporeon</a></li><li><a href="../../pokemon/smoochum/">Smoochum</a></li><li><a href="../../pokemon/luvdisc/">Luvdisc</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/93/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../skill-link/"><span class="rw-record-nav__label">← Skill Link</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../solar-power/"><span class="rw-record-nav__label">Solar Power →</span></a>
</nav>
