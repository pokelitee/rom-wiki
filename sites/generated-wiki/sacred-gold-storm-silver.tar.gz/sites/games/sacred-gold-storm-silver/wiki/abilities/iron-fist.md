# Iron Fist

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>89</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">7</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Strengthens punch-based moves to 1.2× their power.</strong></p>
<p>Moves flagged as being punch-based have 1.2× their base power for this Pokémon. Sucker Punch is not flagged as punch-based; its original, Japanese name only means &quot;surprise attack&quot;.</p>

<figure class="rw-pokedex-entry">
<blockquote>Boosts the power of punching moves.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/107.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hitmonchan](../pokemon/hitmonchan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/166.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 1 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/375.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metang](../pokemon/metang.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/376.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metagross](../pokemon/metagross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/390.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimchar](../pokemon/chimchar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/391.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Monferno](../pokemon/monferno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/392.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Infernape](../pokemon/infernape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 2 |

## Hack changes

<details markdown="1">
<summary>1 field changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">6 Pokémon that gained this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ledian/">Ledian</a></li><li><a href="../../pokemon/metang/">Metang</a></li><li><a href="../../pokemon/metagross/">Metagross</a></li><li><a href="../../pokemon/chimchar/">Chimchar</a></li><li><a href="../../pokemon/monferno/">Monferno</a></li><li><a href="../../pokemon/infernape/">Infernape</a></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the name; structured effect text comes from PokéDB / PokéAPI reference data. Flavor text also comes from that reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/89/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../download/"><span class="rw-record-nav__label">← Download</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../poison-heal/"><span class="rw-record-nav__label">Poison Heal →</span></a>
</nav>
