# Rivalry

<section class="rw-ability-summary">
<dl class="rw-summary__facts">
<div><dt>Ability ID</dt><dd>79</dd></div>
<div><dt>Pokémon with this ability</dt><dd><a href="#pokemon">6</a></dd></div>
</dl>
</section>

## Effect

<p><strong>Increases damage inflicted to 1.25× against Pokémon of the same gender, but decreases damage to 0.75× against the opposite gender.</strong></p>
<p>This Pokémon inflicts 1.25× as much regular damage against Pokémon of the same gender and 0.75× as much regular damage against Pokémon of the opposite gender. If either Pokémon is genderless, damage is unaffected.</p>

<figure class="rw-pokedex-entry">
<blockquote>Raises Attack if the foe is of the same gender.</blockquote>
<figcaption>Diamond Pearl Pokédex</figcaption>
</figure>

## Pokémon

| Pokémon | Type | Ability slot |
| ------- | ---- | ------------ |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoran♀](../pokemon/nidoran-f.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoqueen](../pokemon/nidoqueen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoran♂](../pokemon/nidoran-m.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 2 |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoking](../pokemon/nidoking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> | 2 |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>1 field changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Pokémon</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 Pokémon that lost this ability</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shinx/">Shinx</a></li><li><a href="../../pokemon/luxio/">Luxio</a></li><li><a href="../../pokemon/luxray/">Luxray</a></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

The ability name and Pokémon assignments are exact ROM facts. Ability behavior is never inferred from the ROM or the name; effect and flavor text come from PokéDB / PokéAPI reference data.
Ability name source: ROM message table `a/0/2/7` member `720`.
[View the PokéDB / PokéAPI source record](https://pokeapi.co/api/v2/ability/79/).

</details>

<nav class="rw-record-nav" aria-label="Ability navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../motor-drive/"><span class="rw-record-nav__label">← Motor Drive</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../steadfast/"><span class="rw-record-nav__label">Steadfast →</span></a>
</nav>
