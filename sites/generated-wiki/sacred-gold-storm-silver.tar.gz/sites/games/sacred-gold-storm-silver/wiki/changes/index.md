# Changes from base game

Every supported ROM dataset is compared with the configured clean base ROM. Unchanged records remain visible on their detail pages.

| Section | Unchanged | Changed | Added | Removed |
| ------- | --------: | ------: | ----: | ------: |
| [Pokémon](#pokemon) | 63 | 445 | 0 | 0 |
| [Abilities](#abilities) | 37 | 86 | 0 | 0 |
| [Moves](#moves) | 434 | 37 | 0 | 0 |
| [Items](#items) | 246 | 267 | 0 | 0 |
| [Wild encounters](#wild-encounters) | 84 | 130 | 0 | 0 |
| [Trainers](#trainers) | 6 | 731 | 0 | 0 |
| [Locations](#locations) | 388 | 152 | 0 | 0 |

## Pokémon

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Bulbasaur](../pokemon/bulbasaur.md) | Changed | Abilities, Level-up moves |
| [Ivysaur](../pokemon/ivysaur.md) | Changed | Abilities, Level-up moves |
| [Venusaur](../pokemon/venusaur.md) | Changed | Abilities, Level-up moves |
| [Charmander](../pokemon/charmander.md) | Changed | Abilities, Level-up moves |
| [Charmeleon](../pokemon/charmeleon.md) | Changed | Abilities, Level-up moves |
| [Charizard](../pokemon/charizard.md) | Changed | Abilities, Level-up moves |
| [Squirtle](../pokemon/squirtle.md) | Changed | Abilities, Level-up moves |
| [Wartortle](../pokemon/wartortle.md) | Changed | Abilities, Level-up moves |
| [Blastoise](../pokemon/blastoise.md) | Changed | Abilities, Level-up moves |
| [Caterpie](../pokemon/caterpie.md) | Changed | Abilities, Level-up moves |
| [Metapod](../pokemon/metapod.md) | Changed | Abilities |
| [Butterfree](../pokemon/butterfree.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Weedle](../pokemon/weedle.md) | Changed | Abilities, Level-up moves |
| [Kakuna](../pokemon/kakuna.md) | Changed | Abilities |
| [Beedrill](../pokemon/beedrill.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Pidgey](../pokemon/pidgey.md) | Changed | Level-up moves |
| [Pidgeotto](../pokemon/pidgeotto.md) | Changed | Level-up moves |
| [Pidgeot](../pokemon/pidgeot.md) | Changed | Base stats, Base experience, Level-up moves |
| [Rattata](../pokemon/rattata.md) | Changed | Abilities, Level-up moves |
| [Raticate](../pokemon/raticate.md) | Changed | Base stats, Abilities, Level-up moves |
| [Spearow](../pokemon/spearow.md) | Changed | Abilities, Level-up moves |
| [Fearow](../pokemon/fearow.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Ekans](../pokemon/ekans.md) | Changed | Level-up moves |
| [Arbok](../pokemon/arbok.md) | Changed | Base stats, Base experience, Level-up moves |
| [Pikachu](../pokemon/pikachu.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Raichu](../pokemon/raichu.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Sandshrew](../pokemon/sandshrew.md) | Changed | Level-up moves |
| [Sandslash](../pokemon/sandslash.md) | Changed | Level-up moves |
| [Nidoran♀](../pokemon/nidoran-f.md) | Changed | Level-up moves |
| [Nidorina](../pokemon/nidorina.md) | Changed | Level-up moves |
| [Nidoqueen](../pokemon/nidoqueen.md) | Changed | Base stats |
| [Nidoran♂](../pokemon/nidoran-m.md) | Changed | Level-up moves |
| [Nidorino](../pokemon/nidorino.md) | Changed | Level-up moves |
| [Nidoking](../pokemon/nidoking.md) | Changed | Base stats |
| [Clefairy](../pokemon/clefairy.md) | Changed | Level-up moves |
| [Clefable](../pokemon/clefable.md) | Changed | Abilities, Level-up moves |
| [Vulpix](../pokemon/vulpix.md) | Changed | Abilities, Machines, Level-up moves |
| [Ninetales](../pokemon/ninetales.md) | Changed | Abilities, Machines, Level-up moves |
| [Jigglypuff](../pokemon/jigglypuff.md) | Changed | Abilities, Level-up moves |
| [Wigglytuff](../pokemon/wigglytuff.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Zubat](../pokemon/zubat.md) | Changed | Abilities, Level-up moves |
| [Golbat](../pokemon/golbat.md) | Changed | Level-up moves |
| [Oddish](../pokemon/oddish.md) | Changed | Level-up moves |
| [Gloom](../pokemon/gloom.md) | Changed | Abilities, Level-up moves |
| [Vileplume](../pokemon/vileplume.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Paras](../pokemon/paras.md) | Changed | Level-up moves |
| [Parasect](../pokemon/parasect.md) | Changed | Base stats, Level-up moves |
| [Venonat](../pokemon/venonat.md) | Changed | Level-up moves |
| [Venomoth](../pokemon/venomoth.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Persian](../pokemon/persian.md) | Changed | Base stats, Level-up moves |
| [Psyduck](../pokemon/psyduck.md) | Changed | Level-up moves |
| [Golduck](../pokemon/golduck.md) | Changed | Level-up moves |
| [Primeape](../pokemon/primeape.md) | Changed | Level-up moves |
| [Growlithe](../pokemon/growlithe.md) | Changed | Level-up moves |
| [Arcanine](../pokemon/arcanine.md) | Changed | Level-up moves |
| [Poliwag](../pokemon/poliwag.md) | Changed | Level-up moves |
| [Poliwhirl](../pokemon/poliwhirl.md) | Changed | Evolutions, Machines, Level-up moves |
| [Poliwrath](../pokemon/poliwrath.md) | Changed | Base stats, Machines, Level-up moves |
| [Abra](../pokemon/abra.md) | Changed | Abilities |
| [Kadabra](../pokemon/kadabra.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Alakazam](../pokemon/alakazam.md) | Changed | Abilities, Level-up moves |
| [Machop](../pokemon/machop.md) | Changed | Level-up moves |
| [Machoke](../pokemon/machoke.md) | Changed | Evolutions, Level-up moves |
| [Machamp](../pokemon/machamp.md) | Changed | Level-up moves |
| [Bellsprout](../pokemon/bellsprout.md) | Changed | Abilities, Level-up moves |
| [Weepinbell](../pokemon/weepinbell.md) | Changed | Abilities, Level-up moves |
| [Victreebel](../pokemon/victreebel.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Tentacool](../pokemon/tentacool.md) | Changed | Level-up moves |
| [Tentacruel](../pokemon/tentacruel.md) | Changed | Level-up moves |
| [Geodude](../pokemon/geodude.md) | Changed | Level-up moves |
| [Graveler](../pokemon/graveler.md) | Changed | Evolutions, Level-up moves |
| [Golem](../pokemon/golem.md) | Changed | Level-up moves |
| [Ponyta](../pokemon/ponyta.md) | Changed | Abilities, Level-up moves |
| [Rapidash](../pokemon/rapidash.md) | Changed | Abilities, Level-up moves |
| [Slowpoke](../pokemon/slowpoke.md) | Changed | Evolutions |
| [Magnemite](../pokemon/magnemite.md) | Changed | Level-up moves |
| [Magneton](../pokemon/magneton.md) | Changed | Evolutions, Level-up moves |
| [Farfetch'd](../pokemon/farfetchd.md) | Changed | Base stats, Types, Abilities, Base experience, Machines, Level-up moves |
| [Doduo](../pokemon/doduo.md) | Changed | Abilities, Level-up moves |
| [Dodrio](../pokemon/dodrio.md) | Changed | Abilities, Level-up moves |
| [Dewgong](../pokemon/dewgong.md) | Changed | Base stats, Level-up moves |
| [Grimer](../pokemon/grimer.md) | Changed | Level-up moves |
| [Muk](../pokemon/muk.md) | Changed | Level-up moves |
| [Shellder](../pokemon/shellder.md) | Changed | Level-up moves |
| [Gastly](../pokemon/gastly.md) | Changed | Level-up moves |
| [Haunter](../pokemon/haunter.md) | Changed | Evolutions, Level-up moves |
| [Gengar](../pokemon/gengar.md) | Changed | Level-up moves |
| [Onix](../pokemon/onix.md) | Changed | Base stats, Base experience, Evolutions |
| [Drowzee](../pokemon/drowzee.md) | Changed | Level-up moves |
| [Hypno](../pokemon/hypno.md) | Changed | Level-up moves |
| [Krabby](../pokemon/krabby.md) | Changed | Abilities, Machines, Level-up moves |
| [Kingler](../pokemon/kingler.md) | Changed | Abilities, Machines, Level-up moves |
| [Voltorb](../pokemon/voltorb.md) | Changed | Abilities, Level-up moves |
| [Electrode](../pokemon/electrode.md) | Changed | Abilities, Machines, Level-up moves |
| [Exeggcute](../pokemon/exeggcute.md) | Changed | Level-up moves |
| [Exeggutor](../pokemon/exeggutor.md) | Changed | Level-up moves |
| [Cubone](../pokemon/cubone.md) | Changed | Abilities, Level-up moves |
| [Marowak](../pokemon/marowak.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Hitmonlee](../pokemon/hitmonlee.md) | Changed | Level-up moves |
| [Hitmonchan](../pokemon/hitmonchan.md) | Changed | Level-up moves |
| [Lickitung](../pokemon/lickitung.md) | Changed | Abilities, Level-up moves |
| [Koffing](../pokemon/koffing.md) | Changed | Level-up moves |
| [Weezing](../pokemon/weezing.md) | Changed | Level-up moves |
| [Rhyhorn](../pokemon/rhyhorn.md) | Changed | Abilities, Level-up moves |
| [Rhydon](../pokemon/rhydon.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Chansey](../pokemon/chansey.md) | Changed | Level-up moves |
| [Kangaskhan](../pokemon/kangaskhan.md) | Changed | Level-up moves |
| [Seadra](../pokemon/seadra.md) | Changed | Base stats, Evolutions, Level-up moves |
| [Seaking](../pokemon/seaking.md) | Changed | Base stats, Level-up moves |
| [Staryu](../pokemon/staryu.md) | Changed | Level-up moves |
| [Starmie](../pokemon/starmie.md) | Changed | Level-up moves |
| [Scyther](../pokemon/scyther.md) | Changed | Evolutions, Level-up moves |
| [Jynx](../pokemon/jynx.md) | Changed | Base stats, Abilities, Level-up moves |
| [Electabuzz](../pokemon/electabuzz.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Magmar](../pokemon/magmar.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Pinsir](../pokemon/pinsir.md) | Changed | Level-up moves |
| [Tauros](../pokemon/tauros.md) | Changed | Level-up moves |
| [Magikarp](../pokemon/magikarp.md) | Changed | Level-up moves |
| [Gyarados](../pokemon/gyarados.md) | Changed | Level-up moves |
| [Lapras](../pokemon/lapras.md) | Changed | Level-up moves |
| [Eevee](../pokemon/eevee.md) | Changed | Hatch cycles, Evolutions, Machines, Level-up moves |
| [Vaporeon](../pokemon/vaporeon.md) | Changed | Abilities, Machines, Level-up moves |
| [Jolteon](../pokemon/jolteon.md) | Changed | Abilities, Machines, Level-up moves |
| [Flareon](../pokemon/flareon.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Porygon](../pokemon/porygon.md) | Changed | Evolutions, Level-up moves |
| [Omanyte](../pokemon/omanyte.md) | Changed | Level-up moves |
| [Omastar](../pokemon/omastar.md) | Changed | Level-up moves |
| [Snorlax](../pokemon/snorlax.md) | Changed | Level-up moves |
| [Articuno](../pokemon/articuno.md) | Changed | Abilities |
| [Zapdos](../pokemon/zapdos.md) | Changed | Abilities |
| [Moltres](../pokemon/moltres.md) | Changed | Abilities |
| [Dratini](../pokemon/dratini.md) | Changed | Abilities |
| [Dragonair](../pokemon/dragonair.md) | Changed | Abilities |
| [Dragonite](../pokemon/dragonite.md) | Changed | Abilities |
| [Mewtwo](../pokemon/mewtwo.md) | Changed | Abilities |
| [Mew](../pokemon/mew.md) | Changed | Abilities |
| [Chikorita](../pokemon/chikorita.md) | Changed | Abilities, Level-up moves |
| [Bayleef](../pokemon/bayleef.md) | Changed | Abilities, Level-up moves |
| [Meganium](../pokemon/meganium.md) | Changed | Level-up moves |
| [Cyndaquil](../pokemon/cyndaquil.md) | Changed | Abilities |
| [Quilava](../pokemon/quilava.md) | Changed | Abilities |
| [Typhlosion](../pokemon/typhlosion.md) | Changed | Abilities, Level-up moves |
| [Totodile](../pokemon/totodile.md) | Changed | Abilities, Level-up moves |
| [Croconaw](../pokemon/croconaw.md) | Changed | Abilities, Level-up moves |
| [Feraligatr](../pokemon/feraligatr.md) | Changed | Abilities, Level-up moves |
| [Sentret](../pokemon/sentret.md) | Changed | Abilities, Level-up moves |
| [Furret](../pokemon/furret.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Hoothoot](../pokemon/hoothoot.md) | Changed | Abilities, Machines, Level-up moves |
| [Noctowl](../pokemon/noctowl.md) | Changed | Base stats, Abilities, Machines, Level-up moves |
| [Ledyba](../pokemon/ledyba.md) | Changed | Level-up moves |
| [Ledian](../pokemon/ledian.md) | Changed | Base stats, Abilities, Level-up moves |
| [Spinarak](../pokemon/spinarak.md) | Changed | Abilities, Level-up moves |
| [Ariados](../pokemon/ariados.md) | Changed | Base stats, Abilities |
| [Crobat](../pokemon/crobat.md) | Changed | Abilities, Level-up moves |
| [Chinchou](../pokemon/chinchou.md) | Changed | Abilities |
| [Lanturn](../pokemon/lanturn.md) | Changed | Base stats, Abilities |
| [Pichu](../pokemon/pichu.md) | Changed | Abilities, Level-up moves |
| [Cleffa](../pokemon/cleffa.md) | Changed | Level-up moves |
| [Igglybuff](../pokemon/igglybuff.md) | Changed | Level-up moves |
| [Togepi](../pokemon/togepi.md) | Changed | Abilities, Level-up moves |
| [Togetic](../pokemon/togetic.md) | Changed | Abilities, Level-up moves |
| [Natu](../pokemon/natu.md) | Changed | Level-up moves |
| [Xatu](../pokemon/xatu.md) | Changed | Level-up moves |
| [Mareep](../pokemon/mareep.md) | Changed | Level-up moves |
| [Flaaffy](../pokemon/flaaffy.md) | Changed | Level-up moves |
| [Ampharos](../pokemon/ampharos.md) | Changed | Machines, Level-up moves |
| [Bellossom](../pokemon/bellossom.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Marill](../pokemon/marill.md) | Changed | Base stats |
| [Azumarill](../pokemon/azumarill.md) | Changed | Base stats, Level-up moves |
| [Sudowoodo](../pokemon/sudowoodo.md) | Changed | Base stats, Level-up moves |
| [Politoed](../pokemon/politoed.md) | Changed | Base stats, Abilities |
| [Hoppip](../pokemon/hoppip.md) | Changed | Level-up moves |
| [Skiploom](../pokemon/skiploom.md) | Changed | Level-up moves |
| [Jumpluff](../pokemon/jumpluff.md) | Changed | Level-up moves |
| [Aipom](../pokemon/aipom.md) | Changed | Level-up moves |
| [Sunkern](../pokemon/sunkern.md) | Changed | Level-up moves |
| [Sunflora](../pokemon/sunflora.md) | Changed | Base stats, Base experience, Level-up moves |
| [Yanma](../pokemon/yanma.md) | Changed | Level-up moves |
| [Wooper](../pokemon/wooper.md) | Changed | Abilities, Level-up moves |
| [Quagsire](../pokemon/quagsire.md) | Changed | Base stats, Abilities, Level-up moves |
| [Espeon](../pokemon/espeon.md) | Changed | Abilities, Level-up moves |
| [Umbreon](../pokemon/umbreon.md) | Changed | Abilities, Machines, Level-up moves |
| [Murkrow](../pokemon/murkrow.md) | Changed | Level-up moves |
| [Slowking](../pokemon/slowking.md) | Changed | Level-up moves |
| [Misdreavus](../pokemon/misdreavus.md) | Changed | Level-up moves |
| [Unown](../pokemon/unown.md) | Changed | Base stats, Base experience, Level-up moves |
| [Wobbuffet](../pokemon/wobbuffet.md) | Changed | Level-up moves |
| [Girafarig](../pokemon/girafarig.md) | Changed | Base stats, Level-up moves |
| [Pineco](../pokemon/pineco.md) | Changed | Level-up moves |
| [Forretress](../pokemon/forretress.md) | Changed | Level-up moves |
| [Dunsparce](../pokemon/dunsparce.md) | Changed | Base stats |
| [Gligar](../pokemon/gligar.md) | Changed | Abilities |
| [Steelix](../pokemon/steelix.md) | Changed | Base stats |
| [Snubbull](../pokemon/snubbull.md) | Changed | Level-up moves |
| [Granbull](../pokemon/granbull.md) | Changed | Level-up moves |
| [Qwilfish](../pokemon/qwilfish.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Scizor](../pokemon/scizor.md) | Changed | Level-up moves |
| [Shuckle](../pokemon/shuckle.md) | Changed | Abilities |
| [Heracross](../pokemon/heracross.md) | Changed | Level-up moves |
| [Sneasel](../pokemon/sneasel.md) | Changed | Abilities, Level-up moves |
| [Teddiursa](../pokemon/teddiursa.md) | Changed | Abilities |
| [Ursaring](../pokemon/ursaring.md) | Changed | Level-up moves |
| [Slugma](../pokemon/slugma.md) | Changed | Level-up moves |
| [Magcargo](../pokemon/magcargo.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Swinub](../pokemon/swinub.md) | Changed | Abilities, Level-up moves |
| [Piloswine](../pokemon/piloswine.md) | Changed | Level-up moves |
| [Corsola](../pokemon/corsola.md) | Changed | Base stats, Level-up moves |
| [Octillery](../pokemon/octillery.md) | Changed | Level-up moves |
| [Delibird](../pokemon/delibird.md) | Changed | Abilities, Level-up moves |
| [Mantine](../pokemon/mantine.md) | Changed | Machines, Level-up moves |
| [Skarmory](../pokemon/skarmory.md) | Changed | Abilities, Level-up moves |
| [Houndour](../pokemon/houndour.md) | Changed | Level-up moves |
| [Houndoom](../pokemon/houndoom.md) | Changed | Abilities, Level-up moves |
| [Kingdra](../pokemon/kingdra.md) | Changed | Level-up moves |
| [Phanpy](../pokemon/phanpy.md) | Changed | Level-up moves |
| [Donphan](../pokemon/donphan.md) | Changed | Level-up moves |
| [Porygon2](../pokemon/porygon2.md) | Changed | Evolutions, Level-up moves |
| [Stantler](../pokemon/stantler.md) | Changed | Base stats, Level-up moves |
| [Smeargle](../pokemon/smeargle.md) | Changed | Base stats |
| [Smoochum](../pokemon/smoochum.md) | Changed | Abilities |
| [Elekid](../pokemon/elekid.md) | Changed | Abilities |
| [Magby](../pokemon/magby.md) | Changed | Abilities |
| [Miltank](../pokemon/miltank.md) | Changed | Level-up moves |
| [Blissey](../pokemon/blissey.md) | Changed | Level-up moves |
| [Raikou](../pokemon/raikou.md) | Changed | Abilities, Level-up moves |
| [Entei](../pokemon/entei.md) | Changed | Abilities, Level-up moves |
| [Suicune](../pokemon/suicune.md) | Changed | Abilities, Level-up moves |
| [Larvitar](../pokemon/larvitar.md) | Changed | Abilities |
| [Pupitar](../pokemon/pupitar.md) | Changed | Abilities |
| [Tyranitar](../pokemon/tyranitar.md) | Changed | Abilities, Level-up moves |
| [Ho-oh](../pokemon/ho-oh.md) | Changed | Name |
| [Celebi](../pokemon/celebi.md) | Changed | Abilities, Level-up moves |
| [Treecko](../pokemon/treecko.md) | Changed | Abilities |
| [Grovyle](../pokemon/grovyle.md) | Changed | Abilities |
| [Sceptile](../pokemon/sceptile.md) | Changed | Abilities, Level-up moves |
| [Torchic](../pokemon/torchic.md) | Changed | Abilities |
| [Combusken](../pokemon/combusken.md) | Changed | Abilities |
| [Blaziken](../pokemon/blaziken.md) | Changed | Abilities, Level-up moves |
| [Mudkip](../pokemon/mudkip.md) | Changed | Abilities, Level-up moves |
| [Marshtomp](../pokemon/marshtomp.md) | Changed | Abilities, Level-up moves |
| [Swampert](../pokemon/swampert.md) | Changed | Abilities, Level-up moves |
| [Poochyena](../pokemon/poochyena.md) | Changed | Level-up moves |
| [Mightyena](../pokemon/mightyena.md) | Changed | Base stats, Level-up moves |
| [Linoone](../pokemon/linoone.md) | Changed | Base stats, Level-up moves |
| [Wurmple](../pokemon/wurmple.md) | Changed | Abilities, Level-up moves |
| [Silcoon](../pokemon/silcoon.md) | Changed | Abilities |
| [Beautifly](../pokemon/beautifly.md) | Changed | Base stats, Abilities, Level-up moves |
| [Cascoon](../pokemon/cascoon.md) | Changed | Abilities |
| [Dustox](../pokemon/dustox.md) | Changed | Base stats, Abilities, Level-up moves |
| [Lotad](../pokemon/lotad.md) | Changed | Level-up moves |
| [Lombre](../pokemon/lombre.md) | Changed | Level-up moves |
| [Ludicolo](../pokemon/ludicolo.md) | Changed | Level-up moves |
| [Seedot](../pokemon/seedot.md) | Changed | Level-up moves |
| [Nuzleaf](../pokemon/nuzleaf.md) | Changed | Level-up moves |
| [Shiftry](../pokemon/shiftry.md) | Changed | Level-up moves |
| [Taillow](../pokemon/taillow.md) | Changed | Abilities, Level-up moves |
| [Swellow](../pokemon/swellow.md) | Changed | Base stats, Abilities, Level-up moves |
| [Wingull](../pokemon/wingull.md) | Changed | Abilities |
| [Pelipper](../pokemon/pelipper.md) | Changed | Base stats, Abilities, Level-up moves |
| [Ralts](../pokemon/ralts.md) | Changed | Base stats, Level-up moves |
| [Kirlia](../pokemon/kirlia.md) | Changed | Base stats, Level-up moves |
| [Gardevoir](../pokemon/gardevoir.md) | Changed | Level-up moves |
| [Surskit](../pokemon/surskit.md) | Changed | Abilities, Machines |
| [Masquerain](../pokemon/masquerain.md) | Changed | Base stats, Types, Abilities, Base experience, Level-up moves |
| [Shroomish](../pokemon/shroomish.md) | Changed | Level-up moves |
| [Breloom](../pokemon/breloom.md) | Changed | Abilities, Level-up moves |
| [Slakoth](../pokemon/slakoth.md) | Changed | Abilities |
| [Vigoroth](../pokemon/vigoroth.md) | Changed | Abilities, Level-up moves |
| [Slaking](../pokemon/slaking.md) | Changed | Level-up moves |
| [Nincada](../pokemon/nincada.md) | Changed | Level-up moves |
| [Ninjask](../pokemon/ninjask.md) | Changed | Level-up moves |
| [Whismur](../pokemon/whismur.md) | Changed | Abilities, Level-up moves |
| [Loudred](../pokemon/loudred.md) | Changed | Abilities |
| [Exploud](../pokemon/exploud.md) | Changed | Abilities, Level-up moves |
| [Azurill](../pokemon/azurill.md) | Changed | Level-up moves |
| [Nosepass](../pokemon/nosepass.md) | Changed | Base stats, Evolutions, Level-up moves |
| [Delcatty](../pokemon/delcatty.md) | Changed | Base stats, Level-up moves |
| [Sableye](../pokemon/sableye.md) | Changed | Base stats, Abilities, Base experience, Level-up moves |
| [Mawile](../pokemon/mawile.md) | Changed | Base stats, Base experience, Level-up moves |
| [Aron](../pokemon/aron.md) | Changed | Level-up moves |
| [Lairon](../pokemon/lairon.md) | Changed | Level-up moves |
| [Aggron](../pokemon/aggron.md) | Changed | Level-up moves |
| [Meditite](../pokemon/meditite.md) | Changed | Level-up moves |
| [Medicham](../pokemon/medicham.md) | Changed | Level-up moves |
| [Plusle](../pokemon/plusle.md) | Changed | Base stats, Abilities |
| [Minun](../pokemon/minun.md) | Changed | Base stats, Abilities |
| [Volbeat](../pokemon/volbeat.md) | Changed | Base stats, Types, Level-up moves |
| [Illumise](../pokemon/illumise.md) | Changed | Base stats, Level-up moves |
| [Roselia](../pokemon/roselia.md) | Changed | Level-up moves |
| [Gulpin](../pokemon/gulpin.md) | Changed | Level-up moves |
| [Swalot](../pokemon/swalot.md) | Changed | Base stats, Level-up moves |
| [Carvanha](../pokemon/carvanha.md) | Changed | Abilities, Level-up moves |
| [Sharpedo](../pokemon/sharpedo.md) | Changed | Abilities, Level-up moves |
| [Wailmer](../pokemon/wailmer.md) | Changed | Abilities, Level-up moves |
| [Wailord](../pokemon/wailord.md) | Changed | Abilities, Level-up moves |
| [Numel](../pokemon/numel.md) | Changed | Abilities |
| [Camerupt](../pokemon/camerupt.md) | Changed | Abilities |
| [Torkoal](../pokemon/torkoal.md) | Changed | Base stats, Level-up moves |
| [Spoink](../pokemon/spoink.md) | Changed | Level-up moves |
| [Grumpig](../pokemon/grumpig.md) | Changed | Level-up moves |
| [Spinda](../pokemon/spinda.md) | Changed | Base stats, Base experience, Level-up moves |
| [Trapinch](../pokemon/trapinch.md) | Changed | Level-up moves |
| [Vibrava](../pokemon/vibrava.md) | Changed | Level-up moves |
| [Flygon](../pokemon/flygon.md) | Changed | Base stats, Level-up moves |
| [Cacnea](../pokemon/cacnea.md) | Changed | Abilities, Level-up moves |
| [Cacturne](../pokemon/cacturne.md) | Changed | Abilities, Level-up moves |
| [Swablu](../pokemon/swablu.md) | Changed | Level-up moves |
| [Altaria](../pokemon/altaria.md) | Changed | Base stats, Abilities, Level-up moves |
| [Zangoose](../pokemon/zangoose.md) | Changed | Level-up moves |
| [Seviper](../pokemon/seviper.md) | Changed | Level-up moves |
| [Lunatone](../pokemon/lunatone.md) | Changed | Base stats, Level-up moves |
| [Solrock](../pokemon/solrock.md) | Changed | Base stats, Level-up moves |
| [Barboach](../pokemon/barboach.md) | Changed | Level-up moves |
| [Whiscash](../pokemon/whiscash.md) | Changed | Level-up moves |
| [Corphish](../pokemon/corphish.md) | Changed | Abilities, Level-up moves |
| [Crawdaunt](../pokemon/crawdaunt.md) | Changed | Abilities, Level-up moves |
| [Baltoy](../pokemon/baltoy.md) | Changed | Level-up moves |
| [Claydol](../pokemon/claydol.md) | Changed | Level-up moves |
| [Lileep](../pokemon/lileep.md) | Changed | Abilities, Level-up moves |
| [Cradily](../pokemon/cradily.md) | Changed | Abilities, Level-up moves |
| [Anorith](../pokemon/anorith.md) | Changed | Abilities |
| [Armaldo](../pokemon/armaldo.md) | Changed | Abilities, Level-up moves |
| [Feebas](../pokemon/feebas.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Milotic](../pokemon/milotic.md) | Changed | Abilities, Level-up moves |
| [Castform](../pokemon/castform.md) | Changed | Base stats |
| [Kecleon](../pokemon/kecleon.md) | Changed | Base stats, Level-up moves |
| [Shuppet](../pokemon/shuppet.md) | Changed | Base stats, Level-up moves |
| [Banette](../pokemon/banette.md) | Changed | Base stats, Level-up moves |
| [Dusclops](../pokemon/dusclops.md) | Changed | Evolutions, Level-up moves |
| [Tropius](../pokemon/tropius.md) | Changed | Base stats, Base experience, Level-up moves |
| [Chimecho](../pokemon/chimecho.md) | Changed | Base stats, Level-up moves |
| [Absol](../pokemon/absol.md) | Changed | Level-up moves |
| [Glalie](../pokemon/glalie.md) | Changed | Base stats, Types, Abilities, Machines, Level-up moves |
| [Walrein](../pokemon/walrein.md) | Changed | Level-up moves |
| [Clamperl](../pokemon/clamperl.md) | Changed | Evolutions, Level-up moves |
| [Relicanth](../pokemon/relicanth.md) | Changed | Level-up moves |
| [Luvdisc](../pokemon/luvdisc.md) | Changed | Base stats, Abilities, Base experience, Wild held items |
| [Bagon](../pokemon/bagon.md) | Changed | Level-up moves |
| [Shelgon](../pokemon/shelgon.md) | Changed | Level-up moves |
| [Salamence](../pokemon/salamence.md) | Changed | Level-up moves |
| [Beldum](../pokemon/beldum.md) | Changed | Abilities, Level-up moves |
| [Metang](../pokemon/metang.md) | Changed | Abilities |
| [Metagross](../pokemon/metagross.md) | Changed | Abilities, Level-up moves |
| [Regirock](../pokemon/regirock.md) | Changed | Abilities |
| [Regice](../pokemon/regice.md) | Changed | Abilities |
| [Registeel](../pokemon/registeel.md) | Changed | Abilities |
| [Jirachi](../pokemon/jirachi.md) | Changed | Abilities |
| [Turtwig](../pokemon/turtwig.md) | Changed | Abilities, Level-up moves |
| [Grotle](../pokemon/grotle.md) | Changed | Abilities, Level-up moves |
| [Torterra](../pokemon/torterra.md) | Changed | Abilities, Level-up moves |
| [Chimchar](../pokemon/chimchar.md) | Changed | Abilities |
| [Monferno](../pokemon/monferno.md) | Changed | Abilities |
| [Infernape](../pokemon/infernape.md) | Changed | Abilities, Level-up moves |
| [Piplup](../pokemon/piplup.md) | Changed | Abilities |
| [Prinplup](../pokemon/prinplup.md) | Changed | Abilities |
| [Empoleon](../pokemon/empoleon.md) | Changed | Abilities |
| [Starly](../pokemon/starly.md) | Changed | Abilities, Level-up moves |
| [Staravia](../pokemon/staravia.md) | Changed | Abilities, Level-up moves |
| [Staraptor](../pokemon/staraptor.md) | Changed | Base stats, Abilities, Level-up moves |
| [Bidoof](../pokemon/bidoof.md) | Changed | Level-up moves |
| [Bibarel](../pokemon/bibarel.md) | Changed | Base stats, Level-up moves |
| [Kricketot](../pokemon/kricketot.md) | Changed | Abilities, Level-up moves |
| [Kricketune](../pokemon/kricketune.md) | Changed | Base stats |
| [Shinx](../pokemon/shinx.md) | Changed | Abilities, Level-up moves |
| [Luxio](../pokemon/luxio.md) | Changed | Types, Abilities, Level-up moves |
| [Luxray](../pokemon/luxray.md) | Changed | Base stats, Types, Abilities, Level-up moves |
| [Budew](../pokemon/budew.md) | Changed | Abilities, Level-up moves |
| [Roserade](../pokemon/roserade.md) | Changed | Abilities, Level-up moves |
| [Cranidos](../pokemon/cranidos.md) | Changed | Abilities, Level-up moves |
| [Rampardos](../pokemon/rampardos.md) | Changed | Abilities, Level-up moves |
| [Shieldon](../pokemon/shieldon.md) | Changed | Abilities |
| [Bastiodon](../pokemon/bastiodon.md) | Changed | Abilities, Level-up moves |
| [Burmy](../pokemon/burmy.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Wormadam](../pokemon/wormadam-plant.md) | Changed | Base stats, Abilities |
| [Mothim](../pokemon/mothim.md) | Changed | Base stats, Abilities, Level-up moves |
| [Combee](../pokemon/combee.md) | Changed | Abilities, Evolutions, Level-up moves |
| [Vespiquen](../pokemon/vespiquen.md) | Changed | Machines, Level-up moves |
| [Pachirisu](../pokemon/pachirisu.md) | Changed | Base stats, Abilities, Level-up moves |
| [Buizel](../pokemon/buizel.md) | Changed | Abilities, Level-up moves |
| [Floatzel](../pokemon/floatzel.md) | Changed | Abilities, Level-up moves |
| [Cherrim](../pokemon/cherrim.md) | Changed | Base stats, Level-up moves |
| [Shellos](../pokemon/shellos.md) | Changed | Level-up moves |
| [Gastrodon](../pokemon/gastrodon.md) | Changed | Level-up moves |
| [Ambipom](../pokemon/ambipom.md) | Changed | Abilities, Level-up moves |
| [Drifloon](../pokemon/drifloon.md) | Changed | Level-up moves |
| [Drifblim](../pokemon/drifblim.md) | Changed | Level-up moves |
| [Buneary](../pokemon/buneary.md) | Changed | Abilities, Level-up moves |
| [Lopunny](../pokemon/lopunny.md) | Changed | Abilities, Level-up moves |
| [Mismagius](../pokemon/mismagius.md) | Changed | Base stats, Level-up moves |
| [Honchkrow](../pokemon/honchkrow.md) | Changed | Level-up moves |
| [Glameow](../pokemon/glameow.md) | Changed | Level-up moves |
| [Purugly](../pokemon/purugly.md) | Changed | Base stats, Level-up moves |
| [Chingling](../pokemon/chingling.md) | Changed | Level-up moves |
| [Stunky](../pokemon/stunky.md) | Changed | Level-up moves |
| [Skuntank](../pokemon/skuntank.md) | Changed | Base stats, Level-up moves |
| [Bronzor](../pokemon/bronzor.md) | Changed | Base stats, Level-up moves |
| [Bronzong](../pokemon/bronzong.md) | Changed | Machines, Level-up moves |
| [Happiny](../pokemon/happiny.md) | Changed | Level-up moves |
| [Chatot](../pokemon/chatot.md) | Changed | Base stats, Abilities, Base experience, Growth rate, Level-up moves |
| [Spiritomb](../pokemon/spiritomb.md) | Changed | Level-up moves |
| [Gible](../pokemon/gible.md) | Changed | Abilities, Level-up moves |
| [Gabite](../pokemon/gabite.md) | Changed | Abilities, Level-up moves |
| [Garchomp](../pokemon/garchomp.md) | Changed | Level-up moves |
| [Munchlax](../pokemon/munchlax.md) | Changed | Level-up moves |
| [Riolu](../pokemon/riolu.md) | Changed | Level-up moves |
| [Lucario](../pokemon/lucario.md) | Changed | Level-up moves |
| [Hippopotas](../pokemon/hippopotas.md) | Changed | Level-up moves |
| [Hippowdon](../pokemon/hippowdon.md) | Changed | Level-up moves |
| [Drapion](../pokemon/drapion.md) | Changed | Level-up moves |
| [Croagunk](../pokemon/croagunk.md) | Changed | Machines, Level-up moves |
| [Toxicroak](../pokemon/toxicroak.md) | Changed | Machines, Level-up moves |
| [Carnivine](../pokemon/carnivine.md) | Changed | Base stats, Types, Machines, Level-up moves |
| [Lumineon](../pokemon/lumineon.md) | Changed | Base stats, Level-up moves |
| [Mantyke](../pokemon/mantyke.md) | Changed | Evolutions, Level-up moves |
| [Snover](../pokemon/snover.md) | Changed | Abilities, Level-up moves |
| [Abomasnow](../pokemon/abomasnow.md) | Changed | Base stats, Abilities, Level-up moves |
| [Weavile](../pokemon/weavile.md) | Changed | Abilities, Level-up moves |
| [Magnezone](../pokemon/magnezone.md) | Changed | Level-up moves |
| [Lickilicky](../pokemon/lickilicky.md) | Changed | Abilities, Level-up moves |
| [Rhyperior](../pokemon/rhyperior.md) | Changed | Abilities, Level-up moves |
| [Tangrowth](../pokemon/tangrowth.md) | Changed | Level-up moves |
| [Electivire](../pokemon/electivire.md) | Changed | Types, Abilities, Level-up moves |
| [Magmortar](../pokemon/magmortar.md) | Changed | Abilities, Level-up moves |
| [Togekiss](../pokemon/togekiss.md) | Changed | Level-up moves |
| [Yanmega](../pokemon/yanmega.md) | Changed | Level-up moves |
| [Leafeon](../pokemon/leafeon.md) | Changed | Abilities, Level-up moves |
| [Glaceon](../pokemon/glaceon.md) | Changed | Abilities, Machines, Level-up moves |
| [Gliscor](../pokemon/gliscor.md) | Changed | Abilities |
| [Mamoswine](../pokemon/mamoswine.md) | Changed | Abilities, Level-up moves |
| [Porygon-Z](../pokemon/porygon-z.md) | Changed | Level-up moves |
| [Gallade](../pokemon/gallade.md) | Changed | Level-up moves |
| [Probopass](../pokemon/probopass.md) | Changed | Base stats, Level-up moves |
| [Froslass](../pokemon/froslass.md) | Changed | Base stats, Abilities, Level-up moves |
| [Rotom](../pokemon/rotom.md) | Changed | Base stats |
| [Heatran](../pokemon/heatran.md) | Changed | Abilities |
| [Regigigas](../pokemon/regigigas.md) | Changed | Abilities |
| [Phione](../pokemon/phione.md) | Changed | Base stats |
| [Arceus](../pokemon/arceus.md) | Changed | Wild held items, Level-up moves |
| [Wormadam Sandy](../pokemon/wormadam-sandy.md) | Changed | Base stats, Abilities |
| [Wormadam Trash](../pokemon/wormadam-trash.md) | Changed | Base stats, Abilities |
| [Rotom Heat](../pokemon/rotom-heat.md) | Changed | Types |
| [Rotom Wash](../pokemon/rotom-wash.md) | Changed | Types |
| [Rotom Frost](../pokemon/rotom-frost.md) | Changed | Types |
| [Rotom Fan](../pokemon/rotom-fan.md) | Changed | Base stats, Types, Abilities |
| [Rotom Mow](../pokemon/rotom-mow.md) | Changed | Types |

## Abilities

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Stench](../abilities/stench.md) | Changed | Pokémon |
| [Drizzle](../abilities/drizzle.md) | Changed | Pokémon |
| [Speed Boost](../abilities/speed-boost.md) | Changed | Pokémon |
| [Battle Armor](../abilities/battle-armor.md) | Changed | Pokémon |
| [Sturdy](../abilities/sturdy.md) | Changed | Pokémon |
| [Damp](../abilities/damp.md) | Changed | Pokémon |
| [Limber](../abilities/limber.md) | Changed | Pokémon |
| [Sand Veil](../abilities/sand-veil.md) | Changed | Pokémon |
| [Static](../abilities/static.md) | Changed | Pokémon |
| [Volt Absorb](../abilities/volt-absorb.md) | Changed | Pokémon |
| [Water Absorb](../abilities/water-absorb.md) | Changed | Pokémon |
| [Oblivious](../abilities/oblivious.md) | Changed | Pokémon |
| [Cloud Nine](../abilities/cloud-nine.md) | Changed | Pokémon |
| [Compoundeyes](../abilities/compound-eyes.md) | Changed | Pokémon |
| [Immunity](../abilities/immunity.md) | Changed | Pokémon |
| [Flash Fire](../abilities/flash-fire.md) | Changed | Pokémon |
| [Shield Dust](../abilities/shield-dust.md) | Changed | Pokémon |
| [Own Tempo](../abilities/own-tempo.md) | Changed | Pokémon |
| [Intimidate](../abilities/intimidate.md) | Changed | Pokémon |
| [Rough Skin](../abilities/rough-skin.md) | Changed | Pokémon |
| [Levitate](../abilities/levitate.md) | Changed | Pokémon |
| [Effect Spore](../abilities/effect-spore.md) | Changed | Pokémon |
| [Synchronize](../abilities/synchronize.md) | Changed | Pokémon |
| [Natural Cure](../abilities/natural-cure.md) | Changed | Pokémon |
| [Lightningrod](../abilities/lightning-rod.md) | Changed | Pokémon |
| [Serene Grace](../abilities/serene-grace.md) | Changed | Pokémon |
| [Swift Swim](../abilities/swift-swim.md) | Changed | Pokémon |
| [Chlorophyll](../abilities/chlorophyll.md) | Changed | Pokémon |
| [Illuminate](../abilities/illuminate.md) | Changed | Pokémon |
| [Poison Point](../abilities/poison-point.md) | Changed | Pokémon |
| [Inner Focus](../abilities/inner-focus.md) | Changed | Pokémon |
| [Magma Armor](../abilities/magma-armor.md) | Changed | Pokémon |
| [Water Veil](../abilities/water-veil.md) | Changed | Pokémon |
| [Soundproof](../abilities/soundproof.md) | Changed | Pokémon |
| [Rain Dish](../abilities/rain-dish.md) | Changed | Pokémon |
| [Pressure](../abilities/pressure.md) | Changed | Pokémon |
| [Thick Fat](../abilities/thick-fat.md) | Changed | Pokémon |
| [Early Bird](../abilities/early-bird.md) | Changed | Pokémon |
| [Flame Body](../abilities/flame-body.md) | Changed | Pokémon |
| [Run Away](../abilities/run-away.md) | Changed | Pokémon |
| [Keen Eye](../abilities/keen-eye.md) | Changed | Pokémon |
| [Hyper Cutter](../abilities/hyper-cutter.md) | Changed | Pokémon |
| [Pickup](../abilities/pickup.md) | Changed | Pokémon |
| [Hustle](../abilities/hustle.md) | Changed | Pokémon |
| [Cute Charm](../abilities/cute-charm.md) | Changed | Pokémon |
| [Shed Skin](../abilities/shed-skin.md) | Changed | Pokémon |
| [Guts](../abilities/guts.md) | Changed | Pokémon |
| [Marvel Scale](../abilities/marvel-scale.md) | Changed | Pokémon |
| [Swarm](../abilities/swarm.md) | Changed | Pokémon |
| [Rock Head](../abilities/rock-head.md) | Changed | Pokémon |
| [Drought](../abilities/drought.md) | Changed | Pokémon |
| [Vital Spirit](../abilities/vital-spirit.md) | Changed | Pokémon |
| [Shell Armor](../abilities/shell-armor.md) | Changed | Pokémon |
| [Tangled Feet](../abilities/tangled-feet.md) | Changed | Pokémon |
| [Motor Drive](../abilities/motor-drive.md) | Changed | Pokémon |
| [Rivalry](../abilities/rivalry.md) | Changed | Pokémon |
| [Steadfast](../abilities/steadfast.md) | Changed | Pokémon |
| [Snow Cloak](../abilities/snow-cloak.md) | Changed | Pokémon |
| [Gluttony](../abilities/gluttony.md) | Changed | Pokémon |
| [Anger Point](../abilities/anger-point.md) | Changed | Pokémon |
| [Unburden](../abilities/unburden.md) | Changed | Pokémon |
| [Dry Skin](../abilities/dry-skin.md) | Changed | Pokémon |
| [Iron Fist](../abilities/iron-fist.md) | Changed | Pokémon |
| [Poison Heal](../abilities/poison-heal.md) | Changed | Pokémon |
| [Adaptability](../abilities/adaptability.md) | Changed | Pokémon |
| [Hydration](../abilities/hydration.md) | Changed | Pokémon |
| [Solar Power](../abilities/solar-power.md) | Changed | Pokémon |
| [Quick Feet](../abilities/quick-feet.md) | Changed | Pokémon |
| [Sniper](../abilities/sniper.md) | Changed | Pokémon |
| [Magic Guard](../abilities/magic-guard.md) | Changed | Pokémon |
| [Technician](../abilities/technician.md) | Changed | Pokémon |
| [Leaf Guard](../abilities/leaf-guard.md) | Changed | Pokémon |
| [Super Luck](../abilities/super-luck.md) | Changed | Pokémon |
| [Aftermath](../abilities/aftermath.md) | Changed | Pokémon |
| [Anticipation](../abilities/anticipation.md) | Changed | Pokémon |
| [Forewarn](../abilities/forewarn.md) | Changed | Pokémon |
| [Unaware](../abilities/unaware.md) | Changed | Pokémon |
| [Tinted Lens](../abilities/tinted-lens.md) | Changed | Pokémon |
| [Filter](../abilities/filter.md) | Changed | Pokémon |
| [Slow Start](../abilities/slow-start.md) | Changed | Pokémon |
| [Scrappy](../abilities/scrappy.md) | Changed | Pokémon |
| [Storm Drain](../abilities/storm-drain.md) | Changed | Pokémon |
| [Ice Body](../abilities/ice-body.md) | Changed | Pokémon |
| [Solid Rock](../abilities/solid-rock.md) | Changed | Pokémon |
| [Honey Gather](../abilities/honey-gather.md) | Changed | Pokémon |
| [Reckless](../abilities/reckless.md) | Changed | Pokémon |

## Moves

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Cut](../moves/cut.md) | Changed | Type, Power, Accuracy |
| [Bind](../moves/bind.md) | Changed | Accuracy |
| [Jump Kick](../moves/jump-kick.md) | Changed | Power |
| [Tackle](../moves/tackle.md) | Changed | Power, Accuracy |
| [Wrap](../moves/wrap.md) | Changed | Accuracy |
| [Thrash](../moves/thrash.md) | Changed | Power |
| [Disable](../moves/disable.md) | Changed | Accuracy |
| [Strength](../moves/strength.md) | Changed | Type, Power, Effect, Effect chance |
| [Petal Dance](../moves/petal-dance.md) | Changed | Power |
| [Fire Spin](../moves/fire-spin.md) | Changed | Power, Accuracy |
| [Toxic](../moves/toxic.md) | Changed | Accuracy |
| [Hypnosis](../moves/hypnosis.md) | Changed | Accuracy |
| [Clamp](../moves/clamp.md) | Changed | Accuracy |
| [Hi Jump Kick](../moves/hi-jump-kick.md) | Changed | Power |
| [Glare](../moves/glare.md) | Changed | Accuracy |
| [Poison Gas](../moves/poison-gas.md) | Changed | Accuracy |
| [Crabhammer](../moves/crabhammer.md) | Changed | Accuracy |
| [Cotton Spore](../moves/cotton-spore.md) | Changed | Accuracy |
| [Scary Face](../moves/scary-face.md) | Changed | Accuracy |
| [Bone Rush](../moves/bone-rush.md) | Changed | Accuracy |
| [Giga Drain](../moves/giga-drain.md) | Changed | Power |
| [Fury Cutter](../moves/fury-cutter.md) | Changed | Power |
| [Future Sight](../moves/future-sight.md) | Changed | Power, Accuracy |
| [Rock Smash](../moves/rock-smash.md) | Changed | Power, Effect chance |
| [Whirlpool](../moves/whirlpool.md) | Changed | Power, Accuracy |
| [Uproar](../moves/uproar.md) | Changed | Power |
| [Hail](../moves/hail.md) | Changed | Flags |
| [Sand Tomb](../moves/sand-tomb.md) | Changed | Power, Accuracy |
| [Bullet Seed](../moves/bullet-seed.md) | Changed | Power |
| [Icicle Spear](../moves/icicle-spear.md) | Changed | Power |
| [Covet](../moves/covet.md) | Changed | Power |
| [Rock Blast](../moves/rock-blast.md) | Changed | Accuracy |
| [Doom Desire](../moves/doom-desire.md) | Changed | Power, Accuracy |
| [Feint](../moves/feint.md) | Changed | Power |
| [Last Resort](../moves/last-resort.md) | Changed | Power |
| [Drain Punch](../moves/drain-punch.md) | Changed | Power, Pp |
| [Magma Storm](../moves/magma-storm.md) | Changed | Accuracy |

## Items

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Master Ball](../items/master-ball.md) | Changed | Locations |
| [Ultra Ball](../items/ultra-ball.md) | Changed | Locations, Shops |
| [Great Ball](../items/great-ball.md) | Changed | Shops |
| [Poké Ball](../items/poke-ball.md) | Changed | Locations |
| [Net Ball](../items/net-ball.md) | Changed | Shops |
| [Dusk Ball](../items/dusk-ball.md) | Changed | Shops |
| [Potion](../items/potion.md) | Changed | Locations |
| [Antidote](../items/antidote.md) | Changed | Locations, Shops |
| [Parlyz Heal](../items/parlyz-heal.md) | Changed | Locations, Shops |
| [Full Restore](../items/full-restore.md) | Changed | Trainer battle items |
| [Hyper Potion](../items/hyper-potion.md) | Changed | Locations, Trainer battle items |
| [Super Potion](../items/super-potion.md) | Changed | Locations, Shops, Trainer battle items |
| [Full Heal](../items/full-heal.md) | Changed | Locations |
| [Revive](../items/revive.md) | Changed | Shops |
| [Max Revive](../items/max-revive.md) | Changed | Locations |
| [Lemonade](../items/lemonade.md) | Changed | Trainer battle items |
| [Moomoo Milk](../items/moomoo-milk.md) | Changed | Trainer battle items |
| [Energy Root](../items/energy-root.md) | Changed | Locations |
| [Heal Powder](../items/heal-powder.md) | Changed | Locations |
| [Revival Herb](../items/revival-herb.md) | Changed | Locations |
| [Protein](../items/protein.md) | Changed | Locations |
| [Iron](../items/iron.md) | Changed | Locations |
| [Calcium](../items/calcium.md) | Changed | Locations |
| [Rare Candy](../items/rare-candy.md) | Changed | Locations |
| [PP Max](../items/pp-max.md) | Changed | Locations |
| [Dire Hit](../items/dire-hit.md) | Changed | Locations |
| [X Attack](../items/x-attack.md) | Changed | Locations |
| [Blue Flute](../items/blue-flute.md) | Changed | Locations |
| [Super Repel](../items/super-repel.md) | Changed | Shops |
| [Escape Rope](../items/escape-rope.md) | Changed | Locations |
| [Sun Stone](../items/sun-stone.md) | Changed | Locations |
| [Moon Stone](../items/moon-stone.md) | Changed | Locations, Trades |
| [Fire Stone](../items/fire-stone.md) | Changed | Locations, Shops |
| [Thunderstone](../items/thunder-stone.md) | Changed | Locations, Shops |
| [Water Stone](../items/water-stone.md) | Changed | Locations, Shops |
| [Leaf Stone](../items/leaf-stone.md) | Changed | Locations, Shops |
| [Big Mushroom](../items/big-mushroom.md) | Changed | Locations |
| [Pearl](../items/pearl.md) | Changed | Locations |
| [Nugget](../items/nugget.md) | Changed | Locations, Trades |
| [Heart Scale](../items/heart-scale.md) | Changed | Locations, Wild Held By |
| [Root Fossil](../items/root-fossil.md) | Changed | Locations |
| [Claw Fossil](../items/claw-fossil.md) | Changed | Locations |
| [Helix Fossil](../items/helix-fossil.md) | Changed | Locations |
| [Dome Fossil](../items/dome-fossil.md) | Changed | Locations |
| [Armor Fossil](../items/armor-fossil.md) | Changed | Locations |
| [Skull Fossil](../items/skull-fossil.md) | Changed | Locations |
| [Shiny Stone](../items/shiny-stone.md) | Changed | Locations, Shops |
| [Dusk Stone](../items/dusk-stone.md) | Changed | Locations, Shops |
| [Dawn Stone](../items/dawn-stone.md) | Changed | Locations, Shops, Trades |
| [Oval Stone](../items/oval-stone.md) | Changed | Locations, Trades |
| [Odd Keystone](../items/odd-keystone.md) | Changed | Locations |
| [Griseous Orb](../items/griseous-orb.md) | Changed | Locations |
| [Adamant Orb](../items/adamant-orb.md) | Changed | Locations |
| [Lustrous Orb](../items/lustrous-orb.md) | Changed | Locations |
| [Grass Mail](../items/grass-mail.md) | Changed | Shops |
| [Flame Mail](../items/flame-mail.md) | Changed | Shops |
| [Bubble Mail](../items/bubble-mail.md) | Changed | Shops |
| [Bloom Mail](../items/bloom-mail.md) | Changed | Shops |
| [Tunnel Mail](../items/tunnel-mail.md) | Changed | Shops |
| [Steel Mail](../items/steel-mail.md) | Changed | Shops |
| [Heart Mail](../items/heart-mail.md) | Changed | Shops |
| [Snow Mail](../items/snow-mail.md) | Changed | Shops |
| [Space Mail](../items/space-mail.md) | Changed | Shops |
| [Air Mail](../items/air-mail.md) | Changed | Shops |
| [Cheri Berry](../items/cheri-berry.md) | Changed | Locations, Trades |
| [Chesto Berry](../items/chesto-berry.md) | Changed | Locations, Trainer Held By |
| [Pecha Berry](../items/pecha-berry.md) | Changed | Locations |
| [Rawst Berry](../items/rawst-berry.md) | Changed | Locations |
| [Aspear Berry](../items/aspear-berry.md) | Changed | Locations, Trades |
| [Leppa Berry](../items/leppa-berry.md) | Changed | Locations |
| [Oran Berry](../items/oran-berry.md) | Changed | Locations, Trainer Held By |
| [Persim Berry](../items/persim-berry.md) | Changed | Locations, Trades |
| [Lum Berry](../items/lum-berry.md) | Changed | Locations, Trainer Held By |
| [Sitrus Berry](../items/sitrus-berry.md) | Changed | Locations, Trainer Held By |
| [Wiki Berry](../items/wiki-berry.md) | Changed | Locations |
| [Aguav Berry](../items/aguav-berry.md) | Changed | Locations |
| [Iapapa Berry](../items/iapapa-berry.md) | Changed | Locations |
| [Razz Berry](../items/razz-berry.md) | Changed | Locations |
| [Bluk Berry](../items/bluk-berry.md) | Changed | Locations |
| [Wepear Berry](../items/wepear-berry.md) | Changed | Locations |
| [Pinap Berry](../items/pinap-berry.md) | Changed | Locations, Trainer Held By |
| [Pomeg Berry](../items/pomeg-berry.md) | Changed | Locations |
| [Kelpsy Berry](../items/kelpsy-berry.md) | Changed | Locations, Trainer Held By |
| [Hondew Berry](../items/hondew-berry.md) | Changed | Locations |
| [Grepa Berry](../items/grepa-berry.md) | Changed | Locations |
| [Cornn Berry](../items/cornn-berry.md) | Changed | Locations |
| [Nomel Berry](../items/nomel-berry.md) | Changed | Locations |
| [Durin Berry](../items/durin-berry.md) | Changed | Locations |
| [Occa Berry](../items/occa-berry.md) | Changed | Trainer Held By |
| [Passho Berry](../items/passho-berry.md) | Changed | Trainer Held By, Trades |
| [Wacan Berry](../items/wacan-berry.md) | Changed | Trades |
| [Rindo Berry](../items/rindo-berry.md) | Changed | Trainer Held By |
| [Yache Berry](../items/yache-berry.md) | Changed | Trainer Held By |
| [Chople Berry](../items/chople-berry.md) | Changed | Trainer Held By |
| [Shuca Berry](../items/shuca-berry.md) | Changed | Trainer Held By |
| [Payapa Berry](../items/payapa-berry.md) | Changed | Trainer Held By |
| [Tanga Berry](../items/tanga-berry.md) | Changed | Trainer Held By |
| [Colbur Berry](../items/colbur-berry.md) | Changed | Trainer Held By |
| [Liechi Berry](../items/liechi-berry.md) | Changed | Trainer Held By |
| [Petaya Berry](../items/petaya-berry.md) | Changed | Trainer Held By |
| [Micle Berry](../items/micle-berry.md) | Changed | Trades |
| [Custap Berry](../items/custap-berry.md) | Changed | Trainer Held By |
| [White Herb](../items/white-herb.md) | Changed | Trainer Held By |
| [Macho Brace](../items/macho-brace.md) | Changed | Locations, Trades |
| [Exp. Share](../items/exp-share.md) | Changed | Locations |
| [Quick Claw](../items/quick-claw.md) | Changed | Locations |
| [Soothe Bell](../items/soothe-bell.md) | Changed | Locations, Trades |
| [Choice Band](../items/choice-band.md) | Changed | Locations |
| [King's Rock](../items/kings-rock.md) | Changed | Field use, Field-use function, Party use, Party effects, Locations, Evolutions |
| [Soul Dew](../items/soul-dew.md) | Changed | Locations |
| [DeepSeaTooth](../items/deep-sea-tooth.md) | Changed | Field use, Field-use function, Party use, Party effects, Locations, Evolutions |
| [DeepSeaScale](../items/deep-sea-scale.md) | Changed | Field use, Field-use function, Party use, Party effects, Locations, Evolutions |
| [Smoke Ball](../items/smoke-ball.md) | Changed | Trades |
| [Everstone](../items/everstone.md) | Changed | Locations |
| [Lucky Egg](../items/lucky-egg.md) | Changed | Locations |
| [Metal Coat](../items/metal-coat.md) | Changed | Field use, Field-use function, Party use, Party effects, Locations, Trades, Evolutions |
| [Leftovers](../items/leftovers.md) | Changed | Trainer Held By |
| [Dragon Scale](../items/dragon-scale.md) | Changed | Field use, Field-use function, Held effect, Held-effect parameter, Party use, Party effects, Locations, Evolutions |
| [Light Ball](../items/light-ball.md) | Changed | Locations |
| [Hard Stone](../items/hard-stone.md) | Changed | Locations, Trainer Held By |
| [Miracle Seed](../items/miracle-seed.md) | Changed | Locations |
| [BlackGlasses](../items/black-glasses.md) | Changed | Locations |
| [Black Belt](../items/black-belt.md) | Changed | Locations |
| [Magnet](../items/magnet.md) | Changed | Locations |
| [Mystic Water](../items/mystic-water.md) | Changed | Locations |
| [Sharp Beak](../items/sharp-beak.md) | Changed | Locations, Trainer Held By |
| [Poison Barb](../items/poison-barb.md) | Changed | Locations |
| [TwistedSpoon](../items/twisted-spoon.md) | Changed | Locations |
| [Charcoal](../items/charcoal.md) | Changed | Locations |
| [Silk Scarf](../items/silk-scarf.md) | Changed | Trainer Held By |
| [Up-Grade](../items/up-grade.md) | Changed | Field use, Field-use function, Held effect, Party use, Party effects, Locations, Evolutions |
| [Shell Bell](../items/shell-bell.md) | Changed | Locations |
| [Lucky Punch](../items/lucky-punch.md) | Changed | Locations |
| [Metal Powder](../items/metal-powder.md) | Changed | Locations |
| [Thick Club](../items/thick-club.md) | Changed | Locations |
| [Stick](../items/stick.md) | Changed | Locations |
| [Wide Lens](../items/wide-lens.md) | Changed | Trades |
| [Light Clay](../items/light-clay.md) | Changed | Trainer Held By |
| [Life Orb](../items/life-orb.md) | Changed | Trainer Held By |
| [Power Herb](../items/power-herb.md) | Changed | Locations, Trainer Held By |
| [Toxic Orb](../items/toxic-orb.md) | Changed | Locations, Trainer Held By |
| [Flame Orb](../items/flame-orb.md) | Changed | Locations, Trainer Held By |
| [Quick Powder](../items/quick-powder.md) | Changed | Locations |
| [Focus Sash](../items/focus-sash.md) | Changed | Trainer Held By |
| [Iron Ball](../items/iron-ball.md) | Changed | Trainer Held By, Trades |
| [Black Sludge](../items/black-sludge.md) | Changed | Trainer Held By |
| [Heat Rock](../items/heat-rock.md) | Changed | Trainer Held By |
| [Damp Rock](../items/damp-rock.md) | Changed | Trainer Held By |
| [Choice Scarf](../items/choice-scarf.md) | Changed | Trainer Held By |
| [Big Root](../items/big-root.md) | Changed | Trainer Held By |
| [Flame Plate](../items/flame-plate.md) | Changed | Locations |
| [Splash Plate](../items/splash-plate.md) | Changed | Locations |
| [Zap Plate](../items/zap-plate.md) | Changed | Locations |
| [Meadow Plate](../items/meadow-plate.md) | Changed | Locations |
| [Icicle Plate](../items/icicle-plate.md) | Changed | Locations |
| [Toxic Plate](../items/toxic-plate.md) | Changed | Locations |
| [Earth Plate](../items/earth-plate.md) | Changed | Locations |
| [Sky Plate](../items/sky-plate.md) | Changed | Locations |
| [Mind Plate](../items/mind-plate.md) | Changed | Locations |
| [Insect Plate](../items/insect-plate.md) | Changed | Locations |
| [Stone Plate](../items/stone-plate.md) | Changed | Locations |
| [Spooky Plate](../items/spooky-plate.md) | Changed | Locations |
| [Dread Plate](../items/dread-plate.md) | Changed | Locations, Wild Held By |
| [Iron Plate](../items/iron-plate.md) | Changed | Locations |
| [Protector](../items/protector.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Electirizer](../items/electirizer.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Magmarizer](../items/magmarizer.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Dubious Disc](../items/dubious-disc.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Trades, Evolutions |
| [Reaper Cloth](../items/reaper-cloth.md) | Changed | Field use, Field-use function, Held effect, Fling power, Party use, Party effects, Locations, Evolutions |
| [Razor Claw](../items/razor-claw.md) | Changed | Locations |
| [Razor Fang](../items/razor-fang.md) | Changed | Locations |
| [TM01](../items/tm01.md) | Changed | Locations, Shops |
| [TM02](../items/tm02.md) | Changed | Locations |
| [TM03](../items/tm03.md) | Changed | Locations |
| [TM04](../items/tm04.md) | Changed | Locations |
| [TM05](../items/tm05.md) | Changed | Locations |
| [TM06](../items/tm06.md) | Changed | Locations |
| [TM07](../items/tm07.md) | Changed | Locations, Shops |
| [TM08](../items/tm08.md) | Changed | Locations |
| [TM10](../items/tm10.md) | Changed | Locations |
| [TM11](../items/tm11.md) | Changed | Shops |
| [TM12](../items/tm12.md) | Changed | Locations |
| [TM13](../items/tm13.md) | Changed | Locations |
| [TM18](../items/tm18.md) | Changed | Locations, Shops |
| [TM19](../items/tm19.md) | Changed | Locations |
| [TM23](../items/tm23.md) | Changed | Locations, Shops |
| [TM24](../items/tm24.md) | Changed | Locations |
| [TM28](../items/tm28.md) | Changed | Shops |
| [TM29](../items/tm29.md) | Changed | Locations |
| [TM30](../items/tm30.md) | Changed | Locations, Shops |
| [TM31](../items/tm31.md) | Changed | Locations |
| [TM34](../items/tm34.md) | Changed | Locations |
| [TM35](../items/tm35.md) | Changed | Locations |
| [TM37](../items/tm37.md) | Changed | Locations, Shops |
| [TM40](../items/tm40.md) | Changed | Locations |
| [TM44](../items/tm44.md) | Changed | Locations |
| [TM45](../items/tm45.md) | Changed | Locations, Shops |
| [TM46](../items/tm46.md) | Changed | Locations |
| [TM47](../items/tm47.md) | Changed | Locations |
| [TM48](../items/tm48.md) | Changed | Locations, Shops |
| [TM50](../items/tm50.md) | Changed | Locations |
| [TM51](../items/tm51.md) | Changed | Shops |
| [TM53](../items/tm53.md) | Changed | Locations |
| [TM57](../items/tm57.md) | Changed | Locations |
| [TM59](../items/tm59.md) | Changed | Locations, Shops |
| [TM61](../items/tm61.md) | Changed | Locations |
| [TM62](../items/tm62.md) | Changed | Locations |
| [TM63](../items/tm63.md) | Changed | Locations |
| [TM65](../items/tm65.md) | Changed | Locations |
| [TM70](../items/tm70.md) | Changed | Locations |
| [TM71](../items/tm71.md) | Changed | Locations |
| [TM73](../items/tm73.md) | Changed | Locations |
| [TM76](../items/tm76.md) | Changed | Locations |
| [TM79](../items/tm79.md) | Changed | Locations |
| [TM80](../items/tm80.md) | Changed | Locations |
| [TM81](../items/tm81.md) | Changed | Locations |
| [TM83](../items/tm83.md) | Changed | Locations |
| [TM84](../items/tm84.md) | Changed | Locations |
| [TM86](../items/tm86.md) | Changed | Locations, Shops |
| [TM89](../items/tm89.md) | Changed | Locations, Shops |
| [TM92](../items/tm92.md) | Changed | Locations, Shops |
| [HM01](../items/hm01.md) | Changed | Locations |
| [HM02](../items/hm02.md) | Changed | Locations |
| [HM03](../items/hm03.md) | Changed | Locations |
| [HM04](../items/hm04.md) | Changed | Locations |
| [HM05](../items/hm05.md) | Changed | Locations |
| [HM06](../items/hm06.md) | Changed | Locations |
| [HM08](../items/hm08.md) | Changed | Locations |
| [Point Card](../items/point-card.md) | Changed | Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Selectable |
| [Woodland Ore](../items/woodland-ore.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Selectable, Locations, Evolutions |
| [Fashion Case](../items/fashion-case.md) | Changed | Locations |
| [Serenade Orb](../items/serenade-orb.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Locations, Evolutions |
| [Aubade Orb](../items/aubade-orb.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Locations, Evolutions |
| [Chilled Ore](../items/chilled-ore.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Locations, Evolutions |
| [Red Chain](../items/red-chain.md) | Changed | Locations |
| [Coin Case](../items/coin-case.md) | Changed | Locations |
| [Old Rod](../items/old-rod.md) | Changed | Locations |
| [Good Rod](../items/good-rod.md) | Changed | Locations |
| [Super Rod](../items/super-rod.md) | Changed | Locations |
| [Bicycle](../items/bicycle.md) | Changed | Locations |
| [Lunar Wing](../items/lunar-wing.md) | Changed | Locations |
| [Voltaic Ore](../items/voltaic-ore.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Locations, Evolutions |
| [Azure Flute](../items/azure-flute.md) | Changed | Locations |
| [S.S. Ticket](../items/ss-ticket.md) | Changed | Locations |
| [Magma Stone](../items/magma-stone.md) | Changed | Locations |
| [SecretPotion](../items/secret-potion.md) | Changed | Locations |
| [Gracidea](../items/gracidea.md) | Changed | Locations |
| [Covenant Orb](../items/covenant-orb.md) | Changed | Name, Price, Pocket, Field pocket, Field use, Field-use function, Fling power, Party use, Party effects, Prevents tossing, Locations, Evolutions |
| [Apricorn Box](../items/apricorn-box.md) | Changed | Locations |
| [Unown Report](../items/unown-report.md) | Changed | Name |
| [Berry Pots](../items/berry-pots.md) | Changed | Locations |
| [Clear Bell](../items/clear-bell.md) | Changed | Locations |
| [SquirtBottle](../items/squirt-bottle.md) | Changed | Locations |
| [Red Scale](../items/red-scale.md) | Changed | Locations |
| [Lost Item](../items/lost-item.md) | Changed | Locations |
| [Silver Wing](../items/silver-wing.md) | Changed | Locations |
| [Rainbow Wing](../items/rainbow-wing.md) | Changed | Locations |
| [Mystery Egg](../items/mystery-egg.md) | Changed | Locations |
| [Lure Ball](../items/lure-ball.md) | Changed | Locations |
| [GB Sounds](../items/gb-sounds.md) | Changed | Locations |
| [Tidal Bell](../items/tidal-bell.md) | Changed | Locations |
| [RageCandyBar](../items/rage-candy-bar.md) | Changed | Locations |
| [Jade Orb](../items/jade-orb.md) | Changed | Locations |
| [Lock Capsule](../items/lock-capsule.md) | Changed | Locations |
| [Red Orb](../items/red-orb.md) | Changed | Locations |
| [Blue Orb](../items/blue-orb.md) | Changed | Locations |
| [Enigma Stone](../items/enigma-stone.md) | Changed | Locations |

## Wild encounters

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [New Bark Town](../encounters/area-000.md) | Changed | Old Rod, Good Rod, Super Rod, Special |
| [Route 29](../encounters/area-001.md) | Changed | Walking, Walking Variants, Special |
| [Cherrygrove City](../encounters/area-002.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 30](../encounters/area-003.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 31](../encounters/area-004.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Special |
| [Violet City](../encounters/area-005.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Sprout Tower](../encounters/area-006.md) | Changed | Walking, Walking Variants, Special |
| [Sprout Tower](../encounters/area-007.md) | Changed | Walking, Walking Variants, Special |
| [Route 32](../encounters/area-008.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Ruins of Alph](../encounters/area-009.md) | Changed | Walking, Walking Variants, Surf, Rock Smash, Old Rod, Good Rod, Super Rod, Special |
| [Ruins of Alph](../encounters/area-010.md) | Changed | Walking, Walking Variants |
| [Union Cave](../encounters/area-014.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Union Cave](../encounters/area-015.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Union Cave](../encounters/area-016.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Special |
| [Route 33](../encounters/area-017.md) | Changed | Walking, Walking Variants, Special |
| [Slowpoke Well](../encounters/area-018.md) | Changed | Name, Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Slowpoke Well](../encounters/area-019.md) | Changed | Name, Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Ilex Forest](../encounters/area-020.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 34](../encounters/area-021.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 35](../encounters/area-022.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [National Park](../encounters/area-023.md) | Changed | Walking, Walking Variants, Special |
| [National Park](../encounters/area-024.md) | Changed | Walking, Walking Variants, Special |
| [Route 36](../encounters/area-025.md) | Changed | Walking, Walking Variants, Special |
| [Route 37](../encounters/area-026.md) | Changed | Walking, Walking Variants, Special |
| [Ecruteak City](../encounters/area-027.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Burned Tower](../encounters/area-028.md) | Changed | Walking, Walking Variants, Special |
| [Burned Tower](../encounters/area-029.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-030.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-031.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-032.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-033.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-034.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-035.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-036.md) | Changed | Walking, Walking Variants, Special |
| [Bell Tower](../encounters/area-037.md) | Changed | Walking, Walking Variants, Special |
| [Route 38](../encounters/area-038.md) | Changed | Walking, Walking Variants, Special |
| [Route 39](../encounters/area-039.md) | Changed | Walking, Walking Variants, Special |
| [Olivine City](../encounters/area-040.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 40](../encounters/area-041.md) | Changed | Surf, Old Rod, Good Rod, Special |
| [Route 41](../encounters/area-042.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Whirl Islands](../encounters/area-043.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Whirl Islands](../encounters/area-044.md) | Changed | Walking, Walking Variants, Special |
| [Whirl Islands](../encounters/area-046.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Whirl Islands](../encounters/area-048.md) | Changed | Walking, Walking Variants, Special |
| [Cianwood City](../encounters/area-051.md) | Changed | Surf, Rock Smash, Old Rod, Good Rod, Super Rod, Special |
| [Route 42](../encounters/area-052.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Mortar](../encounters/area-053.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Mortar](../encounters/area-054.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Mortar](../encounters/area-055.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Mortar](../encounters/area-056.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 43](../encounters/area-057.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Lake of Rage](../encounters/area-058.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 44](../encounters/area-059.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Ice Path](../encounters/area-060.md) | Changed | Walking, Walking Variants, Special |
| [Ice Path](../encounters/area-061.md) | Changed | Walking, Walking Variants, Special |
| [Ice Path](../encounters/area-062.md) | Changed | Walking, Walking Variants, Special |
| [Ice Path](../encounters/area-063.md) | Changed | Walking, Walking Variants, Special |
| [Blackthorn City](../encounters/area-065.md) | Changed | Old Rod, Good Rod, Super Rod, Special |
| [Dragon's Den](../encounters/area-066.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 45](../encounters/area-067.md) | Changed | Walking, Walking Variants, Old Rod, Good Rod, Super Rod, Special |
| [Route 46](../encounters/area-068.md) | Changed | Walking, Walking Variants, Special |
| [Dark Cave](../encounters/area-069.md) | Changed | Walking, Walking Variants, Rock Smash, Old Rod, Good Rod, Super Rod, Special |
| [Dark Cave](../encounters/area-070.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 47](../encounters/area-071.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Moon](../encounters/area-072.md) | Changed | Surf, Super Rod, Special |
| [Mt. Moon](../encounters/area-073.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Seafoam Islands](../encounters/area-074.md) | Changed | Walking, Walking Variants, Special |
| [Seafoam Islands](../encounters/area-075.md) | Changed | Walking, Walking Variants, Special |
| [Seafoam Islands](../encounters/area-076.md) | Changed | Walking, Walking Variants, Special |
| [Seafoam Islands](../encounters/area-077.md) | Changed | Walking, Walking Variants, Special |
| [Seafoam Islands](../encounters/area-078.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Silver Cave](../encounters/area-079.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Silver Cave](../encounters/area-080.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Silver Cave](../encounters/area-081.md) | Changed | Walking, Walking Variants, Special |
| [Cliff Edge Gate](../encounters/area-082.md) | Changed | Special |
| [Cliff Cave](../encounters/area-083.md) | Changed | Walking, Walking Variants, Rock Smash, Special |
| [Bell Tower](../encounters/area-084.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Silver](../encounters/area-085.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Silver Cave](../encounters/area-086.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Mt. Silver Cave](../encounters/area-087.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Silver Cave](../encounters/area-088.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Silver Cave](../encounters/area-089.md) | Changed | Walking, Walking Variants, Special |
| [Route 12](../encounters/area-092.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 19](../encounters/area-093.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 20](../encounters/area-094.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Pallet Town](../encounters/area-095.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Viridian City](../encounters/area-096.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Cerulean City](../encounters/area-097.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Vermilion City](../encounters/area-098.md) | Changed | Surf, Rock Smash, Old Rod, Good Rod, Super Rod, Special |
| [Fuchsia City](../encounters/area-100.md) | Changed | Super Rod, Special |
| [Cinnabar Island](../encounters/area-101.md) | Changed | Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 48](../encounters/area-102.md) | Changed | Walking, Walking Variants, Special |
| [Route 26](../encounters/area-103.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 27](../encounters/area-104.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 28](../encounters/area-105.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Special |
| [Mt. Moon](../encounters/area-106.md) | Changed | Walking, Walking Variants, Special |
| [Mt. Moon](../encounters/area-107.md) | Changed | Walking, Walking Variants, Special |
| [Rock Tunnel](../encounters/area-108.md) | Changed | Walking, Walking Variants, Special |
| [Rock Tunnel](../encounters/area-109.md) | Changed | Walking, Walking Variants, Rock Smash, Special |
| [Victory Road](../encounters/area-110.md) | Changed | Walking, Walking Variants, Special |
| [Route 1](../encounters/area-111.md) | Changed | Walking, Walking Variants, Special |
| [Route 2](../encounters/area-112.md) | Changed | Walking, Walking Variants, Special |
| [Route 3](../encounters/area-113.md) | Changed | Walking, Walking Variants, Special |
| [Route 4](../encounters/area-114.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 5](../encounters/area-115.md) | Changed | Walking, Walking Variants, Special |
| [Route 6](../encounters/area-116.md) | Changed | Walking, Walking Variants, Surf, Super Rod, Special |
| [Route 7](../encounters/area-117.md) | Changed | Walking, Walking Variants, Special |
| [Route 8](../encounters/area-118.md) | Changed | Walking, Walking Variants, Special |
| [Route 9](../encounters/area-119.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 10](../encounters/area-120.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 11](../encounters/area-121.md) | Changed | Walking, Walking Variants, Special |
| [Route 13](../encounters/area-122.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 14](../encounters/area-123.md) | Changed | Walking, Walking Variants, Special |
| [Route 15](../encounters/area-124.md) | Changed | Walking, Walking Variants, Special |
| [Route 16](../encounters/area-125.md) | Changed | Walking, Walking Variants, Special |
| [Route 17](../encounters/area-126.md) | Changed | Walking, Walking Variants, Special |
| [Route 18](../encounters/area-127.md) | Changed | Walking, Walking Variants, Special |
| [Route 21](../encounters/area-128.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 22](../encounters/area-129.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 24](../encounters/area-130.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Route 25](../encounters/area-131.md) | Changed | Walking, Walking Variants, Surf, Old Rod, Good Rod, Super Rod, Special |
| [Tohjo Falls](../encounters/area-132.md) | Changed | Walking, Walking Variants, Surf, Super Rod, Special |
| [Diglett's Cave](../encounters/area-133.md) | Changed | Name, Walking, Walking Variants, Special |
| [Victory Road](../encounters/area-134.md) | Changed | Walking, Walking Variants, Special |
| [Victory Road](../encounters/area-135.md) | Changed | Walking, Walking Variants, Special |
| [Route 2](../encounters/area-136.md) | Changed | Walking, Walking Variants, Special |
| [Viridian Forest](../encounters/area-137.md) | Changed | Walking, Walking Variants, Special |
| [Cerulean Cave](../encounters/area-139.md) | Changed | Walking, Walking Variants, Surf, Rock Smash, Old Rod, Good Rod, Super Rod, Special |
| [Cerulean Cave](../encounters/area-140.md) | Changed | Walking, Walking Variants, Special |
| [Cerulean Cave](../encounters/area-141.md) | Changed | Walking, Walking Variants, Surf, Rock Smash, Old Rod, Good Rod, Super Rod, Special |

## Trainers

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Rival Silver](../trainers/trainer-0001.md) | Changed | Party, Script references |
| [Team Rocket Carolyn](../trainers/trainer-0002.md) | Changed | Name, Class Id, Class Name, AI flags, Party, Script references |
| [Team Rocket Andrew](../trainers/trainer-0003.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Bug Catcher Wade](../trainers/trainer-0004.md) | Changed | Party |
| [Beauty Victoria](../trainers/trainer-0005.md) | Changed | Party |
| [Policeman Keith](../trainers/trainer-0006.md) | Changed | Party |
| [Juggler Irwin](../trainers/trainer-0007.md) | Changed | Party |
| [Youngster Joey](../trainers/trainer-0008.md) | Changed | Party |
| [Swimmer♀ Elaine](../trainers/trainer-0009.md) | Changed | Party |
| [Twins Amy&Mimi](../trainers/trainer-0010.md) | Changed | Name, Party |
| [Pokémon Trainer Lyra](../trainers/trainer-0011.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0012.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0013.md) | Changed | Party |
| [Burglar Duncan](../trainers/trainer-0014.md) | Changed | Party |
| [Firebreather Otis](../trainers/trainer-0015.md) | Changed | Party |
| [Swimmer♂ Simon](../trainers/trainer-0016.md) | Changed | Party |
| [Black Belt Kenji](../trainers/trainer-0017.md) | Changed | Party |
| [Fisherman Justin](../trainers/trainer-0018.md) | Changed | Party |
| [Pokémon Trainer Ethan](../trainers/trainer-0019.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Leader Falkner](../trainers/trainer-0020.md) | Changed | AI flags, Party |
| [Leader Bugsy](../trainers/trainer-0021.md) | Changed | AI battle items, Party, Script references |
| [Lass Carrie](../trainers/trainer-0022.md) | Changed | Party |
| [Poké Maniac Larry](../trainers/trainer-0023.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0024.md) | Changed | Party |
| [Hiker Russel](../trainers/trainer-0025.md) | Changed | Party |
| [Camper Roland](../trainers/trainer-0026.md) | Changed | Party, Locations |
| [Picnicker Liz](../trainers/trainer-0027.md) | Changed | Party |
| [Ace Trainer Jake](../trainers/trainer-0028.md) | Changed | Party |
| [Bird Keeper Rod](../trainers/trainer-0029.md) | Changed | Party |
| [Leader Whitney](../trainers/trainer-0030.md) | Changed | AI battle items, Party, Script references |
| [Leader Morty](../trainers/trainer-0031.md) | Changed | Party, Script references |
| [Leader Pryce](../trainers/trainer-0032.md) | Changed | Party, Script references |
| [Leader Jasmine](../trainers/trainer-0033.md) | Changed | Party, Script references |
| [Leader Chuck](../trainers/trainer-0034.md) | Changed | AI flags, Party |
| [Leader Clair](../trainers/trainer-0035.md) | Changed | Party, Script references |
| [Ace Trainer Joyce](../trainers/trainer-0036.md) | Changed | Party |
| [Gentleman Preston](../trainers/trainer-0037.md) | Changed | Party |
| [Teacher Colette](../trainers/trainer-0038.md) | Changed | Party |
| [Rancher Bobbie](../trainers/trainer-0039.md) | Changed | Name, Class Id, Class Name, Party |
| [Pokémon Trainer Mira](../trainers/trainer-0040.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Guitarist Clyde](../trainers/trainer-0041.md) | Changed | Party |
| [Psychic Nathan](../trainers/trainer-0042.md) | Changed | Party |
| [Sage Chow](../trainers/trainer-0043.md) | Changed | Party |
| [Pokéfan Derek](../trainers/trainer-0044.md) | Changed | Party |
| [Pokéfan Ruth](../trainers/trainer-0045.md) | Changed | Party |
| [Medium Martha](../trainers/trainer-0046.md) | Changed | Party |
| [Aroma Lady Julia](../trainers/trainer-0047.md) | Changed | Name, Class Id, Class Name, Party, Locations |
| [Bug Catcher Rob](../trainers/trainer-0048.md) | Changed | Party |
| [Parasol Lady Joan](../trainers/trainer-0049.md) | Changed | Name, Class Id, Class Name, Party, Locations |
| [Bird Keeper Abe](../trainers/trainer-0050.md) | Changed | Party |
| [Sage Nico](../trainers/trainer-0051.md) | Changed | Party |
| [Sage Edmond](../trainers/trainer-0052.md) | Changed | Party |
| [Sage Jin](../trainers/trainer-0053.md) | Changed | Party |
| [Sage Troy](../trainers/trainer-0054.md) | Changed | Party |
| [Sage Neal](../trainers/trainer-0055.md) | Changed | Party |
| [Ruin Maniac Gordon](../trainers/trainer-0056.md) | Changed | Class Id, Class Name, Party, Locations |
| [Fisherman Ralph](../trainers/trainer-0057.md) | Changed | Party |
| [Fisherman Arnold](../trainers/trainer-0058.md) | Changed | Party |
| [Fisherman Kyle](../trainers/trainer-0059.md) | Changed | Party |
| [Fisherman Henry](../trainers/trainer-0060.md) | Changed | Party |
| [Hiker Anthony](../trainers/trainer-0061.md) | Changed | Party |
| [Gentleman Samuel](../trainers/trainer-0062.md) | Changed | Class Id, Class Name, Party, Locations |
| [Pokémon Trainer Buck](../trainers/trainer-0063.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Youngster Ian](../trainers/trainer-0064.md) | Changed | Party |
| [Picnicker Gina](../trainers/trainer-0065.md) | Changed | Party |
| [Camper Todd](../trainers/trainer-0066.md) | Changed | Party |
| [Bug Catcher Benny](../trainers/trainer-0067.md) | Changed | Party |
| [Bug Catcher Al](../trainers/trainer-0068.md) | Changed | Party |
| [Bug Catcher Josh](../trainers/trainer-0069.md) | Changed | Party |
| [Beauty Samantha](../trainers/trainer-0070.md) | Changed | Party |
| [Lass Cathy](../trainers/trainer-0071.md) | Changed | Party |
| [Bird Keeper Bryan](../trainers/trainer-0072.md) | Changed | Party, Locations |
| [Bird Keeper Theo](../trainers/trainer-0073.md) | Changed | Party |
| [Camper Ivan](../trainers/trainer-0074.md) | Changed | Party |
| [Camper Elliot](../trainers/trainer-0075.md) | Changed | Party |
| [Picnicker Brooke](../trainers/trainer-0076.md) | Changed | Party |
| [Lady Kim](../trainers/trainer-0077.md) | Changed | Class Id, Class Name, Party, Locations |
| [Bug Catcher Arnie](../trainers/trainer-0078.md) | Changed | Party |
| [Bug Catcher Ken](../trainers/trainer-0079.md) | Changed | Party |
| [Policeman Dirk](../trainers/trainer-0080.md) | Changed | Party |
| [Twins Tori&Til](../trainers/trainer-0081.md) | Changed | Name, Party |
| [Bird Keeper Toby](../trainers/trainer-0082.md) | Changed | Party |
| [Picnicker Cindy](../trainers/trainer-0083.md) | Changed | Party, Script references |
| [Camper Barry](../trainers/trainer-0084.md) | Changed | Party, Script references |
| [Swimmer♀ Paula](../trainers/trainer-0085.md) | Changed | Party |
| [Swimmer♂ Randall](../trainers/trainer-0086.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0087.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Team Rocket Grunt](../trainers/trainer-0088.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Medium Grace](../trainers/trainer-0089.md) | Changed | Party |
| [Swimmer♀ Kaylee](../trainers/trainer-0090.md) | Changed | Party |
| [Swimmer♀ Susie](../trainers/trainer-0091.md) | Changed | Party |
| [Swimmer♀ Denise](../trainers/trainer-0092.md) | Changed | Party |
| [Swimmer♀ Kara](../trainers/trainer-0093.md) | Changed | Party |
| [Swimmer♀ Wendy](../trainers/trainer-0094.md) | Changed | Party |
| [Swimmer♂ Charlie](../trainers/trainer-0095.md) | Changed | Party |
| [Swimmer♂ George](../trainers/trainer-0096.md) | Changed | Party |
| [Swimmer♂ Berke](../trainers/trainer-0097.md) | Changed | Party |
| [Swimmer♂ Ronald](../trainers/trainer-0098.md) | Changed | Party |
| [Swimmer♂ Matthew](../trainers/trainer-0099.md) | Changed | Party |
| [Hiker Anthony](../trainers/trainer-0100.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0101.md) | Changed | Party |
| [Ace Trainer Gaven](../trainers/trainer-0102.md) | Changed | Party |
| [Ace Trainer Blake](../trainers/trainer-0103.md) | Changed | Party |
| [Ace Trainer Brian](../trainers/trainer-0104.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0105.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Team Rocket Grunt](../trainers/trainer-0106.md) | Changed | Name, Class Id, Class Name, Party |
| [Executive Ariana](../trainers/trainer-0107.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Ace Trainer Ryan](../trainers/trainer-0108.md) | Changed | Party |
| [Ace Trainer Alton](../trainers/trainer-0109.md) | Changed | Party |
| [Ace Trainer Paulo](../trainers/trainer-0110.md) | Changed | Party |
| [Ace Trainer Mike](../trainers/trainer-0111.md) | Changed | Party |
| [Ace Trainer Cody](../trainers/trainer-0112.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0113.md) | Changed | Party |
| [Ace Trainer Reena](../trainers/trainer-0114.md) | Changed | Party |
| [Ace Trainer Megan](../trainers/trainer-0115.md) | Changed | Party |
| [Ace Trainer Lois](../trainers/trainer-0116.md) | Changed | Party |
| [Ace Trainer Lola](../trainers/trainer-0117.md) | Changed | Party |
| [Ace Trainer Kate](../trainers/trainer-0118.md) | Changed | Party, Script references |
| [Ace Trainer Fran](../trainers/trainer-0119.md) | Changed | Party |
| [Ace Trainer Irene](../trainers/trainer-0120.md) | Changed | Party, Script references |
| [Ace Trainer Kelly](../trainers/trainer-0121.md) | Changed | Party |
| [Fisherman Marvin](../trainers/trainer-0122.md) | Changed | Party |
| [Fisherman Tully](../trainers/trainer-0123.md) | Changed | Party |
| [Fisherman Wilton](../trainers/trainer-0124.md) | Changed | Party |
| [Fisherman Edgar](../trainers/trainer-0125.md) | Changed | Party |
| [Fisherman Andre](../trainers/trainer-0126.md) | Changed | Party |
| [Fisherman Raymond](../trainers/trainer-0127.md) | Changed | Party |
| [Fisherman Jonah](../trainers/trainer-0128.md) | Changed | Party |
| [Poké Maniac Shane](../trainers/trainer-0129.md) | Changed | Party |
| [Poké Maniac Beckett](../trainers/trainer-0130.md) | Changed | Party |
| [Poké Maniac Brent](../trainers/trainer-0131.md) | Changed | Party |
| [Poké Maniac Ron](../trainers/trainer-0132.md) | Changed | Party |
| [Poké Maniac Morgan](../trainers/trainer-0133.md) | Changed | Party |
| [Hiker Benjamin](../trainers/trainer-0134.md) | Changed | Party |
| [School Kid Johnny](../trainers/trainer-0135.md) | Changed | Party |
| [Lass Linda](../trainers/trainer-0136.md) | Changed | Party, Script references |
| [Bird Keeper Vance](../trainers/trainer-0137.md) | Changed | Party |
| [Pokémon Trainer Cheryl](../trainers/trainer-0138.md) | Changed | Name, Class Id, Class Name, Party |
| [Picnicker Debra](../trainers/trainer-0139.md) | Changed | Party |
| [Bug Catcher Doug](../trainers/trainer-0140.md) | Changed | Party |
| [Pokémon Trainer Marley](../trainers/trainer-0141.md) | Changed | Name, Class Id, Class Name, Party |
| [Picnicker Gina](../trainers/trainer-0142.md) | Changed | Party |
| [Hiker Erik](../trainers/trainer-0143.md) | Changed | Party |
| [Hiker Michael](../trainers/trainer-0144.md) | Changed | Party |
| [Hiker Parry](../trainers/trainer-0145.md) | Changed | Party |
| [Hiker Timothy](../trainers/trainer-0146.md) | Changed | Party |
| [Camper Ted](../trainers/trainer-0147.md) | Changed | Party |
| [Camper Lloyd](../trainers/trainer-0148.md) | Changed | Party |
| [Camper Dean](../trainers/trainer-0149.md) | Changed | Party |
| [Camper Sid](../trainers/trainer-0150.md) | Changed | Party |
| [Picnicker Erin](../trainers/trainer-0151.md) | Changed | Party |
| [Picnicker Hope](../trainers/trainer-0152.md) | Changed | Party |
| [Picnicker Sharon](../trainers/trainer-0153.md) | Changed | Party |
| [Hiker Bailey](../trainers/trainer-0154.md) | Changed | Party |
| [Hiker Anthony](../trainers/trainer-0155.md) | Changed | Party |
| [Black Belt Yoshi](../trainers/trainer-0156.md) | Changed | Party |
| [Black Belt Lao](../trainers/trainer-0157.md) | Changed | Party |
| [Black Belt Kiyo](../trainers/trainer-0158.md) | Changed | Party, Script references |
| [Black Belt Lung](../trainers/trainer-0159.md) | Changed | Party |
| [Kimono Girl Naoko](../trainers/trainer-0160.md) | Changed | Party, Script references |
| [Kimono Girl Sayo](../trainers/trainer-0161.md) | Changed | Party, Script references |
| [Kimono Girl Zuki](../trainers/trainer-0162.md) | Changed | Party, Script references |
| [Kimono Girl Kuni](../trainers/trainer-0163.md) | Changed | Party, Script references |
| [Kimono Girl Miki](../trainers/trainer-0164.md) | Changed | Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0165.md) | Changed | Name, Class Id, Class Name, Party |
| [Team Rocket Grunt](../trainers/trainer-0166.md) | Changed | Name, Class Id, Class Name, Party |
| [Team Rocket Grunt](../trainers/trainer-0167.md) | Changed | Name, Class Id, Class Name, Party |
| [Team Rocket Grunt](../trainers/trainer-0168.md) | Changed | Name, Class Id, Class Name, Party |
| [Team Rocket Grunt](../trainers/trainer-0169.md) | Changed | Name, Class Id, Class Name, Party |
| [Executive Archer](../trainers/trainer-0170.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Executive Petrel](../trainers/trainer-0171.md) | Changed | Name, Class Id, Class Name, AI flags, Party, Script references |
| [Poké Maniac Brent](../trainers/trainer-0172.md) | Changed | Party |
| [Poké Maniac Brent](../trainers/trainer-0173.md) | Changed | Party |
| [Pokémon Trainer Riley](../trainers/trainer-0174.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Medium Bethany](../trainers/trainer-0175.md) | Changed | Party |
| [Medium Margaret](../trainers/trainer-0176.md) | Changed | Party |
| [Medium Ethel](../trainers/trainer-0177.md) | Changed | Party |
| [School Kid Jack](../trainers/trainer-0178.md) | Changed | Party |
| [School Kid Kipp](../trainers/trainer-0179.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0180.md) | Changed | Party |
| [Pokéfan William](../trainers/trainer-0181.md) | Changed | Party |
| [Pokéfan Beverly](../trainers/trainer-0182.md) | Changed | Party |
| [Lass Alice](../trainers/trainer-0183.md) | Changed | Party, Script references |
| [Lass Krise](../trainers/trainer-0184.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0185.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0186.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0187.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0188.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0189.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0190.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0191.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0192.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0193.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0194.md) | Changed | Name, Class Id, AI flags, Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0195.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0196.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0197.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0198.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0199.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0200.md) | Changed | Party |
| [Poké Maniac Andrew](../trainers/trainer-0201.md) | Changed | Party |
| [Poké Maniac Calvin](../trainers/trainer-0202.md) | Changed | Party |
| [Hiker Phillip](../trainers/trainer-0203.md) | Changed | Party |
| [Hiker Leonard](../trainers/trainer-0204.md) | Changed | Party |
| [Ace Trainer Nick](../trainers/trainer-0205.md) | Changed | Party |
| [Ace Trainer Gwen](../trainers/trainer-0206.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0207.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0208.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Beauty Cassie](../trainers/trainer-0209.md) | Changed | Party |
| [Beauty Caroline](../trainers/trainer-0210.md) | Changed | Party |
| [Sailor Huey](../trainers/trainer-0211.md) | Changed | Party |
| [Sailor Terrell](../trainers/trainer-0212.md) | Changed | Party |
| [Sailor Kent](../trainers/trainer-0213.md) | Changed | Party |
| [Sailor Roberto](../trainers/trainer-0214.md) | Changed | Party |
| [Lass Connie](../trainers/trainer-0215.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0216.md) | Changed | Party |
| [Bird Keeper Denis](../trainers/trainer-0217.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0218.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0219.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0220.md) | Changed | Party |
| [Team Rocket Mickey](../trainers/trainer-0221.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0222.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0223.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0224.md) | Changed | Party |
| [Kimono Girl Izumi](../trainers/trainer-0225.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Kimono Girl Misa](../trainers/trainer-0226.md) | Changed | Name, Class Id, Class Name, Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0227.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0228.md) | Changed | Party |
| [Team Rocket Mickey](../trainers/trainer-0229.md) | Changed | Class Id, Party |
| [Psychic Franklin](../trainers/trainer-0230.md) | Changed | Party |
| [Gentleman Edward](../trainers/trainer-0231.md) | Changed | Party |
| [Guitarist Vincent](../trainers/trainer-0232.md) | Changed | Party |
| [Super Nerd Eric](../trainers/trainer-0233.md) | Changed | Party |
| [Hiker Eoin](../trainers/trainer-0234.md) | Changed | Party |
| [Hiker Noland](../trainers/trainer-0235.md) | Changed | Party |
| [Ace Trainer Shaye](../trainers/trainer-0236.md) | Changed | Party |
| [Ace Trainer Carol](../trainers/trainer-0237.md) | Changed | Party |
| [Sailor Stanly](../trainers/trainer-0238.md) | Changed | Party, Script references |
| [Sailor Jeff](../trainers/trainer-0239.md) | Changed | Party |
| [Sailor Garrett](../trainers/trainer-0240.md) | Changed | Party |
| [Sailor Kenneth](../trainers/trainer-0241.md) | Changed | Party |
| [Juggler Fritz](../trainers/trainer-0242.md) | Changed | Party |
| [Swimmer♀ Katie](../trainers/trainer-0243.md) | Changed | Party |
| [Champion Lance](../trainers/trainer-0244.md) | Changed | Party, Script references |
| [Elite Four Will](../trainers/trainer-0245.md) | Changed | Party, Script references |
| [Elite Four Karen](../trainers/trainer-0246.md) | Changed | Party, Script references |
| [Elite Four Koga](../trainers/trainer-0247.md) | Changed | Party, Script references |
| [Bug Catcher Ed](../trainers/trainer-0248.md) | Changed | Party |
| [Idol Carly](../trainers/trainer-0249.md) | Changed | Name, Class Id, Class Name, Party, Locations |
| [Black Belt Kenji](../trainers/trainer-0250.md) | Changed | Party |
| [Black Belt Nob](../trainers/trainer-0251.md) | Changed | Party |
| [Swimmer♂ Harold](../trainers/trainer-0252.md) | Changed | Party |
| [Leader Brock](../trainers/trainer-0253.md) | Changed | Party, Script references |
| [Leader Misty](../trainers/trainer-0254.md) | Changed | Party, Script references |
| [Leader Lt. Surge](../trainers/trainer-0255.md) | Changed | Party, Script references |
| [Leader Erika](../trainers/trainer-0256.md) | Changed | Party, Script references |
| [Leader Janine](../trainers/trainer-0257.md) | Changed | Party, Script references |
| [Leader Sabrina](../trainers/trainer-0258.md) | Changed | Party, Script references |
| [Leader Blaine](../trainers/trainer-0259.md) | Changed | Party, Script references |
| [Pokémon Trainer Red](../trainers/trainer-0260.md) | Changed | Party, Script references |
| [Leader Blue](../trainers/trainer-0261.md) | Changed | Party, Script references |
| [Team Rocket Mickey](../trainers/trainer-0262.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0263.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0264.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0266.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0267.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0268.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0269.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0270.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0271.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0272.md) | Changed | Party, Script references |
| [Swimmer♂ Mickey](../trainers/trainer-0273.md) | Changed | Party |
| [Camper Todd](../trainers/trainer-0274.md) | Changed | Party |
| [Camper Todd](../trainers/trainer-0275.md) | Changed | Party |
| [Picnicker Liz](../trainers/trainer-0276.md) | Changed | Party |
| [Picnicker Liz](../trainers/trainer-0277.md) | Changed | Party |
| [Black Belt Kenji](../trainers/trainer-0278.md) | Changed | Party |
| [Youngster Joey](../trainers/trainer-0279.md) | Changed | Party |
| [Youngster Joey](../trainers/trainer-0280.md) | Changed | Party |
| [Firebreather Richard](../trainers/trainer-0281.md) | Changed | Party |
| [Firebreather Ned](../trainers/trainer-0282.md) | Changed | Party |
| [Burglar Orson](../trainers/trainer-0283.md) | Changed | Party |
| [Burglar Corey](../trainers/trainer-0284.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0285.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0286.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0287.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0288.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0289.md) | Changed | Party |
| [Elder Li](../trainers/trainer-0290.md) | Changed | Party, Script references |
| [Swimmer♀ Debbie](../trainers/trainer-0291.md) | Changed | Party |
| [Swimmer♀ Mickey](../trainers/trainer-0292.md) | Changed | Party |
| [Swimmer♀ Nicole](../trainers/trainer-0293.md) | Changed | Party |
| [Swimmer♀ Lori](../trainers/trainer-0294.md) | Changed | Party |
| [Swimmer♀ Mickey](../trainers/trainer-0295.md) | Changed | Party |
| [Swimmer♀ Nikki](../trainers/trainer-0296.md) | Changed | Party |
| [Swimmer♀ Diana](../trainers/trainer-0297.md) | Changed | Party |
| [Swimmer♀ Briana](../trainers/trainer-0298.md) | Changed | Party |
| [Bird Keeper Hank](../trainers/trainer-0299.md) | Changed | Party |
| [Bird Keeper Roy](../trainers/trainer-0300.md) | Changed | Party |
| [Bird Keeper Boris](../trainers/trainer-0301.md) | Changed | Party |
| [Bird Keeper Bob](../trainers/trainer-0302.md) | Changed | Party |
| [Bird Keeper Jose](../trainers/trainer-0303.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0304.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0305.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0306.md) | Changed | Party |
| [Camper Mickey](../trainers/trainer-0307.md) | Changed | Party |
| [Camper Jerry](../trainers/trainer-0308.md) | Changed | Party |
| [Biker Dwayne](../trainers/trainer-0309.md) | Changed | Party |
| [Biker Harris](../trainers/trainer-0310.md) | Changed | Party |
| [Biker Zeke](../trainers/trainer-0311.md) | Changed | Party |
| [Biker Charles](../trainers/trainer-0312.md) | Changed | Party |
| [Biker Reese](../trainers/trainer-0313.md) | Changed | Party |
| [Biker Joel](../trainers/trainer-0314.md) | Changed | Party |
| [Biker Glenn](../trainers/trainer-0315.md) | Changed | Party |
| [Psychic Herman](../trainers/trainer-0316.md) | Changed | Party |
| [Psychic Fidel](../trainers/trainer-0317.md) | Changed | Party |
| [Firebreather Burt](../trainers/trainer-0318.md) | Changed | Party |
| [Firebreather Bill](../trainers/trainer-0319.md) | Changed | Party |
| [Fisherman Martin](../trainers/trainer-0320.md) | Changed | Party |
| [Fisherman Stephen](../trainers/trainer-0321.md) | Changed | Party |
| [Fisherman Barney](../trainers/trainer-0322.md) | Changed | Party |
| [Fisherman Tully](../trainers/trainer-0323.md) | Changed | Party |
| [Fisherman Tully](../trainers/trainer-0324.md) | Changed | Party |
| [Fisherman Wilton](../trainers/trainer-0325.md) | Changed | Party |
| [Twins Jo&Zoe](../trainers/trainer-0326.md) | Changed | Name, Party |
| [School Kid Danny](../trainers/trainer-0327.md) | Changed | Party |
| [School Kid Tommy](../trainers/trainer-0328.md) | Changed | Party |
| [School Kid Dudley](../trainers/trainer-0329.md) | Changed | Party |
| [School Kid Joe](../trainers/trainer-0330.md) | Changed | Party |
| [School Kid Billy](../trainers/trainer-0331.md) | Changed | Party |
| [Picnicker Heidi](../trainers/trainer-0332.md) | Changed | Party |
| [Picnicker Edna](../trainers/trainer-0333.md) | Changed | Party |
| [Picnicker Gina](../trainers/trainer-0334.md) | Changed | Party |
| [Picnicker Erin](../trainers/trainer-0335.md) | Changed | Party |
| [Picnicker Tanya](../trainers/trainer-0336.md) | Changed | Party |
| [Gentleman Gregory](../trainers/trainer-0337.md) | Changed | Party |
| [Gentleman Mickey](../trainers/trainer-0338.md) | Changed | Party |
| [Black Belt Wai](../trainers/trainer-0339.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0340.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0341.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0342.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0343.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0344.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0345.md) | Changed | Party |
| [Beauty Julia](../trainers/trainer-0346.md) | Changed | Party |
| [Beauty Mickey](../trainers/trainer-0347.md) | Changed | Party |
| [Pokéfan Robert](../trainers/trainer-0348.md) | Changed | Party |
| [Pokéfan Joshua](../trainers/trainer-0349.md) | Changed | Party |
| [Pokéfan Carter](../trainers/trainer-0350.md) | Changed | Party |
| [Pokéfan Trevor](../trainers/trainer-0351.md) | Changed | Party |
| [Pokéfan Georgia](../trainers/trainer-0352.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0353.md) | Changed | Party |
| [Lass Laura](../trainers/trainer-0354.md) | Changed | Party |
| [Lass Shannon](../trainers/trainer-0355.md) | Changed | Party |
| [Lass Michelle](../trainers/trainer-0356.md) | Changed | Party |
| [Hiker Clarke](../trainers/trainer-0357.md) | Changed | Party |
| [Hiker Kenny](../trainers/trainer-0358.md) | Changed | Party |
| [Hiker Jim](../trainers/trainer-0359.md) | Changed | Party |
| [Bug Catcher Arnie](../trainers/trainer-0360.md) | Changed | Party |
| [Ace Trainer Kevin](../trainers/trainer-0361.md) | Changed | Party, Script references |
| [Ace Trainer Quinn](../trainers/trainer-0362.md) | Changed | Party |
| [Ace Trainer Emma](../trainers/trainer-0363.md) | Changed | Party |
| [Super Nerd Sam](../trainers/trainer-0364.md) | Changed | Party |
| [Super Nerd Tyrone](../trainers/trainer-0365.md) | Changed | Party |
| [Super Nerd Pat](../trainers/trainer-0366.md) | Changed | Party |
| [Super Nerd Shawn](../trainers/trainer-0367.md) | Changed | Party |
| [Medium Rebecca](../trainers/trainer-0368.md) | Changed | Party |
| [Medium Darcy](../trainers/trainer-0369.md) | Changed | Party |
| [Swimmer♂ Jerome](../trainers/trainer-0370.md) | Changed | Party |
| [Swimmer♂ Tucker](../trainers/trainer-0371.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0372.md) | Changed | Party |
| [Swimmer♂ Frankie](../trainers/trainer-0373.md) | Changed | Party |
| [Swimmer♂ Tyson](../trainers/trainer-0374.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0375.md) | Changed | Party |
| [Swimmer♂ Mickey](../trainers/trainer-0376.md) | Changed | Party |
| [Swimmer♂ Parker](../trainers/trainer-0377.md) | Changed | Party |
| [Youngster Warren](../trainers/trainer-0378.md) | Changed | Party |
| [Youngster Jimmy](../trainers/trainer-0379.md) | Changed | Party |
| [Youngster Owen](../trainers/trainer-0380.md) | Changed | Party |
| [Youngster Jason](../trainers/trainer-0381.md) | Changed | Party |
| [Teacher Hillary](../trainers/trainer-0382.md) | Changed | Party |
| [Ace Trainer Peter](../trainers/trainer-0383.md) | Changed | Class Id, Class Name, Party, Locations |
| [Hiker Daniel](../trainers/trainer-0384.md) | Changed | Party |
| [Twins Dara nd Dia](../trainers/trainer-0385.md) | Changed | Name, Party |
| [Psychic Greg](../trainers/trainer-0386.md) | Changed | Party |
| [Twins Amy nd Mimi](../trainers/trainer-0387.md) | Changed | Name, Party |
| [Firebreather Walt](../trainers/trainer-0388.md) | Changed | Party |
| [Cowgirl Tay-Tay](../trainers/trainer-0389.md) | Changed | Name, Class Id, Class Name, Party |
| [Firebreather Ray](../trainers/trainer-0390.md) | Changed | Party |
| [Poké Maniac Issac](../trainers/trainer-0391.md) | Changed | Party |
| [Poké Maniac Donald](../trainers/trainer-0392.md) | Changed | Party |
| [Super Nerd Teru](../trainers/trainer-0393.md) | Changed | Party |
| [Ace Trainer Mickey](../trainers/trainer-0394.md) | Changed | Party |
| [Psychic Mark](../trainers/trainer-0395.md) | Changed | Party |
| [Juggler Horton](../trainers/trainer-0396.md) | Changed | Party |
| [School Kid Chad](../trainers/trainer-0397.md) | Changed | Party |
| [Beauty Valerie](../trainers/trainer-0398.md) | Changed | Party |
| [Firebreather Lyle](../trainers/trainer-0399.md) | Changed | Party |
| [Lass Dana](../trainers/trainer-0400.md) | Changed | Party |
| [Gentleman Alfred](../trainers/trainer-0401.md) | Changed | Party |
| [Picnicker Tiffany](../trainers/trainer-0402.md) | Changed | Party |
| [Camper Spencer](../trainers/trainer-0403.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0404.md) | Changed | Party |
| [Psychic Phil](../trainers/trainer-0405.md) | Changed | Party |
| [Poké Maniac Zach](../trainers/trainer-0406.md) | Changed | Party |
| [Ace Trainer Allen](../trainers/trainer-0407.md) | Changed | Party |
| [Ace Trainer Cybil](../trainers/trainer-0408.md) | Changed | Party |
| [Socialite Brandon](../trainers/trainer-0409.md) | Changed | Class Id, Class Name, Party, Locations |
| [Sailor Harry](../trainers/trainer-0410.md) | Changed | Party |
| [Psychic Vernon](../trainers/trainer-0411.md) | Changed | Party |
| [Psychic Eli](../trainers/trainer-0412.md) | Changed | Party |
| [Fisherman Scott](../trainers/trainer-0413.md) | Changed | Party |
| [Bird Keeper Jose](../trainers/trainer-0414.md) | Changed | Party |
| [Psychic Jared](../trainers/trainer-0415.md) | Changed | Party |
| [Twins Jo&Zoe](../trainers/trainer-0416.md) | Changed | Name, Party |
| [Ace Trainer Jenn](../trainers/trainer-0417.md) | Changed | Party, Script references |
| [Elite Four Bruno](../trainers/trainer-0418.md) | Changed | Party, Script references |
| [Lass Ellen](../trainers/trainer-0419.md) | Changed | Party |
| [Bird Keeper Perry](../trainers/trainer-0420.md) | Changed | Party |
| [Bird Keeper Bret](../trainers/trainer-0421.md) | Changed | Party |
| [Psychic Rodney](../trainers/trainer-0422.md) | Changed | Party |
| [Pokéfan Jeremy](../trainers/trainer-0423.md) | Changed | Party |
| [Pokéfan Colin](../trainers/trainer-0424.md) | Changed | Party |
| [Twins Meg&Peg](../trainers/trainer-0425.md) | Changed | Name, Party |
| [Twins Meg nd Peg](../trainers/trainer-0426.md) | Changed | Name |
| [Teacher Shirley](../trainers/trainer-0427.md) | Changed | Party |
| [School Kid Nate](../trainers/trainer-0428.md) | Changed | Party |
| [School Kid Ricky](../trainers/trainer-0429.md) | Changed | Party |
| [School Kid Jack](../trainers/trainer-0430.md) | Changed | Party |
| [School Kid Jack](../trainers/trainer-0431.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0432.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0433.md) | Changed | Party |
| [School Kid Chad](../trainers/trainer-0434.md) | Changed | Party |
| [School Kid Chad](../trainers/trainer-0435.md) | Changed | Party |
| [Pokéfan Beverly](../trainers/trainer-0436.md) | Changed | Party |
| [Pokéfan Beverly](../trainers/trainer-0437.md) | Changed | Party |
| [Pokéfan Derek](../trainers/trainer-0438.md) | Changed | Party |
| [Pokéfan Derek](../trainers/trainer-0439.md) | Changed | Party |
| [Sailor Huey](../trainers/trainer-0440.md) | Changed | Party |
| [Sailor Huey](../trainers/trainer-0441.md) | Changed | Party |
| [Lass Mickey](../trainers/trainer-0442.md) | Changed | Party |
| [Lass Mickey](../trainers/trainer-0443.md) | Changed | Party |
| [Ace Trainer Reena](../trainers/trainer-0444.md) | Changed | Party |
| [Ace Trainer Reena](../trainers/trainer-0445.md) | Changed | Party |
| [Bird Keeper Jose](../trainers/trainer-0446.md) | Changed | Party |
| [Bird Keeper Vance](../trainers/trainer-0447.md) | Changed | Party |
| [Bird Keeper Vance](../trainers/trainer-0448.md) | Changed | Party |
| [Bug Catcher Arnie](../trainers/trainer-0449.md) | Changed | Party |
| [Fisherman Wilton](../trainers/trainer-0450.md) | Changed | Party |
| [Hiker Parry](../trainers/trainer-0451.md) | Changed | Party |
| [Hiker Parry](../trainers/trainer-0452.md) | Changed | Party |
| [Picnicker Erin](../trainers/trainer-0453.md) | Changed | Party |
| [Juggler Irwin](../trainers/trainer-0454.md) | Changed | Party |
| [Juggler Irwin](../trainers/trainer-0455.md) | Changed | Party |
| [Ace Trainer Gaven](../trainers/trainer-0456.md) | Changed | Party |
| [Ace Trainer Gaven](../trainers/trainer-0457.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0458.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0459.md) | Changed | Party |
| [Bug Catcher Wade](../trainers/trainer-0460.md) | Changed | Party |
| [Bug Catcher Wade](../trainers/trainer-0461.md) | Changed | Party |
| [Fisherman Ralph](../trainers/trainer-0462.md) | Changed | Party |
| [Fisherman Ralph](../trainers/trainer-0463.md) | Changed | Party |
| [Lass Dana](../trainers/trainer-0464.md) | Changed | Party |
| [Lass Dana](../trainers/trainer-0465.md) | Changed | Party |
| [Picnicker Tiffany](../trainers/trainer-0466.md) | Changed | Party |
| [Picnicker Tiffany](../trainers/trainer-0467.md) | Changed | Party |
| [Scientist Ross](../trainers/trainer-0468.md) | Changed | Party |
| [Scientist Mitch](../trainers/trainer-0469.md) | Changed | Party |
| [Scientist Gregg](../trainers/trainer-0470.md) | Changed | Party, Script references |
| [Scientist Garett](../trainers/trainer-0471.md) | Changed | Party |
| [Scientist Trenton](../trainers/trainer-0472.md) | Changed | Party |
| [Executive Proton](../trainers/trainer-0473.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Executive Petrel](../trainers/trainer-0474.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Executive Ariana](../trainers/trainer-0475.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Executive Archer](../trainers/trainer-0476.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Rocket Boss Giovanni](../trainers/trainer-0477.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Executive Ariana](../trainers/trainer-0478.md) | Changed | AI battle items, Party |
| [Executive Ariana](../trainers/trainer-0479.md) | Changed | Party |
| [Skier Diana](../trainers/trainer-0480.md) | Changed | Party |
| [Skier Jill](../trainers/trainer-0481.md) | Changed | Party |
| [Boarder Deandre](../trainers/trainer-0482.md) | Changed | Party |
| [Boarder Patton](../trainers/trainer-0483.md) | Changed | Party |
| [Boarder Gerardo](../trainers/trainer-0484.md) | Changed | Party |
| [Executive Archer](../trainers/trainer-0485.md) | Changed | AI battle items, Party |
| [Executive Proton](../trainers/trainer-0486.md) | Changed | Party, Script references |
| [Executive Petrel](../trainers/trainer-0487.md) | Changed | AI battle items, Party |
| [Executive Petrel](../trainers/trainer-0488.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0489.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0490.md) | Changed | Party, Script references |
| [Rival Silver](../trainers/trainer-0491.md) | Changed | Party, Script references |
| [Pokéfan Alex](../trainers/trainer-0492.md) | Changed | Party |
| [Medium Edith](../trainers/trainer-0493.md) | Changed | Party |
| [Medium Georgina](../trainers/trainer-0494.md) | Changed | Party |
| [Passerby Boy](../trainers/trainer-0495.md) | Changed | Script references |
| [Passerby Boy](../trainers/trainer-0496.md) | Changed | Script references |
| [Passerby Boy](../trainers/trainer-0497.md) | Changed | Script references |
| [Mystery Man Eusine](../trainers/trainer-0498.md) | Changed | Party, Script references |
| [Team Rocket Grunt](../trainers/trainer-0499.md) | Changed | Party |
| [Ace Trainer Kobe](../trainers/trainer-0500.md) | Changed | Party |
| [Ace Trainer Piper](../trainers/trainer-0501.md) | Changed | Party |
| [Twins Clea&Gil](../trainers/trainer-0502.md) | Changed | Name, Party |
| [School Kid Jack](../trainers/trainer-0503.md) | Changed | Party |
| [School Kid Mickey](../trainers/trainer-0504.md) | Changed | Party |
| [School Kid Alan](../trainers/trainer-0505.md) | Changed | Party |
| [School Kid Mickey](../trainers/trainer-0506.md) | Changed | Party |
| [School Kid Chad](../trainers/trainer-0507.md) | Changed | Party |
| [Sailor Huey](../trainers/trainer-0509.md) | Changed | Party |
| [Youngster Joey](../trainers/trainer-0510.md) | Changed | Party |
| [Rival ………](../trainers/trainer-0511.md) | Changed | Name, Class Id, Class Name, AI flags, Party, Script references |
| [Bug Catcher Wade](../trainers/trainer-0512.md) | Changed | Party |
| [Bug Catcher Arnie](../trainers/trainer-0513.md) | Changed | Party |
| [Bug Catcher Mickey](../trainers/trainer-0514.md) | Changed | Party |
| [Fisherman Ralph](../trainers/trainer-0515.md) | Changed | Party |
| [Fisherman Mickey](../trainers/trainer-0516.md) | Changed | Party |
| [Fisherman Tully](../trainers/trainer-0517.md) | Changed | Party |
| [Picnicker Liz](../trainers/trainer-0518.md) | Changed | Party |
| [Picnicker Mickey](../trainers/trainer-0519.md) | Changed | Party |
| [Picnicker Gina](../trainers/trainer-0520.md) | Changed | Party |
| [Champion Steven](../trainers/trainer-0521.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Picnicker Tiffany](../trainers/trainer-0522.md) | Changed | Party |
| [Hiker Anthony](../trainers/trainer-0523.md) | Changed | Party |
| [Camper Todd](../trainers/trainer-0525.md) | Changed | Party |
| [Champion Cynthia](../trainers/trainer-0526.md) | Changed | Name, Class Id, Class Name, AI battle items, Party, Script references |
| [Juggler Irwin](../trainers/trainer-0527.md) | Changed | Party |
| [Lass Dana](../trainers/trainer-0528.md) | Changed | Party |
| [Mystery Man Eusine](../trainers/trainer-0529.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Poké Maniac Brent](../trainers/trainer-0530.md) | Changed | Party |
| [Pokémon Trainer Ethan](../trainers/trainer-0531.md) | Changed | Name, Class Id, Class Name, Battle type, Double Battle, AI flags, AI battle items, Party, Script references |
| [Pokémon Trainer Lyra](../trainers/trainer-0532.md) | Changed | Name, Class Id, Class Name, AI flags, AI battle items, Party, Script references |
| [Bug Catcher Wayne](../trainers/trainer-0533.md) | Changed | Party |
| [Beauty Kimberly](../trainers/trainer-0534.md) | Changed | Party |
| [Camper Bertrand](../trainers/trainer-0536.md) | Changed | Party |
| [Poké Maniac Harrison](../trainers/trainer-0537.md) | Changed | Party |
| [Super Nerd Hugh](../trainers/trainer-0538.md) | Changed | Party |
| [Super Nerd Markus](../trainers/trainer-0539.md) | Changed | Party |
| [Sage Mickey](../trainers/trainer-0542.md) | Changed | Party |
| [Sage Mickey](../trainers/trainer-0543.md) | Changed | Party |
| [Sage Mickey](../trainers/trainer-0544.md) | Changed | Party |
| [Ace Trainer French](../trainers/trainer-0545.md) | Changed | Party |
| [School Kid Sherman](../trainers/trainer-0546.md) | Changed | Party |
| [Hiker Bruce](../trainers/trainer-0547.md) | Changed | Party |
| [Black Belt Manford](../trainers/trainer-0548.md) | Changed | Party |
| [Double Team Zac&Jen](../trainers/trainer-0549.md) | Changed | Name, Party |
| [Black Belt Ander](../trainers/trainer-0550.md) | Changed | Party |
| [Hiker Dwight](../trainers/trainer-0551.md) | Changed | Party |
| [Youngster Regis](../trainers/trainer-0552.md) | Changed | Party |
| [Young Couple Moe nd Lulu](../trainers/trainer-0553.md) | Changed | Name, Party |
| [Gentleman Milton](../trainers/trainer-0554.md) | Changed | Party |
| [Bird Keeper Justin](../trainers/trainer-0555.md) | Changed | Party |
| [Bird Keeper Gail](../trainers/trainer-0556.md) | Changed | Party |
| [Young Couple Vic&Tara](../trainers/trainer-0557.md) | Changed | Name, Party |
| [Fisherman Kyler](../trainers/trainer-0558.md) | Changed | Party |
| [Young Couple Tim&Sue](../trainers/trainer-0559.md) | Changed | Name, Party |
| [Camper Clark](../trainers/trainer-0560.md) | Changed | Party |
| [Camper Tanner](../trainers/trainer-0561.md) | Changed | Party |
| [Picnicker Piper](../trainers/trainer-0562.md) | Changed | Party |
| [Picnicker Ginger](../trainers/trainer-0563.md) | Changed | Party |
| [Teacher Clarice](../trainers/trainer-0564.md) | Changed | Party |
| [Bird Keeper Josh](../trainers/trainer-0565.md) | Changed | Party |
| [School Kid Connor](../trainers/trainer-0566.md) | Changed | Party |
| [School Kid Torin](../trainers/trainer-0567.md) | Changed | Party |
| [School Kid Travis](../trainers/trainer-0568.md) | Changed | Party |
| [Twins Kay&Tia](../trainers/trainer-0569.md) | Changed | Name, Party |
| [Pokéfan Boone](../trainers/trainer-0570.md) | Changed | Party |
| [Pokéfan Eleanor](../trainers/trainer-0571.md) | Changed | Party |
| [Biker Dale](../trainers/trainer-0572.md) | Changed | Party |
| [Biker Jacob](../trainers/trainer-0573.md) | Changed | Party |
| [Biker Aiden](../trainers/trainer-0574.md) | Changed | Party |
| [Biker Dan](../trainers/trainer-0575.md) | Changed | Party |
| [Biker Theron](../trainers/trainer-0576.md) | Changed | Party |
| [Biker Markey](../trainers/trainer-0577.md) | Changed | Party |
| [Biker Teddy](../trainers/trainer-0578.md) | Changed | Party |
| [Biker Ernest](../trainers/trainer-0579.md) | Changed | Party |
| [Camper Pedro](../trainers/trainer-0580.md) | Changed | Party |
| [Picnicker Adrian](../trainers/trainer-0581.md) | Changed | Party |
| [Picnicker Cheyenne](../trainers/trainer-0582.md) | Changed | Party |
| [Bird Keeper Bert](../trainers/trainer-0583.md) | Changed | Party |
| [Bird Keeper Ernie](../trainers/trainer-0584.md) | Changed | Party |
| [Swimmer♂ Elmo](../trainers/trainer-0585.md) | Changed | Party |
| [Swimmer♂ Luis](../trainers/trainer-0586.md) | Changed | Party |
| [Swimmer♀ Leona](../trainers/trainer-0587.md) | Changed | Party |
| [Swimmer♀ Mina](../trainers/trainer-0588.md) | Changed | Party |
| [Fisherman Murphy](../trainers/trainer-0589.md) | Changed | Party |
| [Fisherman Liam](../trainers/trainer-0590.md) | Changed | Party |
| [Fisherman Gideon](../trainers/trainer-0591.md) | Changed | Party |
| [Swimmer♀ Chelan](../trainers/trainer-0592.md) | Changed | Party |
| [Swimmer♀ Kendra](../trainers/trainer-0593.md) | Changed | Party |
| [Swimmer♂ Esteban](../trainers/trainer-0594.md) | Changed | Party |
| [Swimmer♂ Duane](../trainers/trainer-0595.md) | Changed | Party |
| [Bird Keeper Kinsley](../trainers/trainer-0596.md) | Changed | Party |
| [Bird Keeper Easton](../trainers/trainer-0597.md) | Changed | Party |
| [Twins Day&Dani](../trainers/trainer-0598.md) | Changed | Name, Party |
| [Camper Virgil](../trainers/trainer-0599.md) | Changed | Party |
| [Picnicker Selina](../trainers/trainer-0600.md) | Changed | Party |
| [Team Rocket Grunt](../trainers/trainer-0601.md) | Changed | Party, Script references |
| [Bird Keeper Jose](../trainers/trainer-0602.md) | Changed | Party |
| [Picnicker Erin](../trainers/trainer-0603.md) | Changed | Party |
| [Ace Trainer Gaven](../trainers/trainer-0604.md) | Changed | Party |
| [Black Belt Kenji](../trainers/trainer-0605.md) | Changed | Party |
| [Hiker Parry](../trainers/trainer-0606.md) | Changed | Party |
| [Ace Trainer Reena](../trainers/trainer-0607.md) | Changed | Party |
| [Fisherman Wilton](../trainers/trainer-0608.md) | Changed | Party |
| [Ace Trainer Jamie](../trainers/trainer-0609.md) | Changed | Party |
| [Pokéfan Derek](../trainers/trainer-0610.md) | Changed | Party |
| [Pokéfan Beverly](../trainers/trainer-0611.md) | Changed | Party |
| [Bird Keeper Vance](../trainers/trainer-0612.md) | Changed | Party |
| [Lass Krise](../trainers/trainer-0613.md) | Changed | Party |
| [Lass Krise](../trainers/trainer-0614.md) | Changed | Party |
| [Lass Krise](../trainers/trainer-0615.md) | Changed | Party |
| [Youngster Ian](../trainers/trainer-0616.md) | Changed | Party |
| [Youngster Ian](../trainers/trainer-0617.md) | Changed | Party |
| [Youngster Ian](../trainers/trainer-0618.md) | Changed | Party |
| [Firebreather Walt](../trainers/trainer-0619.md) | Changed | Party |
| [Firebreather Walt](../trainers/trainer-0620.md) | Changed | Party |
| [Firebreather Walt](../trainers/trainer-0621.md) | Changed | Party |
| [Bug Catcher Doug](../trainers/trainer-0622.md) | Changed | Party |
| [Bug Catcher Doug](../trainers/trainer-0623.md) | Changed | Party |
| [Bug Catcher Doug](../trainers/trainer-0624.md) | Changed | Party |
| [Bug Catcher Rob](../trainers/trainer-0625.md) | Changed | Party |
| [Bug Catcher Rob](../trainers/trainer-0626.md) | Changed | Party |
| [Bug Catcher Rob](../trainers/trainer-0627.md) | Changed | Party |
| [Biker Reese](../trainers/trainer-0628.md) | Changed | Party |
| [Biker Reese](../trainers/trainer-0629.md) | Changed | Party |
| [Biker Reese](../trainers/trainer-0630.md) | Changed | Party |
| [Biker Aiden](../trainers/trainer-0631.md) | Changed | Party |
| [Biker Aiden](../trainers/trainer-0632.md) | Changed | Party |
| [Biker Aiden](../trainers/trainer-0633.md) | Changed | Party |
| [Biker Ernest](../trainers/trainer-0634.md) | Changed | Party |
| [Biker Ernest](../trainers/trainer-0635.md) | Changed | Party |
| [Biker Ernest](../trainers/trainer-0636.md) | Changed | Party |
| [Teacher Hillary](../trainers/trainer-0637.md) | Changed | Party |
| [Teacher Hillary](../trainers/trainer-0638.md) | Changed | Party |
| [Teacher Hillary](../trainers/trainer-0639.md) | Changed | Party |
| [School Kid Billy](../trainers/trainer-0640.md) | Changed | Party |
| [School Kid Billy](../trainers/trainer-0641.md) | Changed | Party |
| [School Kid Billy](../trainers/trainer-0642.md) | Changed | Party |
| [Twins Kay&Tia](../trainers/trainer-0643.md) | Changed | Name, Party |
| [Twins Kay&Tia](../trainers/trainer-0644.md) | Changed | Name, Party |
| [Twins Kay&Tia](../trainers/trainer-0645.md) | Changed | Name, Party |
| [Bird Keeper Josh](../trainers/trainer-0646.md) | Changed | Party |
| [Bird Keeper Josh](../trainers/trainer-0647.md) | Changed | Party |
| [Bird Keeper Josh](../trainers/trainer-0648.md) | Changed | Party |
| [School Kid Torin](../trainers/trainer-0649.md) | Changed | Party |
| [School Kid Torin](../trainers/trainer-0650.md) | Changed | Party |
| [School Kid Torin](../trainers/trainer-0651.md) | Changed | Party |
| [Young Couple Tim&Sue](../trainers/trainer-0652.md) | Changed | Name, Party |
| [Young Couple Tim&Sue](../trainers/trainer-0653.md) | Changed | Name, Party |
| [Young Couple Tim&Sue](../trainers/trainer-0654.md) | Changed | Name, Party |
| [Hiker Kenny](../trainers/trainer-0655.md) | Changed | Party |
| [Hiker Kenny](../trainers/trainer-0656.md) | Changed | Party |
| [Hiker Kenny](../trainers/trainer-0657.md) | Changed | Party |
| [Camper Tanner](../trainers/trainer-0658.md) | Changed | Party |
| [Camper Tanner](../trainers/trainer-0659.md) | Changed | Party |
| [Camper Tanner](../trainers/trainer-0660.md) | Changed | Party |
| [Fisherman Kyle](../trainers/trainer-0661.md) | Changed | Party |
| [Fisherman Kyle](../trainers/trainer-0662.md) | Changed | Party |
| [Fisherman Kyle](../trainers/trainer-0663.md) | Changed | Party |
| [Fisherman Kyler](../trainers/trainer-0664.md) | Changed | Party |
| [Fisherman Kyler](../trainers/trainer-0665.md) | Changed | Party |
| [Fisherman Kyler](../trainers/trainer-0666.md) | Changed | Party |
| [Pokémon Trainer Cheryl](../trainers/trainer-0667.md) | Changed | Party, Script references |
| [Pokémon Trainer Marley](../trainers/trainer-0668.md) | Changed | Party, Script references |
| [Pokémon Trainer Mira](../trainers/trainer-0669.md) | Changed | Party, Script references |
| [Pokémon Trainer Riley](../trainers/trainer-0670.md) | Changed | Party, Script references |
| [Pokémon Trainer Buck](../trainers/trainer-0671.md) | Changed | Party, Script references |
| [Gentleman Alfred](../trainers/trainer-0672.md) | Changed | Party |
| [Gentleman Alfred](../trainers/trainer-0673.md) | Changed | Party |
| [Gentleman Alfred](../trainers/trainer-0674.md) | Changed | Party |
| [Pokémon Trainer Lance](../trainers/trainer-0675.md) | Changed | Party |
| [Sailor Parker](../trainers/trainer-0676.md) | Changed | Party |
| [Sailor Eddie](../trainers/trainer-0677.md) | Changed | Party |
| [Swimmer♀ Joy](../trainers/trainer-0678.md) | Changed | Party |
| [Beauty Callie](../trainers/trainer-0679.md) | Changed | Party |
| [Parasol Lady Kassandra](../trainers/trainer-0680.md) | Changed | Class Id, Class Name, Party |
| [Ace Trainer Arabella](../trainers/trainer-0681.md) | Changed | Party |
| [Ace Trainer Bonita](../trainers/trainer-0682.md) | Changed | Party |
| [Ace Trainer Salma](../trainers/trainer-0683.md) | Changed | Party |
| [Double Team Elan&Ida](../trainers/trainer-0684.md) | Changed | Name, Party |
| [Hiker Edwin](../trainers/trainer-0685.md) | Changed | Party |
| [Boarder Bryce](../trainers/trainer-0686.md) | Changed | Party |
| [Boarder Shaun](../trainers/trainer-0687.md) | Changed | Party |
| [Skier Cady](../trainers/trainer-0688.md) | Changed | Party |
| [Super Nerd Cary](../trainers/trainer-0689.md) | Changed | Party, Script references |
| [Super Nerd Waldo](../trainers/trainer-0690.md) | Changed | Party, Script references |
| [Super Nerd Merle](../trainers/trainer-0691.md) | Changed | Party, Script references |
| [Scientist Lowell](../trainers/trainer-0692.md) | Changed | Party, Script references |
| [Scientist Linden](../trainers/trainer-0693.md) | Changed | Party, Script references |
| [Scientist Daniel](../trainers/trainer-0694.md) | Changed | Party, Script references |
| [Ace Trainer Cheria](../trainers/trainer-0695.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Ace Trainer Donnie](../trainers/trainer-0696.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Ace Trainer Richard](../trainers/trainer-0697.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Ace Trainer Eliza](../trainers/trainer-0698.md) | Changed | Name, Class Id, Class Name, AI flags, Party |
| [Ace Trainer Abner](../trainers/trainer-0699.md) | Changed | Class Id, Class Name, AI flags, Party |
| [Rocket Boss Giovanni](../trainers/trainer-0700.md) | Changed | Party, Script references |
| [Champion Lance](../trainers/trainer-0701.md) | Changed | Party, Script references |
| [Elite Four Will](../trainers/trainer-0702.md) | Changed | Party, Script references |
| [Elite Four Koga](../trainers/trainer-0703.md) | Changed | Party, Script references |
| [Elite Four Bruno](../trainers/trainer-0704.md) | Changed | Party, Script references |
| [Elite Four Karen](../trainers/trainer-0705.md) | Changed | Party, Script references |
| [Executive Proton](../trainers/trainer-0706.md) | Changed | AI battle items, Party |
| [Tower Tycoon Palmer](../trainers/trainer-0707.md) | Changed | Party |
| [Hall Matron Argenta](../trainers/trainer-0708.md) | Changed | Party |
| [Factory Head Thorton](../trainers/trainer-0709.md) | Changed | Party |
| [Arcade Star Dahlia](../trainers/trainer-0710.md) | Changed | Party |
| [Castle Valet Darach](../trainers/trainer-0711.md) | Changed | Party |
| [Leader Falkner](../trainers/trainer-0712.md) | Changed | Party, Script references |
| [Leader Bugsy](../trainers/trainer-0713.md) | Changed | Party, Script references |
| [Leader Whitney](../trainers/trainer-0714.md) | Changed | AI flags, Party, Script references |
| [Leader Morty](../trainers/trainer-0715.md) | Changed | Party, Script references |
| [Leader Pryce](../trainers/trainer-0716.md) | Changed | Party, Script references |
| [Leader Jasmine](../trainers/trainer-0717.md) | Changed | Party, Script references |
| [Leader Chuck](../trainers/trainer-0718.md) | Changed | AI flags, Party, Script references |
| [Leader Clair](../trainers/trainer-0719.md) | Changed | Party, Script references |
| [Leader Brock](../trainers/trainer-0720.md) | Changed | Party, Script references |
| [Leader Misty](../trainers/trainer-0721.md) | Changed | Party, Script references |
| [Leader Lt. Surge](../trainers/trainer-0722.md) | Changed | Party, Script references |
| [Leader Erika](../trainers/trainer-0723.md) | Changed | Party, Script references |
| [Leader Janine](../trainers/trainer-0724.md) | Changed | Party, Script references |
| [Leader Sabrina](../trainers/trainer-0725.md) | Changed | AI flags, Party, Script references |
| [Leader Blaine](../trainers/trainer-0726.md) | Changed | Party, Script references |
| [Leader Blue](../trainers/trainer-0727.md) | Changed | Party, Script references |
| [Beauty Charlotte](../trainers/trainer-0728.md) | Changed | Party, Script references |
| [Young Couple Duff&Eda](../trainers/trainer-0729.md) | Changed | Name, Party |
| [Double Team Thom&Kae](../trainers/trainer-0730.md) | Changed | Name, Party |
| [Hiker Devin](../trainers/trainer-0731.md) | Changed | Party |
| [Camper Grant](../trainers/trainer-0732.md) | Changed | Party |
| [Champion Lance](../trainers/trainer-0733.md) | Changed | Party |
| [Leader Clair](../trainers/trainer-0734.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0735.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0736.md) | Changed | Party |
| [Rival Silver](../trainers/trainer-0737.md) | Changed | Party |

## Locations

| Record | Status | Changed fields |
| ------ | ------ | -------------- |
| [Bellchime Trail](../locations/header-006.md) | Changed | Items, Script Awarded Items |
| [Burned Tower](../locations/header-007.md) | Changed | Static Encounters |
| [Route 10](../locations/header-018.md) | Changed | Static Encounters |
| [Route 11](../locations/header-019.md) | Changed | Warps, Items, Static Encounters |
| [Route 25](../locations/header-029.md) | Changed | Script Awarded Items, Static Encounters |
| [Route 27](../locations/header-031.md) | Changed | Items |
| [Route 29](../locations/header-033.md) | Changed | Script Awarded Items, Static Encounters |
| [Route 30](../locations/header-034.md) | Changed | Script Awarded Items, Pokemon Gifts |
| [Route 31](../locations/header-035.md) | Changed | Script Awarded Items |
| [Route 32](../locations/header-036.md) | Changed | Items, Script Awarded Items, Static Encounters |
| [Route 33](../locations/header-037.md) | Changed | Static Encounters |
| [Route 34](../locations/header-038.md) | Changed | Items, Script Awarded Items, Static Encounters |
| [Route 35](../locations/header-039.md) | Changed | Items, Static Encounters |
| [Route 36](../locations/header-040.md) | Changed | Script Awarded Items, Static Encounters |
| [Route 37](../locations/header-041.md) | Changed | Script Awarded Items, Static Encounters |
| [Route 38](../locations/header-042.md) | Changed | Items, Script Awarded Items, Static Encounters |
| [Route 39](../locations/header-043.md) | Changed | Items, Script Awarded Items |
| [Route 42](../locations/header-044.md) | Changed | Items, Script Awarded Items |
| [Route 44](../locations/header-046.md) | Changed | Items |
| [Route 46](../locations/header-048.md) | Changed | Script Awarded Items, Static Encounters |
| [Pewter City](../locations/header-051.md) | Changed | Script Awarded Items, Static Encounters |
| [Vermilion City](../locations/header-054.md) | Changed | Script Awarded Items, Static Encounters |
| [Fuchsia City](../locations/header-056.md) | Changed | Script Awarded Items |
| [Cinnabar Island](../locations/header-057.md) | Changed | Items, Script Awarded Items |
| [Indigo Plateau](../locations/header-058.md) | Changed | Script Awarded Items, Static Encounters |
| [New Bark Town](../locations/header-061.md) | Changed | Script Awarded Items |
| [New Bark Town](../locations/header-063.md) | Changed | Script Awarded Items |
| [Cherrygrove City](../locations/header-067.md) | Changed | Script Awarded Items |
| [Violet City](../locations/header-073.md) | Changed | Script Awarded Items |
| [Azalea Town](../locations/header-074.md) | Changed | Warps, Script Awarded Items |
| [Cianwood City](../locations/header-075.md) | Changed | Script Awarded Items, Pokemon Gifts |
| [Olivine City](../locations/header-077.md) | Changed | Items |
| [Ecruteak City](../locations/header-078.md) | Changed | Items, Script Awarded Items |
| [Ecruteak City](../locations/header-079.md) | Changed | Script Awarded Items |
| [Ecruteak City](../locations/header-080.md) | Changed | Script Awarded Items |
| [Ecruteak City](../locations/header-085.md) | Changed | Script Awarded Items |
| [Ecruteak City](../locations/header-086.md) | Changed | Script Awarded Items, Trainers |
| [Mahogany Town](../locations/header-087.md) | Changed | Script Awarded Items |
| [Lake of Rage](../locations/header-088.md) | Changed | Script Awarded Items, Static Encounters |
| [Route 40](../locations/header-094.md) | Changed | Items, Script Awarded Items |
| [National Park](../locations/header-096.md) | Changed | Items, Script Awarded Items, Pokemon Gifts |
| [Diglett's Cave](../locations/header-106.md) | Changed | Name, Warps, Items, Script Awarded Items |
| [Ruins of Alph](../locations/header-113.md) | Changed | Items |
| [Slowpoke Well](../locations/header-114.md) | Changed | Name, Warps |
| [Lighthouse](../locations/header-115.md) | Changed | Script Awarded Items |
| [Ilex Forest](../locations/header-117.md) | Changed | Items, Script Awarded Items, Static Encounters |
| [Goldenrod Tunnel](../locations/header-118.md) | Changed | Script Awarded Items, Trainers |
| [Mt. Mortar](../locations/header-119.md) | Changed | Items |
| [Ice Path](../locations/header-120.md) | Changed | Items |
| [Dark Cave](../locations/header-123.md) | Changed | Items, Script Awarded Items |
| [Victory Road](../locations/header-124.md) | Changed | Items |
| [Mahogany Town](../locations/header-133.md) | Changed | Trainers |
| [Goldenrod City](../locations/header-137.md) | Changed | Script Awarded Items |
| [Olivine City](../locations/header-138.md) | Changed | Script Awarded Items |
| [Cianwood City](../locations/header-139.md) | Changed | Script Awarded Items |
| [Mahogany Town](../locations/header-140.md) | Changed | Script Awarded Items |
| [Blackthorn City](../locations/header-141.md) | Changed | Script Awarded Items |
| [Route 30](../locations/header-143.md) | Changed | Script Awarded Items |
| [Viridian Forest](../locations/header-147.md) | Changed | Static Encounters |
| [Route 47](../locations/header-151.md) | Changed | Items, Script Awarded Items, Trainers |
| [Union Cave](../locations/header-154.md) | Changed | Static Encounters |
| [Sprout Tower](../locations/header-155.md) | Changed | Script Awarded Items |
| [Sprout Tower](../locations/header-156.md) | Changed | Script Awarded Items |
| [Violet City](../locations/header-158.md) | Changed | Script Awarded Items |
| [Violet City](../locations/header-162.md) | Changed | Script Awarded Items |
| [Azalea Town](../locations/header-166.md) | Changed | Script Awarded Items |
| [Route 32](../locations/header-169.md) | Changed | Script Awarded Items |
| [Route 34](../locations/header-171.md) | Changed | Script Awarded Items |
| [Route 38](../locations/header-172.md) | Changed | Script Awarded Items |
| [Dark Cave](../locations/header-176.md) | Changed | Items |
| [Slowpoke Well](../locations/header-177.md) | Changed | Name, Warps, Items, Static Encounters, Trainers |
| [Victory Road](../locations/header-179.md) | Changed | Items |
| [Azalea Town](../locations/header-180.md) | Changed | Script Awarded Items |
| [Slowpoke Well](../locations/header-181.md) | Changed | Name, Warps, Items, Script Awarded Items |
| [Goldenrod City](../locations/header-182.md) | Changed | Script Awarded Items, Pokemon Gifts, Trainers |
| [Goldenrod City](../locations/header-184.md) | Changed | Script Awarded Items |
| [Goldenrod City](../locations/header-185.md) | Changed | Script Awarded Items |
| [Radio Tower](../locations/header-190.md) | Changed | Script Awarded Items, Trainers |
| [Goldenrod City](../locations/header-195.md) | Changed | Script Awarded Items |
| [Goldenrod City](../locations/header-197.md) | Changed | Script Awarded Items |
| [Goldenrod City](../locations/header-203.md) | Changed | Pokemon Gifts |
| [Goldenrod City](../locations/header-205.md) | Changed | Script Awarded Items, Trainers |
| [Route 39](../locations/header-214.md) | Changed | Script Awarded Items |
| [Burned Tower](../locations/header-217.md) | Changed | Items |
| [Lighthouse](../locations/header-221.md) | Changed | Items |
| [Olivine City](../locations/header-228.md) | Changed | Script Awarded Items |
| [Olivine City](../locations/header-230.md) | Changed | Script Awarded Items |
| [Olivine City](../locations/header-231.md) | Changed | Script Awarded Items |
| [Cianwood City](../locations/header-233.md) | Changed | Script Awarded Items |
| [Cianwood City](../locations/header-235.md) | Changed | Script Awarded Items |
| [Cianwood City](../locations/header-236.md) | Changed | Script Awarded Items, Pokemon Gifts |
| [Ice Path](../locations/header-237.md) | Changed | Items |
| [Olivine City](../locations/header-240.md) | Changed | Script Awarded Items |
| [Mahogany Town](../locations/header-246.md) | Changed | Script Awarded Items |
| [Team Rocket HQ](../locations/header-248.md) | Changed | Items, Script Awarded Items, Static Encounters |
| [Team Rocket HQ](../locations/header-249.md) | Changed | Items |
| [Mt. Mortar](../locations/header-250.md) | Changed | Items |
| [Mt. Mortar](../locations/header-252.md) | Changed | Items, Script Awarded Items, Pokemon Gifts, Static Encounters |
| [Dragon's Den](../locations/header-253.md) | Changed | Script Awarded Items |
| [Cliff Edge Gate](../locations/header-279.md) | Changed | Trainers |
| [Dragon's Den](../locations/header-288.md) | Changed | Pokemon Gifts |
| [Blackthorn City](../locations/header-289.md) | Changed | Script Awarded Items |
| [Blackthorn City](../locations/header-293.md) | Changed | Script Awarded Items |
| [Pokémon League](../locations/header-300.md) | Changed | Script Awarded Items |
| [S.S. Aqua](../locations/header-307.md) | Changed | Script Awarded Items |
| [Ruins of Alph](../locations/header-321.md) | Changed | Script Awarded Items |
| [Route 27](../locations/header-322.md) | Changed | Script Awarded Items |
| [Ruins of Alph](../locations/header-325.md) | Changed | Items |
| [Ruins of Alph](../locations/header-326.md) | Changed | Items |
| [S.S. Aqua](../locations/header-328.md) | Changed | Script Awarded Items |
| [Cliff Cave](../locations/header-342.md) | Changed | Script Awarded Items, Trainers |
| [Vermilion City](../locations/header-362.md) | Changed | Script Awarded Items |
| [Vermilion City](../locations/header-365.md) | Changed | Script Awarded Items |
| [New Bark Town](../locations/header-384.md) | Changed | Trainers |
| [Celadon City](../locations/header-393.md) | Changed | Trainers |
| [Celadon City](../locations/header-395.md) | Changed | Script Awarded Items |
| [Saffron City](../locations/header-398.md) | Changed | Trainers |
| [Saffron City](../locations/header-399.md) | Changed | Script Awarded Items |
| [Saffron City](../locations/header-400.md) | Changed | Script Awarded Items |
| [Saffron City](../locations/header-402.md) | Changed | Script Awarded Items, Pokemon Gifts |
| [Rotom's Room](../locations/header-403.md) | Changed | Name |
| [Saffron City](../locations/header-410.md) | Changed | Script Awarded Items |
| [Frontier Access](../locations/header-411.md) | Changed | Items |
| [Route 2](../locations/header-414.md) | Changed | Warps |
| [Cerulean City](../locations/header-427.md) | Changed | Script Awarded Items |
| [Lavender Town](../locations/header-436.md) | Changed | Script Awarded Items |
| [Lavender Town](../locations/header-438.md) | Changed | Script Awarded Items |
| [Mt. Moon](../locations/header-449.md) | Changed | Script Awarded Items |
| [Cerulean Cave](../locations/header-451.md) | Changed | Static Encounters, Trainers |
| [Seafoam Islands](../locations/header-456.md) | Changed | Static Encounters |
| [Seafoam Islands](../locations/header-457.md) | Changed | Script Awarded Items |
| [Mt. Silver Cave](../locations/header-462.md) | Changed | Static Encounters |
| [Mt. Silver Cave](../locations/header-465.md) | Changed | Script Awarded Items |
| [Route 10](../locations/header-466.md) | Changed | Script Awarded Items |
| [Power Plant](../locations/header-467.md) | Changed | Script Awarded Items |
| [Pewter City](../locations/header-473.md) | Changed | Script Awarded Items |
| [Pewter City](../locations/header-475.md) | Changed | Script Awarded Items |
| [Pewter City](../locations/header-477.md) | Changed | Script Awarded Items, Pokemon Gifts, Trainers |
| [Fuchsia City](../locations/header-480.md) | Changed | Script Awarded Items |
| [National Park](../locations/header-487.md) | Changed | Script Awarded Items |
| [Power Plant](../locations/header-489.md) | Changed | Script Awarded Items |
| [Viridian City](../locations/header-496.md) | Changed | Script Awarded Items |
| [Pallet Town](../locations/header-505.md) | Changed | Script Awarded Items |
| [Sinjoh Ruins](../locations/header-521.md) | Changed | Script Awarded Items |
| [Sinjoh Ruins](../locations/header-522.md) | Changed | Script Awarded Items, Pokemon Gifts, Static Encounters |
| [Embedded Tower](../locations/header-524.md) | Changed | Script Awarded Items, Static Encounters |
| [Embedded Tower](../locations/header-525.md) | Changed | Script Awarded Items, Static Encounters |
| [Embedded Tower](../locations/header-526.md) | Changed | Static Encounters |
| [Frontier Access](../locations/header-528.md) | Changed | Script Awarded Items |
| [Route 12](../locations/header-533.md) | Changed | Script Awarded Items, Pokemon Gifts |
| [Safari Zone Gate](../locations/header-534.md) | Changed | Script Awarded Items |
| [Goldenrod City](../locations/header-536.md) | Changed | Script Awarded Items |
