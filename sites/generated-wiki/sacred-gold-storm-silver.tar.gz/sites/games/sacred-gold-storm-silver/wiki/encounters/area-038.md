# Route 38

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>38</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 38](../locations/header-042.md) | `header-042` | 186 | `R38` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/404.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 26 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/404.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 26 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/52.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meowth](../pokemon/meowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/404.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 26 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/300.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26 | 5% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/125.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/125.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/300.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/snubbull/">Snubbull</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 27</li><li><a href="../../pokemon/voltorb/">Voltorb</a> — Lv. 26</li><li><a href="../../pokemon/elekid/">Elekid</a> — Lv. 26</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 26</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 26</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 26</li><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 27</li><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 26</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 27</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 27</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/snubbull/">Snubbull</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 27</li><li><a href="../../pokemon/voltorb/">Voltorb</a> — Lv. 26</li><li><a href="../../pokemon/elekid/">Elekid</a> — Lv. 26</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 26</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 26</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 26</li><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 27</li><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 26</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 27</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 27</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/snubbull/">Snubbull</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 27</li><li><a href="../../pokemon/voltorb/">Voltorb</a> — Lv. 26</li><li><a href="../../pokemon/elekid/">Elekid</a> — Lv. 26</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 26</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 26</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 26</li><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 27</li><li><a href="../../pokemon/cherubi/">Cherubi</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 26</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 27</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 27</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/snubbull/">Snubbull</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 16</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 13</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 13</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/skitty/">Skitty</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 27</li><li><a href="../../pokemon/voltorb/">Voltorb</a> — Lv. 26</li><li><a href="../../pokemon/elekid/">Elekid</a> — Lv. 26</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 26</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 26</li><li><a href="../../pokemon/meowth/">Meowth</a> — Lv. 26</li><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 27</li><li><a href="../../pokemon/skitty/">Skitty</a> — Lv. 26</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 26</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 27</li><li><a href="../../pokemon/miltank/">Miltank</a> — Lv. 27</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Electabuzz</li><li>Dodrio</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 209<span class="rw-diff-arrow">→</span>125</li><li>Name: Snubbull<span class="rw-diff-arrow">→</span>Electabuzz</li><li>Slug: snubbull<span class="rw-diff-arrow">→</span>electabuzz</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Skitty</li><li>Cherubi</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `38`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-026/"><span class="rw-record-nav__label">← Route 37</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-039/"><span class="rw-record-nav__label">Route 39 →</span></a>
</nav>
