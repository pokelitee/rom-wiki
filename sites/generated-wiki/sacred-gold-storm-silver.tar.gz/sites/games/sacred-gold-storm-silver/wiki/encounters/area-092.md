# Route 12

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>92</dd></div>
<div><dt>Methods</dt><dd><a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map header | Location-name index | Internal map |
| -------- | ---------- | ------------------: | ------------ |
| [Route 12](../locations/header-020.md) | `header-020` | 160 | `R12` |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Slowpoke](../pokemon/slowpoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 20–55 | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Slowbro](../pokemon/slowbro.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 20–55 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 50 | 30% |

## Special encounters

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>5 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Tentacruel — Lv. 25</li><li>Quagsire — Lv. 25</li><li>Tentacruel — Lv. 25</li><li>Tentacruel — Lv. 25</li><li>Tentacool — Lv. 25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Slowbro — Lv. 20–55</li><li>Slowpoke — Lv. 20–55</li><li>Slowbro — Lv. 20–55</li><li>Slowbro — Lv. 20–55</li><li>Slowpoke — Lv. 20–55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Tentacool — Lv. 10</li><li>Tentacool — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Tentacool — Lv. 20</li><li>Tentacool — Lv. 20</li><li>Tentacool — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Tentacool — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Horsea — Lv. 20</li><li>Horsea — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Horsea — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Qwilfish — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Tentacool — Lv. 40</li><li>Tentacool — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Qwilfish — Lv. 50</li><li>Qwilfish — Lv. 50</li><li>Poliwhirl — Lv. 50</li><li>Seadra — Lv. 50</li><li>Qwilfish — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Relicanth<details><summary>Exact data</summary><code>{&quot;id&quot;:369,&quot;name&quot;:&quot;Relicanth&quot;,&quot;slug&quot;:&quot;relicanth&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Night Fishing: Tentacool<details><summary>Exact data</summary><code>{&quot;id&quot;:72,&quot;name&quot;:&quot;Tentacool&quot;,&quot;slug&quot;:&quot;tentacool&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `92`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-121/"><span class="rw-record-nav__label">← Route 11</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-122/"><span class="rw-record-nav__label">Route 13 →</span></a>
</nav>
