# Headbutt encounters { #headbutt-encounters }

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 23–24 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 23–25 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 23–24 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–27 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (648, 341), (649, 341) |
| 1 | Regular | (662, 341), (662, 340) |
| 2 | Regular | (657, 331), (657, 330) |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 45](../locations/header-047.md) | `header-047` | `R45` |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `47`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-046/"><span class="rw-record-nav__label">← Headbutt encounters — Route 44</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-048/"><span class="rw-record-nav__label">Headbutt encounters — Route 46 →</span></a>
</nav>
