# Victory Road

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>134</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Victory Road](../locations/header-178.md) | 178 | 221 | `D43R0102` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 44 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 46 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 44 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 44 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 46 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 44 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machoke](../pokemon/machoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 44 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 46 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 44 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Exploud](../pokemon/exploud.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Aggron](../pokemon/aggron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Donphan — Lv. 33</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Onix — Lv. 34</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Lairon — Lv. 44</li><li>Loudred — Lv. 45</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 45</li><li>Machoke — Lv. 44</li><li>Hariyama — Lv. 45</li><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Magneton — Lv. 45</li><li>Medicham — Lv. 46</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Donphan — Lv. 33</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Onix — Lv. 34</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Lairon — Lv. 44</li><li>Loudred — Lv. 45</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 45</li><li>Machoke — Lv. 44</li><li>Hariyama — Lv. 45</li><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Magneton — Lv. 45</li><li>Medicham — Lv. 46</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Donphan — Lv. 33</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Onix — Lv. 34</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Lairon — Lv. 44</li><li>Loudred — Lv. 45</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 45</li><li>Machoke — Lv. 44</li><li>Hariyama — Lv. 45</li><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Magneton — Lv. 45</li><li>Medicham — Lv. 46</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Donphan — Lv. 33</li><li>Golbat — Lv. 32</li><li>Graveler — Lv. 32</li><li>Rhyhorn — Lv. 35</li><li>Onix — Lv. 36</li><li>Onix — Lv. 34</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Lairon — Lv. 44</li><li>Loudred — Lv. 45</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 45</li><li>Machoke — Lv. 44</li><li>Hariyama — Lv. 45</li><li>Kadabra — Lv. 44</li><li>Venomoth — Lv. 45</li><li>Magneton — Lv. 45</li><li>Medicham — Lv. 46</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Exploud</li><li>Aggron</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Marowak</li><li>Chimecho</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `134`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-110/"><span class="rw-record-nav__label">← Victory Road</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-135/"><span class="rw-record-nav__label">Victory Road →</span></a>
</nav>
