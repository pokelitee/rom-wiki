# Whirl Islands

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>44</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Whirl Islands](../locations/header-242.md) | `header-242` | 218 | `D40R0102` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/98.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 37–38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 37–38 | 10% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/98.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 37–38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 37–38 | 10% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/98.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/90.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 35–36 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 37–38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 37–38 | 10% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/98.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/120.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staryu](../pokemon/staryu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 35</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 35</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 36</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 36</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 36</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 37</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 38</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 35</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 35</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 36</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 36</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 36</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 37</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 38</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 35</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 35</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 36</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 36</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 36</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 37</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 38</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 24</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 24</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 35</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 35</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 36</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 36</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 36</li><li><a href="../../pokemon/krabby/">Krabby</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 37</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 38</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 37</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 38</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Dewgong</li><li>Kingler</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Staryu</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `44`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-043/"><span class="rw-record-nav__label">← Whirl Islands</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-046/"><span class="rw-record-nav__label">Whirl Islands →</span></a>
</nav>
