# Mt. Silver Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>86</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map header | Location-name index | Internal map |
| -------- | ---------- | ------------------: | ------------ |
| [Mt. Silver Cave](../locations/header-122.md) | `header-122` | 219 | `D41R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Teddiursa](../pokemon/teddiursa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 62–64 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 62–64 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magmar](../pokemon/magmar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 62 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Larvitar](../pokemon/larvitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Teddiursa](../pokemon/teddiursa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 62–64 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 62–64 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magmar](../pokemon/magmar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 62 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Larvitar](../pokemon/larvitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 58 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Larvitar](../pokemon/larvitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 50 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Misdreavus](../pokemon/misdreavus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 62 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 63–64 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 63–64 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 50–65 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seadra](../pokemon/seadra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 55–65 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Horsea](../pokemon/horsea.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–50 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Corphish](../pokemon/corphish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Krabby](../pokemon/krabby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Corphish](../pokemon/corphish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 60 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 60 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Crawdaunt](../pokemon/crawdaunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--dark">Dark</span></span> | 60 | 30% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pupitar](../pokemon/pupitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Larvitar](../pokemon/larvitar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 45</li><li>Onix — Lv. 42</li><li>Phanpy — Lv. 43</li><li>Graveler — Lv. 43</li><li>Donphan — Lv. 44</li><li>Onix — Lv. 42</li><li>Donphan — Lv. 44</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 41</li><li>Graveler — Lv. 42</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Ursaring — Lv. 64</li><li>Donphan — Lv. 64</li><li>Magmar — Lv. 62</li><li>Quagsire — Lv. 62</li><li>Ursaring — Lv. 62</li><li>Donphan — Lv. 62</li><li>Teddiursa — Lv. 58</li><li>Phanpy — Lv. 58</li><li>Ursaring — Lv. 63</li><li>Donphan — Lv. 63</li><li>Larvitar — Lv. 50</li><li>Graveler — Lv. 62</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 45</li><li>Onix — Lv. 42</li><li>Phanpy — Lv. 43</li><li>Graveler — Lv. 43</li><li>Donphan — Lv. 44</li><li>Onix — Lv. 42</li><li>Donphan — Lv. 44</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 41</li><li>Graveler — Lv. 42</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Ursaring — Lv. 64</li><li>Donphan — Lv. 64</li><li>Magmar — Lv. 62</li><li>Quagsire — Lv. 62</li><li>Ursaring — Lv. 62</li><li>Donphan — Lv. 62</li><li>Teddiursa — Lv. 58</li><li>Phanpy — Lv. 58</li><li>Ursaring — Lv. 63</li><li>Donphan — Lv. 63</li><li>Larvitar — Lv. 50</li><li>Graveler — Lv. 62</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 45</li><li>Onix — Lv. 42</li><li>Phanpy — Lv. 43</li><li>Graveler — Lv. 43</li><li>Donphan — Lv. 44</li><li>Onix — Lv. 42</li><li>Donphan — Lv. 44</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 41</li><li>Graveler — Lv. 42</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Ursaring — Lv. 64</li><li>Donphan — Lv. 64</li><li>Magmar — Lv. 62</li><li>Quagsire — Lv. 62</li><li>Ursaring — Lv. 62</li><li>Donphan — Lv. 62</li><li>Teddiursa — Lv. 58</li><li>Phanpy — Lv. 58</li><li>Ursaring — Lv. 63</li><li>Donphan — Lv. 63</li><li>Larvitar — Lv. 50</li><li>Graveler — Lv. 62</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 45</li><li>Onix — Lv. 42</li><li>Phanpy — Lv. 43</li><li>Graveler — Lv. 43</li><li>Donphan — Lv. 44</li><li>Onix — Lv. 42</li><li>Donphan — Lv. 44</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 45</li><li>Graveler — Lv. 41</li><li>Graveler — Lv. 42</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li>Ursaring — Lv. 64</li><li>Donphan — Lv. 64</li><li>Golduck — Lv. 62</li><li>Graveler — Lv. 62</li><li>Quagsire — Lv. 58</li><li>Golbat — Lv. 58</li><li>Ursaring — Lv. 63</li><li>Donphan — Lv. 63</li><li>Larvitar — Lv. 50</li><li>Misdreavus — Lv. 62</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 50</li><li>Seaking — Lv. 35–45</li><li>Goldeen — Lv. 30–40</li><li>Goldeen — Lv. 30–40</li><li>Seaking — Lv. 30–40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Horsea — Lv. 20–50</li><li>Seadra — Lv. 55–65</li><li>Horsea — Lv. 20–50</li><li>Horsea — Lv. 20–50</li><li>Golbat — Lv. 50–65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Goldeen — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Corphish — Lv. 10</li><li>Corphish — Lv. 10</li><li>Krabby — Lv. 10</li><li>Goldeen — Lv. 10</li><li>Corphish — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 20</li><li>Seaking — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Seaking — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Corphish — Lv. 20</li><li>Corphish — Lv. 20</li><li>Krabby — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Corphish — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Gyarados — Lv. 40</li><li>Seaking — Lv. 40</li><li>Seaking — Lv. 40</li><li>Gyarados — Lv. 40</li><li>Seaking — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Crawdaunt — Lv. 60</li><li>Crawdaunt — Lv. 60</li><li>Kingler — Lv. 60</li><li>Seaking — Lv. 60</li><li>Crawdaunt — Lv. 60</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Pupitar</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 95<span class="rw-diff-arrow">→</span>232</li><li>Name: Onix<span class="rw-diff-arrow">→</span>Donphan</li><li>Slug: onix<span class="rw-diff-arrow">→</span>donphan</li></ul></li><li>Night Fishing: Gyarados<details><summary>Exact data</summary><code>{&quot;id&quot;:130,&quot;name&quot;:&quot;Gyarados&quot;,&quot;slug&quot;:&quot;gyarados&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Larvitar</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `86`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-081/"><span class="rw-record-nav__label">← Mt. Silver Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-087/"><span class="rw-record-nav__label">Mt. Silver Cave →</span></a>
</nav>
