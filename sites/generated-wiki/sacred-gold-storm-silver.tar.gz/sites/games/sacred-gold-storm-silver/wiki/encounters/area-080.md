# Mt. Silver Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>80</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Mt. Silver Cave](../locations/header-463.md) | 463 | 219 | `D41R0106` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 63 (20%); 64 (4%); 66 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 (20%); 64 (4%); 66 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 64 (10%); 66 (10%) | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 64 (5%); 65 (5%) | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 63 (20%); 64 (4%); 66 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 (20%); 64 (4%); 66 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 64 (10%); 66 (10%) | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 64 (5%); 65 (5%) | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 63 (20%); 64 (4%); 66 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 64 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dusclops](../pokemon/dusclops.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 66 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Mawile](../pokemon/mawile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sableye](../pokemon/sableye.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ghost">Ghost</span></span> | 65 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 64 (5%); 65 (5%) | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Misdreavus](../pokemon/misdreavus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 64 (4%); 66 (1%) | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–40 (60%); 35–45 (30%) | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–40 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 85% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 60% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 70% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magnezone](../pokemon/magnezone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 48</li><li>Golduck — Lv. 48</li><li>Donphan — Lv. 50</li><li>Quagsire — Lv. 45</li><li>Sneasel — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Golbat — Lv. 66</li><li>Graveler — Lv. 66</li><li>Magneton — Lv. 64</li><li>Sableye — Lv. 65</li><li>Mawile — Lv. 65</li><li>Magneton — Lv. 66</li><li>Graveler — Lv. 62</li><li>Golbat — Lv. 63</li><li>Golbat — Lv. 64</li><li>Graveler — Lv. 64</li><li>Solrock — Lv. 64</li><li>Solrock — Lv. 65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 48</li><li>Golduck — Lv. 48</li><li>Donphan — Lv. 50</li><li>Quagsire — Lv. 45</li><li>Sneasel — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Golbat — Lv. 66</li><li>Graveler — Lv. 66</li><li>Magneton — Lv. 64</li><li>Sableye — Lv. 65</li><li>Mawile — Lv. 65</li><li>Magneton — Lv. 66</li><li>Graveler — Lv. 62</li><li>Golbat — Lv. 63</li><li>Golbat — Lv. 64</li><li>Graveler — Lv. 64</li><li>Solrock — Lv. 64</li><li>Solrock — Lv. 65</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 48</li><li>Golduck — Lv. 48</li><li>Donphan — Lv. 50</li><li>Quagsire — Lv. 45</li><li>Sneasel — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Golbat — Lv. 66</li><li>Graveler — Lv. 66</li><li>Magneton — Lv. 64</li><li>Sableye — Lv. 65</li><li>Mawile — Lv. 65</li><li>Magneton — Lv. 66</li><li>Graveler — Lv. 62</li><li>Golbat — Lv. 63</li><li>Golbat — Lv. 64</li><li>Graveler — Lv. 64</li><li>Solrock — Lv. 64</li><li>Solrock — Lv. 65</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 48</li><li>Golduck — Lv. 48</li><li>Donphan — Lv. 50</li><li>Quagsire — Lv. 45</li><li>Sneasel — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Misdreavus — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Misdreavus — Lv. 66</li><li>Golbat — Lv. 66</li><li>Magneton — Lv. 64</li><li>Sableye — Lv. 65</li><li>Mawile — Lv. 65</li><li>Dusclops — Lv. 66</li><li>Graveler — Lv. 62</li><li>Golbat — Lv. 63</li><li>Misdreavus — Lv. 64</li><li>Golbat — Lv. 64</li><li>Lunatone — Lv. 64</li><li>Lunatone — Lv. 65</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Magnezone</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 195<span class="rw-diff-arrow">→</span>42</li><li>Name: Quagsire<span class="rw-diff-arrow">→</span>Golbat</li><li>Slug: quagsire<span class="rw-diff-arrow">→</span>golbat</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lunatone</li><li>Solrock</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `80`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-079/"><span class="rw-record-nav__label">← Mt. Silver Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-081/"><span class="rw-record-nav__label">Mt. Silver Cave →</span></a>
</nav>
