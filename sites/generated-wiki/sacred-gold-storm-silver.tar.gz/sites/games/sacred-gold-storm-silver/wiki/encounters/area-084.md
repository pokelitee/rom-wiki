# Bell Tower

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>84</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Bell Tower](../locations/header-341.md) | `header-341` | 205 | `D17R0112` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/334.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/337.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lunatone](../pokemon/lunatone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 44–45 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/94.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gengar](../pokemon/gengar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/344.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Claydol](../pokemon/claydol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 45</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 45</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 43</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 45</li><li><a href="../../pokemon/altaria/">Altaria</a> — Lv. 45</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 43</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 44</li><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 44</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 44</li><li><a href="../../pokemon/claydol/">Claydol</a> — Lv. 45</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 45</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 45</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 43</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 45</li><li><a href="../../pokemon/altaria/">Altaria</a> — Lv. 45</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 43</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 44</li><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 44</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 44</li><li><a href="../../pokemon/claydol/">Claydol</a> — Lv. 45</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 20</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 45</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 45</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 43</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 45</li><li><a href="../../pokemon/altaria/">Altaria</a> — Lv. 45</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 43</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 44</li><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 44</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 44</li><li><a href="../../pokemon/claydol/">Claydol</a> — Lv. 45</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/gastly/">Gastly</a> — Lv. 20</li><li><a href="../../pokemon/gastly/">Gastly</a> — Lv. 21</li><li><a href="../../pokemon/gastly/">Gastly</a> — Lv. 22</li><li><a href="../../pokemon/gastly/">Gastly</a> — Lv. 20</li><li><a href="../../pokemon/gastly/">Gastly</a> — Lv. 21</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 23</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 24</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 22</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 45</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 45</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 43</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 45</li><li><a href="../../pokemon/altaria/">Altaria</a> — Lv. 45</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 43</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 44</li><li><a href="../../pokemon/lunatone/">Lunatone</a> — Lv. 44</li><li><a href="../../pokemon/solrock/">Solrock</a> — Lv. 44</li><li><a href="../../pokemon/claydol/">Claydol</a> — Lv. 45</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Zigzagoon</li><li>Spinda</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Gengar</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 19<span class="rw-diff-arrow">→</span>344</li><li>Name: Rattata<span class="rw-diff-arrow">→</span>Claydol</li><li>Slug: rattata<span class="rw-diff-arrow">→</span>claydol</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Meditite</li><li>Chatot</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Claydol</li><li>Bronzong</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `84`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-037/"><span class="rw-record-nav__label">← Bell Tower</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-065/"><span class="rw-record-nav__label">Blackthorn City →</span></a>
</nav>
