# Ice Path

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>61</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Ice Path](../locations/header-237.md) | 237 | 217 | `D39R0102` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 39 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 1% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 39 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 1% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 41 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellder](../pokemon/shellder.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 39 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 1% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 22</li><li>Swinub — Lv. 21</li><li>Zubat — Lv. 22</li><li>Golbat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Golbat — Lv. 22</li><li>Jynx — Lv. 22</li><li>Swinub — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 40</li><li>Spheal — Lv. 38</li><li>Seel — Lv. 38</li><li>Swinub — Lv. 39</li><li>Golbat — Lv. 41</li><li>Swinub — Lv. 38</li><li>Golbat — Lv. 40</li><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 39</li><li>Shellder — Lv. 38</li><li>Shellder — Lv. 39</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 22</li><li>Swinub — Lv. 21</li><li>Zubat — Lv. 22</li><li>Golbat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Golbat — Lv. 22</li><li>Jynx — Lv. 22</li><li>Swinub — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 40</li><li>Spheal — Lv. 38</li><li>Seel — Lv. 38</li><li>Swinub — Lv. 39</li><li>Golbat — Lv. 41</li><li>Swinub — Lv. 38</li><li>Golbat — Lv. 40</li><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 39</li><li>Shellder — Lv. 38</li><li>Shellder — Lv. 39</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 22</li><li>Zubat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Zubat — Lv. 22</li><li>Golbat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Golbat — Lv. 22</li><li>Jynx — Lv. 22</li><li>Zubat — Lv. 22</li><li>Swinub — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 40</li><li>Spheal — Lv. 38</li><li>Seel — Lv. 38</li><li>Swinub — Lv. 39</li><li>Golbat — Lv. 41</li><li>Swinub — Lv. 38</li><li>Golbat — Lv. 40</li><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 39</li><li>Shellder — Lv. 38</li><li>Shellder — Lv. 39</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 22</li><li>Zubat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Zubat — Lv. 22</li><li>Golbat — Lv. 22</li><li>Swinub — Lv. 21</li><li>Golbat — Lv. 22</li><li>Jynx — Lv. 22</li><li>Zubat — Lv. 22</li><li>Swinub — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 40</li><li>Spheal — Lv. 38</li><li>Seel — Lv. 38</li><li>Swinub — Lv. 39</li><li>Golbat — Lv. 41</li><li>Swinub — Lv. 38</li><li>Golbat — Lv. 40</li><li>Smoochum — Lv. 38</li><li>Delibird — Lv. 39</li><li>Shellder — Lv. 38</li><li>Shellder — Lv. 39</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Piloswine</li><li>Sealeo</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Delibird</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `61`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-060/"><span class="rw-record-nav__label">← Ice Path</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-062/"><span class="rw-record-nav__label">Ice Path →</span></a>
</nav>
