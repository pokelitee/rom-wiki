# Route 8

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>118</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 8](../locations/header-016.md) | `header-016` | 156 | `R08` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–54 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50–52 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–54 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50–52 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50–53 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–54 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/354.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Banette](../pokemon/banette.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 50–52 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/59.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arcanine](../pokemon/arcanine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/65.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Alakazam](../pokemon/alakazam.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 53</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 52</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 52</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 53</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 52</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 52</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 19</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 53</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 52</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 52</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 17</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 15</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 17</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 19</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 17</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 19</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 17</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 18</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 53</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 52</li><li><a href="../../pokemon/haunter/">Haunter</a> — Lv. 53</li><li><a href="../../pokemon/xatu/">Xatu</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 52</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 52</li><li><a href="../../pokemon/banette/">Banette</a> — Lv. 50</li><li><a href="../../pokemon/banette/">Banette</a> — Lv. 52</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Arcanine</li><li>Alakazam</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 17<span class="rw-diff-arrow">→</span>58</li><li>Name: Pidgeotto<span class="rw-diff-arrow">→</span>Growlithe</li><li>Slug: pidgeotto<span class="rw-diff-arrow">→</span>growlithe</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Shuppet</li><li>Duskull</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `118`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-117/"><span class="rw-record-nav__label">← Route 7</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-119/"><span class="rw-record-nav__label">Route 9 →</span></a>
</nav>
