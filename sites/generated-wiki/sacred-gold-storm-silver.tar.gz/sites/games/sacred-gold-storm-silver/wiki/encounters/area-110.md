# Victory Road

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>110</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Victory Road](../locations/header-124.md) | `header-124` | 221 | `D43R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/105.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–46 | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/105.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–46 | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/105.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/208.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Steelix](../pokemon/steelix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--ground">Ground</span></span> | 45–46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/437.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bronzong](../pokemon/bronzong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–46 | 10% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/169.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crobat](../pokemon/crobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/358.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/105.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 34</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 46</li><li><a href="../../pokemon/marowak/">Marowak</a> — Lv. 45</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 46</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 46</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 46</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 46</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 34</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 46</li><li><a href="../../pokemon/marowak/">Marowak</a> — Lv. 45</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 46</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 46</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 46</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 46</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 34</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 46</li><li><a href="../../pokemon/marowak/">Marowak</a> — Lv. 45</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 46</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 46</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 46</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 46</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 32</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 32</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 35</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 36</li><li><a href="../../pokemon/onix/">Onix</a> — Lv. 34</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 46</li><li><a href="../../pokemon/marowak/">Marowak</a> — Lv. 45</li><li><a href="../../pokemon/rhydon/">Rhydon</a> — Lv. 46</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 46</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 46</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/bronzong/">Bronzong</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 45</li><li><a href="../../pokemon/steelix/">Steelix</a> — Lv. 46</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Crobat</li><li>Golem</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Marowak</li><li>Chimecho</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `110`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-098/"><span class="rw-record-nav__label">← Vermilion City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-134/"><span class="rw-record-nav__label">Victory Road →</span></a>
</nav>
