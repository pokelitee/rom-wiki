# Route 9

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>119</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 9](../locations/header-017.md) | 17 | 157 | `R09` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 49 (20%); 50 (4%); 51 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 50 (10%) | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51 (4%); 50 (1%) | 5% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 49 (20%); 50 (4%); 51 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 50 (10%) | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51 (4%); 50 (1%) | 5% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 49 (20%); 50 (4%); 51 (1%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 50 (10%) | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 49 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51 (4%); 50 (1%) | 5% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 15–30 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 33 (30%); 44 (5%); 55 (4%); 11 (1%) | 40% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 70% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 100% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoqueen](../pokemon/nidoqueen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nidoking](../pokemon/nidoking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marowak](../pokemon/marowak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Spearow — Lv. 13</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Raticate — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marowak — Lv. 50</li><li>Primeape — Lv. 51</li><li>Arbok — Lv. 49</li><li>Nidorina — Lv. 49</li><li>Nidorino — Lv. 49</li><li>Arbok — Lv. 50</li><li>Fearow — Lv. 49</li><li>Primeape — Lv. 49</li><li>Primeape — Lv. 50</li><li>Marowak — Lv. 51</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Spearow — Lv. 13</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Raticate — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marowak — Lv. 50</li><li>Primeape — Lv. 51</li><li>Arbok — Lv. 49</li><li>Nidorina — Lv. 49</li><li>Nidorino — Lv. 49</li><li>Arbok — Lv. 50</li><li>Fearow — Lv. 49</li><li>Primeape — Lv. 49</li><li>Primeape — Lv. 50</li><li>Marowak — Lv. 51</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Spearow — Lv. 13</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Fearow — Lv. 15</li><li>Primeape — Lv. 15</li><li>Raticate — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marowak — Lv. 50</li><li>Primeape — Lv. 51</li><li>Arbok — Lv. 49</li><li>Nidorina — Lv. 49</li><li>Nidorino — Lv. 49</li><li>Arbok — Lv. 50</li><li>Fearow — Lv. 49</li><li>Primeape — Lv. 49</li><li>Primeape — Lv. 50</li><li>Marowak — Lv. 51</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Raticate — Lv. 15</li><li>Primeape — Lv. 15</li><li>Raticate — Lv. 13</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Mankey — Lv. 13</li><li>Rattata — Lv. 15</li><li>Raticate — Lv. 15</li><li>Primeape — Lv. 15</li><li>Rattata — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marowak — Lv. 50</li><li>Primeape — Lv. 51</li><li>Arbok — Lv. 49</li><li>Nidorina — Lv. 49</li><li>Nidorino — Lv. 49</li><li>Arbok — Lv. 50</li><li>Fearow — Lv. 49</li><li>Primeape — Lv. 49</li><li>Primeape — Lv. 50</li><li>Marowak — Lv. 51</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 15</li><li>Goldeen — Lv. 10</li><li>Seaking — Lv. 15</li><li>Seaking — Lv. 15</li><li>Goldeen — Lv. 15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 11</li><li>Seaking — Lv. 33</li><li>Seaking — Lv. 55</li><li>Seaking — Lv. 44</li><li>Goldeen — Lv. 15–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Goldeen — Lv. 10</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 10</li><li>Seaking — Lv. 10</li><li>Goldeen — Lv. 10</li><li>Seaking — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Goldeen — Lv. 20</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 20</li><li>Seaking — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Seaking — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Seaking — Lv. 50</li><li>Seaking — Lv. 50</li><li>Seaking — Lv. 50</li><li>Seaking — Lv. 50</li><li>Seaking — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Nidoqueen</li><li>Nidoking</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 302<span class="rw-diff-arrow">→</span>180</li><li>Name: Sableye<span class="rw-diff-arrow">→</span>Flaaffy</li><li>Slug: sableye<span class="rw-diff-arrow">→</span>flaaffy</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Marowak</li><li>Kangaskhan</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `119`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-118/"><span class="rw-record-nav__label">← Route 8</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-009/"><span class="rw-record-nav__label">Ruins of Alph →</span></a>
</nav>
