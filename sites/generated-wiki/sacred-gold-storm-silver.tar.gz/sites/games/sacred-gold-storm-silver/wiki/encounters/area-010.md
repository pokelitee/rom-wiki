# Ruins of Alph

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>10</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Ruins of Alph](../locations/header-315.md) | `header-315` | 209 | `D24R0205` |

## Walking (Morning)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 15 | 100% |

## Walking (Day)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 15 | 100% |

## Walking (Night)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 15 | 100% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/201.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Unown](../pokemon/unown.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

<details markdown="1">
<summary>2 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 5</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li><li><a href="../../pokemon/unown/">Unown</a> — Lv. 15</li></ul></li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `10`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-009/"><span class="rw-record-nav__label">← Ruins of Alph</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-011/"><span class="rw-record-nav__label">Ruins of Alph →</span></a>
</nav>
