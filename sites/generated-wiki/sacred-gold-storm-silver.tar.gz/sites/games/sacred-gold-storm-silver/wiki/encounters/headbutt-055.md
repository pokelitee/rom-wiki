# Headbutt encounters { #headbutt-encounters }

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 15–17 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 15–17 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 15–17 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 18–20 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 18–20 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (1198, 225), (1199, 225) |
| 1 | Regular | (1200, 225), (1201, 225) |
| 2 | Regular | (1204, 225), (1205, 225) |
| 3 | Regular | (1210, 225), (1211, 225) |
| 4 | Regular | (1216, 225), (1217, 225) |
| 5 | Regular | (1220, 225), (1221, 225) |
| 6 | Regular | (1222, 225), (1223, 225) |
| 7 | Regular | (1234, 229), (1235, 229), (1234, 227), (1235, 227) |
| 8 | Regular | (1240, 237), (1241, 237) |
| 9 | Regular | (1188, 255), (1189, 255) |
| 10 | Regular | (1190, 255), (1191, 255) |
| 11 | Regular | (1193, 249), (1193, 248) |
| 12 | Regular | (1193, 247), (1193, 246) |
| 13 | Regular | (1193, 243), (1193, 242) |
| 14 | Regular | (1193, 269), (1193, 268) |
| 15 | Regular | (1198, 273), (1199, 273) |
| 16 | Regular | (1202, 273), (1203, 273) |
| 17 | Regular | (1210, 273), (1211, 273) |
| 18 | Regular | (1215, 271), (1216, 271) |
| 19 | Regular | (1223, 271), (1224, 271) |
| 20 | Regular | (1219, 267), (1220, 267) |
| 21 | Regular | (1221, 267), (1222, 267) |
| 22 | Regular | (1230, 271), (1231, 271) |
| 23 | Regular | (1232, 271), (1233, 271) |
| 24 | Regular | (1234, 271), (1235, 271) |
| 25 | Regular | (1237, 269), (1237, 268), (1237, 267), (1236, 267) |
| 26 | Regular | (1240, 267), (1240, 266) |
| 27 | Regular | (1240, 265), (1240, 264) |
| 28 | Regular | (1240, 263), (1240, 262) |
| 29 | Regular | (1237, 257), (1237, 256) |
| 30 | Regular | (1238, 253), (1239, 253) |
| 31 | Regular | (1240, 255), (1240, 254) |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Celadon City](../locations/header-055.md) | `header-055` | `T07` |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `55`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-054/"><span class="rw-record-nav__label">← Headbutt encounters — Vermilion City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-056/"><span class="rw-record-nav__label">Headbutt encounters — Fuchsia City →</span></a>
</nav>
