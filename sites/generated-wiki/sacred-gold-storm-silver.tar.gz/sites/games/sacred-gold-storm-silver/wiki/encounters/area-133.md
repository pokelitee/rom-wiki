# Diglett's Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>133</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Diglett's Cave](../locations/header-106.md) | `header-106` | 197 | `D01R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 22–46 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51–63 | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 22–46 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51–63 | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 22–46 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/449.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippopotas](../pokemon/hippopotas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 51–63 | 10% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/450.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hippowdon](../pokemon/hippowdon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/206.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dunsparce](../pokemon/dunsparce.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>4 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Name</p>
<div class="rw-change__value">DIGLETT&#x27;s Cave<span class="rw-diff-arrow">→</span>Diglett&#x27;s Cave</div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 19</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 24</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 61</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 63</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 38</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 41</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 47</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 22</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 51</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 54</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 46</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 19</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 24</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 61</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 63</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 38</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 41</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 47</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 22</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 51</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 54</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 46</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 19</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 24</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 61</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 63</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 38</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 41</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 47</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 22</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 51</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 54</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 46</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 19</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 15</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 17</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 19</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 24</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 61</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 63</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 38</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 41</li><li><a href="../../pokemon/hippopotas/">Hippopotas</a> — Lv. 47</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 22</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 33</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 51</li><li><a href="../../pokemon/dugtrio/">Dugtrio</a> — Lv. 54</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 29</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 46</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Hippowdon</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Dunsparce</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `133`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-070/"><span class="rw-record-nav__label">← Dark Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-066/"><span class="rw-record-nav__label">Dragon&#x27;s Den →</span></a>
</nav>
