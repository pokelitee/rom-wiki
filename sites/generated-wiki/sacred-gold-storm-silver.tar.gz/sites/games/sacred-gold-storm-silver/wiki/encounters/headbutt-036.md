# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 32](../locations/header-036.md) | `header-036` | `R32` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–5 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 4–5 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 4–5 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–7 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 6–7 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (458, 289), (459, 289) |
| 1 | Regular | (478, 291), (478, 290) |
| 2 | Regular | (464, 299), (465, 299) |
| 3 | Regular | (472, 302), (473, 302), (473, 303), (473, 304) |
| 4 | Regular | (478, 315), (478, 314) |
| 5 | Regular | (474, 327), (475, 327), (474, 329), (474, 328) |
| 6 | Regular | (463, 318), (464, 318), (463, 320), (464, 320), (463, 319) |
| 7 | Regular | (464, 327), (465, 327), (465, 329), (465, 328) |
| 8 | Regular | (460, 331), (461, 331) |
| 9 | Regular | (460, 311), (461, 311), (461, 313), (461, 312) |
| 10 | Regular | (454, 335), (455, 335), (455, 334) |
| 11 | Regular | (453, 353), (453, 352) |
| 12 | Regular | (453, 351), (453, 350) |
| 13 | Regular | (450, 359), (451, 359) |
| 14 | Regular | (453, 375), (454, 375), (453, 377), (453, 376) |
| 15 | Regular | (456, 383), (456, 382) |
| 16 | Regular | (449, 387), (449, 386) |
| 17 | Regular | (465, 398), (466, 398), (466, 397) |
| 18 | Regular | (470, 402), (471, 402) |
| 19 | Regular | (472, 409) |
| 20 | Regular | (476, 439) |
| 21 | Regular | (469, 430), (469, 429) |
| 22 | Regular | (471, 440), (472, 440) |
| 23 | Regular | (471, 421) |
| 24 | Regular | (462, 406), (463, 406) |
| 25 | Regular | (455, 417), (455, 416) |
| 26 | Regular | (450, 403), (451, 403) |
| 27 | Regular | (472, 394), (472, 393), (472, 392) |
| 28 | Regular | (458, 307), (459, 307) |
| 29 | Regular | (449, 377), (449, 376), (449, 375) |
| 30 | Regular | (461, 323), (461, 322) |
| 31 | Regular | (478, 316), (478, 317) |
| 32 | Regular | (478, 319), (478, 318) |
| 33 | Regular | (461, 419), (462, 419), (462, 420), (462, 421) |
| 34 | Regular | (455, 406), (455, 407) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `36`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-035/"><span class="rw-record-nav__label">← Headbutt encounters — Route 31</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-037/"><span class="rw-record-nav__label">Headbutt encounters — Route 33 →</span></a>
</nav>
