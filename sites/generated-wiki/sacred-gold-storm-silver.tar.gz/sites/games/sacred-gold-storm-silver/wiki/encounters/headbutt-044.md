# Headbutt encounters { #headbutt-encounters }

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 13–14 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 13–14 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13–14 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 15–16 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/190.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Aipom](../pokemon/aipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 15–16 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (424, 173), (425, 173), (425, 172) |
| 1 | Regular | (426, 187), (427, 187) |
| 2 | Regular | (448, 184), (449, 184) |
| 3 | Regular | (470, 186) |
| 4 | Regular | (461, 186), (461, 185), (460, 185) |
| 5 | Regular | (442, 182), (443, 182) |
| 6 | Regular | (432, 181), (433, 181), (432, 182) |
| 7 | Regular | (436, 177), (437, 177) |
| 8 | Regular | (458, 181), (458, 180), (458, 179), (459, 179), (459, 180), (459, 181) |
| 9 | Regular | (469, 179), (470, 179) |

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 42](../locations/header-044.md) | `header-044` | `R42` |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `44`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-043/"><span class="rw-record-nav__label">← Headbutt encounters — Route 39</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-045/"><span class="rw-record-nav__label">Headbutt encounters — Route 43 →</span></a>
</nav>
