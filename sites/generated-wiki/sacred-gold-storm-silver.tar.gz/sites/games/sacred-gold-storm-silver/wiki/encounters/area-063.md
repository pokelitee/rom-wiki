# Ice Path

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>63</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Ice Path](../locations/header-239.md) | `header-239` | 217 | `D39R0104` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 43–44 | 5% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 43–44 | 5% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 43 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 43–44 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/473.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mamoswine](../pokemon/mamoswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/365.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Walrein](../pokemon/walrein.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 23</li><li>Swinub — Lv. 22</li><li>Zubat — Lv. 23</li><li>Golbat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Golbat — Lv. 23</li><li>Jynx — Lv. 23</li><li>Swinub — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Jynx — Lv. 44</li><li>Sneasel — Lv. 44</li><li>Glalie — Lv. 43</li><li>Sealeo — Lv. 43</li><li>Dewgong — Lv. 43</li><li>Piloswine — Lv. 44</li><li>Piloswine — Lv. 42</li><li>Golbat — Lv. 42</li><li>Jynx — Lv. 43</li><li>Sneasel — Lv. 43</li><li>Golbat — Lv. 43</li><li>Golbat — Lv. 44</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 23</li><li>Swinub — Lv. 22</li><li>Zubat — Lv. 23</li><li>Golbat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Golbat — Lv. 23</li><li>Jynx — Lv. 23</li><li>Swinub — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Jynx — Lv. 44</li><li>Sneasel — Lv. 44</li><li>Glalie — Lv. 43</li><li>Sealeo — Lv. 43</li><li>Dewgong — Lv. 43</li><li>Piloswine — Lv. 44</li><li>Piloswine — Lv. 42</li><li>Golbat — Lv. 42</li><li>Jynx — Lv. 43</li><li>Sneasel — Lv. 43</li><li>Golbat — Lv. 43</li><li>Golbat — Lv. 44</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 23</li><li>Zubat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Zubat — Lv. 23</li><li>Golbat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Golbat — Lv. 23</li><li>Jynx — Lv. 23</li><li>Zubat — Lv. 23</li><li>Swinub — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Jynx — Lv. 44</li><li>Sneasel — Lv. 44</li><li>Glalie — Lv. 43</li><li>Sealeo — Lv. 43</li><li>Dewgong — Lv. 43</li><li>Piloswine — Lv. 44</li><li>Piloswine — Lv. 42</li><li>Golbat — Lv. 42</li><li>Jynx — Lv. 43</li><li>Sneasel — Lv. 43</li><li>Golbat — Lv. 43</li><li>Golbat — Lv. 44</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Jynx — Lv. 23</li><li>Zubat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Zubat — Lv. 23</li><li>Golbat — Lv. 23</li><li>Swinub — Lv. 22</li><li>Golbat — Lv. 23</li><li>Jynx — Lv. 23</li><li>Zubat — Lv. 23</li><li>Swinub — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Jynx — Lv. 44</li><li>Sneasel — Lv. 44</li><li>Glalie — Lv. 43</li><li>Sealeo — Lv. 43</li><li>Dewgong — Lv. 43</li><li>Piloswine — Lv. 44</li><li>Piloswine — Lv. 42</li><li>Golbat — Lv. 42</li><li>Jynx — Lv. 43</li><li>Sneasel — Lv. 43</li><li>Golbat — Lv. 43</li><li>Golbat — Lv. 44</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Walrein</li><li>Mamoswine</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 220<span class="rw-diff-arrow">→</span>221</li><li>Name: Swinub<span class="rw-diff-arrow">→</span>Piloswine</li><li>Slug: swinub<span class="rw-diff-arrow">→</span>piloswine</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Jynx</li><li>Sneasel</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `63`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-062/"><span class="rw-record-nav__label">← Ice Path</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-020/"><span class="rw-record-nav__label">Ilex Forest →</span></a>
</nav>
