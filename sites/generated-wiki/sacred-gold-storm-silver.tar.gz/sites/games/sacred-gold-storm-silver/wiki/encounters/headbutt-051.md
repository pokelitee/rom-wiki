# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Pewter City](../locations/header-051.md) | `header-051` | `T03` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3–5 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 7–9 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 7–9 | 20% |

## Secret trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 5–9 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 5–12 | 35% |

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (1052, 117), (1053, 117) |
| 1 | Regular | (1060, 117), (1061, 117) |
| 2 | Regular | (1070, 117), (1071, 117) |
| 3 | Regular | (1040, 111), (1041, 111), (1040, 109), (1041, 109) |
| 4 | Regular | (1042, 111), (1043, 111), (1043, 110), (1043, 109), (1042, 109) |
| 5 | Regular | (1042, 99), (1043, 99), (1043, 101) |
| 6 | Regular | (1044, 101), (1045, 101), (1044, 99), (1045, 99) |
| 7 | Regular | (1052, 101), (1053, 101) |
| 8 | Regular | (1043, 93) |
| 9 | Regular | (1051, 93) |
| 10 | Regular | (1061, 87), (1062, 87), (1061, 85), (1062, 85) |
| 11 | Regular | (1065, 87), (1066, 87), (1065, 85), (1066, 85) |
| 12 | Regular | (1065, 81), (1065, 80) |
| 13 | Regular | (1066, 73), (1067, 73) |
| 14 | Regular | (1062, 73), (1063, 73) |
| 15 | Regular | (1060, 77), (1061, 77) |
| 16 | Regular | (1029, 75), (1030, 75) |
| 17 | Regular | (1031, 75), (1032, 75) |
| 18 | Regular | (1030, 85), (1030, 84) |
| 19 | Regular | (1030, 81), (1030, 80) |
| 20 | Regular | (1030, 79), (1030, 78), (1030, 77), (1031, 77) |
| 21 | Secret | (1037, 119) |
| 22 | Secret | (1037, 120), (1037, 121) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `51`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-050/"><span class="rw-record-nav__label">← Headbutt encounters — Viridian City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-052/"><span class="rw-record-nav__label">Headbutt encounters — Cerulean City →</span></a>
</nav>
