# Bell Tower

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>31</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Bell Tower](../locations/header-333.md) | `header-333` | 205 | `D17R0103` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/92.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastly](../pokemon/gastly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 40–41 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40–41 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/92.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastly](../pokemon/gastly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 40–41 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40–41 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/92.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastly](../pokemon/gastly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> | 40–41 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 40–41 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 40–41 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/93.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Haunter](../pokemon/haunter.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--poison">Poison</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 22</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 22</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Shuppet — Lv. 41</li><li>Duskull — Lv. 41</li><li>Rattata — Lv. 40</li><li>Gastly — Lv. 40</li><li>Rattata — Lv. 41</li><li>Zigzagoon — Lv. 40</li><li>Golbat — Lv. 43</li><li>Shuppet — Lv. 40</li><li>Duskull — Lv. 40</li><li>Rattata — Lv. 41</li><li>Gastly — Lv. 41</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 22</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 22</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Shuppet — Lv. 41</li><li>Duskull — Lv. 41</li><li>Rattata — Lv. 40</li><li>Gastly — Lv. 40</li><li>Rattata — Lv. 41</li><li>Zigzagoon — Lv. 40</li><li>Golbat — Lv. 43</li><li>Shuppet — Lv. 40</li><li>Duskull — Lv. 40</li><li>Rattata — Lv. 41</li><li>Gastly — Lv. 41</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 22</li><li>Rattata — Lv. 20</li><li>Rattata — Lv. 21</li><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 22</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Shuppet — Lv. 41</li><li>Duskull — Lv. 41</li><li>Rattata — Lv. 40</li><li>Gastly — Lv. 40</li><li>Rattata — Lv. 41</li><li>Zigzagoon — Lv. 40</li><li>Golbat — Lv. 43</li><li>Shuppet — Lv. 40</li><li>Duskull — Lv. 40</li><li>Rattata — Lv. 41</li><li>Gastly — Lv. 41</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Gastly — Lv. 20</li><li>Gastly — Lv. 21</li><li>Gastly — Lv. 22</li><li>Gastly — Lv. 20</li><li>Gastly — Lv. 21</li><li>Rattata — Lv. 23</li><li>Rattata — Lv. 24</li><li>Rattata — Lv. 22</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Shuppet — Lv. 41</li><li>Duskull — Lv. 41</li><li>Rattata — Lv. 40</li><li>Gastly — Lv. 40</li><li>Rattata — Lv. 41</li><li>Zigzagoon — Lv. 40</li><li>Golbat — Lv. 43</li><li>Shuppet — Lv. 40</li><li>Duskull — Lv. 40</li><li>Rattata — Lv. 41</li><li>Gastly — Lv. 41</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Zigzagoon</li><li>Spinda</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Linoone</li><li>Haunter</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Meditite</li><li>Chatot</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Shuppet</li><li>Duskull</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `31`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-030/"><span class="rw-record-nav__label">← Bell Tower</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-032/"><span class="rw-record-nav__label">Bell Tower →</span></a>
</nav>
