# Route 14

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>123</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 14](../locations/header-022.md) | `header-022` | 162 | `R14` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/277.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swellow](../pokemon/swellow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–53 | 24% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 51–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–55 | 6% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/277.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swellow](../pokemon/swellow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–53 | 24% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 51–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–55 | 6% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 51–55 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/277.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swellow](../pokemon/swellow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 52–53 | 24% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/49.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venomoth](../pokemon/venomoth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 51–53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–55 | 6% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/189.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jumpluff](../pokemon/jumpluff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/438.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bonsly](../pokemon/bonsly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/439.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Chansey — Lv. 25</li><li>Skiploom — Lv. 26</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Pidgeotto — Lv. 25</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Skiploom — Lv. 26</li><li>Hoppip — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 52</li><li>Chansey — Lv. 55</li><li>Skiploom — Lv. 51</li><li>Swellow — Lv. 52</li><li>Skiploom — Lv. 53</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li><li>Swellow — Lv. 53</li><li>Chansey — Lv. 54</li><li>Nidorina — Lv. 55</li><li>Nidorino — Lv. 55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Chansey — Lv. 25</li><li>Skiploom — Lv. 26</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Pidgeotto — Lv. 25</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Skiploom — Lv. 26</li><li>Hoppip — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 52</li><li>Chansey — Lv. 55</li><li>Skiploom — Lv. 51</li><li>Swellow — Lv. 52</li><li>Skiploom — Lv. 53</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li><li>Swellow — Lv. 53</li><li>Chansey — Lv. 54</li><li>Nidorina — Lv. 55</li><li>Nidorino — Lv. 55</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Chansey — Lv. 25</li><li>Skiploom — Lv. 26</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Pidgeotto — Lv. 25</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Skiploom — Lv. 26</li><li>Hoppip — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 52</li><li>Chansey — Lv. 55</li><li>Skiploom — Lv. 51</li><li>Swellow — Lv. 52</li><li>Skiploom — Lv. 53</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li><li>Swellow — Lv. 53</li><li>Chansey — Lv. 54</li><li>Nidorina — Lv. 55</li><li>Nidorino — Lv. 55</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Chansey — Lv. 25</li><li>Quagsire — Lv. 26</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Noctowl — Lv. 25</li><li>Nidorina — Lv. 23</li><li>Nidorino — Lv. 23</li><li>Quagsire — Lv. 26</li><li>Quagsire — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Chansey — Lv. 52</li><li>Chansey — Lv. 55</li><li>Venomoth — Lv. 51</li><li>Swellow — Lv. 52</li><li>Venomoth — Lv. 53</li><li>Nidorina — Lv. 51</li><li>Nidorino — Lv. 51</li><li>Swellow — Lv. 53</li><li>Chansey — Lv. 54</li><li>Nidorina — Lv. 55</li><li>Nidorino — Lv. 55</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Jumpluff</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 30<span class="rw-diff-arrow">→</span>33</li><li>Name: Nidorina<span class="rw-diff-arrow">→</span>Nidorino</li><li>Slug: nidorina<span class="rw-diff-arrow">→</span>nidorino</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Bonsly</li><li>Mime Jr.</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `123`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-122/"><span class="rw-record-nav__label">← Route 13</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-124/"><span class="rw-record-nav__label">Route 15 →</span></a>
</nav>
