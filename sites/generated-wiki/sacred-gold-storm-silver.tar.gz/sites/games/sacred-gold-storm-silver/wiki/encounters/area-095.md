# Pallet Town

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>95</dd></div>
<div><dt>Methods</dt><dd><a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Pallet Town](../locations/header-049.md) | `header-049` | 138 | `T01` |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–70 | 100% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/456.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Finneon](../pokemon/finneon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–70 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 1–70 | 100% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/120.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staryu](../pokemon/staryu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–70 | 100% |

## Special encounters

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

<details markdown="1">
<summary>5 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 35</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 30</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 35</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 35</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 35</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 1–70</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 1–70</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 1–70</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 1–70</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 1–70</li><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 1–70</li><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 1–70</li><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 1–70</li><li><a href="../../pokemon/finneon/">Finneon</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 1–70</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 1–70</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 1–70</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 1–70</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 40</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 1–70</li><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 1–70</li><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 1–70</li><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 1–70</li><li><a href="../../pokemon/staryu/">Staryu</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Night Fishing: Shellder<details><summary>Exact data</summary><code>{&quot;id&quot;:90,&quot;name&quot;:&quot;Shellder&quot;,&quot;slug&quot;:&quot;shellder&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `95`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-040/"><span class="rw-record-nav__label">← Olivine City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-108/"><span class="rw-record-nav__label">Rock Tunnel →</span></a>
</nav>
