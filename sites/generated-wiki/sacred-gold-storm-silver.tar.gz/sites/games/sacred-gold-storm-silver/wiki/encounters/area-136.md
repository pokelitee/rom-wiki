# Route 2

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>136</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Route 2](../locations/header-414.md) | `header-414` | 150 | `R02R0101` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dustox](../pokemon/dustox.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 45–48 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dustox](../pokemon/dustox.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 45–48 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dustox](../pokemon/dustox.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 45–49 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ariados](../pokemon/ariados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Yanma](../pokemon/yanma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–48 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pidgeot](../pokemon/pidgeot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Burmy](../pokemon/burmy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Caterpie — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Pidgey — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Pidgeotto — Lv. 10</li><li>Pidgeotto — Lv. 7</li><li>Butterfree — Lv. 7</li><li>Butterfree — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 47</li><li>Cherrim — Lv. 48</li><li>Pachirisu — Lv. 45</li><li>Ledian — Lv. 46</li><li>Staravia — Lv. 46</li><li>Ledian — Lv. 47</li><li>Beautifly — Lv. 45</li><li>Dustox — Lv. 45</li><li>Cherrim — Lv. 45</li><li>Cherrim — Lv. 46</li><li>Beautifly — Lv. 49</li><li>Dustox — Lv. 49</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Caterpie — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Pidgey — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Pidgeotto — Lv. 10</li><li>Pidgeotto — Lv. 7</li><li>Butterfree — Lv. 7</li><li>Butterfree — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 47</li><li>Cherrim — Lv. 48</li><li>Pachirisu — Lv. 45</li><li>Ledian — Lv. 46</li><li>Staravia — Lv. 46</li><li>Ledian — Lv. 47</li><li>Beautifly — Lv. 45</li><li>Dustox — Lv. 45</li><li>Cherrim — Lv. 45</li><li>Cherrim — Lv. 46</li><li>Beautifly — Lv. 49</li><li>Dustox — Lv. 49</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Caterpie — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Spinarak — Lv. 10</li><li>Pidgeotto — Lv. 7</li><li>Butterfree — Lv. 7</li><li>Butterfree — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 47</li><li>Cherrim — Lv. 48</li><li>Pachirisu — Lv. 45</li><li>Ledian — Lv. 46</li><li>Staravia — Lv. 46</li><li>Ledian — Lv. 47</li><li>Beautifly — Lv. 45</li><li>Dustox — Lv. 45</li><li>Cherrim — Lv. 45</li><li>Cherrim — Lv. 46</li><li>Beautifly — Lv. 49</li><li>Dustox — Lv. 49</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li>Spinarak — Lv. 4</li><li>Ariados — Lv. 7</li><li>Hoothoot — Lv. 3</li><li>Spinarak — Lv. 3</li><li>Hoothoot — Lv. 5</li><li>Hoothoot — Lv. 3</li><li>Spinarak — Lv. 3</li><li>Noctowl — Lv. 10</li><li>Ariados — Lv. 7</li><li>Noctowl — Lv. 7</li><li>Noctowl — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Yanma — Lv. 47</li><li>Yanma — Lv. 48</li><li>Pachirisu — Lv. 45</li><li>Ariados — Lv. 46</li><li>Bibarel — Lv. 46</li><li>Ariados — Lv. 47</li><li>Beautifly — Lv. 45</li><li>Dustox — Lv. 45</li><li>Yanma — Lv. 45</li><li>Yanma — Lv. 46</li><li>Beautifly — Lv. 49</li><li>Dustox — Lv. 49</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Pidgeot</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 10<span class="rw-diff-arrow">→</span>13</li><li>Name: Caterpie<span class="rw-diff-arrow">→</span>Weedle</li><li>Slug: caterpie<span class="rw-diff-arrow">→</span>weedle</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Pikachu</li><li>Burmy</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `136`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-112/"><span class="rw-record-nav__label">← Route 2</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-094/"><span class="rw-record-nav__label">Route 20 →</span></a>
</nav>
