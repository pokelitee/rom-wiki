# Route 36

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>25</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 36](../locations/header-040.md) | `header-040` | 184 | `R36` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 10% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 10% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 18 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/30.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorina](../pokemon/nidorina.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/311.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/312.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 18 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/33.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidorino](../pokemon/nidorino.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 19 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/234.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Stantler](../pokemon/stantler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 19 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/29.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nidoran♀](../pokemon/nidoran-f.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/416.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vespiquen](../pokemon/vespiquen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/438.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bonsly](../pokemon/bonsly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/439.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mime Jr.](../pokemon/mime-jr.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/plusle/">Plusle</a> — Lv. 18</li><li><a href="../../pokemon/minun/">Minun</a> — Lv. 18</li><li><a href="../../pokemon/nidorina/">Nidorina</a> — Lv. 19</li><li><a href="../../pokemon/nidorino/">Nidorino</a> — Lv. 19</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 18</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 19</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 19</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/plusle/">Plusle</a> — Lv. 18</li><li><a href="../../pokemon/minun/">Minun</a> — Lv. 18</li><li><a href="../../pokemon/nidorina/">Nidorina</a> — Lv. 19</li><li><a href="../../pokemon/nidorino/">Nidorino</a> — Lv. 19</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 18</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 19</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 19</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 15</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/plusle/">Plusle</a> — Lv. 18</li><li><a href="../../pokemon/minun/">Minun</a> — Lv. 18</li><li><a href="../../pokemon/nidorina/">Nidorina</a> — Lv. 19</li><li><a href="../../pokemon/nidorino/">Nidorino</a> — Lv. 19</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 18</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 19</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 19</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 15</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 13</li><li><a href="../../pokemon/nidoran-f/">Nidoran♀</a> — Lv. 12</li><li><a href="../../pokemon/nidoran-m/">Nidoran♂</a> — Lv. 12</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 13</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 15</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 13</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/plusle/">Plusle</a> — Lv. 18</li><li><a href="../../pokemon/minun/">Minun</a> — Lv. 18</li><li><a href="../../pokemon/nidorina/">Nidorina</a> — Lv. 19</li><li><a href="../../pokemon/nidorino/">Nidorino</a> — Lv. 19</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 18</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 17</li><li><a href="../../pokemon/combee/">Combee</a> — Lv. 18</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 19</li><li><a href="../../pokemon/stantler/">Stantler</a> — Lv. 19</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Vespiquen</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 32<span class="rw-diff-arrow">→</span>29</li><li>Name: Nidoran♂<span class="rw-diff-arrow">→</span>Nidoran♀</li><li>Slug: nidoran-m<span class="rw-diff-arrow">→</span>nidoran-f</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Bonsly</li><li>Mime Jr.</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `25`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-022/"><span class="rw-record-nav__label">← Route 35</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-026/"><span class="rw-record-nav__label">Route 37 →</span></a>
</nav>
