# Union Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>14</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Union Cave](../locations/header-099.md) | 99 | 210 | `D25R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandshrew](../pokemon/sandshrew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machop](../pokemon/machop.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 14 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 14 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandshrew](../pokemon/sandshrew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machop](../pokemon/machop.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 14 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 14 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandshrew](../pokemon/sandshrew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 12 (20%); 15 (5%) | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 13 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Machop](../pokemon/machop.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 14 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Aron](../pokemon/aron.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 14 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 14 | 5% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–30 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shellos](../pokemon/shellos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–35 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 30–35 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–15 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–15 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–15 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–30 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 30% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Loudred](../pokemon/loudred.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gible](../pokemon/gible.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Zubat — Lv. 5</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Rattata — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Whismur — Lv. 13</li><li>Geodude — Lv. 13</li><li>Makuhita — Lv. 14</li><li>Machop — Lv. 14</li><li>Sandshrew — Lv. 12</li><li>Zubat — Lv. 12</li><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Cubone — Lv. 14</li><li>Aron — Lv. 14</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Zubat — Lv. 5</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Rattata — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Whismur — Lv. 13</li><li>Geodude — Lv. 13</li><li>Makuhita — Lv. 14</li><li>Machop — Lv. 14</li><li>Sandshrew — Lv. 12</li><li>Zubat — Lv. 12</li><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Cubone — Lv. 14</li><li>Aron — Lv. 14</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Zubat — Lv. 5</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Rattata — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Whismur — Lv. 13</li><li>Geodude — Lv. 13</li><li>Makuhita — Lv. 14</li><li>Machop — Lv. 14</li><li>Sandshrew — Lv. 12</li><li>Zubat — Lv. 12</li><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Cubone — Lv. 14</li><li>Aron — Lv. 14</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Zubat — Lv. 5</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Sandshrew — Lv. 6</li><li>Geodude — Lv. 6</li><li>Onix — Lv. 6</li><li>Zubat — Lv. 7</li><li>Rattata — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Whismur — Lv. 13</li><li>Geodude — Lv. 13</li><li>Makuhita — Lv. 14</li><li>Machop — Lv. 14</li><li>Sandshrew — Lv. 12</li><li>Zubat — Lv. 12</li><li>Sandshrew — Lv. 15</li><li>Zubat — Lv. 15</li><li>Cubone — Lv. 14</li><li>Aron — Lv. 14</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Quagsire — Lv. 10–20</li><li>Quagsire — Lv. 15–25</li><li>Quagsire — Lv. 10–20</li><li>Quagsire — Lv. 10–20</li><li>Wooper — Lv. 10–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Gastrodon — Lv. 30–35</li><li>Shellos — Lv. 25–30</li><li>Gastrodon — Lv. 30–35</li><li>Quagsire — Lv. 25–35</li><li>Wooper — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Goldeen — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Barboach — Lv. 10–15</li><li>Barboach — Lv. 10–15</li><li>Goldeen — Lv. 10–15</li><li>Magikarp — Lv. 10–15</li><li>Barboach — Lv. 10–15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Goldeen — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Barboach — Lv. 25–30</li><li>Barboach — Lv. 25–30</li><li>Goldeen — Lv. 25–30</li><li>Magikarp — Lv. 25–30</li><li>Barboach — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 40</li><li>Whiscash — Lv. 40</li><li>Seaking — Lv. 40</li><li>Gyarados — Lv. 40</li><li>Whiscash — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Sandslash</li><li>Loudred</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Gible</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `14`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-132/"><span class="rw-record-nav__label">← Tohjo Falls</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-015/"><span class="rw-record-nav__label">Union Cave →</span></a>
</nav>
