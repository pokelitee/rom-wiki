# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Ilex Forest](../locations/header-117.md) | `header-117` | `D36R0101` |

## Common trees

=== "Sacred Gold"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3–5 | 60% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 3–5 | 10% |

=== "Storm Silver"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 3–5 | 60% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 3–5 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/14.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kakuna](../pokemon/kakuna.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 3–5 | 10% |

## Rare trees

=== "Sacred Gold"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6–8 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 10% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 10% |

=== "Storm Silver"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6–8 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 6–8 | 10% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 6–8 | 10% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (9, 81), (9, 80) |
| 1 | Regular | (9, 79), (9, 78) |
| 2 | Regular | (9, 77), (9, 76) |
| 3 | Regular | (9, 71), (9, 70) |
| 4 | Regular | (9, 69), (9, 68) |
| 5 | Regular | (9, 67), (9, 66) |
| 6 | Regular | (10, 63), (11, 63), (10, 61), (11, 61) |
| 7 | Regular | (12, 63), (13, 63), (12, 61), (13, 61) |
| 8 | Regular | (12, 75), (13, 75), (12, 74) |
| 9 | Regular | (16, 71), (17, 71) |
| 10 | Regular | (18, 71), (19, 71) |
| 11 | Regular | (22, 71), (23, 71) |
| 12 | Regular | (21, 67), (22, 67) |
| 13 | Regular | (37, 73), (37, 72) |
| 14 | Regular | (42, 71), (43, 71), (42, 69), (43, 69) |
| 15 | Regular | (28, 51), (29, 51) |
| 16 | Regular | (33, 61), (33, 60) |
| 17 | Regular | (33, 59), (33, 58) |
| 18 | Regular | (33, 55), (33, 54) |
| 19 | Regular | (42, 63), (43, 63), (42, 62) |
| 20 | Regular | (40, 59), (40, 58) |
| 21 | Regular | (40, 55), (40, 54) |
| 22 | Regular | (50, 55), (51, 55), (50, 54), (51, 54) |
| 23 | Regular | (46, 49), (47, 49), (47, 48) |
| 24 | Regular | (48, 47), (49, 47) |
| 25 | Regular | (9, 50), (9, 51) |
| 26 | Regular | (10, 43), (11, 43), (11, 42) |
| 27 | Regular | (12, 39), (13, 39), (13, 38) |
| 28 | Regular | (22, 33), (23, 33), (23, 32), (23, 31), (22, 31) |
| 29 | Regular | (28, 33), (29, 33), (29, 34), (29, 35) |
| 30 | Regular | (30, 25), (31, 25) |
| 31 | Regular | (34, 29), (35, 29) |
| 32 | Regular | (36, 29), (37, 29), (37, 28), (37, 27), (36, 27) |
| 33 | Regular | (32, 19), (33, 19) |
| 34 | Regular | (34, 19), (35, 19) |
| 35 | Regular | (40, 25), (40, 24), (40, 23), (41, 23) |
| 36 | Regular | (50, 25), (51, 25), (51, 26), (51, 27) |
| 37 | Regular | (54, 31), (54, 30) |
| 38 | Regular | (42, 39), (43, 39) |
| 39 | Regular | (48, 21), (49, 21) |
| 40 | Regular | (40, 16), (41, 16), (40, 15), (41, 15), (40, 14), (41, 14) |
| 41 | Regular | (32, 9), (33, 9) |
| 42 | Regular | (36, 9), (37, 9) |
| 43 | Regular | (38, 9), (39, 9) |
| 44 | Regular | (24, 19), (25, 19), (24, 17), (25, 17) |
| 45 | Regular | (20, 21), (21, 21) |
| 46 | Regular | (16, 21), (17, 21), (16, 20) |
| 47 | Regular | (9, 25), (9, 24) |
| 48 | Regular | (9, 23), (9, 22) |
| 49 | Regular | (34, 35), (35, 35), (34, 33), (35, 33) |
| 50 | Regular | (36, 35), (37, 35), (36, 33), (37, 33) |
| 51 | Regular | (38, 39), (38, 38) |
| 52 | Regular | (38, 37), (38, 36) |
| 53 | Regular | (50, 47), (51, 47) |
| 54 | Regular | (52, 47), (53, 47) |
| 55 | Regular | (46, 35), (47, 35) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `117`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-096/"><span class="rw-record-nav__label">← Headbutt encounters — National Park</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-147/"><span class="rw-record-nav__label">Headbutt encounters — Viridian Forest →</span></a>
</nav>
