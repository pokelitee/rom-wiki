# Route 2

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>112</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 2](../locations/header-010.md) | `header-010` | 150 | `R02` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/166.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 46–47 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/166.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 46–47 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/168.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ariados](../pokemon/ariados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/193.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Yanma](../pokemon/yanma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 46–47 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/18.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeot](../pokemon/pidgeot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/191.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sunkern](../pokemon/sunkern.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 10</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 7</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 49</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 49</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 45</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 47</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 48</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 47</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 47</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 48</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 48</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 10</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 7</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 49</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 49</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 45</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 47</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 48</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 47</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 47</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 48</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 48</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 10</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 7</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 7</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 49</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 49</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 45</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 47</li><li><a href="../../pokemon/ledian/">Ledian</a> — Lv. 48</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 47</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 47</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 48</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 48</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">11 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 4</li><li><a href="../../pokemon/ariados/">Ariados</a> — Lv. 7</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 3</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 3</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 5</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 3</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 3</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 10</li><li><a href="../../pokemon/ariados/">Ariados</a> — Lv. 7</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 7</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 49</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 49</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 45</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 47</li><li><a href="../../pokemon/ariados/">Ariados</a> — Lv. 47</li><li><a href="../../pokemon/ariados/">Ariados</a> — Lv. 48</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 47</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 47</li><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 48</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 48</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 46</li><li><a href="../../pokemon/yanma/">Yanma</a> — Lv. 47</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Pidgeot</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 10<span class="rw-diff-arrow">→</span>13</li><li>Name: Caterpie<span class="rw-diff-arrow">→</span>Weedle</li><li>Slug: caterpie<span class="rw-diff-arrow">→</span>weedle</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Sunkern</li><li>Budew</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `112`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-093/"><span class="rw-record-nav__label">← Route 19</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-136/"><span class="rw-record-nav__label">Route 2 →</span></a>
</nav>
