# Route 39

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>39</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 39](../locations/header-043.md) | `header-043` | 187 | `R39` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/239.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/100.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Voltorb](../pokemon/voltorb.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/52.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meowth](../pokemon/meowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/241.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Miltank](../pokemon/miltank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/128.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tauros](../pokemon/tauros.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 28 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/300.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 27 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/52.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meowth](../pokemon/meowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/57.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/300.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skitty](../pokemon/skitty.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/420.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherubi](../pokemon/cherubi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Rattata — Lv. 16</li><li>Magnemite — Lv. 16</li><li>Raticate — Lv. 17</li><li>Rattata — Lv. 16</li><li>Raticate — Lv. 17</li><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Farfetch&#x27;d — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Voltorb — Lv. 27</li><li>Elekid — Lv. 27</li><li>Cherubi — Lv. 27</li><li>Mankey — Lv. 27</li><li>Ponyta — Lv. 27</li><li>Raticate — Lv. 28</li><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Tauros — Lv. 28</li><li>Miltank — Lv. 28</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Rattata — Lv. 16</li><li>Magnemite — Lv. 16</li><li>Raticate — Lv. 17</li><li>Rattata — Lv. 16</li><li>Raticate — Lv. 17</li><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Farfetch&#x27;d — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Voltorb — Lv. 27</li><li>Elekid — Lv. 27</li><li>Cherubi — Lv. 27</li><li>Mankey — Lv. 27</li><li>Ponyta — Lv. 27</li><li>Raticate — Lv. 28</li><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Tauros — Lv. 28</li><li>Miltank — Lv. 28</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Rattata — Lv. 16</li><li>Magnemite — Lv. 16</li><li>Raticate — Lv. 17</li><li>Rattata — Lv. 16</li><li>Raticate — Lv. 17</li><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Farfetch&#x27;d — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Voltorb — Lv. 27</li><li>Elekid — Lv. 27</li><li>Cherubi — Lv. 27</li><li>Mankey — Lv. 27</li><li>Ponyta — Lv. 27</li><li>Raticate — Lv. 28</li><li>Farfetch&#x27;d — Lv. 27</li><li>Pidgeotto — Lv. 28</li><li>Tauros — Lv. 28</li><li>Miltank — Lv. 28</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Rattata — Lv. 16</li><li>Magnemite — Lv. 16</li><li>Raticate — Lv. 17</li><li>Rattata — Lv. 16</li><li>Raticate — Lv. 17</li><li>Tauros — Lv. 15</li><li>Miltank — Lv. 15</li><li>Rattata — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Skitty — Lv. 27</li><li>Farfetch&#x27;d — Lv. 28</li><li>Voltorb — Lv. 27</li><li>Elekid — Lv. 27</li><li>Meowth — Lv. 27</li><li>Mankey — Lv. 27</li><li>Ponyta — Lv. 27</li><li>Raticate — Lv. 28</li><li>Skitty — Lv. 27</li><li>Farfetch&#x27;d — Lv. 28</li><li>Tauros — Lv. 28</li><li>Miltank — Lv. 28</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Primeape</li><li>Rapidash</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 19<span class="rw-diff-arrow">→</span>52</li><li>Name: Rattata<span class="rw-diff-arrow">→</span>Meowth</li><li>Slug: rattata<span class="rw-diff-arrow">→</span>meowth</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Skitty</li><li>Cherubi</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `39`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-038/"><span class="rw-record-nav__label">← Route 38</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-114/"><span class="rw-record-nav__label">Route 4 →</span></a>
</nav>
