# Burned Tower

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>29</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Burned Tower](../locations/header-217.md) | `header-217` | 206 | `D18R0102` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/240.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magby](../pokemon/magby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/240.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magby](../pokemon/magby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/109.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Koffing](../pokemon/koffing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/240.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magby](../pokemon/magby.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 23 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/355.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Duskull](../pokemon/duskull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/353.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shuppet](../pokemon/shuppet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 23–24 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/110.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weezing](../pokemon/weezing.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/126.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magmar](../pokemon/magmar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/358.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 16</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 23</li><li><a href="../../pokemon/magby/">Magby</a> — Lv. 23</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 23</li><li><a href="../../pokemon/linoone/">Linoone</a> — Lv. 24</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 23</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 23</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 23</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 16</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 23</li><li><a href="../../pokemon/magby/">Magby</a> — Lv. 23</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 23</li><li><a href="../../pokemon/linoone/">Linoone</a> — Lv. 24</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 23</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 23</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 23</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 16</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 23</li><li><a href="../../pokemon/magby/">Magby</a> — Lv. 23</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 23</li><li><a href="../../pokemon/linoone/">Linoone</a> — Lv. 24</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 23</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 23</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 23</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 16</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li><li><a href="../../pokemon/magmar/">Magmar</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 23</li><li><a href="../../pokemon/magby/">Magby</a> — Lv. 23</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 23</li><li><a href="../../pokemon/linoone/">Linoone</a> — Lv. 24</li><li><a href="../../pokemon/koffing/">Koffing</a> — Lv. 23</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 24</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 24</li><li><a href="../../pokemon/shuppet/">Shuppet</a> — Lv. 23</li><li><a href="../../pokemon/duskull/">Duskull</a> — Lv. 23</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Zigzagoon</li><li>Spinda</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Weezing</li><li>Magmar</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Meditite</li><li>Chatot</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Chimecho</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `29`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-028/"><span class="rw-record-nav__label">← Burned Tower</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-099/"><span class="rw-record-nav__label">Celadon City →</span></a>
</nav>
