# Ruins of Alph

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>9</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#rock-smash">Rock Smash</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Ruins of Alph](../locations/header-113.md) | `header-113` | 209 | `D24R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–30 | 90% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–35 | 10% |

## Rock Smash

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–15 | 80% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 12–15 | 20% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–12 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–12 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 10–12 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 25–30 | 25% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 25–35 | 5% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Relicanth](../pokemon/relicanth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 40 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Togepi](../pokemon/togepi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>8 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 18</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Smeargle — Lv. 26</li><li>Smeargle — Lv. 27</li><li>Smeargle — Lv. 28</li><li>Smeargle — Lv. 29</li><li>Natu — Lv. 26</li><li>Natu — Lv. 27</li><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Girafarig — Lv. 28</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 18</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Smeargle — Lv. 26</li><li>Smeargle — Lv. 27</li><li>Smeargle — Lv. 28</li><li>Smeargle — Lv. 29</li><li>Natu — Lv. 26</li><li>Natu — Lv. 27</li><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Girafarig — Lv. 28</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 18</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Smeargle — Lv. 26</li><li>Smeargle — Lv. 27</li><li>Smeargle — Lv. 28</li><li>Smeargle — Lv. 29</li><li>Natu — Lv. 26</li><li>Natu — Lv. 27</li><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Girafarig — Lv. 28</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 18</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Natu — Lv. 20</li><li>Natu — Lv. 22</li><li>Smeargle — Lv. 20</li><li>Smeargle — Lv. 22</li><li>Natu — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Smeargle — Lv. 26</li><li>Smeargle — Lv. 27</li><li>Smeargle — Lv. 28</li><li>Smeargle — Lv. 29</li><li>Natu — Lv. 26</li><li>Natu — Lv. 27</li><li>Girafarig — Lv. 28</li><li>Girafarig — Lv. 30</li><li>Girafarig — Lv. 28</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Quagsire — Lv. 10–20</li><li>Quagsire — Lv. 15–25</li><li>Quagsire — Lv. 10–20</li><li>Quagsire — Lv. 10–20</li><li>Wooper — Lv. 10–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Quagsire — Lv. 25–35</li><li>Wooper — Lv. 25–30</li><li>Quagsire — Lv. 25–35</li><li>Quagsire — Lv. 25–35</li><li>Wooper — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Rock Smash</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 3–6</li><li>Geodude — Lv. 8–14</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Nosepass — Lv. 12–15</li><li>Geodude — Lv. 10–15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Poliwag — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 10–12</li><li>Dratini — Lv. 10–12</li><li>Remoraid — Lv. 10–12</li><li>Magikarp — Lv. 10–12</li><li>Dratini — Lv. 10–12</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Poliwag — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Dratini — Lv. 25–30</li><li>Dratini — Lv. 25–30</li><li>Remoraid — Lv. 25–30</li><li>Magikarp — Lv. 25–30</li><li>Dragonair — Lv. 25–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Poliwag — Lv. 40</li><li>Poliwag — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Octillery — Lv. 40</li><li>Dragonair — Lv. 40</li><li>Relicanth — Lv. 40</li><li>Gyarados — Lv. 40</li><li>Octillery — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Xatu</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Togepi</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `9`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-119/"><span class="rw-record-nav__label">← Route 9</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-010/"><span class="rw-record-nav__label">Ruins of Alph →</span></a>
</nav>
