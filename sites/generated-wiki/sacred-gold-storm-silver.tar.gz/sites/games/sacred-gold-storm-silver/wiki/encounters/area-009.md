# Ruins of Alph

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>9</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#rock-smash">Rock Smash</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Ruins of Alph](../locations/header-113.md) | `header-113` | 209 | `D24R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/235.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/235.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/235.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smeargle](../pokemon/smeargle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–29 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 28–30 | 20% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–30 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–35 | 10% |

## Rock Smash

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–15 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/299.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nosepass](../pokemon/nosepass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span></span> | 12–15 | 20% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–12 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–12 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 10–12 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/223.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 25–30 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/148.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 25–35 | 5% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/130.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/369.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Relicanth](../pokemon/relicanth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--rock">Rock</span></span> | 40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/148.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dragonair](../pokemon/dragonair.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 40 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/224.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/178.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Xatu](../pokemon/xatu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/175.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Togepi](../pokemon/togepi.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>8 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 18</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 26</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 27</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 28</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 29</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 26</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 27</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 18</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 26</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 27</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 28</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 29</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 26</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 27</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 18</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 26</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 27</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 28</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 29</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 26</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 27</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 18</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 20</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 22</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 20</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 22</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 24</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 26</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 27</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 28</li><li><a href="../../pokemon/smeargle/">Smeargle</a> — Lv. 29</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 26</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 27</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 30</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 28</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 10–20</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 15–25</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 10–20</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 10–20</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 10–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 25–35</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 25–30</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 25–35</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 25–35</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Rock Smash</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 3–6</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8–14</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/nosepass/">Nosepass</a> — Lv. 12–15</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10–15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 10–12</li><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 10–12</li><li><a href="../../pokemon/remoraid/">Remoraid</a> — Lv. 10–12</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–12</li><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 10–12</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 25–30</li><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 25–30</li><li><a href="../../pokemon/remoraid/">Remoraid</a> — Lv. 25–30</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 25–30</li><li><a href="../../pokemon/dragonair/">Dragonair</a> — Lv. 25–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/octillery/">Octillery</a> — Lv. 40</li><li><a href="../../pokemon/dragonair/">Dragonair</a> — Lv. 40</li><li><a href="../../pokemon/relicanth/">Relicanth</a> — Lv. 40</li><li><a href="../../pokemon/gyarados/">Gyarados</a> — Lv. 40</li><li><a href="../../pokemon/octillery/">Octillery</a> — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Xatu</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Togepi</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `9`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-119/"><span class="rw-record-nav__label">← Route 9</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-010/"><span class="rw-record-nav__label">Ruins of Alph →</span></a>
</nav>
