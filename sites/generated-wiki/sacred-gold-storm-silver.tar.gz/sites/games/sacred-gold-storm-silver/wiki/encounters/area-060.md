# Ice Path

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>60</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Ice Path](../locations/header-120.md) | `header-120` | 217 | `D39R0101` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 39–40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38–39 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/459.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snover](../pokemon/snover.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ice">Ice</span></span> | 38–39 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 37–38 | 5% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 39–40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38–39 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/459.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snover](../pokemon/snover.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ice">Ice</span></span> | 38–39 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 37–38 | 5% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 39–40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 38–39 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/363.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spheal](../pokemon/spheal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 38 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/459.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snover](../pokemon/snover.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--ice">Ice</span></span> | 38–39 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 37–38 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/220.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swinub](../pokemon/swinub.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/238.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Smoochum](../pokemon/smoochum.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 38</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 38</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 39</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 40</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 38</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 39</li><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 37</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 39</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 38</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 38</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 39</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 40</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 38</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 39</li><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 37</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 39</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 38</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 38</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 39</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 40</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 38</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 39</li><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 37</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 39</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 21</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 22</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 22</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 22</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 23</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/spheal/">Spheal</a> — Lv. 38</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 38</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 39</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 40</li><li><a href="../../pokemon/swinub/">Swinub</a> — Lv. 38</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 39</li><li><a href="../../pokemon/smoochum/">Smoochum</a> — Lv. 37</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 38</li><li><a href="../../pokemon/snover/">Snover</a> — Lv. 39</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Piloswine</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Smoochum</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `60`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-100/"><span class="rw-record-nav__label">← Fuchsia City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-061/"><span class="rw-record-nav__label">Ice Path →</span></a>
</nav>
