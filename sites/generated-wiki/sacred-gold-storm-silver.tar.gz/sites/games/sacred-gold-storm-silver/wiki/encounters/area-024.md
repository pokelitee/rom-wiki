# National Park

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>24</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [National Park](../locations/header-487.md) | `header-487` | 207 | `D22R0102` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10–14 | 100% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10–14 | 100% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10–14 | 100% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li></ul><p class="rw-comparison-count">8 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li></ul><p class="rw-comparison-count">8 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li></ul><p class="rw-comparison-count">8 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 10</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 14</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 12</li></ul><p class="rw-comparison-count">8 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 10</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 14</li><li><a href="../../pokemon/weedle/">Weedle</a> — Lv. 12</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Caterpie</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Weedle</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 10<span class="rw-diff-arrow">→</span>13</li><li>Name: Caterpie<span class="rw-diff-arrow">→</span>Weedle</li><li>Slug: caterpie<span class="rw-diff-arrow">→</span>weedle</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Caterpie</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Weedle</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `24`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-023/"><span class="rw-record-nav__label">← National Park</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-000/"><span class="rw-record-nav__label">New Bark Town →</span></a>
</nav>
