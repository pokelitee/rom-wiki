# Route 6

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>116</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 6](../locations/header-014.md) | `header-014` | 154 | `R06` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 45–48 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/421.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 45–48 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/53.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Persian](../pokemon/persian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 45–48 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 46–47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 45–48 | 10% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–65 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35–50 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 85% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 60% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 70% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/293.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whismur](../pokemon/whismur.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>5 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 48</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 46</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 46</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 45</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 48</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 48</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 48</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 46</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 46</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 45</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 48</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 48</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 14</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 13</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 47</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 48</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 46</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 46</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 47</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 45</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 45</li><li><a href="../../pokemon/cherrim/">Cherrim</a> — Lv. 46</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 48</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 48</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/oddish/">Oddish</a> — Lv. 13</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 14</li><li><a href="../../pokemon/oddish/">Oddish</a> — Lv. 13</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 12</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 14</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 15</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 47</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 48</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 46</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 46</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 47</li><li><a href="../../pokemon/persian/">Persian</a> — Lv. 45</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 45</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 45</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 46</li><li><a href="../../pokemon/persian/">Persian</a> — Lv. 48</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 48</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 10</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 5</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 10</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 10</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 35</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 20–50</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 30–40</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 35–50</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 10–65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 50</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 50</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 50</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 50</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `116`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-115/"><span class="rw-record-nav__label">← Route 5</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-117/"><span class="rw-record-nav__label">Route 7 →</span></a>
</nav>
