# Route 18

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>127</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 18](../locations/header-026.md) | `header-026` | 166 | `R18` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/316.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gulpin](../pokemon/gulpin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50–53 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/219.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magcargo](../pokemon/magcargo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--rock">Rock</span></span> | 52–56 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/316.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gulpin](../pokemon/gulpin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50–53 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/219.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magcargo](../pokemon/magcargo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--rock">Rock</span></span> | 52–56 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/316.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gulpin](../pokemon/gulpin.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 50–53 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/89.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Muk](../pokemon/muk.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/198.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/219.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magcargo](../pokemon/magcargo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--rock">Rock</span></span> | 52–56 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/88.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grimer](../pokemon/grimer.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/317.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Swalot](../pokemon/swalot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/430.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Honchkrow](../pokemon/honchkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/291.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ninjask](../pokemon/ninjask.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 28</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 29</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 54</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 56</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 50</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 51</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 55</li><li><a href="../../pokemon/gulpin/">Gulpin</a> — Lv. 50</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 53</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 52</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 53</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 53</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 28</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 29</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 54</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 56</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 50</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 51</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 55</li><li><a href="../../pokemon/gulpin/">Gulpin</a> — Lv. 50</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 53</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 52</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 53</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 53</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 55</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 28</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 29</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 54</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 56</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 50</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 51</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 55</li><li><a href="../../pokemon/gulpin/">Gulpin</a> — Lv. 50</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 53</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 52</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 53</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 53</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 55</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 27</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 28</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 26</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 30</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 29</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 54</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 56</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 50</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 51</li><li><a href="../../pokemon/muk/">Muk</a> — Lv. 55</li><li><a href="../../pokemon/gulpin/">Gulpin</a> — Lv. 50</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 53</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 52</li><li><a href="../../pokemon/magcargo/">Magcargo</a> — Lv. 53</li><li><a href="../../pokemon/grimer/">Grimer</a> — Lv. 53</li><li><a href="../../pokemon/murkrow/">Murkrow</a> — Lv. 55</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Swalot</li><li>Honchkrow</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Ninjask</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `127`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-126/"><span class="rw-record-nav__label">← Route 17</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-093/"><span class="rw-record-nav__label">Route 19 →</span></a>
</nav>
