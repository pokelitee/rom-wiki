# Seafoam Islands

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>75</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Seafoam Islands](../locations/header-453.md) | `header-453` | 203 | `D11R0102` |

## Walking (Morning)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 49–51 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/80.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowbro](../pokemon/slowbro.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/361.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 50–52 | 15% |

## Walking (Day)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 49–51 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/80.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowbro](../pokemon/slowbro.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/361.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 50–52 | 15% |

## Walking (Night)

Encounter rate: 5

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 49–51 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/80.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowbro](../pokemon/slowbro.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 58–59 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/361.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Snorunt](../pokemon/snorunt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span></span> | 50–52 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/86.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seel](../pokemon/seel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/478.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Froslass](../pokemon/froslass.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ghost">Ghost</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Psyduck — Lv. 26</li><li>Psyduck — Lv. 27</li><li>Psyduck — Lv. 28</li><li>Golbat — Lv. 32</li><li>Golduck — Lv. 34</li><li>Seel — Lv. 34</li><li>Seel — Lv. 32</li><li>Golbat — Lv. 34</li><li>Psyduck — Lv. 28</li><li>Golduck — Lv. 32</li><li>Zubat — Lv. 28</li><li>Zubat — Lv. 29</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Snorunt — Lv. 50</li><li>Snorunt — Lv. 52</li><li>Piloswine — Lv. 58</li><li>Slowbro — Lv. 58</li><li>Piloswine — Lv. 59</li><li>Slowbro — Lv. 59</li><li>Seel — Lv. 49</li><li>Golbat — Lv. 57</li><li>Snorunt — Lv. 51</li><li>Snorunt — Lv. 52</li><li>Snorunt — Lv. 50</li><li>Seel — Lv. 51</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Psyduck — Lv. 26</li><li>Psyduck — Lv. 27</li><li>Psyduck — Lv. 28</li><li>Golbat — Lv. 32</li><li>Golduck — Lv. 34</li><li>Seel — Lv. 34</li><li>Seel — Lv. 32</li><li>Golbat — Lv. 34</li><li>Psyduck — Lv. 28</li><li>Golduck — Lv. 32</li><li>Zubat — Lv. 28</li><li>Zubat — Lv. 29</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Snorunt — Lv. 50</li><li>Snorunt — Lv. 52</li><li>Piloswine — Lv. 58</li><li>Slowbro — Lv. 58</li><li>Piloswine — Lv. 59</li><li>Slowbro — Lv. 59</li><li>Seel — Lv. 49</li><li>Golbat — Lv. 57</li><li>Snorunt — Lv. 51</li><li>Snorunt — Lv. 52</li><li>Snorunt — Lv. 50</li><li>Seel — Lv. 51</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Psyduck — Lv. 26</li><li>Psyduck — Lv. 27</li><li>Psyduck — Lv. 28</li><li>Golbat — Lv. 32</li><li>Golduck — Lv. 34</li><li>Seel — Lv. 34</li><li>Seel — Lv. 32</li><li>Golbat — Lv. 34</li><li>Psyduck — Lv. 28</li><li>Golduck — Lv. 32</li><li>Zubat — Lv. 28</li><li>Zubat — Lv. 29</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Snorunt — Lv. 50</li><li>Snorunt — Lv. 52</li><li>Piloswine — Lv. 58</li><li>Slowbro — Lv. 58</li><li>Piloswine — Lv. 59</li><li>Slowbro — Lv. 59</li><li>Seel — Lv. 49</li><li>Golbat — Lv. 57</li><li>Snorunt — Lv. 51</li><li>Snorunt — Lv. 52</li><li>Snorunt — Lv. 50</li><li>Seel — Lv. 51</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Psyduck — Lv. 26</li><li>Psyduck — Lv. 27</li><li>Psyduck — Lv. 28</li><li>Golbat — Lv. 32</li><li>Golduck — Lv. 34</li><li>Seel — Lv. 34</li><li>Seel — Lv. 32</li><li>Golbat — Lv. 34</li><li>Psyduck — Lv. 28</li><li>Golduck — Lv. 32</li><li>Zubat — Lv. 28</li><li>Zubat — Lv. 29</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Snorunt — Lv. 50</li><li>Snorunt — Lv. 52</li><li>Piloswine — Lv. 58</li><li>Slowbro — Lv. 58</li><li>Piloswine — Lv. 59</li><li>Slowbro — Lv. 59</li><li>Seel — Lv. 49</li><li>Golbat — Lv. 57</li><li>Snorunt — Lv. 51</li><li>Snorunt — Lv. 52</li><li>Snorunt — Lv. 50</li><li>Seel — Lv. 51</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Glalie</li><li>Froslass</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Golduck</li><li>Kingler</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `75`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-074/"><span class="rw-record-nav__label">← Seafoam Islands</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-076/"><span class="rw-record-nav__label">Seafoam Islands →</span></a>
</nav>
