# Safari Zone encounters

Safari area types can be moved among the zone's physical positions. The sections below therefore describe area configurations rather than assigning them to fixed map headers.

These area types occupy 14 physical maps: [header-343](../locations/header-343.md) / [header-344](../locations/header-344.md) / [header-345](../locations/header-345.md) / [header-346](../locations/header-346.md) / [header-347](../locations/header-347.md) / [header-348](../locations/header-348.md) / [header-349](../locations/header-349.md) / [header-350](../locations/header-350.md) / [header-351](../locations/header-351.md) / [header-352](../locations/header-352.md) / [header-353](../locations/header-353.md) / [header-354](../locations/header-354.md) / [header-355](../locations/header-355.md) / [header-356](../locations/header-356.md). Which map currently holds which area is player-configurable and not decoded here.

## Areas

- [Plains](safari-zone-00.md)
- [Meadow](safari-zone-01.md)
- [Savannah](safari-zone-02.md)
- [Peak](safari-zone-03.md)
- [Rocky Beach](safari-zone-04.md)
- [Wetland](safari-zone-05.md)
- [Forest](safari-zone-06.md)
- [Swamp](safari-zone-07.md)
- [Marshland](safari-zone-08.md)
- [Wasteland](safari-zone-09.md)
- [Mountain](safari-zone-10.md)
- [Desert](safari-zone-11.md)

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/3/0` member `0`.
Source: exact ROM record from `a/2/3/0` member `1`.
Source: exact ROM record from `a/2/3/0` member `2`.
Source: exact ROM record from `a/2/3/0` member `3`.
Source: exact ROM record from `a/2/3/0` member `4`.
Source: exact ROM record from `a/2/3/0` member `5`.
Source: exact ROM record from `a/2/3/0` member `6`.
Source: exact ROM record from `a/2/3/0` member `7`.
Source: exact ROM record from `a/2/3/0` member `8`.
Source: exact ROM record from `a/2/3/0` member `9`.
Source: exact ROM record from `a/2/3/0` member `10`.
Source: exact ROM record from `a/2/3/0` member `11`.
Each member stores ten base slots per method and time of day, followed by block-conditioned records with up to two stored requirements.
Area types can be assigned to different physical Safari Zone positions, so this page does not invent map-header ownership or replacement priority.

</details>
