# Safari Zone encounters

Safari area types can be moved among the zone's physical positions. The sections below therefore describe area configurations rather than assigning them to fixed map headers.

## Plains { #plains }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Rattata](../pokemon/rattata.md) (Lv. 15) | [Rattata](../pokemon/rattata.md) (Lv. 15) | [Raticate](../pokemon/raticate.md) (Lv. 15) |
| 2 | [Abra](../pokemon/abra.md) (Lv. 15) | [Abra](../pokemon/abra.md) (Lv. 15) | [Abra](../pokemon/abra.md) (Lv. 15) |
| 3 | [Girafarig](../pokemon/girafarig.md) (Lv. 15) | [Girafarig](../pokemon/girafarig.md) (Lv. 15) | [Girafarig](../pokemon/girafarig.md) (Lv. 15) |
| 4 | [Rattata](../pokemon/rattata.md) (Lv. 16) | [Rattata](../pokemon/rattata.md) (Lv. 16) | [Raticate](../pokemon/raticate.md) (Lv. 16) |
| 5 | [Abra](../pokemon/abra.md) (Lv. 16) | [Abra](../pokemon/abra.md) (Lv. 16) | [Abra](../pokemon/abra.md) (Lv. 16) |
| 6 | [Girafarig](../pokemon/girafarig.md) (Lv. 16) | [Girafarig](../pokemon/girafarig.md) (Lv. 16) | [Girafarig](../pokemon/girafarig.md) (Lv. 16) |
| 7 | [Rattata](../pokemon/rattata.md) (Lv. 17) | [Rattata](../pokemon/rattata.md) (Lv. 17) | [Raticate](../pokemon/raticate.md) (Lv. 17) |
| 8 | [Abra](../pokemon/abra.md) (Lv. 17) | [Abra](../pokemon/abra.md) (Lv. 17) | [Abra](../pokemon/abra.md) (Lv. 17) |
| 9 | [Girafarig](../pokemon/girafarig.md) (Lv. 17) | [Girafarig](../pokemon/girafarig.md) (Lv. 17) | [Stantler](../pokemon/stantler.md) (Lv. 17) |
| 10 | [Smeargle](../pokemon/smeargle.md) (Lv. 17) | [Smeargle](../pokemon/smeargle.md) (Lv. 17) | [Stantler](../pokemon/stantler.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Girafarig](../pokemon/girafarig.md) (Lv. 40) | [Girafarig](../pokemon/girafarig.md) (Lv. 40) | [Stantler](../pokemon/stantler.md) (Lv. 40) |
| 10 Plains | [Shinx](../pokemon/shinx.md) (Lv. 43) | [Shinx](../pokemon/shinx.md) (Lv. 43) | [Shinx](../pokemon/shinx.md) (Lv. 44) |
| 15 Plains | [Manectric](../pokemon/manectric.md) (Lv. 45) | [Manectric](../pokemon/manectric.md) (Lv. 45) | [Manectric](../pokemon/manectric.md) (Lv. 45) |
| 3 Forest | [Smeargle](../pokemon/smeargle.md) (Lv. 41) | [Smeargle](../pokemon/smeargle.md) (Lv. 41) | [Stantler](../pokemon/stantler.md) (Lv. 41) |
| 15 Forest | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 44) | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 44) | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 44) |
| 5 Peak | [Ponyta](../pokemon/ponyta.md) (Lv. 42) | [Ponyta](../pokemon/ponyta.md) (Lv. 42) | [Ponyta](../pokemon/ponyta.md) (Lv. 42) |
| 10 Peak | [Houndoom](../pokemon/houndoom.md) (Lv. 43) | [Houndoom](../pokemon/houndoom.md) (Lv. 43) | [Houndoom](../pokemon/houndoom.md) (Lv. 44) |
| 15 Peak | [Zangoose](../pokemon/zangoose.md) (Lv. 43) | [Zangoose](../pokemon/zangoose.md) (Lv. 43) | [Zangoose](../pokemon/zangoose.md) (Lv. 45) |
| 12 Waterside | [Lotad](../pokemon/lotad.md) (Lv. 42) | [Lotad](../pokemon/lotad.md) (Lv. 42) | [Lotad](../pokemon/lotad.md) (Lv. 42) |
| 28 Waterside | [Surskit](../pokemon/surskit.md) (Lv. 46) | [Surskit](../pokemon/surskit.md) (Lv. 46) | [Surskit](../pokemon/surskit.md) (Lv. 46) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Meadow { #meadow }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 15) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 15) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 15) |
| 2 | [Hoppip](../pokemon/hoppip.md) (Lv. 15) | [Sunkern](../pokemon/sunkern.md) (Lv. 15) | [Marill](../pokemon/marill.md) (Lv. 15) |
| 3 | [Hoppip](../pokemon/hoppip.md) (Lv. 15) | [Hoppip](../pokemon/hoppip.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 4 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) |
| 5 | [Hoppip](../pokemon/hoppip.md) (Lv. 16) | [Sunkern](../pokemon/sunkern.md) (Lv. 16) | [Marill](../pokemon/marill.md) (Lv. 16) |
| 6 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) | [Hoppip](../pokemon/hoppip.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 7 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) |
| 8 | [Hoppip](../pokemon/hoppip.md) (Lv. 17) | [Sunkern](../pokemon/sunkern.md) (Lv. 17) | [Marill](../pokemon/marill.md) (Lv. 17) |
| 9 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) | [Hoppip](../pokemon/hoppip.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) |
| 10 | [Skiploom](../pokemon/skiploom.md) (Lv. 17) | [Skiploom](../pokemon/skiploom.md) (Lv. 17) | [Clefairy](../pokemon/clefairy.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 5 Plains | [Raticate](../pokemon/raticate.md) (Lv. 40) | [Raticate](../pokemon/raticate.md) (Lv. 40) | [Raticate](../pokemon/raticate.md) (Lv. 40) |
| 12 Plains | [Chansey](../pokemon/chansey.md) (Lv. 42) | [Chansey](../pokemon/chansey.md) (Lv. 42) | [Chansey](../pokemon/chansey.md) (Lv. 42) |
| 35 Plains | [Seedot](../pokemon/seedot.md) (Lv. 45) | [Seedot](../pokemon/seedot.md) (Lv. 45) | [Seedot](../pokemon/seedot.md) (Lv. 45) |
| 8 Forest | [Skiploom](../pokemon/skiploom.md) (Lv. 40) | [Skiploom](../pokemon/skiploom.md) (Lv. 40) | [Skiploom](../pokemon/skiploom.md) (Lv. 40) |
| 28 Forest | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 38) | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 38) | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 38) |
| 35 Forest | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 48) | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 47) | [Nuzleaf](../pokemon/nuzleaf.md) (Lv. 47) |
| 3 Peak | [Geodude](../pokemon/geodude.md) (Lv. 45) | [Geodude](../pokemon/geodude.md) (Lv. 45) | [Clefairy](../pokemon/clefairy.md) (Lv. 42) |
| 35 Peak | [Nosepass](../pokemon/nosepass.md) (Lv. 45) | [Nosepass](../pokemon/nosepass.md) (Lv. 45) | [Nosepass](../pokemon/nosepass.md) (Lv. 45) |
| 42 Peak, 28 Forest | [Riolu](../pokemon/riolu.md) (Lv. 45) | [Riolu](../pokemon/riolu.md) (Lv. 46) | [Riolu](../pokemon/riolu.md) (Lv. 45) |
| 3 Waterside | [Wooper](../pokemon/wooper.md) (Lv. 40) | [Wooper](../pokemon/wooper.md) (Lv. 40) | [Wooper](../pokemon/wooper.md) (Lv. 40) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 7 | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 8 | [Wooper](../pokemon/wooper.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) |
| 9 | [Marill](../pokemon/marill.md) (Lv. 16) | [Marill](../pokemon/marill.md) (Lv. 16) | [Marill](../pokemon/marill.md) (Lv. 16) |
| 10 | [Marill](../pokemon/marill.md) (Lv. 17) | [Marill](../pokemon/marill.md) (Lv. 17) | [Marill](../pokemon/marill.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Waterside | [Skiploom](../pokemon/skiploom.md) (Lv. 47) | [Skiploom](../pokemon/skiploom.md) (Lv. 47) | [Skiploom](../pokemon/skiploom.md) (Lv. 47) |
| 10 Waterside | [Masquerain](../pokemon/masquerain.md) (Lv. 42) | [Masquerain](../pokemon/masquerain.md) (Lv. 42) | [Masquerain](../pokemon/masquerain.md) (Lv. 42) |
| 14 Waterside | [Masquerain](../pokemon/masquerain.md) (Lv. 46) | [Masquerain](../pokemon/masquerain.md) (Lv. 46) | [Masquerain](../pokemon/masquerain.md) (Lv. 46) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 7 | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) |
| 8 | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) |
| 9 | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) |
| 10 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Waterside | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 15) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 15) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 15) |
| 3 Waterside | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) |
| 6 | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) |
| 7 | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) |
| 8 | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) |
| 9 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) |
| 10 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 5 Waterside | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 27) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 27) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 27) |
| 7 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 28) | [Gyarados](../pokemon/gyarados.md) (Lv. 28) | [Gyarados](../pokemon/gyarados.md) (Lv. 28) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) |
| 2 | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) |
| 3 | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) |
| 4 | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) |
| 5 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 6 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 7 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 9 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) |
| 10 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 42) | [Gyarados](../pokemon/gyarados.md) (Lv. 42) | [Gyarados](../pokemon/gyarados.md) (Lv. 42) |
| 14 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 45) | [Gyarados](../pokemon/gyarados.md) (Lv. 45) | [Gyarados](../pokemon/gyarados.md) (Lv. 45) |

## Savannah { #savannah }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 15) | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 15) | [Nidorina](../pokemon/nidorina.md) (Lv. 15) |
| 2 | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 15) | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 15) | [Nidorino](../pokemon/nidorino.md) (Lv. 15) |
| 3 | [Tauros](../pokemon/tauros.md) (Lv. 15) | [Tauros](../pokemon/tauros.md) (Lv. 15) | [Zubat](../pokemon/zubat.md) (Lv. 15) |
| 4 | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 16) | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 16) | [Nidorina](../pokemon/nidorina.md) (Lv. 16) |
| 5 | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 16) | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 16) | [Nidorino](../pokemon/nidorino.md) (Lv. 16) |
| 6 | [Tauros](../pokemon/tauros.md) (Lv. 16) | [Tauros](../pokemon/tauros.md) (Lv. 16) | [Zubat](../pokemon/zubat.md) (Lv. 16) |
| 7 | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 17) | [Nidoran♀](../pokemon/nidoran-f.md) (Lv. 17) | [Nidorina](../pokemon/nidorina.md) (Lv. 17) |
| 8 | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 17) | [Nidoran♂](../pokemon/nidoran-m.md) (Lv. 17) | [Nidorino](../pokemon/nidorino.md) (Lv. 17) |
| 9 | [Tauros](../pokemon/tauros.md) (Lv. 17) | [Tauros](../pokemon/tauros.md) (Lv. 17) | [Zubat](../pokemon/zubat.md) (Lv. 17) |
| 10 | [Rhyhorn](../pokemon/rhyhorn.md) (Lv. 17) | [Rhyhorn](../pokemon/rhyhorn.md) (Lv. 17) | [Golbat](../pokemon/golbat.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 5 Plains | [Tauros](../pokemon/tauros.md) (Lv. 41) | [Tauros](../pokemon/tauros.md) (Lv. 41) | [Tauros](../pokemon/tauros.md) (Lv. 41) |
| 10 Plains | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 38) | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 38) | [Zigzagoon](../pokemon/zigzagoon.md) (Lv. 38) |
| 24 Plains | [Luxio](../pokemon/luxio.md) (Lv. 46) | [Luxio](../pokemon/luxio.md) (Lv. 46) | [Luxio](../pokemon/luxio.md) (Lv. 45) |
| 4 Forest | [Houndour](../pokemon/houndour.md) (Lv. 42) | [Houndour](../pokemon/houndour.md) (Lv. 42) | [Houndour](../pokemon/houndour.md) (Lv. 42) |
| 35 Forest | [Cacturne](../pokemon/cacturne.md) (Lv. 42) | [Cacturne](../pokemon/cacturne.md) (Lv. 42) | [Cacturne](../pokemon/cacturne.md) (Lv. 42) |
| 35 Forest, 12 Plains | [Shroomish](../pokemon/shroomish.md) (Lv. 45) | [Shroomish](../pokemon/shroomish.md) (Lv. 45) | [Shroomish](../pokemon/shroomish.md) (Lv. 45) |
| 5 Peak | [Rhyhorn](../pokemon/rhyhorn.md) (Lv. 41) | [Rhyhorn](../pokemon/rhyhorn.md) (Lv. 41) | [Rhyhorn](../pokemon/rhyhorn.md) (Lv. 41) |
| 10 Peak | [Rhydon](../pokemon/rhydon.md) (Lv. 44) | [Rhydon](../pokemon/rhydon.md) (Lv. 44) | [Rhydon](../pokemon/rhydon.md) (Lv. 44) |
| 35 Peak | [Torkoal](../pokemon/torkoal.md) (Lv. 46) | [Torkoal](../pokemon/torkoal.md) (Lv. 47) | [Torkoal](../pokemon/torkoal.md) (Lv. 47) |
| 5 Waterside | [Azurill](../pokemon/azurill.md) (Lv. 42) | [Azurill](../pokemon/azurill.md) (Lv. 42) | [Azurill](../pokemon/azurill.md) (Lv. 42) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Peak { #peak }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Geodude](../pokemon/geodude.md) (Lv. 15) | [Geodude](../pokemon/geodude.md) (Lv. 15) | [Geodude](../pokemon/geodude.md) (Lv. 15) |
| 2 | [Magnemite](../pokemon/magnemite.md) (Lv. 15) | [Magnemite](../pokemon/magnemite.md) (Lv. 15) | [Magnemite](../pokemon/magnemite.md) (Lv. 15) |
| 3 | [Geodude](../pokemon/geodude.md) (Lv. 15) | [Geodude](../pokemon/geodude.md) (Lv. 15) | [Geodude](../pokemon/geodude.md) (Lv. 15) |
| 4 | [Geodude](../pokemon/geodude.md) (Lv. 16) | [Geodude](../pokemon/geodude.md) (Lv. 16) | [Geodude](../pokemon/geodude.md) (Lv. 16) |
| 5 | [Magnemite](../pokemon/magnemite.md) (Lv. 16) | [Magnemite](../pokemon/magnemite.md) (Lv. 16) | [Wobbuffet](../pokemon/wobbuffet.md) (Lv. 16) |
| 6 | [Graveler](../pokemon/graveler.md) (Lv. 16) | [Graveler](../pokemon/graveler.md) (Lv. 16) | [Magnemite](../pokemon/magnemite.md) (Lv. 16) |
| 7 | [Geodude](../pokemon/geodude.md) (Lv. 17) | [Geodude](../pokemon/geodude.md) (Lv. 17) | [Geodude](../pokemon/geodude.md) (Lv. 17) |
| 8 | [Magneton](../pokemon/magneton.md) (Lv. 17) | [Magneton](../pokemon/magneton.md) (Lv. 17) | [Magneton](../pokemon/magneton.md) (Lv. 17) |
| 9 | [Graveler](../pokemon/graveler.md) (Lv. 17) | [Graveler](../pokemon/graveler.md) (Lv. 17) | [Wobbuffet](../pokemon/wobbuffet.md) (Lv. 17) |
| 10 | [Magmar](../pokemon/magmar.md) (Lv. 17) | [Magmar](../pokemon/magmar.md) (Lv. 17) | [Magneton](../pokemon/magneton.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 5 Plains | [Linoone](../pokemon/linoone.md) (Lv. 46) | [Linoone](../pokemon/linoone.md) (Lv. 46) | [Linoone](../pokemon/linoone.md) (Lv. 46) |
| 12 Plains | [Zangoose](../pokemon/zangoose.md) (Lv. 45) | [Zangoose](../pokemon/zangoose.md) (Lv. 45) | [Zangoose](../pokemon/zangoose.md) (Lv. 43) |
| 3 Forest | [Paras](../pokemon/paras.md) (Lv. 42) | [Paras](../pokemon/paras.md) (Lv. 42) | [Paras](../pokemon/paras.md) (Lv. 42) |
| 5 Forest | [Fearow](../pokemon/fearow.md) (Lv. 44) | [Fearow](../pokemon/fearow.md) (Lv. 44) | [Fearow](../pokemon/fearow.md) (Lv. 44) |
| 56 Forest, 28 Plains | [Vigoroth](../pokemon/vigoroth.md) (Lv. 47) | [Vigoroth](../pokemon/vigoroth.md) (Lv. 47) | [Vigoroth](../pokemon/vigoroth.md) (Lv. 47) |
| 10 Peak | [Magmar](../pokemon/magmar.md) (Lv. 41) | [Magmar](../pokemon/magmar.md) (Lv. 41) | [Wobbuffet](../pokemon/wobbuffet.md) (Lv. 41) |
| 24 Peak | [Lairon](../pokemon/lairon.md) (Lv. 45) | [Lairon](../pokemon/lairon.md) (Lv. 45) | [Lairon](../pokemon/lairon.md) (Lv. 45) |
| 35 Peak, 14 Forest | [Bronzor](../pokemon/bronzor.md) (Lv. 45) | [Bronzor](../pokemon/bronzor.md) (Lv. 45) | [Bronzor](../pokemon/bronzor.md) (Lv. 46) |
| 5 Waterside | [Slowbro](../pokemon/slowbro.md) (Lv. 45) | [Slowbro](../pokemon/slowbro.md) (Lv. 45) | [Slowbro](../pokemon/slowbro.md) (Lv. 45) |
| 35 Waterside | [Spheal](../pokemon/spheal.md) (Lv. 45) | [Spheal](../pokemon/spheal.md) (Lv. 45) | [Spheal](../pokemon/spheal.md) (Lv. 44) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Rocky Beach { #rocky-beach }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Doduo](../pokemon/doduo.md) (Lv. 15) | [Doduo](../pokemon/doduo.md) (Lv. 15) | [Zubat](../pokemon/zubat.md) (Lv. 15) |
| 2 | [Slowpoke](../pokemon/slowpoke.md) (Lv. 15) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 15) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 15) |
| 3 | [Krabby](../pokemon/krabby.md) (Lv. 15) | [Krabby](../pokemon/krabby.md) (Lv. 15) | [Krabby](../pokemon/krabby.md) (Lv. 15) |
| 4 | [Doduo](../pokemon/doduo.md) (Lv. 16) | [Doduo](../pokemon/doduo.md) (Lv. 16) | [Zubat](../pokemon/zubat.md) (Lv. 16) |
| 5 | [Slowpoke](../pokemon/slowpoke.md) (Lv. 16) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 16) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 16) |
| 6 | [Krabby](../pokemon/krabby.md) (Lv. 16) | [Krabby](../pokemon/krabby.md) (Lv. 16) | [Krabby](../pokemon/krabby.md) (Lv. 16) |
| 7 | [Doduo](../pokemon/doduo.md) (Lv. 17) | [Doduo](../pokemon/doduo.md) (Lv. 17) | [Zubat](../pokemon/zubat.md) (Lv. 17) |
| 8 | [Slowpoke](../pokemon/slowpoke.md) (Lv. 17) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 17) | [Slowpoke](../pokemon/slowpoke.md) (Lv. 17) |
| 9 | [Krabby](../pokemon/krabby.md) (Lv. 17) | [Krabby](../pokemon/krabby.md) (Lv. 17) | [Krabby](../pokemon/krabby.md) (Lv. 17) |
| 10 | [Slowbro](../pokemon/slowbro.md) (Lv. 17) | [Slowbro](../pokemon/slowbro.md) (Lv. 17) | [Slowbro](../pokemon/slowbro.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 4 Plains | [Dodrio](../pokemon/dodrio.md) (Lv. 42) | [Dodrio](../pokemon/dodrio.md) (Lv. 42) | [Dodrio](../pokemon/dodrio.md) (Lv. 42) |
| 10 Plains | [Electrike](../pokemon/electrike.md) (Lv. 42) | [Electrike](../pokemon/electrike.md) (Lv. 42) | [Electrike](../pokemon/electrike.md) (Lv. 42) |
| 49 Plains, 49 Peak | [Gible](../pokemon/gible.md) (Lv. 44) | [Gible](../pokemon/gible.md) (Lv. 44) | [Gible](../pokemon/gible.md) (Lv. 44) |
| 5 Forest | [Mareep](../pokemon/mareep.md) (Lv. 43) | [Mareep](../pokemon/mareep.md) (Lv. 43) | [Mareep](../pokemon/mareep.md) (Lv. 43) |
| 10 Forest | [Manectric](../pokemon/manectric.md) (Lv. 37) | [Manectric](../pokemon/manectric.md) (Lv. 37) | [Manectric](../pokemon/manectric.md) (Lv. 37) |
| 18 Forest | [Budew](../pokemon/budew.md) (Lv. 40) | [Budew](../pokemon/budew.md) (Lv. 40) | [Budew](../pokemon/budew.md) (Lv. 40) |
| 3 Peak | [Slowbro](../pokemon/slowbro.md) (Lv. 42) | [Slowbro](../pokemon/slowbro.md) (Lv. 42) | [Slowbro](../pokemon/slowbro.md) (Lv. 42) |
| 8 Peak | [Kingler](../pokemon/kingler.md) (Lv. 40) | [Kingler](../pokemon/kingler.md) (Lv. 40) | [Kingler](../pokemon/kingler.md) (Lv. 40) |
| 24 Peak | [Aron](../pokemon/aron.md) (Lv. 45) | [Aron](../pokemon/aron.md) (Lv. 45) | [Aron](../pokemon/aron.md) (Lv. 44) |
| 5 Waterside | [Slowbro](../pokemon/slowbro.md) (Lv. 37) | [Slowbro](../pokemon/slowbro.md) (Lv. 37) | [Slowbro](../pokemon/slowbro.md) (Lv. 37) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 4 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |
| 5 | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 6 | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 7 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 16) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) |
| 9 | [Lapras](../pokemon/lapras.md) (Lv. 15) | [Lapras](../pokemon/lapras.md) (Lv. 15) | [Lapras](../pokemon/lapras.md) (Lv. 15) |
| 10 | [Lapras](../pokemon/lapras.md) (Lv. 16) | [Lapras](../pokemon/lapras.md) (Lv. 16) | [Lapras](../pokemon/lapras.md) (Lv. 16) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Lapras](../pokemon/lapras.md) (Lv. 37) | [Lapras](../pokemon/lapras.md) (Lv. 37) | [Lapras](../pokemon/lapras.md) (Lv. 36) |
| 14 Waterside | [Lapras](../pokemon/lapras.md) (Lv. 42) | [Lapras](../pokemon/lapras.md) (Lv. 42) | [Lapras](../pokemon/lapras.md) (Lv. 41) |
| 18 Waterside | [Lapras](../pokemon/lapras.md) (Lv. 47) | [Lapras](../pokemon/lapras.md) (Lv. 47) | [Lapras](../pokemon/lapras.md) (Lv. 46) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 14) | [Goldeen](../pokemon/goldeen.md) (Lv. 14) | [Goldeen](../pokemon/goldeen.md) (Lv. 14) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) |
| 8 | [Krabby](../pokemon/krabby.md) (Lv. 13) | [Krabby](../pokemon/krabby.md) (Lv. 13) | [Krabby](../pokemon/krabby.md) (Lv. 13) |
| 9 | [Krabby](../pokemon/krabby.md) (Lv. 14) | [Krabby](../pokemon/krabby.md) (Lv. 14) | [Krabby](../pokemon/krabby.md) (Lv. 14) |
| 10 | [Krabby](../pokemon/krabby.md) (Lv. 15) | [Krabby](../pokemon/krabby.md) (Lv. 15) | [Krabby](../pokemon/krabby.md) (Lv. 15) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Waterside | [Krabby](../pokemon/krabby.md) (Lv. 17) | [Krabby](../pokemon/krabby.md) (Lv. 17) | [Krabby](../pokemon/krabby.md) (Lv. 17) |
| 3 Waterside | [Krabby](../pokemon/krabby.md) (Lv. 18) | [Krabby](../pokemon/krabby.md) (Lv. 18) | [Krabby](../pokemon/krabby.md) (Lv. 18) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 7 | [Krabby](../pokemon/krabby.md) (Lv. 22) | [Krabby](../pokemon/krabby.md) (Lv. 22) | [Krabby](../pokemon/krabby.md) (Lv. 22) |
| 8 | [Krabby](../pokemon/krabby.md) (Lv. 23) | [Krabby](../pokemon/krabby.md) (Lv. 23) | [Krabby](../pokemon/krabby.md) (Lv. 23) |
| 9 | [Krabby](../pokemon/krabby.md) (Lv. 24) | [Krabby](../pokemon/krabby.md) (Lv. 24) | [Krabby](../pokemon/krabby.md) (Lv. 24) |
| 10 | [Krabby](../pokemon/krabby.md) (Lv. 25) | [Krabby](../pokemon/krabby.md) (Lv. 25) | [Krabby](../pokemon/krabby.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 5 Waterside | [Kingler](../pokemon/kingler.md) (Lv. 26) | [Kingler](../pokemon/kingler.md) (Lv. 26) | [Kingler](../pokemon/kingler.md) (Lv. 26) |
| 8 Waterside | [Kingler](../pokemon/kingler.md) (Lv. 27) | [Kingler](../pokemon/kingler.md) (Lv. 27) | [Kingler](../pokemon/kingler.md) (Lv. 27) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 36) | [Goldeen](../pokemon/goldeen.md) (Lv. 36) | [Goldeen](../pokemon/goldeen.md) (Lv. 36) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 37) | [Goldeen](../pokemon/goldeen.md) (Lv. 37) | [Goldeen](../pokemon/goldeen.md) (Lv. 37) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 38) | [Goldeen](../pokemon/goldeen.md) (Lv. 38) | [Goldeen](../pokemon/goldeen.md) (Lv. 38) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 36) | [Seaking](../pokemon/seaking.md) (Lv. 36) | [Seaking](../pokemon/seaking.md) (Lv. 36) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 37) | [Seaking](../pokemon/seaking.md) (Lv. 37) | [Seaking](../pokemon/seaking.md) (Lv. 37) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 38) | [Seaking](../pokemon/seaking.md) (Lv. 38) | [Seaking](../pokemon/seaking.md) (Lv. 38) |
| 9 | [Kingler](../pokemon/kingler.md) (Lv. 38) | [Kingler](../pokemon/kingler.md) (Lv. 38) | [Kingler](../pokemon/kingler.md) (Lv. 38) |
| 10 | [Kingler](../pokemon/kingler.md) (Lv. 39) | [Kingler](../pokemon/kingler.md) (Lv. 39) | [Kingler](../pokemon/kingler.md) (Lv. 39) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 15 Waterside | [Corphish](../pokemon/corphish.md) (Lv. 46) | [Corphish](../pokemon/corphish.md) (Lv. 46) | [Corphish](../pokemon/corphish.md) (Lv. 46) |
| 20 Waterside | [Corphish](../pokemon/corphish.md) (Lv. 48) | [Corphish](../pokemon/corphish.md) (Lv. 48) | [Corphish](../pokemon/corphish.md) (Lv. 48) |

## Wetland { #wetland }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Spearow](../pokemon/spearow.md) (Lv. 15) | [Spearow](../pokemon/spearow.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 2 | [Sentret](../pokemon/sentret.md) (Lv. 15) | [Sentret](../pokemon/sentret.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 3 | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 15) | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 15) | [Psyduck](../pokemon/psyduck.md) (Lv. 15) |
| 4 | [Spearow](../pokemon/spearow.md) (Lv. 16) | [Spearow](../pokemon/spearow.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 5 | [Sentret](../pokemon/sentret.md) (Lv. 16) | [Sentret](../pokemon/sentret.md) (Lv. 16) | [Quagsire](../pokemon/quagsire.md) (Lv. 16) |
| 6 | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 16) | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 16) | [Psyduck](../pokemon/psyduck.md) (Lv. 16) |
| 7 | [Spearow](../pokemon/spearow.md) (Lv. 17) | [Spearow](../pokemon/spearow.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) |
| 8 | [Sentret](../pokemon/sentret.md) (Lv. 17) | [Sentret](../pokemon/sentret.md) (Lv. 17) | [Quagsire](../pokemon/quagsire.md) (Lv. 17) |
| 9 | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 17) | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 17) | [Golduck](../pokemon/golduck.md) (Lv. 17) |
| 10 | [Ditto](../pokemon/ditto.md) (Lv. 17) | [Ditto](../pokemon/ditto.md) (Lv. 17) | [Golduck](../pokemon/golduck.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Plains | [Furret](../pokemon/furret.md) (Lv. 37) | [Furret](../pokemon/furret.md) (Lv. 37) | [Furret](../pokemon/furret.md) (Lv. 37) |
| 6 Plains | [Surskit](../pokemon/surskit.md) (Lv. 40) | [Surskit](../pokemon/surskit.md) (Lv. 40) | [Surskit](../pokemon/surskit.md) (Lv. 40) |
| 14 Plains | [Lombre](../pokemon/lombre.md) (Lv. 47) | [Lombre](../pokemon/lombre.md) (Lv. 47) | [Lombre](../pokemon/lombre.md) (Lv. 47) |
| 3 Forest | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 41) | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 41) | [Farfetch'd](../pokemon/farfetchd.md) (Lv. 41) |
| 8 Forest | [Pachirisu](../pokemon/pachirisu.md) (Lv. 43) | [Pachirisu](../pokemon/pachirisu.md) (Lv. 43) | [Pachirisu](../pokemon/pachirisu.md) (Lv. 43) |
| 4 Peak | [Doduo](../pokemon/doduo.md) (Lv. 45) | [Doduo](../pokemon/doduo.md) (Lv. 45) | [Doduo](../pokemon/doduo.md) (Lv. 45) |
| 5 Peak | [Golduck](../pokemon/golduck.md) (Lv. 40) | [Golduck](../pokemon/golduck.md) (Lv. 40) | [Golduck](../pokemon/golduck.md) (Lv. 40) |
| 63 Peak | [Shelgon](../pokemon/shelgon.md) (Lv. 46) | [Shelgon](../pokemon/shelgon.md) (Lv. 46) | [Shelgon](../pokemon/shelgon.md) (Lv. 46) |
| 15 Waterside | [Ditto](../pokemon/ditto.md) (Lv. 41) | [Ditto](../pokemon/ditto.md) (Lv. 41) | [Ditto](../pokemon/ditto.md) (Lv. 41) |
| 35 Waterside | [Buizel](../pokemon/buizel.md) (Lv. 45) | [Buizel](../pokemon/buizel.md) (Lv. 45) | [Buizel](../pokemon/buizel.md) (Lv. 44) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |
| 2 | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 3 | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 7 | [Psyduck](../pokemon/psyduck.md) (Lv. 16) | [Psyduck](../pokemon/psyduck.md) (Lv. 16) | [Psyduck](../pokemon/psyduck.md) (Lv. 16) |
| 8 | [Psyduck](../pokemon/psyduck.md) (Lv. 17) | [Psyduck](../pokemon/psyduck.md) (Lv. 17) | [Psyduck](../pokemon/psyduck.md) (Lv. 17) |
| 9 | [Quagsire](../pokemon/quagsire.md) (Lv. 16) | [Quagsire](../pokemon/quagsire.md) (Lv. 16) | [Quagsire](../pokemon/quagsire.md) (Lv. 16) |
| 10 | [Quagsire](../pokemon/quagsire.md) (Lv. 17) | [Quagsire](../pokemon/quagsire.md) (Lv. 17) | [Quagsire](../pokemon/quagsire.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 37) | [Quagsire](../pokemon/quagsire.md) (Lv. 37) | [Quagsire](../pokemon/quagsire.md) (Lv. 37) |
| 4 Waterside | [Golduck](../pokemon/golduck.md) (Lv. 37) | [Golduck](../pokemon/golduck.md) (Lv. 37) | [Golduck](../pokemon/golduck.md) (Lv. 37) |
| 6 Waterside | [Golduck](../pokemon/golduck.md) (Lv. 45) | [Golduck](../pokemon/golduck.md) (Lv. 45) | [Golduck](../pokemon/golduck.md) (Lv. 45) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 7 | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) |
| 8 | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) |
| 9 | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) |
| 10 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Waterside | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 17) |
| 3 Waterside | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 18) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 18) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 18) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) |
| 2 | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) |
| 3 | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 22) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) |
| 4 | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) |
| 5 | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) | [Poliwag](../pokemon/poliwag.md) (Lv. 23) |
| 6 | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) |
| 7 | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) | [Poliwag](../pokemon/poliwag.md) (Lv. 24) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 23) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 23) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 23) |
| 9 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) |
| 10 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Corphish](../pokemon/corphish.md) (Lv. 26) | [Corphish](../pokemon/corphish.md) (Lv. 26) | [Corphish](../pokemon/corphish.md) (Lv. 26) |
| 14 Waterside | [Corphish](../pokemon/corphish.md) (Lv. 28) | [Corphish](../pokemon/corphish.md) (Lv. 28) | [Corphish](../pokemon/corphish.md) (Lv. 28) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) |
| 2 | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) | [Poliwag](../pokemon/poliwag.md) (Lv. 35) |
| 3 | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) |
| 4 | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) | [Poliwag](../pokemon/poliwag.md) (Lv. 36) |
| 5 | [Poliwag](../pokemon/poliwag.md) (Lv. 37) | [Poliwag](../pokemon/poliwag.md) (Lv. 37) | [Poliwag](../pokemon/poliwag.md) (Lv. 37) |
| 6 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 7 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 9 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 10 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 6 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 45) | [Gyarados](../pokemon/gyarados.md) (Lv. 44) | [Gyarados](../pokemon/gyarados.md) (Lv. 45) |
| 9 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 48) | [Gyarados](../pokemon/gyarados.md) (Lv. 47) | [Gyarados](../pokemon/gyarados.md) (Lv. 48) |

## Forest { #forest }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Bellsprout](../pokemon/bellsprout.md) (Lv. 15) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 15) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 15) |
| 2 | [Pidgey](../pokemon/pidgey.md) (Lv. 15) | [Pidgey](../pokemon/pidgey.md) (Lv. 15) | [Gastly](../pokemon/gastly.md) (Lv. 15) |
| 3 | [Bellsprout](../pokemon/bellsprout.md) (Lv. 15) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 15) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 15) |
| 4 | [Bellsprout](../pokemon/bellsprout.md) (Lv. 16) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 16) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 16) |
| 5 | [Pidgey](../pokemon/pidgey.md) (Lv. 16) | [Pidgey](../pokemon/pidgey.md) (Lv. 16) | [Haunter](../pokemon/haunter.md) (Lv. 16) |
| 6 | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 16) | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 16) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 16) |
| 7 | [Bellsprout](../pokemon/bellsprout.md) (Lv. 17) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 17) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 17) |
| 8 | [Pidgey](../pokemon/pidgey.md) (Lv. 17) | [Pidgey](../pokemon/pidgey.md) (Lv. 17) | [Gastly](../pokemon/gastly.md) (Lv. 17) |
| 9 | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 17) | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 17) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 17) |
| 10 | [Misdreavus](../pokemon/misdreavus.md) (Lv. 17) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 17) | [Haunter](../pokemon/haunter.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 45) | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 45) | [Mr. Mime](../pokemon/mr-mime.md) (Lv. 45) |
| 24 Plains | [Budew](../pokemon/budew.md) (Lv. 47) | [Budew](../pokemon/budew.md) (Lv. 47) | [Budew](../pokemon/budew.md) (Lv. 47) |
| 4 Forest | [Misdreavus](../pokemon/misdreavus.md) (Lv. 42) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 42) | [Misdreavus](../pokemon/misdreavus.md) (Lv. 42) |
| 35 Forest | [Shuppet](../pokemon/shuppet.md) (Lv. 46) | [Shuppet](../pokemon/shuppet.md) (Lv. 46) | [Shuppet](../pokemon/shuppet.md) (Lv. 47) |
| 4 Peak | [Electabuzz](../pokemon/electabuzz.md) (Lv. 41) | [Electabuzz](../pokemon/electabuzz.md) (Lv. 41) | [Electabuzz](../pokemon/electabuzz.md) (Lv. 41) |
| 56 Peak, 35 Forest | [Bronzong](../pokemon/bronzong.md) (Lv. 45) | [Bronzong](../pokemon/bronzong.md) (Lv. 44) | [Bronzong](../pokemon/bronzong.md) (Lv. 44) |
| 63 Peak | [Beldum](../pokemon/beldum.md) (Lv. 44) | [Beldum](../pokemon/beldum.md) (Lv. 44) | [Beldum](../pokemon/beldum.md) (Lv. 44) |
| 3 Waterside | [Lickitung](../pokemon/lickitung.md) (Lv. 40) | [Lickitung](../pokemon/lickitung.md) (Lv. 40) | [Lickitung](../pokemon/lickitung.md) (Lv. 40) |
| 10 Waterside | [Bidoof](../pokemon/bidoof.md) (Lv. 40) | [Bidoof](../pokemon/bidoof.md) (Lv. 40) | [Bidoof](../pokemon/bidoof.md) (Lv. 40) |
| 24 Waterside | [Surskit](../pokemon/surskit.md) (Lv. 42) | [Surskit](../pokemon/surskit.md) (Lv. 42) | [Surskit](../pokemon/surskit.md) (Lv. 42) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Swamp { #swamp }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Sentret](../pokemon/sentret.md) (Lv. 15) | [Sentret](../pokemon/sentret.md) (Lv. 15) | [Sentret](../pokemon/sentret.md) (Lv. 15) |
| 2 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 15) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 15) | [Drowzee](../pokemon/drowzee.md) (Lv. 15) |
| 3 | [Paras](../pokemon/paras.md) (Lv. 15) | [Paras](../pokemon/paras.md) (Lv. 15) | [Murkrow](../pokemon/murkrow.md) (Lv. 15) |
| 4 | [Sentret](../pokemon/sentret.md) (Lv. 16) | [Sentret](../pokemon/sentret.md) (Lv. 16) | [Sentret](../pokemon/sentret.md) (Lv. 16) |
| 5 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 16) | [Hypno](../pokemon/hypno.md) (Lv. 16) |
| 6 | [Paras](../pokemon/paras.md) (Lv. 16) | [Paras](../pokemon/paras.md) (Lv. 16) | [Murkrow](../pokemon/murkrow.md) (Lv. 16) |
| 7 | [Sentret](../pokemon/sentret.md) (Lv. 17) | [Sentret](../pokemon/sentret.md) (Lv. 17) | [Sentret](../pokemon/sentret.md) (Lv. 17) |
| 8 | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) | [Jigglypuff](../pokemon/jigglypuff.md) (Lv. 17) | [Drowzee](../pokemon/drowzee.md) (Lv. 17) |
| 9 | [Paras](../pokemon/paras.md) (Lv. 17) | [Paras](../pokemon/paras.md) (Lv. 17) | [Murkrow](../pokemon/murkrow.md) (Lv. 17) |
| 10 | [Murkrow](../pokemon/murkrow.md) (Lv. 17) | [Murkrow](../pokemon/murkrow.md) (Lv. 17) | [Hypno](../pokemon/hypno.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Parasect](../pokemon/parasect.md) (Lv. 41) | [Parasect](../pokemon/parasect.md) (Lv. 41) | [Parasect](../pokemon/parasect.md) (Lv. 41) |
| 5 Plains | [Furret](../pokemon/furret.md) (Lv. 42) | [Furret](../pokemon/furret.md) (Lv. 42) | [Furret](../pokemon/furret.md) (Lv. 42) |
| 10 Plains | [Pachirisu](../pokemon/pachirisu.md) (Lv. 47) | [Pachirisu](../pokemon/pachirisu.md) (Lv. 47) | [Pachirisu](../pokemon/pachirisu.md) (Lv. 47) |
| 5 Forest | [Murkrow](../pokemon/murkrow.md) (Lv. 37) | [Murkrow](../pokemon/murkrow.md) (Lv. 37) | [Hypno](../pokemon/hypno.md) (Lv. 37) |
| 8 Forest | [Weepinbell](../pokemon/weepinbell.md) (Lv. 46) | [Weepinbell](../pokemon/weepinbell.md) (Lv. 46) | [Weepinbell](../pokemon/weepinbell.md) (Lv. 46) |
| 15 Forest | [Chimecho](../pokemon/chimecho.md) (Lv. 46) | [Chimecho](../pokemon/chimecho.md) (Lv. 46) | [Chimecho](../pokemon/chimecho.md) (Lv. 47) |
| 10 Peak | [Voltorb](../pokemon/voltorb.md) (Lv. 42) | [Voltorb](../pokemon/voltorb.md) (Lv. 42) | [Voltorb](../pokemon/voltorb.md) (Lv. 42) |
| 28 Peak | [Duskull](../pokemon/duskull.md) (Lv. 38) | [Duskull](../pokemon/duskull.md) (Lv. 38) | [Duskull](../pokemon/duskull.md) (Lv. 38) |
| 56 Peak, 35 Forest | [Bagon](../pokemon/bagon.md) (Lv. 45) | [Bagon](../pokemon/bagon.md) (Lv. 45) | [Bagon](../pokemon/bagon.md) (Lv. 44) |
| 10 Waterside | [Floatzel](../pokemon/floatzel.md) (Lv. 44) | [Floatzel](../pokemon/floatzel.md) (Lv. 44) | [Floatzel](../pokemon/floatzel.md) (Lv. 44) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) | [Magikarp](../pokemon/magikarp.md) (Lv. 16) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) | [Magikarp](../pokemon/magikarp.md) (Lv. 17) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) | [Goldeen](../pokemon/goldeen.md) (Lv. 15) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 16) | [Goldeen](../pokemon/goldeen.md) (Lv. 16) | [Goldeen](../pokemon/goldeen.md) (Lv. 16) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 17) | [Goldeen](../pokemon/goldeen.md) (Lv. 17) | [Goldeen](../pokemon/goldeen.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 4 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 42) | [Seaking](../pokemon/seaking.md) (Lv. 42) | [Seaking](../pokemon/seaking.md) (Lv. 42) |
| 10 Waterside | [Murkrow](../pokemon/murkrow.md) (Lv. 47) | [Murkrow](../pokemon/murkrow.md) (Lv. 47) | [Murkrow](../pokemon/murkrow.md) (Lv. 47) |
| 35 Waterside | [Duskull](../pokemon/duskull.md) (Lv. 48) | [Duskull](../pokemon/duskull.md) (Lv. 48) | [Duskull](../pokemon/duskull.md) (Lv. 48) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 7 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 8 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 9 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 10 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Waterside | [Goldeen](../pokemon/goldeen.md) (Lv. 17) | [Goldeen](../pokemon/goldeen.md) (Lv. 17) | [Goldeen](../pokemon/goldeen.md) (Lv. 17) |
| 3 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 17) | [Seaking](../pokemon/seaking.md) (Lv. 17) | [Seaking](../pokemon/seaking.md) (Lv. 17) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 6 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 27) | [Seaking](../pokemon/seaking.md) (Lv. 27) | [Seaking](../pokemon/seaking.md) (Lv. 27) |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 29) | [Dratini](../pokemon/dratini.md) (Lv. 29) | [Dratini](../pokemon/dratini.md) (Lv. 29) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) | [Goldeen](../pokemon/goldeen.md) (Lv. 35) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 36) | [Goldeen](../pokemon/goldeen.md) (Lv. 36) | [Goldeen](../pokemon/goldeen.md) (Lv. 36) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 37) | [Goldeen](../pokemon/goldeen.md) (Lv. 37) | [Goldeen](../pokemon/goldeen.md) (Lv. 37) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) | [Seaking](../pokemon/seaking.md) (Lv. 35) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 36) | [Seaking](../pokemon/seaking.md) (Lv. 36) | [Seaking](../pokemon/seaking.md) (Lv. 36) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 37) | [Seaking](../pokemon/seaking.md) (Lv. 37) | [Seaking](../pokemon/seaking.md) (Lv. 37) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 36) | [Dratini](../pokemon/dratini.md) (Lv. 36) | [Dratini](../pokemon/dratini.md) (Lv. 36) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 37) | [Dratini](../pokemon/dratini.md) (Lv. 37) | [Dratini](../pokemon/dratini.md) (Lv. 37) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 15 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 42) | [Dragonair](../pokemon/dragonair.md) (Lv. 42) | [Dragonair](../pokemon/dragonair.md) (Lv. 42) |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Marshland { #marshland }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Ekans](../pokemon/ekans.md) (Lv. 15) | [Ekans](../pokemon/ekans.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 2 | [Koffing](../pokemon/koffing.md) (Lv. 15) | [Koffing](../pokemon/koffing.md) (Lv. 15) | [Koffing](../pokemon/koffing.md) (Lv. 15) |
| 3 | [Weezing](../pokemon/weezing.md) (Lv. 15) | [Weezing](../pokemon/weezing.md) (Lv. 15) | [Oddish](../pokemon/oddish.md) (Lv. 15) |
| 4 | [Ekans](../pokemon/ekans.md) (Lv. 16) | [Ekans](../pokemon/ekans.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 5 | [Koffing](../pokemon/koffing.md) (Lv. 16) | [Koffing](../pokemon/koffing.md) (Lv. 16) | [Koffing](../pokemon/koffing.md) (Lv. 16) |
| 6 | [Weezing](../pokemon/weezing.md) (Lv. 16) | [Weezing](../pokemon/weezing.md) (Lv. 16) | [Gloom](../pokemon/gloom.md) (Lv. 16) |
| 7 | [Arbok](../pokemon/arbok.md) (Lv. 17) | [Arbok](../pokemon/arbok.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) |
| 8 | [Koffing](../pokemon/koffing.md) (Lv. 17) | [Koffing](../pokemon/koffing.md) (Lv. 17) | [Koffing](../pokemon/koffing.md) (Lv. 17) |
| 9 | [Weezing](../pokemon/weezing.md) (Lv. 17) | [Weezing](../pokemon/weezing.md) (Lv. 17) | [Oddish](../pokemon/oddish.md) (Lv. 17) |
| 10 | [Grimer](../pokemon/grimer.md) (Lv. 17) | [Grimer](../pokemon/grimer.md) (Lv. 17) | [Gloom](../pokemon/gloom.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Plains | [Gloom](../pokemon/gloom.md) (Lv. 42) | [Gloom](../pokemon/gloom.md) (Lv. 42) | [Gloom](../pokemon/gloom.md) (Lv. 42) |
| 5 Plains | [Jumpluff](../pokemon/jumpluff.md) (Lv. 38) | [Jumpluff](../pokemon/jumpluff.md) (Lv. 38) | [Jumpluff](../pokemon/jumpluff.md) (Lv. 38) |
| 35 Plains | [Seviper](../pokemon/seviper.md) (Lv. 48) | [Seviper](../pokemon/seviper.md) (Lv. 47) | [Seviper](../pokemon/seviper.md) (Lv. 47) |
| 35 Forest | [Carnivine](../pokemon/carnivine.md) (Lv. 41) | [Carnivine](../pokemon/carnivine.md) (Lv. 41) | [Carnivine](../pokemon/carnivine.md) (Lv. 41) |
| 42 Forest | [Croagunk](../pokemon/croagunk.md) (Lv. 44) | [Croagunk](../pokemon/croagunk.md) (Lv. 44) | [Croagunk](../pokemon/croagunk.md) (Lv. 44) |
| 49 Forest | [Roselia](../pokemon/roselia.md) (Lv. 46) | [Roselia](../pokemon/roselia.md) (Lv. 46) | [Roselia](../pokemon/roselia.md) (Lv. 46) |
| 5 Peak | [Diglett](../pokemon/diglett.md) (Lv. 43) | [Diglett](../pokemon/diglett.md) (Lv. 43) | [Diglett](../pokemon/diglett.md) (Lv. 43) |
| 8 Peak | [Shuckle](../pokemon/shuckle.md) (Lv. 44) | [Shuckle](../pokemon/shuckle.md) (Lv. 44) | [Shuckle](../pokemon/shuckle.md) (Lv. 44) |
| 49 Peak | [Banette](../pokemon/banette.md) (Lv. 44) | [Banette](../pokemon/banette.md) (Lv. 44) | [Banette](../pokemon/banette.md) (Lv. 45) |
| 8 Waterside | [Muk](../pokemon/muk.md) (Lv. 38) | [Muk](../pokemon/muk.md) (Lv. 38) | [Muk](../pokemon/muk.md) (Lv. 38) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |
| 2 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |
| 3 | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 4 | [Poliwag](../pokemon/poliwag.md) (Lv. 17) | [Poliwag](../pokemon/poliwag.md) (Lv. 17) | [Poliwag](../pokemon/poliwag.md) (Lv. 17) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) | [Wooper](../pokemon/wooper.md) (Lv. 15) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) | [Wooper](../pokemon/wooper.md) (Lv. 16) |
| 7 | [Wooper](../pokemon/wooper.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) | [Wooper](../pokemon/wooper.md) (Lv. 17) |
| 8 | [Grimer](../pokemon/grimer.md) (Lv. 15) | [Grimer](../pokemon/grimer.md) (Lv. 15) | [Grimer](../pokemon/grimer.md) (Lv. 15) |
| 9 | [Grimer](../pokemon/grimer.md) (Lv. 16) | [Grimer](../pokemon/grimer.md) (Lv. 16) | [Grimer](../pokemon/grimer.md) (Lv. 16) |
| 10 | [Grimer](../pokemon/grimer.md) (Lv. 17) | [Grimer](../pokemon/grimer.md) (Lv. 17) | [Grimer](../pokemon/grimer.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Jumpluff](../pokemon/jumpluff.md) (Lv. 47) | [Jumpluff](../pokemon/jumpluff.md) (Lv. 47) | [Jumpluff](../pokemon/jumpluff.md) (Lv. 47) |
| 13 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 43) | [Quagsire](../pokemon/quagsire.md) (Lv. 43) | [Quagsire](../pokemon/quagsire.md) (Lv. 43) |
| 16 Waterside | [Muk](../pokemon/muk.md) (Lv. 48) | [Muk](../pokemon/muk.md) (Lv. 48) | [Muk](../pokemon/muk.md) (Lv. 48) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) | [Magikarp](../pokemon/magikarp.md) (Lv. 14) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) | [Magikarp](../pokemon/magikarp.md) (Lv. 15) |
| 7 | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) | [Poliwag](../pokemon/poliwag.md) (Lv. 12) |
| 8 | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) | [Poliwag](../pokemon/poliwag.md) (Lv. 13) |
| 9 | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) | [Poliwag](../pokemon/poliwag.md) (Lv. 14) |
| 10 | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) | [Poliwag](../pokemon/poliwag.md) (Lv. 15) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 2 Waterside | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) | [Poliwag](../pokemon/poliwag.md) (Lv. 16) |
| 3 Waterside | [Poliwag](../pokemon/poliwag.md) (Lv. 18) | [Poliwag](../pokemon/poliwag.md) (Lv. 18) | [Poliwag](../pokemon/poliwag.md) (Lv. 18) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 22) |
| 6 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 22) |
| 7 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 23) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 23) |
| 9 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 24) |
| 10 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 26) | [Gyarados](../pokemon/gyarados.md) (Lv. 26) | [Gyarados](../pokemon/gyarados.md) (Lv. 26) |
| 4 Waterside | [Gyarados](../pokemon/gyarados.md) (Lv. 29) | [Gyarados](../pokemon/gyarados.md) (Lv. 29) | [Gyarados](../pokemon/gyarados.md) (Lv. 29) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 2 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 3 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 35) |
| 4 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 5 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 6 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 36) |
| 7 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 37) |
| 8 | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) | [Poliwhirl](../pokemon/poliwhirl.md) (Lv. 38) |
| 9 | [Gyarados](../pokemon/gyarados.md) (Lv. 36) | [Gyarados](../pokemon/gyarados.md) (Lv. 36) | [Gyarados](../pokemon/gyarados.md) (Lv. 36) |
| 10 | [Gyarados](../pokemon/gyarados.md) (Lv. 37) | [Gyarados](../pokemon/gyarados.md) (Lv. 37) | [Gyarados](../pokemon/gyarados.md) (Lv. 37) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 4 Waterside | [Barboach](../pokemon/barboach.md) (Lv. 42) | [Barboach](../pokemon/barboach.md) (Lv. 42) | [Barboach](../pokemon/barboach.md) (Lv. 42) |
| 5 Waterside | [Barboach](../pokemon/barboach.md) (Lv. 45) | [Barboach](../pokemon/barboach.md) (Lv. 45) | [Barboach](../pokemon/barboach.md) (Lv. 45) |

## Wasteland { #wasteland }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Kangaskhan](../pokemon/kangaskhan.md) (Lv. 15) | [Kangaskhan](../pokemon/kangaskhan.md) (Lv. 15) | [Fearow](../pokemon/fearow.md) (Lv. 15) |
| 2 | [Onix](../pokemon/onix.md) (Lv. 15) | [Onix](../pokemon/onix.md) (Lv. 15) | [Onix](../pokemon/onix.md) (Lv. 15) |
| 3 | [Magnemite](../pokemon/magnemite.md) (Lv. 15) | [Magnemite](../pokemon/magnemite.md) (Lv. 15) | [Magnemite](../pokemon/magnemite.md) (Lv. 15) |
| 4 | [Machop](../pokemon/machop.md) (Lv. 16) | [Machop](../pokemon/machop.md) (Lv. 16) | [Fearow](../pokemon/fearow.md) (Lv. 16) |
| 5 | [Onix](../pokemon/onix.md) (Lv. 16) | [Onix](../pokemon/onix.md) (Lv. 16) | [Onix](../pokemon/onix.md) (Lv. 16) |
| 6 | [Magnemite](../pokemon/magnemite.md) (Lv. 16) | [Magnemite](../pokemon/magnemite.md) (Lv. 16) | [Magnemite](../pokemon/magnemite.md) (Lv. 16) |
| 7 | [Kangaskhan](../pokemon/kangaskhan.md) (Lv. 17) | [Kangaskhan](../pokemon/kangaskhan.md) (Lv. 17) | [Fearow](../pokemon/fearow.md) (Lv. 17) |
| 8 | [Machoke](../pokemon/machoke.md) (Lv. 17) | [Onix](../pokemon/onix.md) (Lv. 17) | [Onix](../pokemon/onix.md) (Lv. 17) |
| 9 | [Magnemite](../pokemon/magnemite.md) (Lv. 17) | [Magnemite](../pokemon/magnemite.md) (Lv. 17) | [Magnemite](../pokemon/magnemite.md) (Lv. 17) |
| 10 | [Machop](../pokemon/machop.md) (Lv. 17) | [Machop](../pokemon/machop.md) (Lv. 17) | [Onix](../pokemon/onix.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Manectric](../pokemon/manectric.md) (Lv. 41) | [Manectric](../pokemon/manectric.md) (Lv. 41) | [Manectric](../pokemon/manectric.md) (Lv. 41) |
| 10 Plains | [Illumise](../pokemon/illumise.md) (Lv. 46) | [Illumise](../pokemon/illumise.md) (Lv. 46) | [Illumise](../pokemon/illumise.md) (Lv. 46) |
| 3 Forest | [Bellsprout](../pokemon/bellsprout.md) (Lv. 41) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 41) | [Bellsprout](../pokemon/bellsprout.md) (Lv. 41) |
| 35 Forest | [Medicham](../pokemon/medicham.md) (Lv. 44) | [Medicham](../pokemon/medicham.md) (Lv. 44) | [Medicham](../pokemon/medicham.md) (Lv. 44) |
| 42 Forest | [Breloom](../pokemon/breloom.md) (Lv. 46) | [Breloom](../pokemon/breloom.md) (Lv. 46) | [Breloom](../pokemon/breloom.md) (Lv. 46) |
| 5 Peak | [Machoke](../pokemon/machoke.md) (Lv. 40) | [Machoke](../pokemon/machoke.md) (Lv. 40) | [Machoke](../pokemon/machoke.md) (Lv. 40) |
| 28 Peak | [Skorupi](../pokemon/skorupi.md) (Lv. 44) | [Skorupi](../pokemon/skorupi.md) (Lv. 44) | [Skorupi](../pokemon/skorupi.md) (Lv. 45) |
| 42 Peak | [Solrock](../pokemon/solrock.md) (Lv. 45) | [Solrock](../pokemon/solrock.md) (Lv. 46) | [Solrock](../pokemon/solrock.md) (Lv. 45) |
| 3 Waterside | [Golduck](../pokemon/golduck.md) (Lv. 45) | [Golduck](../pokemon/golduck.md) (Lv. 45) | [Golduck](../pokemon/golduck.md) (Lv. 45) |
| 10 Waterside | [Kingler](../pokemon/kingler.md) (Lv. 48) | [Kingler](../pokemon/kingler.md) (Lv. 48) | [Kingler](../pokemon/kingler.md) (Lv. 48) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Mountain { #mountain }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Raticate](../pokemon/raticate.md) (Lv. 15) | [Raticate](../pokemon/raticate.md) (Lv. 15) | [Zubat](../pokemon/zubat.md) (Lv. 15) |
| 2 | [Lickitung](../pokemon/lickitung.md) (Lv. 15) | [Lickitung](../pokemon/lickitung.md) (Lv. 15) | [Golbat](../pokemon/golbat.md) (Lv. 15) |
| 3 | [Rattata](../pokemon/rattata.md) (Lv. 15) | [Rattata](../pokemon/rattata.md) (Lv. 15) | [Rattata](../pokemon/rattata.md) (Lv. 15) |
| 4 | [Raticate](../pokemon/raticate.md) (Lv. 16) | [Raticate](../pokemon/raticate.md) (Lv. 16) | [Zubat](../pokemon/zubat.md) (Lv. 16) |
| 5 | [Lickitung](../pokemon/lickitung.md) (Lv. 16) | [Lickitung](../pokemon/lickitung.md) (Lv. 16) | [Golbat](../pokemon/golbat.md) (Lv. 16) |
| 6 | [Rattata](../pokemon/rattata.md) (Lv. 16) | [Rattata](../pokemon/rattata.md) (Lv. 16) | [Rattata](../pokemon/rattata.md) (Lv. 16) |
| 7 | [Raticate](../pokemon/raticate.md) (Lv. 17) | [Raticate](../pokemon/raticate.md) (Lv. 17) | [Zubat](../pokemon/zubat.md) (Lv. 17) |
| 8 | [Lickitung](../pokemon/lickitung.md) (Lv. 17) | [Lickitung](../pokemon/lickitung.md) (Lv. 17) | [Golbat](../pokemon/golbat.md) (Lv. 17) |
| 9 | [Magneton](../pokemon/magneton.md) (Lv. 17) | [Magneton](../pokemon/magneton.md) (Lv. 17) | [Magneton](../pokemon/magneton.md) (Lv. 17) |
| 10 | [Larvitar](../pokemon/larvitar.md) (Lv. 17) | [Larvitar](../pokemon/larvitar.md) (Lv. 17) | [Zubat](../pokemon/zubat.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Magneton](../pokemon/magneton.md) (Lv. 42) | [Magneton](../pokemon/magneton.md) (Lv. 42) | [Magneton](../pokemon/magneton.md) (Lv. 42) |
| 10 Plains | [Volbeat](../pokemon/volbeat.md) (Lv. 46) | [Volbeat](../pokemon/volbeat.md) (Lv. 46) | [Volbeat](../pokemon/volbeat.md) (Lv. 46) |
| 10 Forest | [Chingling](../pokemon/chingling.md) (Lv. 38) | [Chingling](../pokemon/chingling.md) (Lv. 38) | [Chingling](../pokemon/chingling.md) (Lv. 38) |
| 20 Forest | [Meditite](../pokemon/meditite.md) (Lv. 44) | [Meditite](../pokemon/meditite.md) (Lv. 43) | [Meditite](../pokemon/meditite.md) (Lv. 43) |
| 35 Forest | [Dusclops](../pokemon/dusclops.md) (Lv. 45) | [Dusclops](../pokemon/dusclops.md) (Lv. 45) | [Dusclops](../pokemon/dusclops.md) (Lv. 46) |
| 5 Peak | [Larvitar](../pokemon/larvitar.md) (Lv. 42) | [Larvitar](../pokemon/larvitar.md) (Lv. 42) | [Larvitar](../pokemon/larvitar.md) (Lv. 42) |
| 15 Peak | [Lunatone](../pokemon/lunatone.md) (Lv. 46) | [Lunatone](../pokemon/lunatone.md) (Lv. 46) | [Lunatone](../pokemon/lunatone.md) (Lv. 46) |
| 56 Peak | [Metang](../pokemon/metang.md) (Lv. 44) | [Metang](../pokemon/metang.md) (Lv. 44) | [Metang](../pokemon/metang.md) (Lv. 44) |
| 3 Waterside | [Krabby](../pokemon/krabby.md) (Lv. 43) | [Krabby](../pokemon/krabby.md) (Lv. 43) | [Krabby](../pokemon/krabby.md) (Lv. 43) |
| 49 Waterside, 21 Peak | [Sealeo](../pokemon/sealeo.md) (Lv. 45) | [Sealeo](../pokemon/sealeo.md) (Lv. 45) | [Sealeo](../pokemon/sealeo.md) (Lv. 45) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Desert { #desert }

### Grass

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Sandshrew](../pokemon/sandshrew.md) (Lv. 15) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 15) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 15) |
| 2 | [Sandslash](../pokemon/sandslash.md) (Lv. 15) | [Sandslash](../pokemon/sandslash.md) (Lv. 15) | [Sandslash](../pokemon/sandslash.md) (Lv. 15) |
| 3 | [Sandshrew](../pokemon/sandshrew.md) (Lv. 15) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 15) | [Fearow](../pokemon/fearow.md) (Lv. 15) |
| 4 | [Sandshrew](../pokemon/sandshrew.md) (Lv. 16) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 16) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 16) |
| 5 | [Sandslash](../pokemon/sandslash.md) (Lv. 16) | [Sandslash](../pokemon/sandslash.md) (Lv. 16) | [Sandslash](../pokemon/sandslash.md) (Lv. 16) |
| 6 | [Cubone](../pokemon/cubone.md) (Lv. 16) | [Cubone](../pokemon/cubone.md) (Lv. 16) | [Fearow](../pokemon/fearow.md) (Lv. 16) |
| 7 | [Sandshrew](../pokemon/sandshrew.md) (Lv. 17) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 17) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 17) |
| 8 | [Sandslash](../pokemon/sandslash.md) (Lv. 17) | [Sandslash](../pokemon/sandslash.md) (Lv. 17) | [Sandslash](../pokemon/sandslash.md) (Lv. 17) |
| 9 | [Cubone](../pokemon/cubone.md) (Lv. 17) | [Cubone](../pokemon/cubone.md) (Lv. 17) | [Sandshrew](../pokemon/sandshrew.md) (Lv. 17) |
| 10 | [Marowak](../pokemon/marowak.md) (Lv. 17) | [Marowak](../pokemon/marowak.md) (Lv. 17) | [Fearow](../pokemon/fearow.md) (Lv. 17) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 3 Plains | [Fearow](../pokemon/fearow.md) (Lv. 38) | [Fearow](../pokemon/fearow.md) (Lv. 38) | [Fearow](../pokemon/fearow.md) (Lv. 38) |
| 14 Plains | [Spinda](../pokemon/spinda.md) (Lv. 45) | [Spinda](../pokemon/spinda.md) (Lv. 45) | [Spinda](../pokemon/spinda.md) (Lv. 45) |
| 49 Plains | [Carnivine](../pokemon/carnivine.md) (Lv. 48) | [Carnivine](../pokemon/carnivine.md) (Lv. 48) | [Carnivine](../pokemon/carnivine.md) (Lv. 48) |
| 35 Forest | [Cacnea](../pokemon/cacnea.md) (Lv. 35) | [Cacnea](../pokemon/cacnea.md) (Lv. 35) | [Cacnea](../pokemon/cacnea.md) (Lv. 35) |
| 49 Forest | [Vibrava](../pokemon/vibrava.md) (Lv. 44) | [Vibrava](../pokemon/vibrava.md) (Lv. 45) | [Vibrava](../pokemon/vibrava.md) (Lv. 44) |
| 6 Peak | [Marowak](../pokemon/marowak.md) (Lv. 41) | [Marowak](../pokemon/marowak.md) (Lv. 41) | [Fearow](../pokemon/fearow.md) (Lv. 41) |
| 28 Peak | [Hippopotas](../pokemon/hippopotas.md) (Lv. 43) | [Hippopotas](../pokemon/hippopotas.md) (Lv. 43) | [Hippopotas](../pokemon/hippopotas.md) (Lv. 43) |
| 49 Peak | [Trapinch](../pokemon/trapinch.md) (Lv. 46) | [Trapinch](../pokemon/trapinch.md) (Lv. 47) | [Trapinch](../pokemon/trapinch.md) (Lv. 46) |
| 8 Waterside | [Lotad](../pokemon/lotad.md) (Lv. 38) | [Lotad](../pokemon/lotad.md) (Lv. 38) | [Lotad](../pokemon/lotad.md) (Lv. 38) |
| 42 Waterside | [Cacturne](../pokemon/cacturne.md) (Lv. 48) | [Cacturne](../pokemon/cacturne.md) (Lv. 48) | [Cacturne](../pokemon/cacturne.md) (Lv. 48) |

### Surf

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 2 | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) | [Wooper](../pokemon/wooper.md) (Lv. 22) |
| 3 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 4 | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) | [Wooper](../pokemon/wooper.md) (Lv. 23) |
| 5 | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) | [Wooper](../pokemon/wooper.md) (Lv. 24) |
| 6 | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) | [Wooper](../pokemon/wooper.md) (Lv. 25) |
| 7 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 8 | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) | [Tentacool](../pokemon/tentacool.md) (Lv. 23) |
| 9 | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) | [Tentacool](../pokemon/tentacool.md) (Lv. 24) |
| 10 | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) | [Tentacool](../pokemon/tentacool.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) | [Quagsire](../pokemon/quagsire.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |
| 20 Forest | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) | [Surskit](../pokemon/surskit.md) (Lv. 25) |

### Old Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) | [Magikarp](../pokemon/magikarp.md) (Lv. 12) |
| 5 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 6 | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) | [Magikarp](../pokemon/magikarp.md) (Lv. 13) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 9 | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) | [Goldeen](../pokemon/goldeen.md) (Lv. 12) |
| 10 | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) | [Goldeen](../pokemon/goldeen.md) (Lv. 13) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |
| 20 Waterside | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) | [Seaking](../pokemon/seaking.md) (Lv. 20) |

### Good Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 2 | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) | [Magikarp](../pokemon/magikarp.md) (Lv. 22) |
| 3 | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) | [Magikarp](../pokemon/magikarp.md) (Lv. 23) |
| 4 | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) | [Magikarp](../pokemon/magikarp.md) (Lv. 24) |
| 5 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 6 | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) | [Goldeen](../pokemon/goldeen.md) (Lv. 22) |
| 7 | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) | [Goldeen](../pokemon/goldeen.md) (Lv. 23) |
| 8 | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) | [Goldeen](../pokemon/goldeen.md) (Lv. 24) |
| 9 | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) | [Seaking](../pokemon/seaking.md) (Lv. 24) |
| 10 | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) | [Seaking](../pokemon/seaking.md) (Lv. 25) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 10 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |
| 20 Waterside | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) | [Dratini](../pokemon/dratini.md) (Lv. 25) |

### Super Rod

#### Base encounters

| Slot | Morning | Day | Night |
| ---: | ------- | --- | ----- |
| 1 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 2 | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) | [Goldeen](../pokemon/goldeen.md) (Lv. 42) |
| 3 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 4 | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) | [Goldeen](../pokemon/goldeen.md) (Lv. 43) |
| 5 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 6 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 7 | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) | [Seaking](../pokemon/seaking.md) (Lv. 44) |
| 8 | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) | [Seaking](../pokemon/seaking.md) (Lv. 45) |
| 9 | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) | [Dratini](../pokemon/dratini.md) (Lv. 44) |
| 10 | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) | [Dratini](../pokemon/dratini.md) (Lv. 45) |

#### Block encounters

| Stored requirements | Morning | Day | Night |
| ------------------- | ------- | --- | ----- |
| 20 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |
| 30 Waterside | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) | [Dragonair](../pokemon/dragonair.md) (Lv. 45) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

### Plains

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Meadow

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Savannah

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Peak

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Rocky Beach

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Wetland

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Forest

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Swamp

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Marshland

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Wasteland

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Mountain

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

### Desert

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/3/0` member `0`.
Source: exact ROM record from `a/2/3/0` member `1`.
Source: exact ROM record from `a/2/3/0` member `2`.
Source: exact ROM record from `a/2/3/0` member `3`.
Source: exact ROM record from `a/2/3/0` member `4`.
Source: exact ROM record from `a/2/3/0` member `5`.
Source: exact ROM record from `a/2/3/0` member `6`.
Source: exact ROM record from `a/2/3/0` member `7`.
Source: exact ROM record from `a/2/3/0` member `8`.
Source: exact ROM record from `a/2/3/0` member `9`.
Source: exact ROM record from `a/2/3/0` member `10`.
Source: exact ROM record from `a/2/3/0` member `11`.
Each member stores ten base slots per method and time of day, followed by block-conditioned records with up to two stored requirements.
Area types can be assigned to different physical Safari Zone positions, so this page does not invent map-header ownership or replacement priority.

</details>
