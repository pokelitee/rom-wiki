# Route 10

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>120</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 10](../locations/header-018.md) | 18 | 158 | `R10` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 47 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 (4%); 50 (4%); 52 (2%) | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 47 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 (4%); 50 (4%); 52 (2%) | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 49 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electrode](../pokemon/electrode.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 51 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Manectric](../pokemon/manectric.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pikachu](../pokemon/pikachu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 47 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Electabuzz](../pokemon/electabuzz.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 (4%); 50 (4%); 52 (2%) | 10% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45–55 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chinchou](../pokemon/chinchou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 10–30 (30%); 20–25 (5%); 20–40 (4%); 35–40 (1%) | 40% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chinchou](../pokemon/chinchou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 10 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Chinchou](../pokemon/chinchou.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 20 | 80% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 20 | 20% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 50 | 100% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luxray](../pokemon/luxray.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Ampharos](../pokemon/ampharos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Pichu](../pokemon/pichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Elekid](../pokemon/elekid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 15</li><li>Electabuzz — Lv. 18</li><li>Raticate — Lv. 16</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Electabuzz — Lv. 15</li><li>Electabuzz — Lv. 18</li><li>Fearow — Lv. 18</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 52</li><li>Flaaffy — Lv. 48</li><li>Electrode — Lv. 50</li><li>Raticate — Lv. 50</li><li>Manectric — Lv. 50</li><li>Luxio — Lv. 49</li><li>Fearow — Lv. 50</li><li>Electabuzz — Lv. 48</li><li>Electabuzz — Lv. 50</li><li>Pikachu — Lv. 47</li><li>Electrode — Lv. 51</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 15</li><li>Electabuzz — Lv. 18</li><li>Raticate — Lv. 16</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Electabuzz — Lv. 15</li><li>Electabuzz — Lv. 18</li><li>Fearow — Lv. 18</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 52</li><li>Flaaffy — Lv. 48</li><li>Electrode — Lv. 50</li><li>Raticate — Lv. 50</li><li>Manectric — Lv. 50</li><li>Luxio — Lv. 49</li><li>Fearow — Lv. 50</li><li>Electabuzz — Lv. 48</li><li>Electabuzz — Lv. 50</li><li>Pikachu — Lv. 47</li><li>Electrode — Lv. 51</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 15</li><li>Raticate — Lv. 18</li><li>Raticate — Lv. 16</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Spearow — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Electabuzz — Lv. 15</li><li>Raticate — Lv. 18</li><li>Fearow — Lv. 18</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 52</li><li>Flaaffy — Lv. 48</li><li>Electrode — Lv. 50</li><li>Raticate — Lv. 50</li><li>Manectric — Lv. 50</li><li>Luxio — Lv. 49</li><li>Fearow — Lv. 50</li><li>Electabuzz — Lv. 48</li><li>Electabuzz — Lv. 50</li><li>Pikachu — Lv. 47</li><li>Electrode — Lv. 51</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 15</li><li>Raticate — Lv. 18</li><li>Quagsire — Lv. 16</li><li>Raticate — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Quagsire — Lv. 16</li><li>Voltorb — Lv. 17</li><li>Electabuzz — Lv. 15</li><li>Raticate — Lv. 18</li><li>Quagsire — Lv. 18</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Electabuzz — Lv. 52</li><li>Flaaffy — Lv. 48</li><li>Electrode — Lv. 50</li><li>Raticate — Lv. 50</li><li>Manectric — Lv. 50</li><li>Luxio — Lv. 49</li><li>Fearow — Lv. 50</li><li>Electabuzz — Lv. 48</li><li>Electabuzz — Lv. 50</li><li>Pikachu — Lv. 47</li><li>Electrode — Lv. 51</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 15</li><li>Goldeen — Lv. 10</li><li>Seaking — Lv. 15</li><li>Seaking — Lv. 15</li><li>Goldeen — Lv. 15</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 35–40</li><li>Chinchou — Lv. 10–30</li><li>Chinchou — Lv. 20–40</li><li>Chinchou — Lv. 20–25</li><li>Fearow — Lv. 45–55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Goldeen — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 10</li><li>Chinchou — Lv. 10</li><li>Chinchou — Lv. 10</li><li>Chinchou — Lv. 10</li><li>Chinchou — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Goldeen — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Chinchou — Lv. 20</li><li>Lanturn — Lv. 20</li><li>Chinchou — Lv. 20</li><li>Chinchou — Lv. 20</li><li>Lanturn — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lanturn — Lv. 50</li><li>Lanturn — Lv. 50</li><li>Lanturn — Lv. 50</li><li>Lanturn — Lv. 50</li><li>Lanturn — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Ampharos</li><li>Luxray</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Pichu</li><li>Elekid</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `120`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-111/"><span class="rw-record-nav__label">← Route 1</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-121/"><span class="rw-record-nav__label">Route 11 →</span></a>
</nav>
