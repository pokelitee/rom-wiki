# Route 7

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>117</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 7](../locations/header-015.md) | `header-015` | 155 | `R07` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50–52 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 54 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–54 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 50–52 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/64.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kadabra](../pokemon/kadabra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 54 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–54 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 52 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/228.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Houndour](../pokemon/houndour.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 50–52 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/58.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Growlithe](../pokemon/growlithe.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/37.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vulpix](../pokemon/vulpix.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 51 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/229.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Houndoom](../pokemon/houndoom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 54 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/53.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Persian](../pokemon/persian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52–54 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/52.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meowth](../pokemon/meowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/182.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellossom](../pokemon/bellossom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 19</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 51</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 52</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 53</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 54</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 19</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 51</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 52</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 53</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 54</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 17</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 15</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 19</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 19</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 51</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 52</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 52</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 53</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 52</li><li><a href="../../pokemon/kadabra/">Kadabra</a> — Lv. 54</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/houndour/">Houndour</a> — Lv. 15</li><li><a href="../../pokemon/murkrow/">Murkrow</a> — Lv. 19</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/murkrow/">Murkrow</a> — Lv. 17</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 18</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 17</li><li><a href="../../pokemon/murkrow/">Murkrow</a> — Lv. 17</li><li><a href="../../pokemon/houndour/">Houndour</a> — Lv. 15</li><li><a href="../../pokemon/murkrow/">Murkrow</a> — Lv. 19</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 19</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/persian/">Persian</a> — Lv. 52</li><li><a href="../../pokemon/persian/">Persian</a> — Lv. 54</li><li><a href="../../pokemon/houndour/">Houndour</a> — Lv. 50</li><li><a href="../../pokemon/vulpix/">Vulpix</a> — Lv. 50</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 50</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 51</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 52</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 52</li><li><a href="../../pokemon/persian/">Persian</a> — Lv. 52</li><li><a href="../../pokemon/persian/">Persian</a> — Lv. 53</li><li><a href="../../pokemon/houndour/">Houndour</a> — Lv. 52</li><li><a href="../../pokemon/houndoom/">Houndoom</a> — Lv. 54</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Bellossom</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 19<span class="rw-diff-arrow">→</span>52</li><li>Name: Rattata<span class="rw-diff-arrow">→</span>Meowth</li><li>Slug: rattata<span class="rw-diff-arrow">→</span>meowth</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Linoone</li><li>Bibarel</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `117`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-116/"><span class="rw-record-nav__label">← Route 6</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-118/"><span class="rw-record-nav__label">Route 8 →</span></a>
</nav>
