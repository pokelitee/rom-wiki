# Route 30

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>3</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 30](../locations/header-034.md) | `header-034` | 178 | `R30` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/276.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Taillow](../pokemon/taillow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/401.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 5–6 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 5–6 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/276.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Taillow](../pokemon/taillow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/14.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kakuna](../pokemon/kakuna.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 5–6 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 5–6 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/167.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/273.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seedot](../pokemon/seedot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/10.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Caterpie](../pokemon/caterpie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 4 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/13.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weedle](../pokemon/weedle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/401.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kricketot](../pokemon/kricketot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 5 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 5–6 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 5–6 | 5% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/270.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/271.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 25–35 | 5% |

## Old Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–10 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–35 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/271.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/280.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ralts](../pokemon/ralts.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Caterpie — Lv. 4</li><li>Metapod — Lv. 4</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 4</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Caterpie — Lv. 4</li><li>Metapod — Lv. 4</li><li>Metapod — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Ralts — Lv. 6</li><li>Surskit — Lv. 6</li><li>Lotad — Lv. 4</li><li>Seedot — Lv. 4</li><li>Taillow — Lv. 4</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 4</li><li>Weedle — Lv. 4</li><li>Ralts — Lv. 5</li><li>Surskit — Lv. 5</li><li>Kakuna — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Caterpie — Lv. 4</li><li>Metapod — Lv. 4</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 4</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Caterpie — Lv. 4</li><li>Metapod — Lv. 4</li><li>Metapod — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Ralts — Lv. 6</li><li>Surskit — Lv. 6</li><li>Lotad — Lv. 4</li><li>Seedot — Lv. 4</li><li>Taillow — Lv. 4</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 4</li><li>Weedle — Lv. 4</li><li>Ralts — Lv. 5</li><li>Surskit — Lv. 5</li><li>Kakuna — Lv. 5</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">7 entries removed</p><ul class="rw-comparison-list"><li>Pidgey — Lv. 4</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 2</li><li>Caterpie — Lv. 3</li><li>Pidgey — Lv. 4</li><li>Metapod — Lv. 4</li></ul><p class="rw-comparison-count">10 entries added</p><ul class="rw-comparison-list"><li>Ralts — Lv. 6</li><li>Surskit — Lv. 6</li><li>Lotad — Lv. 4</li><li>Seedot — Lv. 4</li><li>Weedle — Lv. 5</li><li>Ledyba — Lv. 4</li><li>Taillow — Lv. 4</li><li>Ralts — Lv. 5</li><li>Surskit — Lv. 5</li><li>Kricketot — Lv. 5</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Hoothoot — Lv. 4</li><li>Spinarak — Lv. 2</li><li>Rattata — Lv. 3</li><li>Hoothoot — Lv. 4</li><li>Spinarak — Lv. 2</li><li>Rattata — Lv. 3</li><li>Hoothoot — Lv. 4</li><li>Rattata — Lv. 4</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li>Ralts — Lv. 6</li><li>Surskit — Lv. 6</li><li>Caterpie — Lv. 4</li><li>Lotad — Lv. 4</li><li>Seedot — Lv. 4</li><li>Weedle — Lv. 5</li><li>Hoothoot — Lv. 4</li><li>Spinarak — Lv. 4</li><li>Ralts — Lv. 5</li><li>Surskit — Lv. 5</li><li>Kricketot — Lv. 5</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 32</li><li>Poliwag — Lv. 10–20</li><li>Poliwhirl — Lv. 15–25</li><li>Poliwhirl — Lv. 15–25</li><li>Poliwag — Lv. 15–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lombre — Lv. 25–35</li><li>Lotad — Lv. 25–30</li><li>Lombre — Lv. 25–35</li><li>Poliwhirl — Lv. 25–35</li><li>Poliwag — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>50</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Poliwag — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Psyduck — Lv. 5–10</li><li>Psyduck — Lv. 5–10</li><li>Goldeen — Lv. 5–10</li><li>Poliwag — Lv. 5–10</li><li>Psyduck — Lv. 5–10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Poliwag — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 25–35</li><li>Poliwhirl — Lv. 25–35</li><li>Goldeen — Lv. 25–30</li><li>Psyduck — Lv. 25–30</li><li>Poliwhirl — Lv. 25–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Poliwag — Lv. 40</li><li>Poliwag — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Golduck — Lv. 40</li><li>Golduck — Lv. 40</li><li>Seaking — Lv. 40</li><li>Poliwhirl — Lv. 40</li><li>Golduck — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lombre</li><li>Nuzleaf</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 16<span class="rw-diff-arrow">→</span>165</li><li>Name: Pidgey<span class="rw-diff-arrow">→</span>Ledyba</li><li>Slug: pidgey<span class="rw-diff-arrow">→</span>ledyba</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Ralts</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `3`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-113/"><span class="rw-record-nav__label">← Route 3</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-004/"><span class="rw-record-nav__label">Route 31 →</span></a>
</nav>
