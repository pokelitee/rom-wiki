# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 29](../locations/header-033.md) | `header-033` | `R29` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 2–3 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 2–3 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 2–3 | 20% |

## Rare trees

=== "Sacred Gold"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–5 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/167.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 4–5 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 4–5 | 20% |

=== "Storm Silver"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–5 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 4–5 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 4–5 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (588, 396), (588, 397), (589, 397) |
| 1 | Regular | (612, 395), (612, 396), (613, 395), (613, 396) |
| 2 | Regular | (616, 393), (617, 393), (616, 392) |
| 3 | Regular | (630, 395), (631, 395), (630, 394) |
| 4 | Regular | (648, 397), (649, 397), (648, 396) |
| 5 | Regular | (640, 397), (640, 396) |
| 6 | Regular | (652, 411), (653, 411) |
| 7 | Regular | (640, 410), (641, 410), (641, 409) |
| 8 | Regular | (605, 406), (605, 405), (604, 405) |
| 9 | Regular | (580, 393), (581, 393) |
| 10 | Regular | (580, 403), (581, 403), (581, 405), (581, 404) |
| 11 | Regular | (588, 407), (589, 407), (588, 408), (588, 409) |
| 12 | Regular | (594, 389), (595, 389) |
| 13 | Regular | (604, 389), (605, 389) |
| 14 | Regular | (606, 399), (607, 399), (606, 400), (606, 401), (607, 401) |
| 15 | Regular | (658, 386) |
| 16 | Regular | (617, 407), (618, 407), (618, 406), (618, 405), (617, 405) |
| 17 | Regular | (622, 403), (623, 403), (623, 402) |
| 18 | Regular | (618, 413), (619, 413) |
| 19 | Regular | (628, 413), (629, 413) |
| 20 | Regular | (638, 413), (639, 413) |
| 21 | Regular | (638, 389), (639, 389), (639, 388) |
| 22 | Regular | (640, 401), (641, 401), (640, 400) |
| 23 | Regular | (584, 413), (585, 413) |
| 24 | Regular | (582, 393), (583, 393) |
| 25 | Regular | (668, 395), (669, 395) |
| 26 | Regular | (664, 407), (665, 407) |
| 27 | Regular | (654, 397), (655, 397), (655, 396) |
| 28 | Regular | (658, 395), (659, 395), (659, 394) |
| 29 | Regular | (632, 401), (633, 401), (632, 399), (633, 399) |
| 30 | Regular | (596, 405), (597, 405) |
| 31 | Regular | (606, 411), (607, 411) |
| 32 | Regular | (622, 389), (623, 389) |
| 33 | Regular | (658, 407), (659, 407), (658, 408) |
| 34 | Regular | (646, 385), (647, 385) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `33`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-032/"><span class="rw-record-nav__label">← Headbutt encounters — Route 28</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-034/"><span class="rw-record-nav__label">Headbutt encounters — Route 30 →</span></a>
</nav>
