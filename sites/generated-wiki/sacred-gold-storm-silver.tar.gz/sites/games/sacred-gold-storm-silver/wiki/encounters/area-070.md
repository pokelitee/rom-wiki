# Dark Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>70</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Dark Cave](../locations/header-123.md) | `header-123` | 220 | `D42R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/216.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Teddiursa](../pokemon/teddiursa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/218.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/202.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 25–30 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/216.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Teddiursa](../pokemon/teddiursa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/218.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/202.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 25–30 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 28 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/216.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Teddiursa](../pokemon/teddiursa.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/218.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slugma](../pokemon/slugma.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 26–27 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/202.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wobbuffet](../pokemon/wobbuffet.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 25–30 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 30 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/422.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shellos](../pokemon/shellos.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–35 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–35 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/423.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gastrodon](../pokemon/gastrodon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–40 | 10% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 20 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 30% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/74.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/217.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ursaring](../pokemon/ursaring.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 25</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 20</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 26</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 26</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 28</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 30</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 29</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 25</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 20</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 26</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 26</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 28</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 30</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 29</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 25</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 20</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 26</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 26</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 28</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 30</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 29</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 23</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 23</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 25</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 20</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 26</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 26</li><li><a href="../../pokemon/teddiursa/">Teddiursa</a> — Lv. 27</li><li><a href="../../pokemon/slugma/">Slugma</a> — Lv. 27</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 28</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 30</li><li><a href="../../pokemon/ursaring/">Ursaring</a> — Lv. 30</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 28</li><li><a href="../../pokemon/wobbuffet/">Wobbuffet</a> — Lv. 29</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 2–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 5–15</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 2–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 2–10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/gastrodon/">Gastrodon</a> — Lv. 35–40</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 25–35</li><li><a href="../../pokemon/gastrodon/">Gastrodon</a> — Lv. 30–35</li><li><a href="../../pokemon/gastrodon/">Gastrodon</a> — Lv. 25–35</li><li><a href="../../pokemon/shellos/">Shellos</a> — Lv. 25–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 10</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 10</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 20</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 20</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 40</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 40</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 40</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Ursaring</li><li>Golem</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Quagsire</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `70`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-069/"><span class="rw-record-nav__label">← Dark Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-133/"><span class="rw-record-nav__label">Diglett&#x27;s Cave →</span></a>
</nav>
