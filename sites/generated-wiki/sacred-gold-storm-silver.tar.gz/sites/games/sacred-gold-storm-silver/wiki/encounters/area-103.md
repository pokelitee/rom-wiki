# Route 26

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>103</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 26](../locations/header-030.md) | `header-030` | 174 | `R26` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45–46 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/82.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/115.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45–46 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/82.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/115.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/229.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Houndoom](../pokemon/houndoom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 44 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45–46 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/82.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/115.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–45 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/419.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Floatzel](../pokemon/floatzel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 9–33 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–55 | 100% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/171.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/73.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 45 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/189.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jumpluff](../pokemon/jumpluff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/210.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Granbull](../pokemon/granbull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/magneton/">Magneton</a> — Lv. 45</li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a> — Lv. 46</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 46</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 44</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/magneton/">Magneton</a> — Lv. 45</li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a> — Lv. 46</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 46</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 44</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 30</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/magneton/">Magneton</a> — Lv. 45</li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a> — Lv. 46</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 46</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 44</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 30</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 28</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 30</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/magneton/">Magneton</a> — Lv. 45</li><li><a href="../../pokemon/kangaskhan/">Kangaskhan</a> — Lv. 46</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 46</li><li><a href="../../pokemon/houndoom/">Houndoom</a> — Lv. 44</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 45</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 30</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 25</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 30</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 30</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 45</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 25</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 40</li><li><a href="../../pokemon/floatzel/">Floatzel</a> — Lv. 40–45</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 10–33</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 13–24</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 9–11</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 11</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 9–10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 5–9</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 2–26</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 5–55</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 1</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 11–37</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 40</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 45</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 45</li><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 45</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 40–45</li><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Jumpluff</li></ul></li><li>Night Fishing: Shellder<details><summary>Exact data</summary><code>{&quot;id&quot;:90,&quot;name&quot;:&quot;Shellder&quot;,&quot;slug&quot;:&quot;shellder&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Granbull</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `103`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-131/"><span class="rw-record-nav__label">← Route 25</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-104/"><span class="rw-record-nav__label">Route 27 →</span></a>
</nav>
