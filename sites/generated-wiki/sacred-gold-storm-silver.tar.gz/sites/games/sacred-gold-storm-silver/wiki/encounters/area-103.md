# Route 26

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>103</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 26](../locations/header-030.md) | 30 | 174 | `R26` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 45 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 45 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Houndoom](../pokemon/houndoom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 44 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 45 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Floatzel](../pokemon/floatzel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 45 | 1% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 11 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 9–11 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 13–24 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 9–10 | 5% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–55 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2–26 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–9 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 11–37 | 5% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40–45 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lanturn](../pokemon/lanturn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--electric">Electric</span></span> | 45 | 45% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 45 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Jumpluff](../pokemon/jumpluff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Granbull](../pokemon/granbull.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Ponyta — Lv. 32</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Doduo — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Rapidash — Lv. 45</li><li>Magneton — Lv. 45</li><li>Kangaskhan — Lv. 46</li><li>Rapidash — Lv. 46</li><li>Skiploom — Lv. 44</li><li>Dodrio — Lv. 45</li><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Sandslash — Lv. 44</li><li>Sandslash — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Ponyta — Lv. 32</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Doduo — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Rapidash — Lv. 45</li><li>Magneton — Lv. 45</li><li>Kangaskhan — Lv. 46</li><li>Rapidash — Lv. 46</li><li>Skiploom — Lv. 44</li><li>Dodrio — Lv. 45</li><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Sandslash — Lv. 44</li><li>Sandslash — Lv. 45</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Ponyta — Lv. 32</li><li>Sandslash — Lv. 28</li><li>Doduo — Lv. 28</li><li>Raticate — Lv. 30</li><li>Dodrio — Lv. 30</li><li>Doduo — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Rapidash — Lv. 45</li><li>Magneton — Lv. 45</li><li>Kangaskhan — Lv. 46</li><li>Rapidash — Lv. 46</li><li>Skiploom — Lv. 44</li><li>Dodrio — Lv. 45</li><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Sandslash — Lv. 44</li><li>Sandslash — Lv. 45</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Quagsire — Lv. 30</li><li>Raticate — Lv. 28</li><li>Sandslash — Lv. 28</li><li>Ponyta — Lv. 32</li><li>Raticate — Lv. 28</li><li>Sandslash — Lv. 28</li><li>Quagsire — Lv. 30</li><li>Raticate — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Rapidash — Lv. 45</li><li>Magneton — Lv. 45</li><li>Kangaskhan — Lv. 46</li><li>Rapidash — Lv. 46</li><li>Houndoom — Lv. 44</li><li>Quagsire — Lv. 45</li><li>Arbok — Lv. 44</li><li>Arbok — Lv. 45</li><li>Sandslash — Lv. 44</li><li>Sandslash — Lv. 45</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Tentacruel — Lv. 30</li><li>Tentacool — Lv. 25</li><li>Tentacruel — Lv. 30</li><li>Tentacruel — Lv. 30</li><li>Tentacool — Lv. 30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Buizel — Lv. 45</li><li>Buizel — Lv. 25</li><li>Buizel — Lv. 40</li><li>Floatzel — Lv. 40–45</li><li>Buizel — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Tentacool — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Tentacool — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Luvdisc — Lv. 10–33</li><li>Luvdisc — Lv. 13–24</li><li>Luvdisc — Lv. 9–11</li><li>Luvdisc — Lv. 11</li><li>Luvdisc — Lv. 9–10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Shellder — Lv. 20</li><li>Chinchou — Lv. 20</li><li>Tentacool — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Chinchou — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Luvdisc — Lv. 5–9</li><li>Luvdisc — Lv. 2–26</li><li>Luvdisc — Lv. 5–55</li><li>Luvdisc — Lv. 1</li><li>Luvdisc — Lv. 11–37</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Lanturn — Lv. 40</li><li>Tentacruel — Lv. 40</li><li>Shellder — Lv. 40</li><li>Chinchou — Lv. 40</li><li>Tentacruel — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lanturn — Lv. 45</li><li>Tentacruel — Lv. 45</li><li>Lanturn — Lv. 45</li><li>Luvdisc — Lv. 40–45</li><li>Lanturn — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Jumpluff</li></ul></li><li>Night Fishing: Shellder<details><summary>Exact data</summary><code>{&quot;id&quot;:90,&quot;name&quot;:&quot;Shellder&quot;,&quot;slug&quot;:&quot;shellder&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Granbull</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `103`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-131/"><span class="rw-record-nav__label">← Route 25</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-104/"><span class="rw-record-nav__label">Route 27 →</span></a>
</nav>
