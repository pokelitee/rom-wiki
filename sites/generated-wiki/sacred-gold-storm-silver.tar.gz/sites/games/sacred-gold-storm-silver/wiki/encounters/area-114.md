# Route 4

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>114</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 4](../locations/header-012.md) | `header-012` | 152 | `R04` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–50 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/432.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purugly](../pokemon/purugly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/435.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skuntank](../pokemon/skuntank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--dark">Dark</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/40.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wigglytuff](../pokemon/wigglytuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 1% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–50 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/432.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purugly](../pokemon/purugly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/435.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skuntank](../pokemon/skuntank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--dark">Dark</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/40.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wigglytuff](../pokemon/wigglytuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 1% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 47–50 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47–49 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 47–48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/432.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Purugly](../pokemon/purugly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/435.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skuntank](../pokemon/skuntank.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--dark">Dark</span></span> | 50 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/39.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 46–47 | 9% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/40.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wigglytuff](../pokemon/wigglytuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 50 | 1% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–65 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–35 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 30% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 50 | 30% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/40.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wigglytuff](../pokemon/wigglytuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a> — Lv. 50</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 47</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 48</li><li><a href="../../pokemon/purugly/">Purugly</a> — Lv. 50</li><li><a href="../../pokemon/skuntank/">Skuntank</a> — Lv. 50</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 47</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 46</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 49</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a> — Lv. 50</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 47</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 48</li><li><a href="../../pokemon/purugly/">Purugly</a> — Lv. 50</li><li><a href="../../pokemon/skuntank/">Skuntank</a> — Lv. 50</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 47</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 46</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 49</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 50</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 8</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a> — Lv. 50</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 47</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 48</li><li><a href="../../pokemon/purugly/">Purugly</a> — Lv. 50</li><li><a href="../../pokemon/skuntank/">Skuntank</a> — Lv. 50</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 47</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 46</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 49</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 50</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 8</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 8</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 10</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 8</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/wigglytuff/">Wigglytuff</a> — Lv. 50</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 47</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 48</li><li><a href="../../pokemon/purugly/">Purugly</a> — Lv. 50</li><li><a href="../../pokemon/skuntank/">Skuntank</a> — Lv. 50</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 47</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 47</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 46</li><li><a href="../../pokemon/jigglypuff/">Jigglypuff</a> — Lv. 47</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 49</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 50</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 45–50</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40–45</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 25–35</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–65</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 20</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 20</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 50</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 50</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 50</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Wigglytuff</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Sandslash</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `114`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-039/"><span class="rw-record-nav__label">← Route 39</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-041/"><span class="rw-record-nav__label">Route 40 →</span></a>
</nav>
