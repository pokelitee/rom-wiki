# Mt. Moon

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>106</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Mt. Moon](../locations/header-107.md) | `header-107` | 198 | `D02R0101` |

## Walking (Morning)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 48–50 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 49–50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 49–51 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 48–51 | 15% |

## Walking (Day)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 48–50 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 49–50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 49–51 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 48–51 | 15% |

## Walking (Night)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 48–50 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/35.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 47 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 49–50 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 49–51 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 48–51 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/41.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zubat](../pokemon/zubat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/169.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Crobat](../pokemon/crobat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/358.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chimecho](../pokemon/chimecho.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/sandshrew/">Sandshrew</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/paras/">Paras</a> — Lv. 12</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 51</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 49</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 49</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 50</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 50</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 47</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 49</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 50</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 51</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/sandshrew/">Sandshrew</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/paras/">Paras</a> — Lv. 12</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 51</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 49</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 49</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 50</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 50</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 47</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 49</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 50</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 51</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/sandshrew/">Sandshrew</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/paras/">Paras</a> — Lv. 12</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 51</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 49</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 49</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 50</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 50</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 47</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 49</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 50</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 51</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/sandshrew/">Sandshrew</a> — Lv. 8</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 6</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 8</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 10</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 8</li><li><a href="../../pokemon/paras/">Paras</a> — Lv. 12</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 51</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 49</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 49</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 50</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 50</li><li><a href="../../pokemon/clefairy/">Clefairy</a> — Lv. 47</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 48</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 49</li><li><a href="../../pokemon/parasect/">Parasect</a> — Lv. 50</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 51</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Crobat</li><li>Golem</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Chimecho</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `106`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-073/"><span class="rw-record-nav__label">← Mt. Moon</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-107/"><span class="rw-record-nav__label">Mt. Moon →</span></a>
</nav>
