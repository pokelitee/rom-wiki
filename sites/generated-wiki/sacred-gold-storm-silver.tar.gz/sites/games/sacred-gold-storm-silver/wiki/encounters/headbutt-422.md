# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 16](../locations/header-422.md) | `header-422` | `R16R0301` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> | 26–27 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 26–27 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/21.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 29–30 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/415.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 29–30 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (1162, 263), (1163, 263), (1162, 262) |
| 1 | Regular | (1167, 261), (1167, 260) |
| 2 | Regular | (1163, 280), (1164, 280) |
| 3 | Regular | (1174, 277), (1174, 276) |
| 4 | Regular | (1178, 261), (1179, 261) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `422`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-414/"><span class="rw-record-nav__label">← Headbutt encounters — Route 2 (R02R0101)</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-460/"><span class="rw-record-nav__label">Headbutt encounters — Mt. Silver Cave →</span></a>
</nav>
