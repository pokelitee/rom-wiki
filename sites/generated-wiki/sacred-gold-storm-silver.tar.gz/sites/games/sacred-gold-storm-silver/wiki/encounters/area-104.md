# Route 27

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>104</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 27](../locations/header-031.md) | `header-031` | 175 | `R27` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 42 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 42–43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 42 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 42–43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 42 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/228.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Houndour](../pokemon/houndour.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 42–43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/28.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sandslash](../pokemon/sandslash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44–45 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/24.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Arbok](../pokemon/arbok.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 44–45 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–40 | 94% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/419.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Floatzel](../pokemon/floatzel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 45–50 | 6% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–35 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–37 | 100% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/370.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luvdisc](../pokemon/luvdisc.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–53 | 100% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/84.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Doduo](../pokemon/doduo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/349.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Feebas](../pokemon/feebas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/189.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jumpluff](../pokemon/jumpluff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/326.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grumpig](../pokemon/grumpig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 42</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 43</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 42</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 43</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 42</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 43</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 42</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 43</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 30</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 42</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 43</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 42</li><li><a href="../../pokemon/skiploom/">Skiploom</a> — Lv. 43</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 28</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 30</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 28</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 28</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 30</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 32</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 30</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 42</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 43</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 45</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 45</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 42</li><li><a href="../../pokemon/houndour/">Houndour</a> — Lv. 43</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 44</li><li><a href="../../pokemon/arbok/">Arbok</a> — Lv. 45</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 44</li><li><a href="../../pokemon/sandslash/">Sandslash</a> — Lv. 45</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 15</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 20</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/floatzel/">Floatzel</a> — Lv. 45–50</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 40</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 40</li><li><a href="../../pokemon/floatzel/">Floatzel</a> — Lv. 45–50</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 30–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 25–35</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 20</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 20</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 10</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 30</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 20</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 25</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 20</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 37</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/lanturn/">Lanturn</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li><li><a href="../../pokemon/shellder/">Shellder</a> — Lv. 40</li><li><a href="../../pokemon/chinchou/">Chinchou</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 47</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 38–42</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 39–41</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 1–39</li><li><a href="../../pokemon/luvdisc/">Luvdisc</a> — Lv. 53</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Jumpluff</li></ul></li><li>Night Fishing: Shellder<details><summary>Exact data</summary><code>{&quot;id&quot;:90,&quot;name&quot;:&quot;Shellder&quot;,&quot;slug&quot;:&quot;shellder&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Grumpig</li></ul></li><li>Surf Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 370<span class="rw-diff-arrow">→</span>349</li><li>Name: Luvdisc<span class="rw-diff-arrow">→</span>Feebas</li><li>Slug: luvdisc<span class="rw-diff-arrow">→</span>feebas</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `104`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-103/"><span class="rw-record-nav__label">← Route 26</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-105/"><span class="rw-record-nav__label">Route 28 →</span></a>
</nav>
