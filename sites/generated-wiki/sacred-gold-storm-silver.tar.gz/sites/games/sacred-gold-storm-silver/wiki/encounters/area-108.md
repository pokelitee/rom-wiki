# Rock Tunnel

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>108</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Rock Tunnel](../locations/header-108.md) | `header-108` | 200 | `D05R0101` |

## Walking (Morning)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/296.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52–53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 52–53 | 10% |

## Walking (Day)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/296.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52–53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 52–53 | 10% |

## Walking (Night)

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 53 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/296.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Makuhita](../pokemon/makuhita.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 52 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/132.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ditto](../pokemon/ditto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/56.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mankey](../pokemon/mankey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 52–53 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 52–53 | 10% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/104.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cubone](../pokemon/cubone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/297.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hariyama](../pokemon/hariyama.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/82.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/115.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kangaskhan](../pokemon/kangaskhan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 12</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 52</li><li><a href="../../pokemon/makuhita/">Makuhita</a> — Lv. 52</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 53</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 55</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 53</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 53</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 52</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 53</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 12</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 52</li><li><a href="../../pokemon/makuhita/">Makuhita</a> — Lv. 52</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 53</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 55</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 53</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 53</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 52</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 53</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 12</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 52</li><li><a href="../../pokemon/makuhita/">Makuhita</a> — Lv. 52</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 53</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 55</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 53</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 53</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 52</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 53</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 12</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 10</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 10</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 13</li><li><a href="../../pokemon/machoke/">Machoke</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 8</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/cubone/">Cubone</a> — Lv. 52</li><li><a href="../../pokemon/makuhita/">Makuhita</a> — Lv. 52</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 53</li><li><a href="../../pokemon/ditto/">Ditto</a> — Lv. 55</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 53</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 53</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 52</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 53</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 52</li><li><a href="../../pokemon/mankey/">Mankey</a> — Lv. 53</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Hariyama</li><li>Magneton</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Kangaskhan</li><li>Absol</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `108`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-095/"><span class="rw-record-nav__label">← Pallet Town</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-109/"><span class="rw-record-nav__label">Rock Tunnel →</span></a>
</nav>
