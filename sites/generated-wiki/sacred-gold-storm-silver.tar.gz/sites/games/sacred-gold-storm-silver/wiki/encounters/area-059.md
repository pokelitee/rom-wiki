# Route 44

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>59</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | ID | Location name ID | Internal map |
| -------- | -- | ----------------: | ------------ |
| [Route 44](../locations/header-046.md) | `header-046` | 192 | `R44` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 38–39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Vespiquen](../pokemon/vespiquen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 1% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 38–39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Vespiquen](../pokemon/vespiquen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 1% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lickitung](../pokemon/lickitung.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 38 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 38 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 38–39 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Cherrim](../pokemon/cherrim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 38 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Altaria](../pokemon/altaria.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Vespiquen](../pokemon/vespiquen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 39 | 1% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lotad](../pokemon/lotad.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 20–40 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–45 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> | 30–45 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 85% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Remoraid](../pokemon/remoraid.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35 | 60% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Gyarados](../pokemon/gyarados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--flying">Flying</span></span> | 40 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Octillery](../pokemon/octillery.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangrowth](../pokemon/tangrowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lickilicky](../pokemon/lickilicky.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Combee](../pokemon/combee.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Bellsprout — Lv. 22</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Lickitung — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 38</li><li>Vespiquen — Lv. 39</li><li>Skiploom — Lv. 38</li><li>Butterfree — Lv. 39</li><li>Beedrill — Lv. 39</li><li>Beautifly — Lv. 39</li><li>Lickitung — Lv. 38</li><li>Tangela — Lv. 38</li><li>Cherrim — Lv. 38</li><li>Altaria — Lv. 39</li><li>Nuzleaf — Lv. 38</li><li>Nuzleaf — Lv. 39</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Bellsprout — Lv. 22</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Lickitung — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 38</li><li>Vespiquen — Lv. 39</li><li>Skiploom — Lv. 38</li><li>Butterfree — Lv. 39</li><li>Beedrill — Lv. 39</li><li>Beautifly — Lv. 39</li><li>Lickitung — Lv. 38</li><li>Tangela — Lv. 38</li><li>Cherrim — Lv. 38</li><li>Altaria — Lv. 39</li><li>Nuzleaf — Lv. 38</li><li>Nuzleaf — Lv. 39</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Bellsprout — Lv. 22</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Lickitung — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 38</li><li>Vespiquen — Lv. 39</li><li>Skiploom — Lv. 38</li><li>Butterfree — Lv. 39</li><li>Beedrill — Lv. 39</li><li>Beautifly — Lv. 39</li><li>Lickitung — Lv. 38</li><li>Tangela — Lv. 38</li><li>Cherrim — Lv. 38</li><li>Altaria — Lv. 39</li><li>Nuzleaf — Lv. 38</li><li>Nuzleaf — Lv. 39</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Bellsprout — Lv. 22</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 22</li><li>Tangela — Lv. 23</li><li>Weepinbell — Lv. 24</li><li>Lickitung — Lv. 26</li><li>Lickitung — Lv. 24</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Cherrim — Lv. 38</li><li>Vespiquen — Lv. 39</li><li>Skiploom — Lv. 38</li><li>Butterfree — Lv. 39</li><li>Beedrill — Lv. 39</li><li>Beautifly — Lv. 39</li><li>Lickitung — Lv. 38</li><li>Tangela — Lv. 38</li><li>Cherrim — Lv. 38</li><li>Altaria — Lv. 39</li><li>Nuzleaf — Lv. 38</li><li>Nuzleaf — Lv. 39</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwhirl — Lv. 20–30</li><li>Poliwag — Lv. 15–25</li><li>Poliwhirl — Lv. 20–30</li><li>Poliwhirl — Lv. 20–30</li><li>Poliwag — Lv. 20–30</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Lombre — Lv. 30–45</li><li>Poliwag — Lv. 20–40</li><li>Lombre — Lv. 30–45</li><li>Poliwhirl — Lv. 30–45</li><li>Lotad — Lv. 20–40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Poliwag — Lv. 10</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li>Magikarp — Lv. 10</li><li>Remoraid — Lv. 10</li><li>Magikarp — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Poliwag — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Remoraid — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Remoraid — Lv. 35</li><li>Remoraid — Lv. 35</li><li>Remoraid — Lv. 35</li><li>Magikarp — Lv. 35</li><li>Remoraid — Lv. 35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Remoraid — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Poliwag — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Octillery — Lv. 40</li><li>Gyarados — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Gyarados — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Remoraid<details><summary>Exact data</summary><code>{&quot;id&quot;:223,&quot;name&quot;:&quot;Remoraid&quot;,&quot;slug&quot;:&quot;remoraid&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lickilicky</li><li>Tangrowth</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lombre</li><li>Combee</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `59`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-057/"><span class="rw-record-nav__label">← Route 43</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-067/"><span class="rw-record-nav__label">Route 45 →</span></a>
</nav>
