# Mt. Silver Cave

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>88</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Mt. Silver Cave](../locations/header-461.md) | 461 | 219 | `D41R0104` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 62 (20%); 64 (11%); 63 (14%) | 45% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 (10%); 64 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shelgon](../pokemon/shelgon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 61 (10%); 63 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 50 | 5% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 62 (20%); 64 (11%); 63 (14%) | 45% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 (10%); 64 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shelgon](../pokemon/shelgon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 61 (10%); 63 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 50 | 5% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 62 (20%); 64 (11%); 63 (4%) | 35% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 62 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Misdreavus](../pokemon/misdreavus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 63 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 62 (10%); 64 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shelgon](../pokemon/shelgon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 61 (10%); 63 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 50 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shelgon](../pokemon/shelgon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Paras](../pokemon/paras.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Bagon](../pokemon/bagon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 10<span class="rw-diff-arrow">→</span>20</li><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 47</li><li>Donphan — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Golduck — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Pupitar — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 50</li><li>Parasect — Lv. 64</li><li>Shelgon — Lv. 61</li><li>Quagsire — Lv. 62</li><li>Parasect — Lv. 63</li><li>Parasect — Lv. 64</li><li>Parasect — Lv. 62</li><li>Golduck — Lv. 62</li><li>Bagon — Lv. 50</li><li>Parasect — Lv. 63</li><li>Shelgon — Lv. 63</li><li>Quagsire — Lv. 64</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 10<span class="rw-diff-arrow">→</span>20</li><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 47</li><li>Donphan — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Golduck — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Pupitar — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 50</li><li>Parasect — Lv. 64</li><li>Shelgon — Lv. 61</li><li>Quagsire — Lv. 62</li><li>Parasect — Lv. 63</li><li>Parasect — Lv. 64</li><li>Parasect — Lv. 62</li><li>Golduck — Lv. 62</li><li>Bagon — Lv. 50</li><li>Parasect — Lv. 63</li><li>Shelgon — Lv. 63</li><li>Quagsire — Lv. 64</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 10<span class="rw-diff-arrow">→</span>20</li><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 47</li><li>Donphan — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Golduck — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Pupitar — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 50</li><li>Parasect — Lv. 64</li><li>Shelgon — Lv. 61</li><li>Quagsire — Lv. 62</li><li>Parasect — Lv. 63</li><li>Parasect — Lv. 64</li><li>Parasect — Lv. 62</li><li>Golduck — Lv. 62</li><li>Bagon — Lv. 50</li><li>Parasect — Lv. 63</li><li>Shelgon — Lv. 63</li><li>Quagsire — Lv. 64</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 10<span class="rw-diff-arrow">→</span>20</li><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li>Larvitar — Lv. 15</li><li>Golbat — Lv. 48</li><li>Misdreavus — Lv. 45</li><li>Phanpy — Lv. 46</li><li>Donphan — Lv. 47</li><li>Donphan — Lv. 48</li><li>Misdreavus — Lv. 45</li><li>Golduck — Lv. 48</li><li>Larvitar — Lv. 20</li><li>Golbat — Lv. 48</li><li>Quagsire — Lv. 45</li><li>Pupitar — Lv. 45</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Bagon — Lv. 50</li><li>Parasect — Lv. 64</li><li>Shelgon — Lv. 61</li><li>Quagsire — Lv. 62</li><li>Misdreavus — Lv. 63</li><li>Parasect — Lv. 64</li><li>Parasect — Lv. 62</li><li>Golduck — Lv. 62</li><li>Bagon — Lv. 50</li><li>Parasect — Lv. 63</li><li>Shelgon — Lv. 63</li><li>Quagsire — Lv. 64</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Shelgon</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Bagon</li><li>Paras</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `88`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-087/"><span class="rw-record-nav__label">← Mt. Silver Cave</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-089/"><span class="rw-record-nav__label">Mt. Silver Cave →</span></a>
</nav>
