# Route 45

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>67</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 45](../locations/header-047.md) | `header-047` | 193 | `R45` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/326.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grumpig](../pokemon/grumpig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 43–44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 44–45 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/326.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grumpig](../pokemon/grumpig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 43–44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 44–45 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 42–44 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/326.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Grumpig](../pokemon/grumpig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 43 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/232.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Donphan](../pokemon/donphan.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/323.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Camerupt](../pokemon/camerupt.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/324.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Torkoal](../pokemon/torkoal.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/207.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gligar](../pokemon/gligar.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> | 43–44 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--dragon">Dragon</span></span> | 43–44 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/227.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skarmory](../pokemon/skarmory.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--flying">Flying</span></span> | 44–45 | 5% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 2–25 | 100% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 10 | 10% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 20 | 10% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 90% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/147.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dratini](../pokemon/dratini.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dragon">Dragon</span></span> | 40 | 10% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> |

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/472.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gliscor](../pokemon/gliscor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/76.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golem](../pokemon/golem.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/329.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vibrava](../pokemon/vibrava.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--dragon">Dragon</span></span> |

## Hack changes

<details markdown="1">
<summary>6 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/phanpy/">Phanpy</a> — Lv. 20</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 44</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 45</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 44</li><li><a href="../../pokemon/camerupt/">Camerupt</a> — Lv. 44</li><li><a href="../../pokemon/torkoal/">Torkoal</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li><li><a href="../../pokemon/grumpig/">Grumpig</a> — Lv. 43</li><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 43</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 44</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 43</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 44</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/phanpy/">Phanpy</a> — Lv. 20</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 44</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 45</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 44</li><li><a href="../../pokemon/camerupt/">Camerupt</a> — Lv. 44</li><li><a href="../../pokemon/torkoal/">Torkoal</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li><li><a href="../../pokemon/grumpig/">Grumpig</a> — Lv. 43</li><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 43</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 44</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 43</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 44</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/phanpy/">Phanpy</a> — Lv. 20</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 44</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 45</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 44</li><li><a href="../../pokemon/camerupt/">Camerupt</a> — Lv. 44</li><li><a href="../../pokemon/torkoal/">Torkoal</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li><li><a href="../../pokemon/grumpig/">Grumpig</a> — Lv. 43</li><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 43</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 44</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 43</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 44</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 24</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 23</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 25</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 27</li><li><a href="../../pokemon/phanpy/">Phanpy</a> — Lv. 20</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 44</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 45</li><li><a href="../../pokemon/donphan/">Donphan</a> — Lv. 44</li><li><a href="../../pokemon/camerupt/">Camerupt</a> — Lv. 44</li><li><a href="../../pokemon/torkoal/">Torkoal</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 44</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 42</li><li><a href="../../pokemon/grumpig/">Grumpig</a> — Lv. 43</li><li><a href="../../pokemon/vibrava/">Vibrava</a> — Lv. 43</li><li><a href="../../pokemon/skarmory/">Skarmory</a> — Lv. 44</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 43</li><li><a href="../../pokemon/gligar/">Gligar</a> — Lv. 44</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">3 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li></ul><p class="rw-comparison-count">3 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dratini/">Dratini</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Gliscor</li><li>Golem</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 333<span class="rw-diff-arrow">→</span>112</li><li>Name: Swablu<span class="rw-diff-arrow">→</span>Rhydon</li><li>Slug: swablu<span class="rw-diff-arrow">→</span>rhydon</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Rhyhorn</li><li>Vibrava</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `67`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-059/"><span class="rw-record-nav__label">← Route 44</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-068/"><span class="rw-record-nav__label">Route 46 →</span></a>
</nav>
