# Viridian Forest

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>137</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Viridian Forest](../locations/header-147.md) | `header-147` | 224 | `D46R0101` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 64–68 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 64–68 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 60 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/166.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledian](../pokemon/ledian.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/413.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wormadam](../pokemon/wormadam-plant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 64–68 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/414.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mothim](../pokemon/mothim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 64–68 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 64–68 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 64–68 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 60 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/123.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Scyther](../pokemon/scyther.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/127.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pinsir](../pokemon/pinsir.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/413.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wormadam](../pokemon/wormadam-plant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 64–68 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/414.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mothim](../pokemon/mothim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 64–68 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/47.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Parasect](../pokemon/parasect.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 64 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 64–68 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/455.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Carnivine](../pokemon/carnivine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> | 60 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/168.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ariados](../pokemon/ariados.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 68 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/198.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Murkrow](../pokemon/murkrow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--flying">Flying</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/200.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Misdreavus](../pokemon/misdreavus.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span></span> | 64 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 68 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/413.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wormadam](../pokemon/wormadam-plant.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--grass">Grass</span></span> | 64–68 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/414.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mothim](../pokemon/mothim.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 64–68 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/214.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Heracross](../pokemon/heracross.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--fighting">Fighting</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/275.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shiftry](../pokemon/shiftry.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/45.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Vileplume](../pokemon/vileplume.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/424.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ambipom](../pokemon/ambipom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/26.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raichu](../pokemon/raichu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 15<span class="rw-diff-arrow">→</span>25</li><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Pikachu — Lv. 4</li><li>Pikachu — Lv. 7</li><li>Metapod — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pikachu — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Pidgey — Lv. 7</li><li>Pidgeotto — Lv. 7</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Wormadam — Lv. 68</li><li>Mothim — Lv. 68</li><li>Nuzleaf — Lv. 60</li><li>Scyther — Lv. 64</li><li>Pinsir — Lv. 64</li><li>Tropius — Lv. 68</li><li>Gloom — Lv. 64</li><li>Weepinbell — Lv. 64</li><li>Wormadam — Lv. 64</li><li>Mothim — Lv. 64</li><li>Gloom — Lv. 68</li><li>Weepinbell — Lv. 68</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 15<span class="rw-diff-arrow">→</span>25</li><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Pikachu — Lv. 4</li><li>Pikachu — Lv. 7</li><li>Metapod — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pikachu — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Pidgey — Lv. 7</li><li>Pidgeotto — Lv. 7</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Wormadam — Lv. 68</li><li>Mothim — Lv. 68</li><li>Nuzleaf — Lv. 60</li><li>Scyther — Lv. 64</li><li>Pinsir — Lv. 64</li><li>Tropius — Lv. 68</li><li>Gloom — Lv. 64</li><li>Weepinbell — Lv. 64</li><li>Wormadam — Lv. 64</li><li>Mothim — Lv. 64</li><li>Gloom — Lv. 68</li><li>Weepinbell — Lv. 68</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 15<span class="rw-diff-arrow">→</span>25</li><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Pikachu — Lv. 4</li><li>Pikachu — Lv. 7</li><li>Metapod — Lv. 3</li><li>Pidgey — Lv. 3</li><li>Metapod — Lv. 5</li><li>Caterpie — Lv. 3</li><li>Pikachu — Lv. 4</li><li>Pidgeotto — Lv. 7</li><li>Butterfree — Lv. 7</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Wormadam — Lv. 68</li><li>Mothim — Lv. 68</li><li>Nuzleaf — Lv. 60</li><li>Scyther — Lv. 64</li><li>Pinsir — Lv. 64</li><li>Ledian — Lv. 68</li><li>Gloom — Lv. 64</li><li>Weepinbell — Lv. 64</li><li>Wormadam — Lv. 64</li><li>Mothim — Lv. 64</li><li>Gloom — Lv. 68</li><li>Weepinbell — Lv. 68</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 15<span class="rw-diff-arrow">→</span>25</li><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Pikachu — Lv. 4</li><li>Noctowl — Lv. 7</li><li>Hoothoot — Lv. 3</li><li>Hoothoot — Lv. 5</li><li>Hoothoot — Lv. 3</li><li>Pikachu — Lv. 4</li><li>Noctowl — Lv. 7</li><li>Noctowl — Lv. 7</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Wormadam — Lv. 68</li><li>Mothim — Lv. 68</li><li>Carnivine — Lv. 60</li><li>Murkrow — Lv. 64</li><li>Misdreavus — Lv. 64</li><li>Ariados — Lv. 68</li><li>Gloom — Lv. 64</li><li>Parasect — Lv. 64</li><li>Wormadam — Lv. 64</li><li>Mothim — Lv. 64</li><li>Gloom — Lv. 68</li><li>Weepinbell — Lv. 68</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Numel</li><li>Spoink</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Shiftry</li><li>Vileplume</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 401<span class="rw-diff-arrow">→</span>214</li><li>Name: Kricketot<span class="rw-diff-arrow">→</span>Heracross</li><li>Slug: kricketot<span class="rw-diff-arrow">→</span>heracross</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Budew</li><li>Carnivine</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Raichu</li><li>Ambipom</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `137`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-096/"><span class="rw-record-nav__label">← Viridian City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-043/"><span class="rw-record-nav__label">Whirl Islands →</span></a>
</nav>
