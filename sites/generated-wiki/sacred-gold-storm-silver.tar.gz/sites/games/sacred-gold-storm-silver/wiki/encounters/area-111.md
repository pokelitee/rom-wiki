# Route 1

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>111</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 1](../locations/header-009.md) | `header-009` | 149 | `R01` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/161.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sentret](../pokemon/sentret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/162.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 58–60 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–58 | 5% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/16.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgey](../pokemon/pidgey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/161.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sentret](../pokemon/sentret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/396.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Starly](../pokemon/starly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/17.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pidgeotto](../pokemon/pidgeotto.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/162.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 58–60 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/397.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staravia](../pokemon/staravia.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–58 | 5% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/19.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/77.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ponyta](../pokemon/ponyta.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/263.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Zigzagoon](../pokemon/zigzagoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/399.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bidoof](../pokemon/bidoof.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 48 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/164.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Noctowl](../pokemon/noctowl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 55 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 58–60 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/404.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Luxio](../pokemon/luxio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> | 56–58 | 5% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/264.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/398.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Staraptor](../pokemon/staraptor.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/400.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bibarel](../pokemon/bibarel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--water">Water</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/162.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Furret](../pokemon/furret.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/188.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Skiploom](../pokemon/skiploom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 58</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 60</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 48</li><li><a href="../../pokemon/zigzagoon/">Zigzagoon</a> — Lv. 48</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 48</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 48</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 48</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 48</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 56</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 58</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 55</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 58</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 60</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 48</li><li><a href="../../pokemon/zigzagoon/">Zigzagoon</a> — Lv. 48</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 48</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 48</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 48</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 48</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 56</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 58</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 55</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 55</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 3</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 4</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 6</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 58</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 60</li><li><a href="../../pokemon/sentret/">Sentret</a> — Lv. 48</li><li><a href="../../pokemon/zigzagoon/">Zigzagoon</a> — Lv. 48</li><li><a href="../../pokemon/starly/">Starly</a> — Lv. 48</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 48</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 48</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 48</li><li><a href="../../pokemon/staravia/">Staravia</a> — Lv. 56</li><li><a href="../../pokemon/furret/">Furret</a> — Lv. 58</li><li><a href="../../pokemon/pidgeotto/">Pidgeotto</a> — Lv. 55</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 55</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 2</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 2</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 3</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 58</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 60</li><li><a href="../../pokemon/zigzagoon/">Zigzagoon</a> — Lv. 48</li><li><a href="../../pokemon/bidoof/">Bidoof</a> — Lv. 48</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 48</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 48</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 48</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 48</li><li><a href="../../pokemon/luxio/">Luxio</a> — Lv. 56</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 58</li><li><a href="../../pokemon/noctowl/">Noctowl</a> — Lv. 55</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 55</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Staraptor</li><li>Bibarel</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 261<span class="rw-diff-arrow">→</span>264</li><li>Name: Poochyena<span class="rw-diff-arrow">→</span>Linoone</li><li>Slug: poochyena<span class="rw-diff-arrow">→</span>linoone</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Furret</li><li>Skiploom</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `111`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-109/"><span class="rw-record-nav__label">← Rock Tunnel</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-120/"><span class="rw-record-nav__label">Route 10 →</span></a>
</nav>
