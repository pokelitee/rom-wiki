# Seafoam Islands

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>77</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Seafoam Islands](../locations/header-455.md) | `header-455` | 203 | `D11R0104` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–60 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 58 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 56 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/225.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 56–58 | 5% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–60 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 58 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 56 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/225.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 56–58 | 5% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–60 | 25% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> | 58 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/99.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kingler](../pokemon/kingler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/364.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sealeo](../pokemon/sealeo.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--water">Water</span></span> | 56 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/221.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Piloswine](../pokemon/piloswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/362.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Glalie](../pokemon/glalie.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--rock">Rock</span></span> | 57 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/225.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/215.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Sneasel](../pokemon/sneasel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> | 57 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 56–58 | 5% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/87.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dewgong](../pokemon/dewgong.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ice">Ice</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/461.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weavile](../pokemon/weavile.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--ice">Ice</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/473.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mamoswine](../pokemon/mamoswine.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--ground">Ground</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/225.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Delibird](../pokemon/delibird.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/124.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Jynx](../pokemon/jynx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ice">Ice</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 31</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 34</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 36</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 35</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 36</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 34</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 36</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 31</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 32</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 58</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 60</li><li><a href="../../pokemon/sealeo/">Sealeo</a> — Lv. 56</li><li><a href="../../pokemon/piloswine/">Piloswine</a> — Lv. 57</li><li><a href="../../pokemon/glalie/">Glalie</a> — Lv. 57</li><li><a href="../../pokemon/kingler/">Kingler</a> — Lv. 57</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 56</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 58</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 56</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 57</li><li><a href="../../pokemon/sneasel/">Sneasel</a> — Lv. 57</li><li><a href="../../pokemon/delibird/">Delibird</a> — Lv. 57</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 31</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 34</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 36</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 35</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 36</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 34</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 36</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 31</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 32</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 58</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 60</li><li><a href="../../pokemon/sealeo/">Sealeo</a> — Lv. 56</li><li><a href="../../pokemon/piloswine/">Piloswine</a> — Lv. 57</li><li><a href="../../pokemon/glalie/">Glalie</a> — Lv. 57</li><li><a href="../../pokemon/kingler/">Kingler</a> — Lv. 57</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 56</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 58</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 56</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 57</li><li><a href="../../pokemon/sneasel/">Sneasel</a> — Lv. 57</li><li><a href="../../pokemon/delibird/">Delibird</a> — Lv. 57</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 31</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 34</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 36</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 35</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 36</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 34</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 36</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 31</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 32</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 58</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 60</li><li><a href="../../pokemon/sealeo/">Sealeo</a> — Lv. 56</li><li><a href="../../pokemon/piloswine/">Piloswine</a> — Lv. 57</li><li><a href="../../pokemon/glalie/">Glalie</a> — Lv. 57</li><li><a href="../../pokemon/kingler/">Kingler</a> — Lv. 57</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 56</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 58</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 56</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 57</li><li><a href="../../pokemon/sneasel/">Sneasel</a> — Lv. 57</li><li><a href="../../pokemon/delibird/">Delibird</a> — Lv. 57</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 31</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 32</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/seel/">Seel</a> — Lv. 34</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 36</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 35</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 36</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 34</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 36</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 31</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 32</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 58</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 60</li><li><a href="../../pokemon/sealeo/">Sealeo</a> — Lv. 56</li><li><a href="../../pokemon/piloswine/">Piloswine</a> — Lv. 57</li><li><a href="../../pokemon/glalie/">Glalie</a> — Lv. 57</li><li><a href="../../pokemon/kingler/">Kingler</a> — Lv. 57</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 56</li><li><a href="../../pokemon/dewgong/">Dewgong</a> — Lv. 58</li><li><a href="../../pokemon/jynx/">Jynx</a> — Lv. 56</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 57</li><li><a href="../../pokemon/sneasel/">Sneasel</a> — Lv. 57</li><li><a href="../../pokemon/delibird/">Delibird</a> — Lv. 57</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Weavile</li><li>Mamoswine</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Jynx</li><li>Delibird</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `77`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-076/"><span class="rw-record-nav__label">← Seafoam Islands</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-078/"><span class="rw-record-nav__label">Seafoam Islands →</span></a>
</nav>
