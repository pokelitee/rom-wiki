# Route 46

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>68</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 46](../locations/header-048.md) | 48 | 194 | `R46` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spoink](../pokemon/spoink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swablu](../pokemon/swablu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 5 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 (5%); 6 (5%) | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 5 (9%); 6 (1%) | 10% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spearow](../pokemon/spearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spoink](../pokemon/spoink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Swablu](../pokemon/swablu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 5 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 (5%); 6 (5%) | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Phanpy](../pokemon/phanpy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 5 (9%); 6 (1%) | 10% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Numel](../pokemon/numel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span><span class="rw-type rw-type--ground">Ground</span></span> | 4 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Spoink](../pokemon/spoink.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rattata](../pokemon/rattata.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Clefairy](../pokemon/clefairy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 4 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Jigglypuff](../pokemon/jigglypuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 5 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Houndour](../pokemon/houndour.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span><span class="rw-type rw-type--fire">Fire</span></span> | 5 (5%); 6 (5%) | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 5 (9%); 6 (1%) | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Geodude](../pokemon/geodude.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Igglybuff](../pokemon/igglybuff.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Rattata — Lv. 2</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Geodude — Lv. 2</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Phanpy — Lv. 6</li><li>Jigglypuff — Lv. 6</li><li>Rattata — Lv. 4</li><li>Spoink — Lv. 4</li><li>Swablu — Lv. 4</li><li>Numel — Lv. 5</li><li>Spearow — Lv. 4</li><li>Geodude — Lv. 4</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 6</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 5</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Rattata — Lv. 2</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Geodude — Lv. 2</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Phanpy — Lv. 6</li><li>Jigglypuff — Lv. 6</li><li>Rattata — Lv. 4</li><li>Spoink — Lv. 4</li><li>Swablu — Lv. 4</li><li>Numel — Lv. 5</li><li>Spearow — Lv. 4</li><li>Geodude — Lv. 4</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 6</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 5</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Rattata — Lv. 2</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 2</li><li>Geodude — Lv. 3</li><li>Spearow — Lv. 3</li><li>Rattata — Lv. 4</li><li>Geodude — Lv. 2</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Phanpy — Lv. 6</li><li>Jigglypuff — Lv. 6</li><li>Rattata — Lv. 4</li><li>Spoink — Lv. 4</li><li>Swablu — Lv. 4</li><li>Numel — Lv. 5</li><li>Spearow — Lv. 4</li><li>Geodude — Lv. 4</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 6</li><li>Phanpy — Lv. 5</li><li>Jigglypuff — Lv. 5</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">9 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 3</li><li>Rattata — Lv. 4</li><li>Rattata — Lv. 2</li><li>Geodude — Lv. 3</li><li>Rattata — Lv. 2</li><li>Geodude — Lv. 3</li><li>Geodude — Lv. 3</li><li>Rattata — Lv. 4</li><li>Geodude — Lv. 2</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Houndour — Lv. 6</li><li>Shinx — Lv. 6</li><li>Rattata — Lv. 4</li><li>Spoink — Lv. 4</li><li>Clefairy — Lv. 4</li><li>Jigglypuff — Lv. 5</li><li>Numel — Lv. 4</li><li>Geodude — Lv. 4</li><li>Shinx — Lv. 5</li><li>Houndour — Lv. 6</li><li>Houndour — Lv. 5</li><li>Shinx — Lv. 5</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Fearow</li><li>Graveler</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Igglybuff</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `68`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-067/"><span class="rw-record-nav__label">← Route 45</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-071/"><span class="rw-record-nav__label">Route 47 →</span></a>
</nav>
