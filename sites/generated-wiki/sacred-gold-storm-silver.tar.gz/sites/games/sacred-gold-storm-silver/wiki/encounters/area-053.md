# Mt. Mortar

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>53</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Mt. Mortar](../locations/header-119.md) | `header-119` | 216 | `D38R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/307.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32–33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31–33 | 10% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/307.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32–33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31–33 | 10% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/75.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/42.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33–34 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/111.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/305.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/307.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32–33 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31–33 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20–35 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/184.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Azumarill](../pokemon/azumarill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35 | 5% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30 | 55% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 30 | 45% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/339.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/119.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/340.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 15% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/338.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/118.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/112.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/308.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/298.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Azurill](../pokemon/azurill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 33</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 33</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 34</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 33</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 33</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 31</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 33</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 33</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 33</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 34</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 33</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 33</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 31</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 33</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 33</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 33</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 34</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 33</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 33</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 31</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 33</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/machop/">Machop</a> — Lv. 14</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 13</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 15</li><li><a href="../../pokemon/geodude/">Geodude</a> — Lv. 14</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 16</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 33</li><li><a href="../../pokemon/rhyhorn/">Rhyhorn</a> — Lv. 33</li><li><a href="../../pokemon/lairon/">Lairon</a> — Lv. 33</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 34</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 34</li><li><a href="../../pokemon/golbat/">Golbat</a> — Lv. 33</li><li><a href="../../pokemon/graveler/">Graveler</a> — Lv. 33</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 31</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 32</li><li><a href="../../pokemon/meditite/">Meditite</a> — Lv. 33</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 15–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10–20</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 15–25</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 15–25</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 15–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/marill/">Marill</a> — Lv. 35</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 30</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 30–35</li><li><a href="../../pokemon/azumarill/">Azumarill</a> — Lv. 35</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 30</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 30</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 30</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 30</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/goldeen/">Goldeen</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 40</li><li><a href="../../pokemon/seaking/">Seaking</a> — Lv. 40</li><li><a href="../../pokemon/barboach/">Barboach</a> — Lv. 40</li><li><a href="../../pokemon/whiscash/">Whiscash</a> — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Rhydon</li><li>Medicham</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 183<span class="rw-diff-arrow">→</span>338</li><li>Name: Marill<span class="rw-diff-arrow">→</span>Solrock</li><li>Slug: marill<span class="rw-diff-arrow">→</span>solrock</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Azurill</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `53`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-107/"><span class="rw-record-nav__label">← Mt. Moon</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-054/"><span class="rw-record-nav__label">Mt. Mortar →</span></a>
</nav>
