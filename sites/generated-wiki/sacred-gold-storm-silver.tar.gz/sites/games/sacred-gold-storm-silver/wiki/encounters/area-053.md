# Mt. Mortar

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>53</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Mt. Mortar](../locations/header-119.md) | 119 | 216 | `D38R0101` |

## Walking (Morning)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 33 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 33 | 1% |

## Walking (Day)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 33 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 33 | 1% |

## Walking (Night)

Encounter rate: 10

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Graveler](../pokemon/graveler.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--ground">Ground</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Golbat](../pokemon/golbat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span><span class="rw-type rw-type--flying">Flying</span></span> | 34 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhyhorn](../pokemon/rhyhorn.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Lairon](../pokemon/lairon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--steel">Steel</span><span class="rw-type rw-type--rock">Rock</span></span> | 33 | 10% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Meditite](../pokemon/meditite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 33 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 31 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 32 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 33 | 1% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 60% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Azumarill](../pokemon/azumarill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35 | 5% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–35 | 4% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 35 | 1% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 20 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30 | 55% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 30 | 45% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Barboach](../pokemon/barboach.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 30% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Seaking](../pokemon/seaking.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Whiscash](../pokemon/whiscash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 40 | 15% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Solrock](../pokemon/solrock.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--rock">Rock</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Goldeen](../pokemon/goldeen.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Rhydon](../pokemon/rhydon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span><span class="rw-type rw-type--rock">Rock</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Medicham](../pokemon/medicham.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Azurill](../pokemon/azurill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 14</li><li>Marill — Lv. 15</li><li>Zubat — Lv. 13</li><li>Machop — Lv. 14</li><li>Zubat — Lv. 15</li><li>Zubat — Lv. 13</li><li>Zubat — Lv. 15</li><li>Geodude — Lv. 14</li><li>Rattata — Lv. 16</li><li>Rattata — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marill — Lv. 32</li><li>Marill — Lv. 33</li><li>Rhyhorn — Lv. 33</li><li>Lairon — Lv. 33</li><li>Golbat — Lv. 34</li><li>Graveler — Lv. 34</li><li>Golbat — Lv. 33</li><li>Graveler — Lv. 33</li><li>Marill — Lv. 31</li><li>Marill — Lv. 32</li><li>Meditite — Lv. 32</li><li>Meditite — Lv. 33</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 14</li><li>Marill — Lv. 15</li><li>Zubat — Lv. 13</li><li>Machop — Lv. 14</li><li>Zubat — Lv. 15</li><li>Zubat — Lv. 13</li><li>Zubat — Lv. 15</li><li>Geodude — Lv. 14</li><li>Rattata — Lv. 16</li><li>Rattata — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marill — Lv. 32</li><li>Marill — Lv. 33</li><li>Rhyhorn — Lv. 33</li><li>Lairon — Lv. 33</li><li>Golbat — Lv. 34</li><li>Graveler — Lv. 34</li><li>Golbat — Lv. 33</li><li>Graveler — Lv. 33</li><li>Marill — Lv. 31</li><li>Marill — Lv. 32</li><li>Meditite — Lv. 32</li><li>Meditite — Lv. 33</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 14</li><li>Marill — Lv. 15</li><li>Zubat — Lv. 13</li><li>Machop — Lv. 14</li><li>Zubat — Lv. 15</li><li>Zubat — Lv. 13</li><li>Zubat — Lv. 15</li><li>Geodude — Lv. 14</li><li>Rattata — Lv. 16</li><li>Rattata — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marill — Lv. 32</li><li>Marill — Lv. 33</li><li>Rhyhorn — Lv. 33</li><li>Lairon — Lv. 33</li><li>Golbat — Lv. 34</li><li>Graveler — Lv. 34</li><li>Golbat — Lv. 33</li><li>Graveler — Lv. 33</li><li>Marill — Lv. 31</li><li>Marill — Lv. 32</li><li>Meditite — Lv. 32</li><li>Meditite — Lv. 33</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li>Geodude — Lv. 14</li><li>Marill — Lv. 15</li><li>Zubat — Lv. 13</li><li>Machop — Lv. 14</li><li>Zubat — Lv. 15</li><li>Zubat — Lv. 13</li><li>Zubat — Lv. 15</li><li>Geodude — Lv. 14</li><li>Rattata — Lv. 16</li><li>Rattata — Lv. 14</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Marill — Lv. 32</li><li>Marill — Lv. 33</li><li>Rhyhorn — Lv. 33</li><li>Lairon — Lv. 33</li><li>Golbat — Lv. 34</li><li>Graveler — Lv. 34</li><li>Golbat — Lv. 33</li><li>Graveler — Lv. 33</li><li>Marill — Lv. 31</li><li>Marill — Lv. 32</li><li>Meditite — Lv. 32</li><li>Meditite — Lv. 33</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 15–25</li><li>Goldeen — Lv. 10–20</li><li>Seaking — Lv. 15–25</li><li>Seaking — Lv. 15–25</li><li>Goldeen — Lv. 15–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Marill — Lv. 35</li><li>Marill — Lv. 30</li><li>Marill — Lv. 30–35</li><li>Azumarill — Lv. 35</li><li>Marill — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Magikarp — Lv. 10</li><li>Goldeen — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Goldeen — Lv. 20</li><li>Magikarp — Lv. 20</li><li>Goldeen — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li>Goldeen — Lv. 30</li><li>Barboach — Lv. 30</li><li>Barboach — Lv. 30</li><li>Goldeen — Lv. 30</li><li>Goldeen — Lv. 30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">4 entries removed</p><ul class="rw-comparison-list"><li>Seaking — Lv. 40</li><li>Magikarp — Lv. 40</li><li>Goldeen — Lv. 40</li><li>Magikarp — Lv. 40</li></ul><p class="rw-comparison-count">4 entries added</p><ul class="rw-comparison-list"><li>Whiscash — Lv. 40</li><li>Seaking — Lv. 40</li><li>Barboach — Lv. 40</li><li>Whiscash — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Makuhita</li><li>Absol</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Rhydon</li><li>Medicham</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 183<span class="rw-diff-arrow">→</span>338</li><li>Name: Marill<span class="rw-diff-arrow">→</span>Solrock</li><li>Slug: marill<span class="rw-diff-arrow">→</span>solrock</li></ul></li><li>Night Fishing: Goldeen<details><summary>Exact data</summary><code>{&quot;id&quot;:118,&quot;name&quot;:&quot;Goldeen&quot;,&quot;slug&quot;:&quot;goldeen&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Chingling</li><li>Bronzor</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Azurill</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `53`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-107/"><span class="rw-record-nav__label">← Mt. Moon</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-054/"><span class="rw-record-nav__label">Mt. Mortar →</span></a>
</nav>
