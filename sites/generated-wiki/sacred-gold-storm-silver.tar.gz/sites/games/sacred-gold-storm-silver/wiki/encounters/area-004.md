# Route 31

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>4</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 31](../locations/header-035.md) | `header-035` | 179 | `R31` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 6 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 7 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 8 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/14.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kakuna](../pokemon/kakuna.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 10 | 1% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 1% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/265.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wurmple](../pokemon/wurmple.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 6 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 7 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 8 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/266.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Silcoon](../pokemon/silcoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/268.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Cascoon](../pokemon/cascoon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 10 | 2% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/167.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 6 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 6 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/403.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Shinx](../pokemon/shinx.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/63.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Abra](../pokemon/abra.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/177.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Natu](../pokemon/natu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span><span class="rw-type rw-type--flying">Flying</span></span> | 7 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 7 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 8 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/11.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Metapod](../pokemon/metapod.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/14.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kakuna](../pokemon/kakuna.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 8 | 4% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/267.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beautifly](../pokemon/beautifly.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 10 | 1% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/269.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dustox](../pokemon/dustox.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 1% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/183.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Marill](../pokemon/marill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/283.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Surskit](../pokemon/surskit.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 35% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/284.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Masquerain](../pokemon/masquerain.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--water">Water</span></span> | 25–35 | 5% |

## Old Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 5–15 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/79.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowpoke](../pokemon/slowpoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 5–15 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/349.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Feebas](../pokemon/feebas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 5–15 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/79.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Slowpoke](../pokemon/slowpoke.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/349.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Feebas](../pokemon/feebas.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 80% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/129.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magikarp](../pokemon/magikarp.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 20% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/12.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Butterfree](../pokemon/butterfree.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/15.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Beedrill](../pokemon/beedrill.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/406.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Budew](../pokemon/budew.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |

## Hack changes

<details markdown="1">
<summary>6 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 10</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 6</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 7</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 7</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 7</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/silcoon/">Silcoon</a> — Lv. 8</li><li><a href="../../pokemon/cascoon/">Cascoon</a> — Lv. 8</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 7</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 8</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li></ul><p class="rw-comparison-count">11 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 10</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 6</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 7</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 7</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 7</li><li><a href="../../pokemon/wurmple/">Wurmple</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/silcoon/">Silcoon</a> — Lv. 8</li><li><a href="../../pokemon/cascoon/">Cascoon</a> — Lv. 8</li><li><a href="../../pokemon/budew/">Budew</a> — Lv. 7</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 8</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/pidgey/">Pidgey</a> — Lv. 3</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 4</li><li><a href="../../pokemon/caterpie/">Caterpie</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 5</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/butterfree/">Butterfree</a> — Lv. 10</li><li><a href="../../pokemon/beedrill/">Beedrill</a> — Lv. 10</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 6</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 7</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 7</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 7</li><li><a href="../../pokemon/ledyba/">Ledyba</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 8</li><li><a href="../../pokemon/kakuna/">Kakuna</a> — Lv. 8</li><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 7</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 8</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 5</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 3</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 3</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 3</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/hoothoot/">Hoothoot</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/beautifly/">Beautifly</a> — Lv. 10</li><li><a href="../../pokemon/dustox/">Dustox</a> — Lv. 10</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 6</li><li><a href="../../pokemon/natu/">Natu</a> — Lv. 7</li><li><a href="../../pokemon/shinx/">Shinx</a> — Lv. 7</li><li><a href="../../pokemon/abra/">Abra</a> — Lv. 7</li><li><a href="../../pokemon/spinarak/">Spinarak</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/metapod/">Metapod</a> — Lv. 8</li><li><a href="../../pokemon/kakuna/">Kakuna</a> — Lv. 8</li><li><a href="../../pokemon/exeggcute/">Exeggcute</a> — Lv. 7</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 8</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 32</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10–20</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 15–25</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 15–25</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 15–25</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/masquerain/">Masquerain</a> — Lv. 25–35</li><li><a href="../../pokemon/surskit/">Surskit</a> — Lv. 25–30</li><li><a href="../../pokemon/masquerain/">Masquerain</a> — Lv. 25–35</li><li><a href="../../pokemon/surskit/">Surskit</a> — Lv. 25–30</li><li><a href="../../pokemon/marill/">Marill</a> — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>50</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/feebas/">Feebas</a> — Lv. 5–15</li><li><a href="../../pokemon/slowpoke/">Slowpoke</a> — Lv. 5–15</li><li><a href="../../pokemon/slowpoke/">Slowpoke</a> — Lv. 5–15</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 5–15</li><li><a href="../../pokemon/feebas/">Feebas</a> — Lv. 5–15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/feebas/">Feebas</a> — Lv. 25–30</li><li><a href="../../pokemon/feebas/">Feebas</a> — Lv. 25–30</li><li><a href="../../pokemon/slowpoke/">Slowpoke</a> — Lv. 25–30</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 25–30</li><li><a href="../../pokemon/feebas/">Feebas</a> — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Butterfree</li><li>Beedrill</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 16<span class="rw-diff-arrow">→</span>165</li><li>Name: Pidgey<span class="rw-diff-arrow">→</span>Ledyba</li><li>Slug: pidgey<span class="rw-diff-arrow">→</span>ledyba</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Budew</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `4`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-003/"><span class="rw-record-nav__label">← Route 30</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-008/"><span class="rw-record-nav__label">Route 32 →</span></a>
</nav>
