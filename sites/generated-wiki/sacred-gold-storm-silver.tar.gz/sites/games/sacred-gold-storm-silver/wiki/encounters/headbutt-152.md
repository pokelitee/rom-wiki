# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Route 48](../locations/header-152.md) | `header-152` | `R48` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 15–16 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 15–16 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 15–16 | 20% |

## Rare trees

=== "Sacred Gold"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/167.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Spinarak](../pokemon/spinarak.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 17–18 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 17–18 | 20% |

=== "Storm Silver"

    | Pokémon | Type | Levels | Chance |
    | ------- | ---- | -----: | -----: |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 50% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/165.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ledyba](../pokemon/ledyba.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–18 | 30% |
    | <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 17–18 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (82, 325), (82, 324) |
| 1 | Regular | (75, 335), (76, 335) |
| 2 | Regular | (82, 339), (82, 338) |
| 3 | Regular | (106, 335) |
| 4 | Regular | (106, 347), (106, 346) |
| 5 | Regular | (82, 335), (82, 334), (82, 333) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `152`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-151/"><span class="rw-record-nav__label">← Headbutt encounters — Route 47</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-174/"><span class="rw-record-nav__label">Headbutt encounters — Safari Zone Gate →</span></a>
</nav>
