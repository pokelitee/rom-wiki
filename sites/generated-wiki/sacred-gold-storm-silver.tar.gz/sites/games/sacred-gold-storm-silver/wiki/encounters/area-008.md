# Route 32

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>8</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 32](../locations/header-036.md) | `header-036` | 180 | `R32` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/179.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mareep](../pokemon/mareep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/290.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nincada](../pokemon/nincada.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 11–12 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 12 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/179.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mareep](../pokemon/mareep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/290.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nincada](../pokemon/nincada.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/187.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoppip](../pokemon/hoppip.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 11–12 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 12 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/179.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Mareep](../pokemon/mareep.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 10 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/290.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nincada](../pokemon/nincada.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 10–11 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/81.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magnemite](../pokemon/magnemite.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> | 11–12 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/23.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Ekans](../pokemon/ekans.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--poison">Poison</span></span> | 11 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/425.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifloon](../pokemon/drifloon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> | 12 | 5% |

## Surf

Encounter rate: 15

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/194.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Wooper](../pokemon/wooper.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–30 | 60% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/195.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Quagsire](../pokemon/quagsire.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--ground">Ground</span></span> | 25–35 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/73.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 25–35 | 5% |

## Old Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 10–15 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 10–15 | 45% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/211.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 10–15 | 15% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 25–30 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/54.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Psyduck](../pokemon/psyduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 25–30 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/211.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 25–35 | 30% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/211.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Qwilfish](../pokemon/qwilfish.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 40 | 40% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/73.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacruel](../pokemon/tentacruel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> | 40 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/55.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Golduck](../pokemon/golduck.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 40 | 30% |

## Special encounters

### Land swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/69.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Bellsprout](../pokemon/bellsprout.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> |

### Surf swarm

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/72.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tentacool](../pokemon/tentacool.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--poison">Poison</span></span> |

### Hoenn Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/180.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Flaaffy](../pokemon/flaaffy.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/82.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Magneton](../pokemon/magneton.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--steel">Steel</span></span> |

### Sinnoh Sound radio

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/425.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Drifloon](../pokemon/drifloon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ghost">Ghost</span><span class="rw-type rw-type--flying">Flying</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/417.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pachirisu](../pokemon/pachirisu.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> |

## Hack changes

<details markdown="1">
<summary>7 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 10</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 10</li><li><a href="../../pokemon/ekans/">Ekans</a> — Lv. 11</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 11</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 10</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 10</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 11</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 11</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 10</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 10</li><li><a href="../../pokemon/ekans/">Ekans</a> — Lv. 11</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 11</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 10</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 10</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 11</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 11</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 4</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 6</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 10</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 10</li><li><a href="../../pokemon/ekans/">Ekans</a> — Lv. 11</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 11</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 10</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 10</li><li><a href="../../pokemon/pachirisu/">Pachirisu</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 11</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 11</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 4</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 6</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 6</li><li><a href="../../pokemon/zubat/">Zubat</a> — Lv. 4</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 6</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 6</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/drifloon/">Drifloon</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 10</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 10</li><li><a href="../../pokemon/ekans/">Ekans</a> — Lv. 11</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 11</li><li><a href="../../pokemon/mareep/">Mareep</a> — Lv. 10</li><li><a href="../../pokemon/bellsprout/">Bellsprout</a> — Lv. 10</li><li><a href="../../pokemon/drifloon/">Drifloon</a> — Lv. 12</li><li><a href="../../pokemon/magnemite/">Magnemite</a> — Lv. 12</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 11</li><li><a href="../../pokemon/nincada/">Nincada</a> — Lv. 11</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 36</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 15–25</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 15–25</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 15–25</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10–20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 25–35</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 25–30</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 25–35</li><li><a href="../../pokemon/quagsire/">Quagsire</a> — Lv. 25–35</li><li><a href="../../pokemon/wooper/">Wooper</a> — Lv. 25–30</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">2 changes</p><ul class="rw-comparison-list"><li>Rate: 25<span class="rw-diff-arrow">→</span>50</li><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 10–15</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 10–15</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 10–15</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 10–15</li><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 10–15</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 25–30</li><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 25–30</li><li><a href="../../pokemon/psyduck/">Psyduck</a> — Lv. 25–30</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 25–30</li><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 25–35</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 40</li><li><a href="../../pokemon/tentacool/">Tentacool</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 40</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 40</li><li><a href="../../pokemon/tentacruel/">Tentacruel</a> — Lv. 40</li><li><a href="../../pokemon/qwilfish/">Qwilfish</a> — Lv. 40</li><li><a href="../../pokemon/golduck/">Golduck</a> — Lv. 40</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">4 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Qwilfish<details><summary>Exact data</summary><code>{&quot;id&quot;:211,&quot;name&quot;:&quot;Qwilfish&quot;,&quot;slug&quot;:&quot;qwilfish&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Flaaffy</li><li>Magneton</li></ul></li><li>Night Fishing: Tentacool<details><summary>Exact data</summary><code>{&quot;id&quot;:72,&quot;name&quot;:&quot;Tentacool&quot;,&quot;slug&quot;:&quot;tentacool&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Pachirisu</li><li>Drifloon</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `8`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-004/"><span class="rw-record-nav__label">← Route 31</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-017/"><span class="rw-record-nav__label">Route 33 →</span></a>
</nav>
