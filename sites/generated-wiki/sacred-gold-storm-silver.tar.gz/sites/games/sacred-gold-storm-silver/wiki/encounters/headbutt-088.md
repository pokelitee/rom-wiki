# Headbutt encounters { #headbutt-encounters }

## Map headers

| Location | Map ID | Internal ID |
| -------- | ------ | ----------- |
| [Lake of Rage](../locations/header-088.md) | `header-088` | `T29` |

## Common trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 14–16 | 50% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/204.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Pineco](../pokemon/pineco.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span></span> | 14–16 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 14–16 | 20% |

## Rare trees

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/163.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Hoothoot](../pokemon/hoothoot.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 17–19 | 65% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/48.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Venonat](../pokemon/venonat.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--bug">Bug</span><span class="rw-type rw-type--poison">Poison</span></span> | 17–19 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/102.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Exeggcute](../pokemon/exeggcute.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 17–19 | 20% |

## Secret trees

—

## Tree groups

| Group | Kind | Coordinates |
| ----: | ---- | ----------- |
| 0 | Regular | (552, 52), (552, 53), (553, 53) |
| 1 | Regular | (552, 62), (553, 62), (553, 61) |
| 2 | Regular | (556, 63), (556, 62) |
| 3 | Regular | (556, 61), (556, 60) |
| 4 | Regular | (546, 68), (547, 68) |
| 5 | Regular | (548, 68), (549, 68) |
| 6 | Regular | (543, 80), (543, 79), (544, 79) |
| 7 | Regular | (523, 89), (523, 88) |
| 8 | Regular | (512, 91), (513, 91) |
| 9 | Regular | (508, 91), (509, 91) |
| 10 | Regular | (506, 91), (507, 91) |
| 11 | Regular | (500, 85), (501, 85), (501, 84), (500, 83), (501, 83) |
| 12 | Regular | (494, 81), (495, 81) |
| 13 | Regular | (488, 75), (489, 75) |
| 14 | Regular | (487, 74) |
| 15 | Regular | (487, 73), (487, 72) |
| 16 | Regular | (488, 71), (489, 71) |
| 17 | Regular | (504, 33), (505, 33) |
| 18 | Regular | (506, 33), (507, 33) |
| 19 | Regular | (538, 35), (539, 35) |
| 20 | Regular | (540, 35), (541, 35) |
| 21 | Regular | (542, 35), (543, 35) |

## Hack changes

<details markdown="1">
<summary>Comparison notes</summary>

Verified unchanged from **heartgold-us / soulsilver-us** for all compared fields.

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/2/5/2` member `88`.
The Headbutt member is keyed directly by map-header ID and stores all three slot pools plus tree-group coordinates.
The trainer ID selects the common or rare regular-tree pool; secret groups always use the secret pool.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../headbutt-078/"><span class="rw-record-nav__label">← Headbutt encounters — Ecruteak City</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../headbutt-090/"><span class="rw-record-nav__label">Headbutt encounters — Mt. Silver →</span></a>
</nav>
