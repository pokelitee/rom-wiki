# Route 22

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>129</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a>, <a href="#surf">Surf</a>, <a href="#old-rod">Old Rod</a>, <a href="#good-rod">Good Rod</a>, <a href="#super-rod">Super Rod</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 22](../locations/header-027.md) | `header-027` | 170 | `R22` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–59 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 54–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/57.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 55–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 59 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–59 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 54–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/57.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 55–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 59 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/22.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Fearow](../pokemon/fearow.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/85.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dodrio](../pokemon/dodrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--flying">Flying</span></span> | 56–59 | 30% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 54–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/57.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Primeape](../pokemon/primeape.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span></span> | 55–57 | 15% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/78.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Rapidash](../pokemon/rapidash.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fire">Fire</span></span> | 59 | 10% |

## Surf

Encounter rate: 10

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–55 | 64% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/418.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Buizel](../pokemon/buizel.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 30–55 | 36% |

## Old Rod

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–70 | 100% |

## Good Rod

Encounter rate: 50

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 1–70 | 100% |

## Super Rod

Encounter rate: 75

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 55 | 95% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/186.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Politoed](../pokemon/politoed.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> | 55–60 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/20.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

**Surf swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/60.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwag](../pokemon/poliwag.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/61.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Poliwhirl](../pokemon/poliwhirl.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/271.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Lombre](../pokemon/lombre.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--water">Water</span><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/274.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Nuzleaf](../pokemon/nuzleaf.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--dark">Dark</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>7 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 58</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 59</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 55</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 59</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 57</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 57</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 57</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 58</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 59</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 55</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 59</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 57</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 57</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 57</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">10 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/spearow/">Spearow</a> — Lv. 3</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 7</li><li><a href="../../pokemon/doduo/">Doduo</a> — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 58</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 59</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 55</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 59</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 57</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 57</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 57</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 7</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 5</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 3</li><li><a href="../../pokemon/ponyta/">Ponyta</a> — Lv. 6</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 7</li><li><a href="../../pokemon/rattata/">Rattata</a> — Lv. 4</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 58</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 59</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 54</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 55</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/rapidash/">Rapidash</a> — Lv. 59</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 56</li><li><a href="../../pokemon/dodrio/">Dodrio</a> — Lv. 57</li><li><a href="../../pokemon/raticate/">Raticate</a> — Lv. 57</li><li><a href="../../pokemon/primeape/">Primeape</a> — Lv. 57</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Surf</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 5</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 10</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 30–55</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 30–55</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 30–55</li><li><a href="../../pokemon/buizel/">Buizel</a> — Lv. 30–55</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 30–55</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Old Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 10</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 10</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Good Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 20</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 20</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 1–70</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Super Rod</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">5 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/poliwag/">Poliwag</a> — Lv. 40</li><li><a href="../../pokemon/magikarp/">Magikarp</a> — Lv. 40</li></ul><p class="rw-comparison-count">5 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 55</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 55</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 55</li><li><a href="../../pokemon/poliwhirl/">Poliwhirl</a> — Lv. 55</li><li><a href="../../pokemon/politoed/">Politoed</a> — Lv. 55–60</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">5 changes</p><ul class="rw-comparison-list"><li>Fishing Swarm: Magikarp<details><summary>Exact data</summary><code>{&quot;id&quot;:129,&quot;name&quot;:&quot;Magikarp&quot;,&quot;slug&quot;:&quot;magikarp&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Linoone</li><li>Whismur</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Poliwhirl</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 19<span class="rw-diff-arrow">→</span>20</li><li>Name: Rattata<span class="rw-diff-arrow">→</span>Raticate</li><li>Slug: rattata<span class="rw-diff-arrow">→</span>raticate</li></ul></li><li>Night Fishing: Poliwag<details><summary>Exact data</summary><code>{&quot;id&quot;:60,&quot;name&quot;:&quot;Poliwag&quot;,&quot;slug&quot;:&quot;poliwag&quot;}</code></details><span class="rw-diff-arrow">→</span>—</li><li>Sinnoh Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Bidoof</li><li>Buizel</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Lombre</li><li>Nuzleaf</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `129`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-128/"><span class="rw-record-nav__label">← Route 21</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-130/"><span class="rw-record-nav__label">Route 24 →</span></a>
</nav>
