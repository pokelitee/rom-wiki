# Route 48

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>102</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Map ID | Name ID | Internal ID |
| -------- | ------ | ------: | ----------- |
| [Route 48](../locations/header-152.md) | `header-152` | 196 | `R48` |

## Walking (Morning)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 30 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |

## Walking (Day)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 30 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |

## Walking (Night)

Encounter rate: 25

| Pokémon | Type | Levels | Chance |
| ------- | ---- | -----: | -----: |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/114.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> | 31 | 20% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/50.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Diglett](../pokemon/diglett.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> | 30 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/44.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Gloom](../pokemon/gloom.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/70.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Weepinbell](../pokemon/weepinbell.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--poison">Poison</span></span> | 31 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/203.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Girafarig](../pokemon/girafarig.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span><span class="rw-type rw-type--psychic">Psychic</span></span> | 32 | 10% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/357.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tropius](../pokemon/tropius.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span><span class="rw-type rw-type--flying">Flying</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/359.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Absol](../pokemon/absol.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--dark">Dark</span></span> | 33 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/113.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Chansey](../pokemon/chansey.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/352.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Kecleon](../pokemon/kecleon.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 31–32 | 5% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/83.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Farfetch'd](../pokemon/farfetchd.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--fighting">Fighting</span><span class="rw-type rw-type--flying">Flying</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/465.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Tangrowth](../pokemon/tangrowth.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/51.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Dugtrio](../pokemon/dugtrio.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--ground">Ground</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><img class="rw-table-sprite" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iv/heartgold-soulsilver/440.png" alt="" loading="lazy" referrerpolicy="no-referrer">[Happiny](../pokemon/happiny.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

<details markdown="1">
<summary>3 fields changed</summary>

Compared with **heartgold-us / soulsilver-us**.

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 22</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 24</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 20</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 21</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 22</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 24</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 20</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 25</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 22</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 21</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 32</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 32</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 30</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 31</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 31</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 32</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 31</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 31</li><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 31</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 31</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 33</li><li><a href="../../pokemon/absol/">Absol</a> — Lv. 33</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 22</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 24</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 20</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 21</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 22</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 24</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 20</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 25</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 22</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 21</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 32</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 32</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 30</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 31</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 31</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 32</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 31</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 31</li><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 31</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 31</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 33</li><li><a href="../../pokemon/absol/">Absol</a> — Lv. 33</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 22</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 24</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 20</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 21</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 22</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 24</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 20</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 25</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 22</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 21</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 32</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 32</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 30</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 31</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 31</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 32</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 31</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 31</li><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 31</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 31</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 33</li><li><a href="../../pokemon/absol/">Absol</a> — Lv. 33</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">12 entries removed</p><ul class="rw-comparison-list"><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 22</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 24</li><li><a href="../../pokemon/hoppip/">Hoppip</a> — Lv. 20</li><li><a href="../../pokemon/fearow/">Fearow</a> — Lv. 21</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 22</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 24</li><li><a href="../../pokemon/tauros/">Tauros</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 25</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 22</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 20</li><li><a href="../../pokemon/growlithe/">Growlithe</a> — Lv. 21</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 32</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 32</li><li><a href="../../pokemon/diglett/">Diglett</a> — Lv. 30</li><li><a href="../../pokemon/gloom/">Gloom</a> — Lv. 31</li><li><a href="../../pokemon/weepinbell/">Weepinbell</a> — Lv. 31</li><li><a href="../../pokemon/girafarig/">Girafarig</a> — Lv. 32</li><li><a href="../../pokemon/tangela/">Tangela</a> — Lv. 31</li><li><a href="../../pokemon/farfetchd/">Farfetch&#x27;d</a> — Lv. 31</li><li><a href="../../pokemon/chansey/">Chansey</a> — Lv. 31</li><li><a href="../../pokemon/kecleon/">Kecleon</a> — Lv. 31</li><li><a href="../../pokemon/tropius/">Tropius</a> — Lv. 33</li><li><a href="../../pokemon/absol/">Absol</a> — Lv. 33</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Tangrowth</li><li>Dugtrio</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 128<span class="rw-diff-arrow">→</span>83</li><li>Name: Tauros<span class="rw-diff-arrow">→</span>Farfetch&#x27;d</li><li>Slug: tauros<span class="rw-diff-arrow">→</span>farfetchd</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Happiny</li></ul></li></ul></div>
</section>
</div>

</details>

---

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `102`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-071/"><span class="rw-record-nav__label">← Route 47</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-115/"><span class="rw-record-nav__label">Route 5 →</span></a>
</nav>
