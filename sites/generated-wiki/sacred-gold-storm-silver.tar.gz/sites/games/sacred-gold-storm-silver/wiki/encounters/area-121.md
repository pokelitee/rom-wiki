# Route 11

<section class="rw-encounter-summary">
<dl class="rw-summary__facts">
<div><dt>Area ID</dt><dd>121</dd></div>
<div><dt>Methods</dt><dd><a href="#walking-morning">Walking</a></dd></div>
<div><dt>Map headers</dt><dd><a href="#map-headers">1</a></dd></div>
</dl>
</section>

## Map headers

| Location | Header | Location name ID | Internal map |
| -------- | -----: | ----------------: | ------------ |
| [Route 11](../locations/header-019.md) | 19 | 159 | `R11` |

## Walking (Morning)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hypno](../pokemon/hypno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 (20%); 53 (14%); 54 (5%); 55 (1%) | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 10% |

## Walking (Day)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hypno](../pokemon/hypno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 (20%); 53 (14%); 54 (5%); 55 (1%) | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 10% |

## Walking (Night)

Encounter rate: 20

| Pokémon | Type | Level | Chance |
| ------- | ---- | ----: | -----: |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hypno](../pokemon/hypno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> | 52 (20%); 53 (14%); 54 (5%); 55 (1%) | 40% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Raticate](../pokemon/raticate.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 20% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Plusle](../pokemon/plusle.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Minun](../pokemon/minun.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span></span> | 50 (10%); 53 (5%) | 15% |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Linoone](../pokemon/linoone.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> | 52 | 10% |

## Special encounters

**Land swarm:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Hypno](../pokemon/hypno.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--psychic">Psychic</span></span> |

**Hoenn Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Luxray](../pokemon/luxray.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--electric">Electric</span><span class="rw-type rw-type--dark">Dark</span></span> |

**Sinnoh Sound radio:**

| Pokémon | Type |
| ------- | ---- |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Tangela](../pokemon/tangela.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--grass">Grass</span></span> |
| <span class="rw-cell-media"><span class="rw-table-sprite rw-table-sprite--empty" aria-hidden="true">—</span>[Munchlax](../pokemon/munchlax.md)</span> | <span class="rw-type-list"><span class="rw-type rw-type--normal">Normal</span></span> |

## Hack changes

Compared with **heartgold-us / soulsilver-us**.

<details markdown="1">
<summary>3 fields changed</summary>

<div class="rw-changes">
<section class="rw-change">
<p class="rw-change__field">Walking</p>
<div class="rw-change__value"><p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Magnemite — Lv. 15</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Hypno — Lv. 54</li><li>Hypno — Lv. 55</li><li>Plusle — Lv. 50</li><li>Minun — Lv. 50</li><li>Linoone — Lv. 52</li><li>Hypno — Lv. 53</li><li>Raticate — Lv. 52</li><li>Hypno — Lv. 52</li><li>Hypno — Lv. 53</li><li>Hypno — Lv. 54</li><li>Plusle — Lv. 53</li><li>Minun — Lv. 53</li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Walking Variants</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Day: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Magnemite — Lv. 15</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Hypno — Lv. 54</li><li>Hypno — Lv. 55</li><li>Plusle — Lv. 50</li><li>Minun — Lv. 50</li><li>Linoone — Lv. 52</li><li>Hypno — Lv. 53</li><li>Raticate — Lv. 52</li><li>Hypno — Lv. 52</li><li>Hypno — Lv. 53</li><li>Hypno — Lv. 54</li><li>Plusle — Lv. 53</li><li>Minun — Lv. 53</li></ul></li></ul></li><li>Morning: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Magnemite — Lv. 15</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Hypno — Lv. 54</li><li>Hypno — Lv. 55</li><li>Plusle — Lv. 50</li><li>Minun — Lv. 50</li><li>Linoone — Lv. 52</li><li>Hypno — Lv. 53</li><li>Raticate — Lv. 52</li><li>Hypno — Lv. 52</li><li>Hypno — Lv. 53</li><li>Hypno — Lv. 54</li><li>Plusle — Lv. 53</li><li>Minun — Lv. 53</li></ul></li></ul></li><li>Night: <p class="rw-comparison-count">1 change</p><ul class="rw-comparison-list"><li>Slots: <p class="rw-comparison-count">8 entries removed</p><ul class="rw-comparison-list"><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Magnemite — Lv. 15</li><li>Drowzee — Lv. 14</li><li>Rattata — Lv. 15</li><li>Hypno — Lv. 16</li><li>Drowzee — Lv. 16</li></ul><p class="rw-comparison-count">12 entries added</p><ul class="rw-comparison-list"><li>Hypno — Lv. 54</li><li>Hypno — Lv. 55</li><li>Plusle — Lv. 50</li><li>Minun — Lv. 50</li><li>Linoone — Lv. 52</li><li>Hypno — Lv. 53</li><li>Raticate — Lv. 52</li><li>Hypno — Lv. 52</li><li>Hypno — Lv. 53</li><li>Hypno — Lv. 54</li><li>Plusle — Lv. 53</li><li>Minun — Lv. 53</li></ul></li></ul></li></ul></div>
</section>
<section class="rw-change">
<p class="rw-change__field">Special</p>
<div class="rw-change__value"><p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Hoenn Radio: <p class="rw-comparison-count">2 entries removed</p><ul class="rw-comparison-list"><li>Plusle</li><li>Minun</li></ul><p class="rw-comparison-count">1 entry added</p><ul class="rw-comparison-list"><li>Luxray</li></ul></li><li>Land Swarm: <p class="rw-comparison-count">3 changes</p><ul class="rw-comparison-list"><li>Id: 96<span class="rw-diff-arrow">→</span>97</li><li>Name: Drowzee<span class="rw-diff-arrow">→</span>Hypno</li><li>Slug: drowzee<span class="rw-diff-arrow">→</span>hypno</li></ul></li><li>Sinnoh Radio: <p class="rw-comparison-count">1 entry removed</p><ul class="rw-comparison-list"><li>Shinx</li></ul><p class="rw-comparison-count">2 entries added</p><ul class="rw-comparison-list"><li>Tangela</li><li>Munchlax</li></ul></li></ul></div>
</section>
</div>

</details>

<details class="rw-source-details" markdown="1">
<summary>Data provenance</summary>

Source: exact ROM record from `a/0/3/7` member `121`.
Chance percentages are fixed engine weights applied by slot position; the ROM encounter records store rates, species, and levels.
Morning, day, and night walking lists and the radio, swarm, and fishing replacement species are distinct HGSS fields.

</details>

<nav class="rw-record-nav" aria-label="Wild encounter navigation">
<a class="rw-record-nav__link rw-record-nav__link--prev" href="../area-120/"><span class="rw-record-nav__label">← Route 10</span></a>
<a class="rw-record-nav__link rw-record-nav__link--next" href="../area-092/"><span class="rw-record-nav__label">Route 12 →</span></a>
</nav>
