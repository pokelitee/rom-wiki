# Data downloads

These deterministic gzip files contain the complete normalized datasets used to build this wiki. They include ROM-derived facts and PokéDB reference data, but never ROM or patch bytes.

| Dataset | Download | Records | Schema |
| ------- | -------- | ------: | -----: |
| Abilities | [abilities.json.gz](abilities.json.gz) | 123 | 4 |
| Abilities comparison | [comparisons/abilities.json.gz](comparisons/abilities.json.gz) | 123 | 1 |
| Wild Encounters comparison | [comparisons/encounters.json.gz](comparisons/encounters.json.gz) | 142 | 1 |
| Items comparison | [comparisons/items.json.gz](comparisons/items.json.gz) | 513 | 1 |
| Locations comparison | [comparisons/locations.json.gz](comparisons/locations.json.gz) | 540 | 1 |
| Moves comparison | [comparisons/moves.json.gz](comparisons/moves.json.gz) | 471 | 1 |
| Pokemon comparison | [comparisons/pokemon.json.gz](comparisons/pokemon.json.gz) | 508 | 1 |
| Trainers comparison | [comparisons/trainers.json.gz](comparisons/trainers.json.gz) | 737 | 1 |
| Wild Encounters | [encounters.json.gz](encounters.json.gz) | 142 | 3 |
| Items | [items.json.gz](items.json.gz) | 513 | 8 |
| Locations | [locations.json.gz](locations.json.gz) | 540 | 10 |
| Moves | [moves.json.gz](moves.json.gz) | 471 | 1 |
| Pokemon | [pokemon.json.gz](pokemon.json.gz) | 508 | 2 |
| Trainers | [trainers.json.gz](trainers.json.gz) | 737 | 6 |
| Types | [types.json.gz](types.json.gz) | 17 | 2 |

File sizes and SHA-256 checksums are listed in [the machine-readable manifest](manifest.json).
